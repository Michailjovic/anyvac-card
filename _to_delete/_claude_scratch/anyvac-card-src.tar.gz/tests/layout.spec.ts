import { test, expect, type Page } from "@playwright/test";

/**
 * docs/21 §5e — layout hardening regression tests, run against the mock HA
 * DOM harness (tests/harness/mock-ha.html). Deliberately narrow scope: these
 * cover the geometric regressions the layout-hardening pass (docs/21 §5a/§5b/
 * §5f) targets, not the whole card. See docs/21 for why jsdom is unusable
 * here (no layout engine) and why a real browser is required.
 */

interface MockConfig {
  width: number;
  height: number;
}

/** Minimal HA-shaped config/hass needed for a grid-mode render (`layout: {}`
 *  activates the profile-picking code path under test) — the exact shape was
 *  verified empirically against the real bundle, not guessed. */
async function mountCard(page: Page, opts: MockConfig): Promise<void> {
  await page.goto("/tests/harness/mock-ha.html");
  await page.waitForFunction(() => (window as any).__mockHaReady === true);
  await page.evaluate(async () => {
    await customElements.whenDefined("anyvac-card");
  });
  await page.evaluate(({ width, height }) => {
    const w = window as any;
    const card = document.createElement("anyvac-card") as any;
    const config = {
      type: "custom:anyvac-card",
      layout: {},
      vacuums: [
        { entity: "vacuum.my_roborock", name: "Roborock", color: "green", rooms: [], clean_action: { type: "native" } },
      ],
    };
    const hass = {
      states: {
        "vacuum.my_roborock": {
          entity_id: "vacuum.my_roborock",
          state: "docked",
          attributes: { friendly_name: "Roborock", battery_level: 80 },
          last_changed: new Date().toISOString(),
          last_updated: new Date().toISOString(),
        },
      },
      localize: (k: string) => k,
      language: "en",
      callService: async () => {},
      callWS: async () => ({}),
    };
    card.setConfig(config);
    card.hass = hass;
    card.editMode = true;
    w.__mockHa.cardWrap.style.width = width + "px";
    w.__mockHa.cardWrap.style.height = height + "px";
    w.__mockHa.cardWrap.appendChild(card);
  }, opts);
}

function chipText(page: Page): Promise<string> {
  return page.evaluate(() => {
    const card = ((window as any).__mockHa.cardWrap.querySelector("anyvac-card")) as any;
    const chip = card?.shadowRoot?.querySelector(".version-chip");
    return chip ? (chip.textContent ?? "") : "";
  });
}

function gridHeight(page: Page): Promise<number | null> {
  return page.evaluate(() => {
    const card = ((window as any).__mockHa.cardWrap.querySelector("anyvac-card")) as any;
    const grid = card?.shadowRoot?.querySelector(".avc-grid") as HTMLElement | null;
    return grid ? grid.getBoundingClientRect().height : null;
  });
}

test.describe("layout hardening (docs/21)", () => {
  test("5f: profile is picked from the card's own box, not the window", async ({ page }) => {
    // Wide+short window, but the card itself sits in a narrow, tall box —
    // the kind of embedding (two cards side by side, sections view, sidebar)
    // window.innerWidth/innerHeight couldn't see before this fix.
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 300, height: 700 });
    await expect.poll(() => chipText(page)).toContain("portrait");
  });

  test("5f: a landscape-shaped card box still picks landscape", async ({ page }) => {
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");
  });

  test("5b: grid stays healthy across simulated HA edit-mode reparenting", async ({ page }) => {
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    const before = await gridHeight(page);
    expect(before).not.toBeNull();
    expect(before as number).toBeGreaterThan(120);

    // HA reparents the card into hui-card-options — same slot, same
    // ancestor chain, no window resize, no event fired.
    await page.evaluate(() => (window as any).__mockHa.enterEdit());
    await page.waitForTimeout(200);

    const duringEdit = await gridHeight(page);
    expect(duringEdit).not.toBeNull();
    expect(duringEdit as number).toBeGreaterThan(120);
    // 2026-07-17 follow-up: the mock's hui-card-options actions bar is 32px
    // tall (tests/harness/mock-ha.html) — _editBarHeight() should reserve
    // roughly that much, not just avoid collapsing to zero.
    const shrink = (before as number) - (duringEdit as number);
    expect(shrink).toBeGreaterThanOrEqual(25);
    expect(shrink).toBeLessThanOrEqual(40);

    await page.evaluate(() => (window as any).__mockHa.exitEdit());
    await page.waitForTimeout(200);

    const after = await gridHeight(page);
    expect(after).not.toBeNull();
    expect(after as number).toBeGreaterThan(120);
    // Regression guard for the 0.59.0-0.61.0 class of bug: the grid must
    // never collapse to a degenerate height after an edit-mode transition.
    expect(Math.abs((after as number) - (before as number))).toBeLessThan(50);
  });

  test("5a: measurement completes on a backgrounded tab (rAF neutered + document.hidden)", async ({ page }) => {
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    await page.evaluate(() => {
      const w = window as any;
      // Simulate the real, observed kiosk/background-tab behavior: rAF is
      // schedulable but its callback never actually runs. The pre-5a code
      // (pure rAF) would hang forever here; the fix takes the
      // document.hidden -> setTimeout branch instead.
      w.__origRAF = window.requestAnimationFrame;
      window.requestAnimationFrame = () => {
        w.__rafBlockedCalls = (w.__rafBlockedCalls || 0) + 1;
        return 0;
      };
      Object.defineProperty(document, "hidden", { configurable: true, get: () => true });
    });

    // Resize the card's own box while "hidden" — must still be picked up
    // (via setTimeout(fn, 0)), not hang until the tab regains focus.
    await page.evaluate(() => {
      (window as any).__mockHa.cardWrap.style.width = "300px";
      (window as any).__mockHa.cardWrap.style.height = "700px";
    });

    await expect.poll(() => chipText(page), { timeout: 3000 }).toContain("portrait");

    // The fix branches on document.hidden BEFORE ever calling
    // requestAnimationFrame — so the neutered rAF mock above should never
    // even be invoked while hidden. This is the real assertion: the
    // setTimeout branch was taken, not rAF (which the resize's chip update
    // above already proves succeeded despite rAF being unusable).
    const blockedRafCalls = await page.evaluate(() => (window as any).__rafBlockedCalls ?? 0);
    expect(blockedRafCalls).toBe(0);
  });

  test("5b follow-up: a late position shift with no observable DOM mutation still settles (~250ms)", async ({ page }) => {
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    const before = await gridHeight(page);
    expect(before).not.toBeNull();

    // Simulate late-loading content ABOVE the card (fonts/images finishing
    // after first paint): grows an EXISTING element's inline style, so it
    // fires neither our MutationObserver (no childList change on the
    // watched trees) nor ResizeObserver(this) (the card's own box doesn't
    // change, only its position). Only the docs/21 §5b follow-up settle
    // timer can catch this.
    await page.evaluate(() => {
      (window as any).__mockHa.aboveSpacer.style.height = "150px";
    });

    // Immediately after: still stale — proves the scenario is real, not
    // vacuously already-fixed by some other observer.
    const immediately = await gridHeight(page);
    expect(immediately).not.toBeNull();
    expect(Math.abs((immediately as number) - (before as number))).toBeLessThan(5);

    // Past the settle window: self-corrected with no explicit trigger from
    // the test (no resize, no enterEdit/exitEdit, no window event).
    await page.waitForTimeout(500);
    const settled = await gridHeight(page);
    expect(settled).not.toBeNull();
    const shrink = (before as number) - (settled as number);
    expect(shrink).toBeGreaterThanOrEqual(120);
    expect(shrink).toBeLessThanOrEqual(170);
  });

  test("5b second follow-up: multi-column-spanning regions never overflow the grid (gap accounted for)", async ({ page }) => {
    // Live-confirmed bug (2026-07-17, real HA dashboard): percentage column
    // tracks summing to 100% don't leave room for `gap` — any region
    // spanning 2+ columns (col: "1/3", e.g. badges/map/tools in the default
    // landscape profile) then overflows the grid by (gaps spanned × gap
    // size), which cascades into a page-level scrollbar in both axes. Fixed
    // by using `fr` instead of `%` for numeric tracks (layout.ts `track()`).
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    const rects = await page.evaluate(() => {
      const card = (window as any).__mockHa.cardWrap.querySelector("anyvac-card");
      const grid = card.shadowRoot.querySelector(".avc-grid") as HTMLElement;
      const badges = card.shadowRoot.querySelector(".avc-region--badges") as HTMLElement | null;
      return {
        gridRight: grid.getBoundingClientRect().right,
        badgesRight: badges ? badges.getBoundingClientRect().right : null,
      };
    });
    expect(rects.badgesRight).not.toBeNull();
    // A spanning region's right edge must not exceed the grid container's
    // own right edge (small sub-pixel tolerance for rounding).
    expect((rects.badgesRight as number) - rects.gridRight).toBeLessThanOrEqual(1);
  });

  test("5b third follow-up: a late-mounting edit-mode actions bar still gets reserved without a second toggle", async ({ page }) => {
    // Live-reported (2026-07-17, real HA dashboard, hard refresh): the
    // FIRST edit toggle after a fresh page load didn't reserve room for the
    // actions bar; a SECOND toggle fixed it. Root cause: the actions bar's
    // own first paint inside hui-card-options' shadow root can be slower
    // than the reparenting mutation `_panelViewMo` reacts to, so the very
    // first `_editBarHeight()` read races the bar and gets 0. `_watchEditBar`
    // (docs/21 §5b third follow-up) is a one-shot observer that catches the
    // bar showing up later and re-measures — no second toggle required.
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    const before = await gridHeight(page);
    expect(before).not.toBeNull();

    await page.evaluate(() => (window as any).__mockHa.enterEditColdBar());
    await page.waitForTimeout(150);

    // Bar not mounted yet — height should be essentially unreserved.
    const cold = await gridHeight(page);
    expect(cold).not.toBeNull();
    expect(Math.abs((cold as number) - (before as number))).toBeLessThan(5);

    // Bar finishes its (slower, cold) first paint — no second edit toggle.
    await page.evaluate(() => (window as any).__mockHa.mountLateActionsBar());
    await page.waitForTimeout(300);

    const settled = await gridHeight(page);
    expect(settled).not.toBeNull();
    const shrink = (before as number) - (settled as number);
    expect(shrink).toBeGreaterThanOrEqual(25);
    expect(shrink).toBeLessThanOrEqual(40);
  });

  test("5b fourth follow-up: the actions bar CSS-transitioning its own height in still settles without a second toggle", async ({ page }) => {
    // Live-confirmed root cause (2026-07-17, instrumented the user's real
    // dashboard): the actions bar doesn't appear at full height instantly —
    // it CSS-transitions in (mock: 0 -> 32px over 80ms, tests/harness/
    // mock-ha.html `_mountBar`). A remeasure triggered only by the bar
    // *appearing* (MutationObserver) can fire while its height is still 0
    // and never fire again — nothing else on the card naturally changes
    // state from an edit-mode reservation alone. `_observeEditBar` (docs/21
    // §5b third follow-up) tracks the bar's own box with a ResizeObserver so
    // whichever remeasure runs last, after the transition settles, wins.
    await page.setViewportSize({ width: 1600, height: 900 });
    await mountCard(page, { width: 1200, height: 800 });
    await expect.poll(() => chipText(page)).toContain("landscape");

    const before = await gridHeight(page);
    expect(before).not.toBeNull();

    await page.evaluate(() => (window as any).__mockHa.enterEdit());

    // Give the transition time to fully settle (80ms transition + 2 RAFs to
    // start it), then confirm the FINAL, settled height was reserved — not
    // whatever the grid happened to read mid-transition.
    await page.waitForTimeout(400);

    const settled = await gridHeight(page);
    expect(settled).not.toBeNull();
    const shrink = (before as number) - (settled as number);
    expect(shrink).toBeGreaterThanOrEqual(25);
    expect(shrink).toBeLessThanOrEqual(40);
  });
});
