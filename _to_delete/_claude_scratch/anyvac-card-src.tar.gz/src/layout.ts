/**
 * layout.ts — two-profile percentage-grid layout runtime (docs/18).
 *
 * Model: two complete layout profiles (portrait / landscape), picked by the
 * aspect ratio of the available viewport — never by device type and never by
 * width breakpoints. Each profile is a CSS grid whose tracks are percentages
 * of the available viewport; the UI is a set of named regions placed into the
 * grid per profile. A region not placed in a profile is not rendered there.
 */

export type LayoutProfile = "portrait" | "landscape";

export interface RegionPlace {
  /** Grid line or span, CSS grid-line syntax: 2 or "1/4". */
  row?: number | string;
  col?: number | string;
  overflow?: "hidden" | "auto";
  align?: "stretch" | "start" | "center" | "end";
}

/** Rotated-map fit (docs/19 follow-up). Portrait's 90°-rotated map defaults to
 *  "contain" — fits entirely inside the measured map region, which can leave
 *  empty bars alongside it when the region's aspect ratio doesn't match the
 *  floorplan's. "cover" fills the region completely instead, cropping the
 *  overflow; offset_x/offset_y pan within that overflow so the user controls
 *  what gets cropped rather than it always centering. */
export interface MapCropConfig {
  fit?: "contain" | "cover";
  /** -100..100, 0 = centered. Only meaningful with fit: "cover". */
  offset_x?: number;
  offset_y?: number;
  /** docs/25 §4. "auto" (default) computes whether rotating the floorplan 90°
   *  gives a bigger fit inside the portrait map region than leaving it
   *  upright, and picks whichever wins — replacing the old "portrait always
   *  rotates" rule, which only happened to work because it was tuned against
   *  one specific (wide) floorplan. "normal"/"rotated" force a side, for
   *  edge cases the computed rule doesn't call the way the user wants. */
  mapOrientation?: "auto" | "normal" | "rotated";
  /** docs/32. Independent of `mapOrientation` — that picks 0°/90° for the best
   *  aspect-ratio fit, this adds a further 180° on top when the floorplan is
   *  simply upside down relative to what the user is used to. Composes with
   *  `mapOrientation: "rotated"` (or the auto-computed rotated case) into a
   *  270° total; both directions render via the same `.avc-rot` mechanism
   *  that already keeps room click-positions correct under rotation. */
  flip?: boolean;
}

/** docs/25 §4 — compute whether rotating the floorplan 90° fits the portrait
 *  map region better than leaving it upright. Pure geometry: for each
 *  orientation, "how big could the floorplan render inside this box" is the
 *  contain-fit scale (`min(boxW/contentW, boxH/contentH)`); pick whichever
 *  orientation yields the larger rendered map (bigger = more legible rooms,
 *  bigger tap targets). Ties (near-square floorplans, where it barely
 *  matters either way) default to NOT rotating — it's the cheaper option
 *  (no counter-rotating on-map labels via `.avc-rot`).
 *
 *  `floorplanAR` = floorplan width / height. `boxW`/`boxH` = the measured
 *  portrait map region. Returns `undefined` when there isn't enough data to
 *  decide yet (region not measured) — callers should keep their previous
 *  answer rather than flicker on an unmeasured 0×0 box. */
export function shouldRotateMap(floorplanAR: number, boxW: number, boxH: number): boolean | undefined {
  if (boxW <= 4 || boxH <= 4 || floorplanAR <= 0) return undefined;
  // Normalize floorplan height to 1 → width is floorplanAR. Contain-fit scale
  // is min(boxAxis / contentAxis) per axis; rotating swaps which axis is which.
  const scaleUpright = Math.min(boxW / floorplanAR, boxH);
  const scaleRotated = Math.min(boxW, boxH / floorplanAR);
  // Equal scale (or upright wins/ties) → don't rotate.
  return scaleRotated > scaleUpright;
}

/** docs/25 §7c — portrait map/dock topology as a computed choice, generalizing
 *  `shouldRotateMap()` (§4) from "which way is the floorplan rotated" up one
 *  level to "which overall arrangement fits the floorplan better":
 *
 *  - "split": today's default (`DEFAULT_PROFILES.portrait`) — map and dock
 *    side by side, map gets the full available height, its width follows its
 *    own aspect ratio (post §4 rotation choice).
 *  - "stack": map full-width on top, dock/vacuum row/START below it full-width.
 *    Map gets the full available width, height follows its aspect ratio
 *    (capped so the dock doesn't get squeezed to a sliver).
 *
 *  **Model history (2026-07-24, two corrections same day, both from live
 *  field feedback on the SAME real floorplan — a 4-storey narrow building):**
 *
 *  1. First version reserved the SAME FRACTION of the box for both
 *     candidates (dock keeps a fraction of width in split, the SAME
 *     fraction of height in stack) — wrong, because a real dock's content
 *     (icon strip + layer toggles + mode row, now that the room list is
 *     hidden by default, §7c/§7e) is a roughly FIXED pixel height, not
 *     proportional to the box. Replaced the height fraction with a fixed
 *     `dockHeightPx` estimate (~150px).
 *  2. That alone still wasn't enough — live numbers from the field
 *     (908×1726px content box, ~0.185 floorplan aspect ratio) showed WHY:
 *     split reserves ZERO height for the dock (it sits beside the map, not
 *     below it), so split's "achieved map size" is the box's FULL height
 *     no matter what `dockHeightPx` is set to, while stack's is always
 *     `boxH − dockHeightPx` — strictly less. For a sufficiently narrow
 *     floorplan (map's width need is trivial either way, so both
 *     candidates end up height-bound), split therefore ALWAYS wins on raw
 *     "biggest achievable map" — not a tuning problem, a structural one:
 *     that metric literally cannot prefer stack for a narrow floorplan,
 *     no matter the dock cost estimate. But "biggest map" isn't actually
 *     what looked better — a ~9% smaller map (1576 vs 1726 in the field
 *     numbers) with a properly-sized dock row read as clearly better than
 *     a marginally bigger map next to a mostly-empty column. `STACK_BIAS`
 *     directly encodes that: stack wins by default UNLESS split's raw
 *     score exceeds stack's by more than this margin — i.e. split has to
 *     be a clear, not marginal, win to justify a wide, likely-underused
 *     side column instead of a snug full-width row below the map.
 *  3. `stackBias: 1.3` still wasn't quite enough (2026-07-24, same
 *     floorplan, same day): live A/B on the user's actual reported box
 *     (360×580 and 360×514, both under the earlier 650px rule-of-thumb)
 *     showed split "winning" the raw metric by only ~4% — comfortably
 *     inside the 1.3 margin — while a live screenshot comparison (forced
 *     `topology: stack` vs the computed `split` on the SAME box, via
 *     Claude in Chrome against the user's running instance) showed stack
 *     was still clearly better: for this floorplan the map ends up a
 *     similarly narrow sliver either way (extreme ~0.27 rotated aspect
 *     ratio), so the two candidates' RAW map sizes are almost the same —
 *     but split's leftover dock column only ever holds ~250px of actual
 *     content (avatars/chips/mode row) no matter how much width it's
 *     handed, so anything past that is dead space, while stack's full-
 *     width dock row uses its allotment properly. That "wasted width"
 *     cost isn't in the raw metric at all, so a small default bias never
 *     fully compensated for it. Raised to `1.5`, verified by hand against
 *     both real reported boxes (needs bias > 1.41 for the 514 case) —
 *     comfortably flips both to stack while leaving split able to win
 *     outright for boxes tall enough that it's a genuinely clear margin.
 *
 *  `floorplanAR` = floorplan width / height (post-rotation, i.e. whatever
 *  `_narrow`/`shouldRotateMap` already decided to actually render).
 *  `boxW`/`boxH` = the full portrait content box (map + dock combined, minus
 *  START bar). Returns `undefined` when there isn't enough data yet, same
 *  convention as `shouldRotateMap()`. */
export function shouldStackLayout(
  floorplanAR: number,
  boxW: number,
  boxH: number,
  opts: { dockWidthFrac?: number; dockHeightPx?: number; stackBias?: number } = {},
): boolean | undefined {
  // ~150px estimate: vac-icon-strip (~50-64px) + dock-layers row (~30px) +
  // dock-head mode row (~40px) + dock container padding/gaps (~24px), per
  // today's minimalist portrait dock (docs/25 §7c/§7e — no permanent room
  // list). Only needs to be roughly right: the actual STACK_PORTRAIT_PROFILE
  // dock row is CSS "auto" (sized to real content, not this estimate) — this
  // number only steers the split-vs-stack DECISION, not final layout.
  const { dockWidthFrac = 0.28, dockHeightPx = 150, stackBias = 1.5 } = opts;
  if (boxW <= 4 || boxH <= 4 || floorplanAR <= 0) return undefined;
  const splitMapW = boxW * (1 - dockWidthFrac);
  const scaleSplit = Math.min(splitMapW / floorplanAR, boxH);
  const stackMapH = Math.max(boxH - dockHeightPx, 0);
  const scaleStack = Math.min(boxW / floorplanAR, stackMapH);
  // Stack is the default; split only wins by a clear (not marginal) margin
  // — see model history above for why a raw size comparison alone always
  // favors split for narrow floorplans regardless of the dock estimate.
  return !(scaleSplit > scaleStack * stackBias);
}

export interface ProfileGridConfig {
  /** Track sizes: numbers are % of available viewport, strings pass through
   *  ("1fr", "auto", "120px"). */
  columns?: Array<number | string>;
  rows?: Array<number | string>;
  place?: Record<string, RegionPlace>;
  crop?: MapCropConfig;
  /** docs/25 §7c. "auto" (default, portrait only) computes split vs. stack
   *  from `shouldStackLayout()`. "split"/"stack" force a side — same escape
   *  hatch pattern as `crop.mapOrientation`. Any explicit `columns`/`rows`/
   *  `place` on this profile already opts out of the computed choice
   *  entirely (the card treats a manual layout as intentional) — this field
   *  only matters when none of those are set. */
  topology?: "auto" | "split" | "stack";
}

/** `columns`/`rows`/`place` filled in; `crop`/`topology` stay optional/absent
 *  (no default data to fall back to — see `resolveProfile`'s doc comment). */
export type ResolvedProfileGrid = Required<Omit<ProfileGridConfig, "crop" | "topology">>;

/** docs/25 §7c — the "stack" portrait arrangement (map full-width on top,
 *  dock/vacuum-row/START stacked full-width below it), used in place of
 *  `DEFAULT_PROFILES.portrait` when `shouldStackLayout()` (or a manual
 *  `topology: "stack"` override) picks it. `rows: ["minmax(0, 1fr)", "auto",
 *  "auto"]` mirrors the landscape pattern (docs/19 A5 addendum) — the map
 *  takes whatever's left after dock/start size to their own content, not
 *  the other way around.
 *
 *  `minmax(0, ...)`, not bare `"1fr"` (field bug, 2026-07-24): a bare `1fr`
 *  track's implicit minimum is `auto` (its content's min-content size), not
 *  `0`. `_renderResponsive()` returns the RAW, unwrapped map template
 *  (unbounded natural/intrinsic size — no fit box yet) until the map region
 *  has been measured once (`_mapRegW/_mapRegH`). On a brand-new stack
 *  render, that first unmeasured paint's natural size became the row's
 *  forced minimum, blowing the whole grid out to ~2 phone-screens tall —
 *  and it never recovered, because the very next measurement pass read the
 *  ALREADY-blown-out region size back as "correct" and locked it in (the
 *  settle-loop has no notion of "too big", only "changed by ≥2px"). `auto`
 *  rows (split's `[90, 10]`, or landscape's non-map rows) never had this
 *  because they're either a definite percentage of a definite grid height,
 *  or genuinely want their content's natural size. `minmax(0, 1fr)` caps
 *  the row to its fair share of the (already height-constrained) grid from
 *  frame one — the oversized raw content just gets clipped by the region's
 *  existing `overflow:hidden` (`regionStyles()`) instead of stretching the
 *  grid, and the following measurement pass reads the correctly-sized
 *  region, breaking the lock-in for good. */
export const STACK_PORTRAIT_PROFILE: ResolvedProfileGrid = {
  columns: [100],
  rows: ["minmax(0, 1fr)", "auto", "auto"],
  place: {
    map: { row: 1, col: 1 },
    dock: { row: 2, col: 1, overflow: "auto" },
    start: { row: 3, col: 1 },
  },
};

export interface LayoutConfig {
  /** availW/availH below this → portrait. Default 1.0. */
  threshold?: number;
  /** Force a profile; "auto" (default) picks by aspect ratio. */
  orientation?: "auto" | LayoutProfile;
  gap?: string;
  /** "viewport" (default) | "container" | any CSS length. */
  height?: string;
  portrait?: ProfileGridConfig;
  landscape?: ProfileGridConfig;
}

/** v1.1.0 field fix (2026-08-04, docs/33 follow-up): the landscape map row's
 *  minimum height, in px — see the row-4 comment below for why this floor
 *  moved from row 4's growth limit onto the map's own row instead. Picked
 *  as "clearly usable, rarely binding": only kicks in when the status+dock
 *  column actually wants more than (grid height − this) for its own
 *  content, which needs several vacuums or a long room list. */
const LANDSCAPE_MAP_FLOOR_PX = 260;

/**
 * Canonical docs/18 §4 default profiles (Phase B). Landscape = cockpit: map left
 * (scrolls in split mode, §7b), dock (selection + plan + orchestrated run, §7d)
 * and per-robot status cards right. Portrait = docs/12: slim badges bar, tall
 * rotated map, right thumb dock, full-width START bar. Overridable per config.
 */
export const DEFAULT_PROFILES: Record<LayoutProfile, ResolvedProfileGrid> = {
  landscape: {
    // Phase C (docs/19 A5): map + meta bar go full-width — the map is the main
    // instrument, not a 70%-column tenant. Below that the cockpit splits in
    // two: left column = per-robot status/controller cards (unchanged);
    // right column = a slim vertical vacuum picker (replaces the old
    // horizontal badge-row tabs for this purpose) with the room list docked
    // directly beneath it.
    // Row 1 is "auto", not a fixed %: badges only ever holds global-action
    // badges now (vacuum picking moved to `picker`, docs/19 A5) — a hardcoded
    // percentage reserved dead black space whenever no global_actions are
    // configured (field-caught 2026-07-15). "auto" collapses to whatever the
    // row actually contains, same as the tools/status/picker/dock rows below.
    // The "1fr" lives on the MAP's row instead (field feedback from a tall
    // panel-view page 2026-07-15): everything below the map should size to
    // its own natural content height, and the map should get whatever's left
    // over — not the other way around, which is what put the flex on the
    // status/dock row before and left the map a fixed, often-too-small size
    // on tall viewports.
    // docs/28 §4 (2026-07-25): columns changed from a fixed `[70, 30]` split
    // to content-driven — the right column (`picker` + `dock`, same grid
    // track) should never grow past what it actually needs, and the
    // controller column (`status`) should absorb whatever's left, unbounded
    // (wide status cards aren't a problem the way a wide, mostly-empty dock
    // column is, docs/25 §7c's stack/split finding on the portrait side).
    // `max-content` is safe here in a way the abandoned portrait attempt
    // (docs/21 §5b) wasn't: THAT column's `.dock-row` used `flex-wrap: wrap`
    // with no per-element width cap, so its max-content contribution was
    // always the unwrapped single-line size — never smaller than what was
    // already allocated. Landscape's `.dock-row` doesn't wrap the row; the
    // one variable-length field (`.dock-name`, room name) instead gets its
    // OWN fixed `max-width` (docs/28 §4) so an outlier long name wraps to a
    // second line inside that cap instead of setting the column's width.
    // `.vac-picker .badge` (the `picker` region sharing this column) is
    // `width: 100%`, which intrinsic-sizing treats as auto/shrink-to-fit —
    // its own natural width (vacuum name, always short) drives the column
    // the same way, no separate handling needed.
    // v1.1.0 (2026-08-03, docs/33): row 4 (status column + picker/dock) used
    // to be bare "auto" — sized to whatever its content needed, with NO
    // upper bound, taken out of the grid's height BEFORE the map's `1fr`
    // row gets whatever's left over. A content-heavy status column (many
    // vacuums, or before the same-day compact status-card redesign) could
    // therefore squeeze the map down to a sliver with no floor at all.
    // `minmax(0, 50%)` was meant to give the map row a genuine floor while
    // leaving the LOWER bound at 0 so small content (the common case) still
    // shrinks to fit — but that's not how `minmax()` behaves once a `1fr`
    // row shares the grid: a non-flexible track's percentage MAX is its
    // growth limit, and CSS Grid's "maximize tracks" step grows every
    // non-flexible track up to its growth limit FIRST, using up whatever
    // free space the grid has, before `fr` tracks get whatever's left —
    // regardless of how little that track's own content actually needs.
    // Field-caught 2026-08-04: one vacuum + a short room list still
    // inflated row 4 to a full 50% of the grid, leaving dead space below
    // the real content and starving the map's `1fr` row of height it had
    // no other claimant for (visible as both a gap above the START footer
    // AND the map rendering narrower than the card, letterboxed, because
    // it no longer had enough height for its aspect ratio to reach full
    // width). Fix: put the floor on the map's OWN row instead —
    // `minmax(<mapFloorPx>, 1fr)` guarantees the map at least
    // `LANDSCAPE_MAP_FLOOR_PX` regardless of what row 4 wants, and row 4
    // goes back to bare `"auto"` so it genuinely shrinks to its content
    // again. `status`'s own `overflow: "auto"` still turns "content taller
    // than the map's leftover space" into an internal scrollbar instead of
    // grid overflow, so an unbounded row 4 is safe: excess content
    // scrolls, it doesn't get clipped invisibly. Purely declarative — no
    // JS measurement involved, so this carries none of the docs/21 §5b
    // JS-vs-styleMap risk. Manual `layout.landscape.rows` overrides bypass
    // this entirely (`resolveProfile`), so anyone who already hand-tuned
    // rows is unaffected.
    //
    // v1.1.0 follow-up (2026-08-03, field-caught): `picker` and `dock` used
    // to be TWO separate grid rows (4 and 5), with `status` spanning both
    // ("4/6") so its column matched their combined height. That span made
    // the row-sizing algorithm distribute status's OWN content height
    // across both tracks — inflating row 4 (picker's row) well past what
    // the picker itself needed whenever status was tall, which left a
    // visible gap between the short picker pills and the dock/room-list
    // below them (a live screenshot showed this directly: status column
    // trails off with empty space of its own further down, same underlying
    // cause — neither column's content matches its allotted track height 1:1
    // once a spanning item is involved). Fix: collapse to a SINGLE row for
    // both columns — `picker` is no longer its own grid region at all, it
    // renders as the first thing inside `dock`'s own template instead
    // (`_renderDock`'s new `withPicker` param, gated on `!("picker" in
    // prof.place)` so a manual config that still explicitly places `picker`
    // itself keeps working, unchanged). With one shared row, each column
    // is free to size to its own natural stacked content (picker pills
    // immediately followed by the mode row/room list, no cross-column
    // spanning distribution to inflate the gap between them) — the
    // remaining per-column vertical slack (right column shorter than left,
    // or vice versa) is just genuinely-natural leftover space, not a bug.
    columns: ["minmax(0, 1fr)", "max-content"],
    rows: ["auto", `minmax(${LANDSCAPE_MAP_FLOOR_PX}px, 1fr)`, "auto", "auto"],
    place: {
      badges: { row: 1, col: "1/3" },
      map: { row: 2, col: "1/3" },
      tools: { row: 3, col: "1/3", align: "start" },
      status: { row: 4, col: 1, overflow: "auto" },
      dock: { row: 4, col: 2, overflow: "auto" },
    },
  },
  portrait: {
    // Phase C follow-up (docs/19): the top badges row is dropped — merged mode
    // has no split-mode "shown" focus to switch, so it was only costing height.
    // The map takes that space back; each vacuum's emergency more-info access
    // moves into a small icon strip at the top of the dock column instead
    // (`_renderVacuumIconStrip`, portrait-only).
    // Declarative fallback columns (used until the first fit measurement lands,
    // see `_refineGridColumns`): the map is height-fit (fills row 1's full
    // height, `_renderResponsive`), which usually leaves it NARROWER than a
    // fixed 72% column. A CSS "auto" track can't pick that up on its own — the
    // fitted width lives on an absolutely-positioned inner div precisely so it
    // does NOT feed back into layout/reflow, which also means it carries no
    // intrinsic-size signal for track auto-sizing. So the actual column split
    // is measured-and-applied in JS instead (same settle-and-stop pattern as
    // `_refineGridHeight`), col2 = 1fr picks up whatever col1 doesn't need
    // (field feedback 2026-07-15: "the freed-up width should go to the
    // sidebar, not sit empty").
    columns: [72, 28],
    rows: [90, 10],
    place: {
      map: { row: 1, col: 1 },
      dock: { row: 1, col: 2, overflow: "auto" },
      start: { row: 2, col: "1/3" },
    },
  },
};

/** Pick the active profile from the available viewport. */
export function pickProfile(cfg: LayoutConfig | undefined, availW: number, availH: number): LayoutProfile {
  const o = cfg?.orientation;
  if (o === "portrait" || o === "landscape") return o;
  if (!availW || !availH) return "landscape";
  return availW / availH < (cfg?.threshold ?? 1.0) ? "portrait" : "landscape";
}

/** Read the HA header height (px) from the CSS variable, 0 when absent. */
export function headerPx(el: Element): number {
  try {
    const raw = getComputedStyle(el).getPropertyValue("--header-height").trim();
    const n = parseFloat(raw);
    return Number.isFinite(n) && n > 0 ? n : 0;
  } catch {
    return 0;
  }
}

/** Merge the profile's grid config with the built-in defaults. `crop` isn't
 *  merged here (it has no "default profile" data to fall back to — it's just
 *  present or absent) — callers read `cfg[profile]?.crop` directly. */
export function resolveProfile(cfg: LayoutConfig, profile: LayoutProfile): ResolvedProfileGrid {
  const p = cfg[profile] ?? {};
  const d = DEFAULT_PROFILES[profile];
  return {
    columns: p.columns?.length ? p.columns : d.columns,
    rows: p.rows?.length ? p.rows : d.rows,
    place: p.place && Object.keys(p.place).length ? p.place : d.place,
  };
}

/** `fr`, not `%` — CSS Grid's `fr` unit distributes space AFTER subtracting
 *  `gap`, so proportional tracks never overflow their container by the gap
 *  amount. Plain `%` tracks summing to 100% do: any region spanning 2+
 *  tracks (e.g. `col: "1/3"`) then overflows the grid by (gaps spanned ×
 *  gap size) — confirmed live on a real dashboard 2026-07-17 (docs/21 §5b
 *  second follow-up): a landscape `columns: [70, 30]` with the default 6px
 *  gap overflowed `badges`/`map`/`tools` (all `col: "1/3"`) by exactly 6px,
 *  which cascaded into a page-level horizontal AND vertical scrollbar (the
 *  vertical one was a pure side effect — fixing the column unit alone
 *  removed both). Numerically identical ratio for the config author (a
 *  `70`/`30` split still renders 70:30); only the CSS unit changes. */
function track(v: number | string): string {
  return typeof v === "number" ? v + "fr" : v;
}

export function trackList(list: Array<number | string>): string {
  return list.map(track).join(" ");
}

/** CSS height for the grid root. The measured refinement (innerHeight − rootTop)
 *  is applied on top of this by the card; this is the declarative fallback.
 *  `svh` (not vh/dvh) so a mobile URL-bar show/hide doesn't make the layout jump. */
export function resolveHeightCss(cfg: LayoutConfig): string {
  const h = cfg.height ?? "viewport";
  if (h === "viewport") return "calc(100svh - var(--header-height, 0px))";
  if (h === "container") return "100%";
  return h;
}

/** Inline styles for the grid root (static styles can't express a dynamic grid).
 *
 *  REVERTED 2026-07-16 (mobile crash, card 0.59.0 → 0.61.0): `height` and
 *  `gridTemplateColumns` were pulled out of this object on the theory that
 *  Lit's `styleMap` re-applying every key on every render was silently
 *  fighting the JS-measured overrides in `updated()`. That was true (and
 *  is the reason portrait's column split never visibly changed across
 *  0.56–0.58), but the fix itself is what broke the HA mobile companion
 *  app — user bisected it precisely to 0.59.0, with 0.55.0–0.58.0 all
 *  confirmed non-crashing. Exact mechanism not fully confirmed, but the
 *  safe move is putting both properties back here and accepting that the
 *  JS refinement in `updated()` fights (and mostly loses) against this
 *  declarative object again — a cosmetic imperfection, not a crash. Do NOT
 *  remove these from styleMap again without a mobile-tested alternative. */
export function gridRootStyles(cfg: LayoutConfig, prof: ResolvedProfileGrid): Record<string, string> {
  return {
    display: "grid",
    width: "100%",
    height: resolveHeightCss(cfg),
    alignContent: "start",
    gridTemplateColumns: trackList(prof.columns),
    gridTemplateRows: trackList(prof.rows),
    gap: cfg.gap ?? "6px",
    boxSizing: "border-box",
  };
}

/** Inline styles for a region wrapper. `position:relative` keeps absolutely
 *  positioned children (map overlays, layer toggles) correct in both profiles. */
export function regionStyles(place: RegionPlace): Record<string, string> {
  const s: Record<string, string> = {
    gridRow: String(place.row ?? "auto"),
    gridColumn: String(place.col ?? "1"),
    overflow: place.overflow ?? "hidden",
    position: "relative",
    minWidth: "0",
    minHeight: "0",
  };
  if (place.align && place.align !== "stretch") s.alignSelf = place.align;
  return s;
}

// ── Per-profile scalars (instead of a second breakpoint system) ────────────

type PerProfile<T> = Partial<Record<LayoutProfile, T>>;

function isPerProfile<T>(v: unknown): v is PerProfile<T> {
  return (
    typeof v === "object" && v !== null && !Array.isArray(v) &&
    ("portrait" in (v as object) || "landscape" in (v as object))
  );
}

/** Resolve a scalar that may vary per profile:
 *  pval({portrait: "8px", landscape: "12px"}, profile) or pval("10px", profile). */
export function pval<T>(v: T | PerProfile<T>, profile: LayoutProfile): T | undefined {
  if (isPerProfile<T>(v)) {
    const p = v as PerProfile<T>;
    return p[profile] ?? p[profile === "portrait" ? "landscape" : "portrait"];
  }
  return v as T;
}

/** Overlay `item[profile]` onto the base object (shallow merge). */
export function papply<T extends Record<string, unknown>>(item: T & PerProfile<Partial<T>>, profile: LayoutProfile): T {
  const overlay = (item as PerProfile<Partial<T>>)[profile];
  const base: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(item)) {
    if (k === "portrait" || k === "landscape") continue;
    base[k] = v;
  }
  return (overlay ? { ...base, ...overlay } : base) as T;
}
