import type { LayoutConfig } from "./layout";
import type { CardTheme } from "./const";

// ── Home Assistant core types ─────────────────────────────────────────────

export interface HassConnection {
  sendMessage(message: Record<string, unknown>): void;
  subscribeEvents(
    callback: (event: { data?: Record<string, unknown> }) => void,
    eventType?: string
  ): Promise<() => void>;
}

export interface HomeAssistant {
  states: Record<string, HassEntity>;
  connection: HassConnection;
  callService(
    domain: string,
    service: string,
    data?: Record<string, unknown>,
    target?: Record<string, unknown>
  ): Promise<void>;
  /** Raw WebSocket command (blueprint/save, input_datetime/create, …) */
  callWS<T = unknown>(message: Record<string, unknown>): Promise<T>;
  /** REST API call (config/automation/config/<id>, …) */
  callApi<T = unknown>(method: string, path: string, parameters?: unknown): Promise<T>;
  hassUrl(path?: string): string;
}

export interface HassEntity {
  entity_id: string;
  state: string;
  attributes: Record<string, unknown>;
  last_changed: string;
  last_updated: string;
}

// ── Card config types ─────────────────────────────────────────────────────

export interface MapConfig {
  entity: string;
  rotation: number;
  scale: number;
  offset_x: number;
  offset_y: number;
  /** Seating mode (docs/15): "auto" (default — fitted from room anchors when the
   *  integration + a floorplan + at least one matched room are available) or
   *  "manual" (use the rotation/scale/offset values above). */
  seat?: "auto" | "manual";
}

/** Docs/38 §4.1 (legacy) — `src` was cut from ONE vacuum's own map px space
 *  (same space as that vacuum's `rooms[].bbox_px`); re-normalising anything
 *  against this crop is only valid for `entity`'s own data. */
export interface VacuumCropBox {
  entity: string;
  x0: number; y0: number; x1: number; y1: number;
}

/** Docs/40 §4.5 (Fáze 3) — `src` was cut from the SHARED home frame `frame_id`
 *  names (integration `home_frame.id`), in that frame's own px space (same
 *  space as `rooms[].bbox_home_px`/`outline_home_px` and
 *  `vacuum_position_home_px`/`path_*_home_px`) — valid for EVERY vacuum
 *  currently registered into that frame, not just one. Written automatically
 *  by "Snapshot home frame as floorplan" (`anyvac.snapshot_map_as_floorplan`,
 *  `frame: "home"`); read back by the card's merged-mode renderer
 *  (`homeFrameCropFor`, seatfit.ts) to place every such vacuum's marker/path/
 *  rooms with NO per-vacuum seat at all — one shared identity crop, docs/40
 *  §4.4. A vacuum whose own `home_frame.id` doesn't match `frame_id` (a
 *  different floor, or not registered yet) automatically falls back to its
 *  own legacy per-vacuum seat instead — no separate config for that case. */
export interface HomeFrameCropBox {
  frame_id: string;
  x0: number; y0: number; x1: number; y1: number;
}

/** One clicked point-pair for docs/40 §5.B's foreign-floorplan calibration —
 *  `home_px` is where that physical point sits in the shared home frame
 *  (usually snapped to a detected wall corner, `anyvac.snap_wall_corner`),
 *  `floor_pct` is the SAME physical point clicked on the foreign floorplan
 *  image, as wrap-container percent (0.1% precision, same convention as
 *  room placement). Deliberately NOT a solved seat (contrast docs/39's
 *  `map.seat: "manual"`, which stores rotation/scale/offset once and
 *  forgets the points): storing the raw pairs lets `computeSeatFit`
 *  re-solve the transform on every render, so calibration survives the
 *  home frame's canvas growing later (`grow_frame_canvas`, backend) without
 *  needing to re-click anything — the whole point of anchoring cesta B to
 *  mm-stable home-frame data instead of a robot's own drifting px canvas. */
export interface HomeFrameAnchor {
  home_px: { x: number; y: number };
  floor_pct: { x: number; y: number };
}

export interface ImageBaseConfig {
  src: string;
  rotation?: number;
  scale?: number;
  offset_x?: number;
  offset_y?: number;
  /** Which px space `src` was cut from — a single vacuum's own (legacy,
   *  `entity`) or the shared home frame's (`frame_id`, docs/40 Fáze 3). Only
   *  ever one shape at a time; cleared (and left unset) whenever `src` no
   *  longer traces back to a known crop — e.g. a hand-entered image URL. */
  crop_box?: VacuumCropBox | HomeFrameCropBox;
  /** docs/40 §5.B — N-point calibration anchors for a FOREIGN-origin
   *  floorplan (photo/drawing) calibrated against the shared home frame
   *  once, card-level (not per-vacuum, contrast docs/39's `map.seat`).
   *  2+ pairs fully determine a similarity transform (free rotation + one
   *  scale, offset), recomputed live every render — see `HomeFrameAnchor`.
   *  Mutually pointless together with a `crop_box` (a snapshotted
   *  floorplan is already an identity crop and needs no fit at all), but
   *  harmless if both are somehow set — `homeFrameCropFor` takes priority
   *  wherever a vacuum is home-frame-eligible either way. */
  home_anchors?: HomeFrameAnchor[];
  /** Which home frame `home_anchors` were clicked against (its
   *  `home_frame.id`) — set automatically when the calibration flow saves.
   *  Omit to fit against whichever frame the most configured vacuums are
   *  currently registered into (same default `_select_home_frame`/
   *  `anyvac.snap_wall_corner` use with no explicit `frame_id`) — fine for
   *  the common single-frame home, only needed to disambiguate a real
   *  multi-floor one with more than one active frame at once. */
  home_anchors_frame_id?: string;
}

export interface RoomThreshold {
  days: number;
  color: string;
}

export interface RoomConfig {
  key: string;
  name: string;
  icon?: string;                     // volitelné v rectangle módu
  icon_anchor?: "none"|"tl"|"t"|"tr"|"l"|"c"|"r"|"bl"|"b"|"br";
  segment_id?: number;
  area_id?: string;
  clean_time_mins?: number;
  /** Estimated minutes for a DRY clean of this room (used when the vacuum's role is dry). */
  clean_time_dry?: number;
  /** Estimated minutes for a WET (mop) clean of this room (used when the vacuum's role is wet). */
  clean_time_wet?: number;            // odhadovaný čas úklidu (minuty) — fallback when no entity
  /** Legacy input_number, READ-ONLY fallback estimate. The card never writes it —
   *  estimates are learned by the anyvac integration (docs/14 §3.2). */
  clean_time_entity?: string;
  /** Legacy input_datetime, READ-ONLY fallback for room age. The card never writes it —
   *  history is stamped by the anyvac integration (docs/14 §3.3). */
  last_clean_entity?: string;
  /** Explicit pixel-anchor override. When set, this room's position is fixed (never
   *  recomputed from the integration's live bbox_px) and it also serves as a fit
   *  anchor for auto-seating (docs/15). Omit both to let the room's geometry be
   *  computed live from the integration each render (docs/20, "Rooms z integrace"). */
  map_x?: number;
  map_y?: number;
  map_w?: number;                    // šířka % → aktivuje rectangle mód
  map_h?: number;                    // výška %
  /** COMPUTED ONLY, never config — docs/40 §4.4 (Fáze 3): this room's real
   *  traced shape (`rooms[].outline_home_px`, kontrakt v3) re-normalised into
   *  wrap-container percent points, when this room is live-merged from a
   *  vacuum currently rendered via the shared home frame. `map_x/y/w/h`
   *  above stay the click/select hit-target and icon anchor either way — an
   *  outline is drawn ON TOP of that rectangle as a purely visual refinement,
   *  never a replacement for it, so a room with no outline (bbox-only, or
   *  legacy per-vacuum seat) renders exactly as before. */
  outline_pct?: Array<{ x: number; y: number }>;
}

// ── Clean action strategies ───────────────────────────────────────────────

export interface NativeCleanAction {
  type: "native";
  repeat?: number;
  suction_level?: string;  // option from vacuum entity's fan_speed_list
  mop_mode_entity?: string;
  mop_mode?: string;
  mop_intensity_entity?: string;
  mop_intensity?: string;
}

/**
 * Uses the HA vacuum.clean_area action. room.key (or an area_mappings override)
 * is sent as cleaning_area_id -- no segment_id needed. Degraded mode only: once
 * the AnyVac integration is active for a vacuum, START always calls
 * anyvac.clean instead and this strategy is never exercised (docs/14 §8).
 * No repeat -- an earlier software-repeat implementation (restarting
 * clean_area after each pass) was removed for being unsafe with mop washing
 * (docs/13 A1); repeat now only exists server-side, in anyvac.clean.
 */
export interface NativeAreaCleanAction {
  type: "native-area";
  repeat?: number;         // unused -- kept for shape compat with the other native variants
  suction_level?: string;
  mop_mode_entity?: string;
  mop_mode?: string;
  mop_intensity_entity?: string;
  mop_intensity?: string;
}

/**
 * Legacy alias, no longer offered in the editor (2026-07-30) -- behaves
 * identically to NativeCleanAction (segment_id + app_segment_clean) both with
 * and without the integration. Its original distinguishing behaviour (a
 * roborock.get_maps dynamic resolve, matching rooms via area_mappings instead
 * of a configured segment_id) was deleted in the docs/14 §3.7 frontend purge,
 * making it a pure duplicate of "native". Kept only so existing configs with
 * this literal value keep working; the editor now displays/writes such
 * configs as "native" once touched.
 */
export interface NativeAutoCleanAction {
  type: "native-auto";
  repeat?: number;
  suction_level?: string;
  mop_mode_entity?: string;
  mop_mode?: string;
  mop_intensity_entity?: string;
  mop_intensity?: string;
}

export interface ScriptCleanAction {
  type: "script";
  entity_id: string;
  variables?: Record<string, string>;
}

export type CleanAction = NativeCleanAction | NativeAreaCleanAction | NativeAutoCleanAction | ScriptCleanAction;

// ── Presets & orchestration (docs/11) ─────────────────────────────────────

/**
 * A named "how" bundle for a single vacuum (Manual mode). The user picks one on
 * the vacuum's controller, then picks rooms on the map. Values are applied via
 * the vacuum's clean_action plumbing (mop_mode_entity / mop_intensity_entity /
 * set_fan_speed). Clean type (dry/wet/both) is DERIVED from these, never stored.
 */
export interface SettingPreset {
  /** Stable id (used for backend estimate keying / referencing). */
  id: string;
  label: string;
  icon?: string;
  suction_level?: string;
  mop_mode?: string;
  mop_intensity?: string;
  repeat?: number;
}

/** One step of a (possibly multi-step) targeted clean. */
export interface CleanStep {
  /** Room keys; empty/omitted = all rooms in scope. */
  rooms?: string[];
  suction_level?: string;
  mop_mode?: string;
  mop_intensity?: string;
  repeat?: number;
}

/** Orchestrator policy (Auto mode). Global default on the card; optional per-preset override. */
export interface OrchestratorPolicy {
  /** Never run dry and wet on the same area at the same time. Default true. */
  avoid_dry_wet_collision?: boolean;
  /** Optimisation priority. */
  priority?: "speed" | "fewer_robots";
}

/**
 * A card-level targeted clean (Auto mode). The user taps it; the integration
 * orchestrates which robots, in which order, with what timing. `scope` = what to
 * clean; the orchestrator decides who/how.
 */
export interface GlobalPreset {
  id: string;
  label: string;
  icon?: string;
  /** "all" = whole flat, "select" = pick rooms on the map at run time, or fixed room keys. */
  scope: "all" | "select" | string[];
  /** dry pass only / wet pass only / dry then wet (wet follows dry per room). Default "dry". */
  mode?: "dry" | "wet" | "both";
  /** Optional ordered steps (e.g. a dry pass then a wet pass). */
  steps?: CleanStep[];
  /** Per-preset override of the orchestrator policy. */
  policy?: OrchestratorPolicy;
}

// ── Global action ─────────────────────────────────────────────────────────

/**
 * A badge that triggers a single action across all vacuums.
 * Typical use-case: "Clean whole flat" button.
 * The badge glows when any of watch_entities is in a cleaning state.
 */
export interface GlobalActionScript {
  type: "script";
  entity_id: string;
  variables?: Record<string, string>;
}

export interface GlobalActionService {
  type: "service";
  /** Format: "domain.service", e.g. "script.turn_on" */
  service: string;
  data?: Record<string, unknown>;
}

export type GlobalActionCall = GlobalActionScript | GlobalActionService;

export interface GlobalAction {
  /** Display name shown in the badge */
  name: string;
  /** Optional image path, e.g. /local/Dashboards/Vacuum/celybyt.png */
  image?: string;
  /** Accent colour. Defaults to "orange". */
  color?: VacuumColor;
  /**
   * Entity IDs to watch. When any is cleaning, the badge shows
   * active glow. When all are idle, the badge is dimmed.
   */
  watch_entities?: string[];
  /** What to trigger on hold-to-activate */
  action: GlobalActionCall;
}

// ── Vacuum & card config ──────────────────────────────────────────────────

/**
 * Accent colour. Any hex string (e.g. "#52c41a") works. The three original
 * preset names — "green" / "blue" / "orange" — are also still accepted for
 * backward compatibility: existing configs using them keep their exact
 * original look (see `_color`/`_colorBg`/`_colorBgActive` in the card, and
 * `COLOR_HEX`/`COLOR_BG`/`COLOR_BG_ACTIVE` in const.ts).
 */
export type VacuumColor = string;

export interface VacuumConfig {
  entity: string;
  name?: string;
  image?: string;
  color?: VacuumColor;
  status_entity?: string;
  battery_entity?: string;
  last_clean_entity?: string;
  progress_entity?: string;
  base?: "image" | "map" | "combined";
  image_base?: ImageBaseConfig;
  /** Fixed base/stage height in px (controls card size). 0/undefined = auto. */
  base_height?: number;
  /** Overlay map opacity in combined mode (0-100). */
  overlay_opacity?: number;
  /** CSS mix-blend-mode for the map overlay in combined mode (e.g. 'lighten' to isolate the path). */
  overlay_blend?: string;
  /** Entity id of the AnyVac companion sensor (sensor.*_anyvac_map) for integration mode. */
  integration_entity?: string;
  /** Vacuum's clean-type role for the dry/wet layers; derived from clean_action if unset. */
  clean_type?: "dry" | "wet" | "both";
  /** Manual-mode setting presets (named "how" bundles). Legacy clean_action = presets[0] if unset. */
  presets?: SettingPreset[];
  /** Integration mode: hide the Roborock map image, show only the floorplan + vector robot/path. */
  hide_map?: boolean;
  /** Integration vector: path stroke colour (defaults to the vacuum colour). */
  path_color?: string;
  /** Integration vector: mop (wet) trace band colour (defaults to a wet blue). */
  mop_path_color?: string;
  /** Integration vector: mop band opacity 0-100 (default 28). */
  mop_band_opacity?: number;
  /** Integration vector: mop band width, percent of default (default 100). */
  mop_band_width?: number;
  /** Integration vector: path stroke width, percent of default (default 100). */
  path_width?: number;
  /** Integration vector: draw the configured robot image (vac.image) as the map marker. */
  robot_image_on_map?: boolean;
  /** Integration vector: robot image size, percent of default (default 100). */
  robot_size?: number;
  /** Integration vector: extra rotation (deg) added to the robot image to correct its orientation. */
  robot_image_rotation?: number;
  map?: MapConfig;
  rooms?: RoomConfig[];
  clean_action?: CleanAction;
  current_room_entity?: string;
  error_entity?: string;
}

export interface AnyVacCardConfig {
  type: string;
  vacuums: VacuumConfig[];
  /** Render one shared map with all vacuums (merged), or one map per vacuum (split, default). */
  map_mode?: "split" | "merged";
  /** Merged mode: shared custom floorplan, set once on the card (not per vacuum). */
  image_base?: ImageBaseConfig;
  /** Merged mode: shared card height. */
  base_height?: number;
  /** Merged mode: shared room list, defined once on the card (not per vacuum). */
  rooms?: RoomConfig[];
  /** Optional extra badges for whole-flat or cross-vacuum actions */
  global_actions?: GlobalAction[];
  /** Shared room overlay appearance — applies to all vacuums */
  room_border_normal?: number;    // border width when room is not selected, default 2
  room_border_selected?: number;  // border width when room is selected, default 4
  room_thresholds?: RoomThreshold[];
  room_icon_hidden?: boolean;     // hide all room overlay icons globally
  /**
   * Global room-key → HA area_id mapping for native-area strategy.
   * Defined once here; all vacuums share it.
   * Per-room area_id overrides this when set.
   */
  area_mappings?: Record<string, string>;
  /** Controller surface: "auto" = single orchestrated controller, "manual" = per-robot controllers. Default auto. */
  ui_mode?: "auto" | "manual";
  /** Rotate the map to portrait: "auto" (default, on narrow card width) / "always" / "off". */
  mobile_rotate?: "auto" | "always" | "off";
  /** Card-level targeted cleans for Auto mode (orchestrated across robots). */
  global_presets?: GlobalPreset[];
  /** Default orchestrator policy (overridable per global preset). */
  orchestrator?: OrchestratorPolicy;
  /** Debug: draw a per-room cleaning-progress gauge on the map (reads the integration's
   *  rooms_progress). Off by default — a testing aid, not for everyday cards.
   *  Independent of `debug_dense_dock` below (docs/25 §7e, split 2026-07-24 —
   *  a user relying on this for coverage debugging still gets the minimalist
   *  portrait cockpit; the map gauges this flag draws are dock-independent). */
  debug_room_progress?: boolean;
  /** Debug: portrait-only, brings back the pre-docs/25 dense room list (age/pin/
   *  assigned-vacuum per row) below the map instead of the minimalist map-tap-only
   *  cockpit (docs/25 §7c/§7e). Off by default. Landscape's dock/picker sidebar
   *  (docs/18/19 A5) is unaffected either way — it always shows the room list. */
  debug_dense_dock?: boolean;
  /** Two-profile percentage-grid layout (docs/18). Omitted = today's stacked
   *  render, unchanged. Present = the card becomes a viewport-sized grid with
   *  named regions placed per portrait/landscape profile. */
  layout?: LayoutConfig;
  /** Show debug details (raw geometry readouts etc.) in the production grid UI.
   *  Off by default (docs/18 §7c) — debug data moves behind this toggle. */
  debug?: boolean;
  /** Visual theme (v1.2.0, docs/35). "dark" (default) / "light" / "auto"
   *  (follows prefers-color-scheme) / "legacy" (the exact pre-1.2.0 look). */
  theme?: CardTheme;
  /** Accent colour driving START, room selection and focus rings. Any hex; the
   *  editor offers curated presets (`ACCENT_PRESETS`). Deliberately does NOT
   *  touch status colours — those stay semantic (docs/25 §6, docs/35 §3). */
  accent?: string;
  /** Resting ("calm") presentation when nothing is running and nothing is
   *  selected: the map's leftover trace and the secondary metadata step back so
   *  the primary action is the one thing that reads. Nothing is hidden or
   *  disabled — purely de-emphasis (docs/35 §7). Default on; `false` opts out. */
  calm_state?: boolean;
  /** Opt out of the v1.2.0 press/breathe micro-interactions independently of
   *  the theme. `prefers-reduced-motion` already disables them at the OS
   *  level — this is for people who want them off regardless (docs/35 §5). */
  reduce_motion?: boolean;
}
