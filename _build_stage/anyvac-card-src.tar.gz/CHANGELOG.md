# Changelog

All notable changes to this project are documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.11.4] - 2026-09-18

### Added

- **Align mode: rotation-aware direction arrows on the gizmo, for Scale X/Y
  and Offset X/Y** (field report 2026-09-18). The four side handles (Scale
  X = west/east, Scale Y = north/south) now carry an arrow icon AND a
  matching resize cursor (`ew`/`ns`/`nwse`/`nesw`) that rotate together
  with the seat's own `rotation` — at 90° the "Scale X" handles sit
  top/bottom on screen and now visibly (and cursor-wise) read as a
  vertical drag instead of misleadingly still looking horizontal. Two new
  small hint arrows near the gizmo's centre label Offset X/Y the same way
  — but stay wrap-aligned (NOT seat-rotated), since `offset_x`/`offset_y`
  are wrap-relative positions, not the seat's own local axes, unlike
  scale. New test coverage in `tests/align-overlay.spec.ts`.

## [1.11.3] - 2026-09-18

### Fixed

- **Align mode: keyboard nudges could get permanently stuck once any
  side-panel field (e.g. a layer-opacity slider) took keyboard focus**
  (field report 2026-09-18, following the opacity sliders added earlier
  today — adjusting one to see the floorplan at all was enough to trigger
  this). Two causes, both fixed:
  - `_alignStartGesture`/`_alignBgPointerDown` call `preventDefault()` on
    their pointerdown, which also suppresses the browser's own default
    "clicking elsewhere blurs the focused input" behavior — so clicking or
    dragging on the canvas/gizmo again did NOT return focus either. Both
    now explicitly return focus to the overlay root first
    (`_alignRefocusOverlay`, also reused by the opacity sliders' `change`
    so releasing one hands keyboard control straight back without an extra
    click, and by the open-time autofocus which had the same logic
    inlined).
  - The keydown handler's `inField` guard blocked ALL nudge keys while any
    `<input>` had focus, including `,`/`.`/`[`/`]` (scale/rotation), which
    have no native meaning in a number/range field and never needed
    blocking — only the arrow keys, which a focused field's own
    caret-move/step/slider-drag genuinely wants for itself, are still
    deferred to native behavior now.

## [1.11.2] - 2026-09-18

### Added

- **Align mode: independent (anisotropic) corner-handle scale, an X-axis
  stretch primitive, and side (edge) handles (docs/41 §4.4, field report).**
  Corner handles previously stayed aspect-locked even with "Independent Y
  scale" checked (always uniform `scaleSeatAbout`) — they now unlock into a
  true independent X/Y drag once that box is on, via a new
  `scaleSeatCornerAniso` primitive that reduces to the exact uniform path
  when X/Y factors match, and otherwise decomposes the drag onto the seat's
  own rotated local axes while keeping the opposite (pivot) corner fixed on
  screen (proven algebraically and cross-checked in
  `tests/seat-edit.spec.ts`). Closed a second gap alongside it: the seat
  model only ever had a Y-axis stretch primitive (`stretchSeatY`) — added
  the missing `stretchSeatX` counterpart, and four new side handles (top/
  bottom/left/right edge midpoints) so a single-axis stretch no longer
  requires the corner gizmo at all. The "Scale" side-panel field now reads
  "Scale X" once Independent Y is on, since `scale` already *is* the X
  value — there's no separate `scale_x` in the data model, just a clearer
  label for what was already there. New unit tests (pure geometry,
  independently cross-checked) and E2E coverage in
  `tests/align-overlay.spec.ts`.

## [1.11.1] - 2026-09-18

### Added

- **Align mode: adjustable floorplan/raw-map layer opacity (docs/41 §4.2/§4.3
  `layers.floor`/`layers.rawMap`, field-report fix).** Two range sliders in
  the side panel ("Floorplan" / "Vacuum map", 0-100%) live-drive the two
  `<img>` layers' opacity so both can be seen through each other while
  aligning — the edited vacuum's raw map previously rendered fully opaque
  with no way to see the floorplan underneath it, which on a real calibrated
  setup (existing large `scale` covering most of the canvas, combined with a
  vacuum map that is itself mostly a flat, low-detail colour) could make the
  floorplan appear completely hidden behind what looked like a solid colour
  block. View-only preference — not written to history/future (no undo) and
  not gated by the read-only home-frame state. `AlignSession.layers` already
  carried the `floor`/`rawMap` numbers from Phase A; this wires them into the
  render for the first time. New test in `tests/align-overlay.spec.ts`.

## [1.11.0] - 2026-09-18

### Added

- **Align mode, Phase A (docs/41 §7): pure gesture math for manual floorplan
  seating, card-side only — no UI wiring yet.** New `src/seatedit.ts` module
  (no Lit/HA dependencies, per docs/14 rule 1 — one geometry implementation,
  reused rather than duplicated):
  - `seatToMatrix(seat, wrapW, wrapH, NW, NH)` — the seat transform as a
    `DOMMatrix`, algebraically derived from the same formula `seatfit.ts`'s
    private `seatProjectPct` already uses to place `.map-img`/overlay SVGs,
    so a future overlay can predict on-screen positions without a second
    geometry path.
  - `translateSeat`, `scaleSeatAbout`, `rotateSeatAbout`, `stretchSeatY` —
    pivot-preserving edits for drag/pinch/stretch gestures.
  - `pinchSeat` — two-pointer (touch pinch or two-point click) similarity
    solve via complex-number division, recovering rotation+scale+offset from
    a before/after point pair.
  - `nudgeOffset` (screen-direction aware), `nudgeRotation`, `nudgeScale`,
    `snapRotation` — keyboard nudge helpers for the future overlay's numeric
    controls, per docs/41 §4.4.
  - `seatToYaml` — formats a `SeatParams` as a config-shaped YAML snippet,
    rounded to 0.01 (docs/41 §5 bod 4, the document's own recommendation,
    adopted here since it's Phase A code).
  - `applyFloorplanSeats` — applies a `FloorplanSeats` override layer
    (docs/41 §4.6 shape) onto a card config, correctly following
    `resolveImageBaseSrc`'s existing merged-vs-split resolution rules
    instead of re-deriving them.
- **`computeSeatFit` gains an optional third parameter**,
  `opts?: { snapRotation?: boolean }` (default `true`, unchanged existing
  behaviour). Auto-fit from named room anchors keeps snapping to 90° as
  before; Align mode's future click-based point-pairing tool (Phase E) will
  opt out with `{ snapRotation: false }`, since two robots — or a
  hand-photographed floorplan — can legitimately sit a few degrees off from
  each other. Per docs/41 §5 bod 2 (the document's own recommendation).
  Only the ≥2-anchor branch is affected; the 1-anchor fallback has no
  continuous rotation signal to snap or not (it only tests the four
  axis-aligned orientations against bbox ratios). `seatFromFrame`'s
  whole-degree rounding is untouched — out of scope for this phase.
- New `tests/seat-edit.spec.ts` (26 tests): unit tests for every
  `seatedit.ts` export, plus a DOM ground-truth check — mounts the real card
  (split mode, `mobile_rotate: "off"` to isolate per-vacuum seat from the
  unrelated ambient `.avc-rot` display-rotation wrapper) and compares
  `seatToMatrix`'s predicted position against the actually-rendered
  `.map-img` box, at 4 seats (including negative rotation and an
  anisotropic `scale_y`) × 3 content points each.

Full suite: 128/128 (102 pre-existing, no regressions; 26 new — 22 unit +
4 DOM ground-truth — for this phase).
`tsc --noEmit` reports 25 pre-existing errors, all in `anyvac-card.ts`/
`editor.ts` (zero in `seatedit.ts`/`seatfit.ts`), reproducible identically
against this repo's own committed `node_modules` with zero changes from
this session — `tsconfig.json`'s `moduleResolution: "node"` doesn't consult
`lit@3.3.3`'s package.json `exports["."].types` (only `node16`/`nodenext`/
`bundler` resolution do), so `lit`'s types resolve to `any`, cascading into
the `LitElement` member-access errors. Pre-existing, environment-independent,
and out of Phase A's scope — noted here rather than touched.

- **Align mode, Phase C / Krok 2 batch "C2a" (docs/41 §7): portal shell,
  entry point, and a basic transform gizmo — the first visible UI for Align
  mode.** Krok 1 (this session's live stacking test against the user's real
  HA instance, confirming the `document.body`-portal approach) is recorded
  in docs/41 §5 bod 1, not here (no source change).
  - New `src/align-overlay.ts`: a bare custom element
    (`<anyvac-align-overlay>`) that mounts itself onto `document.body` with
    its own shadow root, adopting the card's own `static styles`
    (`adoptedStyleSheets` — one stylesheet, not a forked copy, docs/14 rule
    1) plus a small allowlist of HA custom properties copied from the
    card's host element. It owns no UI of its own — "portal je jen
    hostitel + styly" (docs/41 §4.1) — the card's own new `updated()` logic
    Lit-`render()`s `_renderAlignOverlay()`'s template straight into the
    portal's shadow root.
  - `seatedit.ts` gains the Align-session data types from docs/41 §4.2
    (`AlignViewState`, `AlignTool`, `AlignSession`, plus
    `defaultAlignView`/`defaultAlignLayers`) — still Lit/HA-free.
  - `types.ts`: new `AnyVacCardConfig.align_mode?: boolean` (default on;
    `false` hides the entry button — kiosk tablets, docs/41 §4.7).
  - New "Align" entry button (`mdi:vector-square-edit`) in both the
    landscape meta bar and the portrait `.dock-layers` row, next to "Flip
    map". Gated exactly per docs/41 §4.7: `resolveImageBaseSrc()` resolves a
    floorplan for at least one shown vacuum, that vacuum's integration
    sensor exists (`_intAttrs`), and `align_mode !== false`.
  - Opening the overlay captures the vacuum's current effective seat
    (`_effectiveSeat`, auto-fit or manual, whichever is showing) exactly
    once into `AlignSession.start`/`draft` — the overlay never reads
    `_effectiveSeat`/`_seatMemo` again for the rest of the session (docs/41
    risk #5); the draft is edited independently and is NOT saved anywhere
    yet (see "Not in this batch" below).
  - Scene: the floorplan image, the edited vacuum's raw map + integration
    overlay (`_renderIntegrationOverlay`, paths + robot marker) seated from
    the draft, and ghost (25% opacity, non-interactive) copies of any other
    vacuum sharing the same floorplan.
  - View transform — pan/zoom/rotate-of-VIEW — is a completely separate
    piece of state (`AlignViewState`/`_alignView`) from the seat being
    edited (docs/41 risk #4): mouse-wheel zoom (viewport-centred, not yet
    cursor-anchored), background drag to pan, and a "Rotate view 90°"
    toolbar button. Never persisted; resets every time the overlay opens.
  - Gizmo: drag the layer to translate; 4 corner handles to uniform-scale
    about the opposite corner; 1 rotation handle to rotate about the
    layer's own centre; a second touch pointer on the layer upgrades a drag
    to a two-finger pinch (translate+rotate+scale at once). All four wired
    directly onto the already-shipped `seatedit.ts` primitives
    (`translateSeat`/`scaleSeatAbout`/`rotateSeatAbout`/`pinchSeat`) — no
    new geometry math, per docs/14 rule 1. Pointer-to-content conversion
    (`_alignPointToWrapPct`) follows the same `DOMMatrix`-inverse approach
    `_clickToContent` already uses for Pin & Go/Zone clicks; corner/rotate
    handle positions reuse the shared `seatToMatrix` primitive rather than
    a second projection formula.
  - Backend override merge, card-side: `setConfig()` now keeps the
    as-authored config in a new `_rawConfig` field; a new
    `_syncEffectiveConfig()`, called at the very top of `shouldUpdate()`
    (before `_watchedEntities()`/`_roomsFor()`, which already run inside
    `shouldUpdate` — see the existing `_memoSync` doc comment), recomputes
    `_config = applyFloorplanSeats(_rawConfig, floorplan_seats)` — JSON-
    diffed against the previous effective config so an unrelated `hass`
    update never forces a spurious `_config` identity change — and clears
    `_roomsMemo`/`_seatMemo` only when the merge actually changed something
    (docs/41 §4.6). The card doesn't yet expose any UI that WRITES an
    override back to the backend (no Save) — this batch only makes the
    card correctly *display* whatever a future Save (or another dashboard,
    or a future editor Adopt) has already written.
  - **Not in this batch (Krok 2's "C2b", per the user's explicit
    two-batch split):** numeric side-panel fields (rotation/scale/offset),
    keyboard nudges, undo/redo, the Save/Reset/Cancel/Copy-YAML action row
    (only a bare, unstyled "×" close button exists for now, so the overlay
    can be opened and closed at all — closing discards the draft
    unconditionally, no confirmation), integration-version degradation
    handling (`hass.services` availability check), and
    `tests/align-overlay.spec.ts`. Also simplified relative to docs/41
    §4.3's full scene: no live per-room bounding-box rectangles
    (`roomBboxToRect` against the draft) and no static config-room
    reference rectangles in the overlay yet — only the integration's own
    paths/marker overlay. Shift-to-snap-90° during a rotate gesture is not
    wired up (`AlignSession.snap90` exists in the data model but nothing
    sets it yet). Cursor-anchored wheel zoom is simplified to
    viewport-centred. A `base_height`-configured card (fixed pixel map
    height rather than floorplan-aspect-driven) will show the integration
    overlay (paths/marker) at a slightly different aspect ratio than the
    rest of the Align scene, since `_renderIntegrationOverlay` internally
    resolves its own aspect via `_wrapAspect()`/`_cardW`, not a parameter
    the overlay can override — the common case (no `base_height`) is
    unaffected since both resolve to the same `_mapAR`.

- **Align mode, Phase C / Krok 2 batch "C2b" (docs/41 §7): numeric side
  panel, keyboard nudges + a touch-friendly step-tier toggle, undo/redo,
  the full Save/Reset/Cancel/Copy-YAML toolbar with a Cancel confirmation
  panel, and home-frame read-only degradation — the overlay is now
  actually usable end-to-end, not just openable.** Also fixes a C2a bug
  that silently broke every gizmo gesture (see "Fixed" below).
  - Numeric side panel (docs/41 §4.3): rotation/scale/offset_x/offset_y
    fields plus an "Independent Y scale" checkbox that reveals a fifth
    `scale_y` field, bound to the draft via `_alignSetField`/
    `_alignToggleScaleY`. Committed on `change` (blur/Enter), not `input`
    — one history entry per typed value, matching the existing
    one-entry-per-gesture/per-keyboard-burst convention, not one per
    keystroke.
  - Keyboard nudges (docs/41 §4.4): arrows = offset (0.1%), `[`/`]` =
    rotation (0.5°), `,`/`.` = scale (0.5%) — `,`/`.` deliberately replace
    the doc's original `+`/`-` proposal, which collides with the browser's
    own `Ctrl+Plus`/`Ctrl+Minus` zoom shortcut. A new persistent, visual
    step-tier toggle (Jemně/Krok/Skok — fine/normal/jump, ×0.1/×1/×10,
    `AlignSession.nudgeTier`/`_alignSetNudgeTier`) is click-driven (touch-
    accessible, no keyboard needed) and can be momentarily overridden by
    holding Ctrl (fine) or Shift (jump) without changing the toggle's own
    selection (`_alignEffectiveNudgeTier`) — chosen after Ctrl/Shift-modified
    arrow/WASD schemes were both ruled out for colliding with browser/OS
    shortcuts (`Ctrl`+arrows history nav on some platforms, `Ctrl+W/A/S/D`
    close-tab/select-all/save-page/bookmark, `Ctrl+Plus/Minus` zoom).
  - Undo/redo (`_alignUndo`/`_alignRedo`, `Ctrl+Z`/`Ctrl+Y`, guarded off
    while focus is in a numeric side-panel field so normal text-undo isn't
    hijacked): one history entry per gesture (pushed in
    `_alignStartGesture`) or per keyboard-nudge burst (gated on
    `!e.repeat`), never per pointermove/repeat-keydown.
  - Toolbar: Save (disabled + tooltip when
    `hass.services.anyvac?.set_floorplan_seat` is missing — docs/41 §4.8),
    Reset (`_alignReset`, back to the session's `start`), Copy YAML
    (`_alignCopyYaml`, clipboard write of `seatToYaml(draft)` with a
    "Copied!" flash), and Cancel — the `×` button and `Escape` both now
    route through `_alignCancel()`, which shows an in-overlay confirmation
    panel (`_alignCancelConfirm`, "Discard"/"Keep editing") whenever the
    draft differs from `start` (`_alignHasChanges`), instead of always
    discarding silently as in C2a.
  - Home-frame degradation (docs/41 §4.8 MVP): a home-frame-registered
    vacuum (`_homeFrameCropFor`) opens Align mode as a read-only ghost —
    gizmo/keyboard nudges/numeric fields/Reset/Save all no-op
    (`_alignReadOnly`, checked once and reused everywhere rather than
    re-derived per call site) — with an "aligned by home frame — nothing
    to adjust" note over the seat layer. Full home-frame editing is Phase G.
  - `tests/align-overlay.spec.ts` (6 new tests, docs/41 §7's named
    coverage): portal-on-`document.body`, a drag moves the draft by the
    expected wrap-percent delta (this is the test that caught the Fixed
    bug below), `Save` sends the draft as the `map` payload 1:1 rounded to
    0.01, a backend `floorplan_seats` override wins over the card's own
    manual seat (and Align mode's `start`/`draft` are captured from that
    same merged seat), `Reset` restores `start`, and `Save` is a disabled
    no-op without the service.

### Fixed

- **Align mode: every gizmo gesture (drag/scale/rotate/pinch) silently
  no-opped — a C2a bug, caught while writing C2b's
  `tests/align-overlay.spec.ts`.** `_alignPointToWrapPct` looked up
  `.align-scene` via `this.renderRoot` (the CARD's own shadow root), but
  the overlay renders into the `_alignHost` PORTAL's shadow root (docs/41
  §4.1) — the query always returned `null`, so `_alignStartGesture` bailed
  before doing anything, on every pointer type, at every zoom/pan/rotation.
  The overlay looked interactive (gizmo handles rendered, cursor changed)
  but nothing actually moved. Fixed by querying
  `this._alignHost?.shadowRoot` instead, matching the (already-correct)
  autofocus lookup in `_openAlign`.

### Planned

## [1.10.2] - 2026-09-17

### Changed

- **Horizontal/vertical slider labelling, extended and made correctable.** Field report:
  1.10.1's "horizontal"/"vertical" relabelling for the two Scale sliders only accounted for
  a vacuum's own `rotation` — but the card also auto-rotates its *whole* map area 90° to fit
  a narrow card box (`_mapRotationDeg()`, independent of any vacuum's `rotation`), and Home
  Assistant's own card-config dialog renders its live preview in a box of whatever width
  *that dialog* happens to use — which is not always the width the same card renders at on
  the real dashboard. So the dialog's preview and the real dashboard can legitimately pick
  different auto-rotations and disagree on which way is "horizontal", which is exactly what
  was reported ("horizontal controls vertical and vice versa") even with `rotation` at a
  value that shouldn't have triggered any swap. There is no way for the editor — a separate
  component from the live card, with no visibility into the real dashboard's width — to
  detect this reliably, so instead: a new **"Swap ↔/↕" toggle** at the top of the Maps tab
  lets the user correct every ↔/↕ label in the tab at once, by eye, against their real
  dashboard (never saved to config — editor-only UI state).
- **The same ↔/↕ relabelling now covers every X/Y pair in the Maps tab**, not just Scale:
  Offset X/Y, Image offset X/Y (`image_base`), and Room position (X/Y) and size (Width/
  Height). Offset-like fields (screen frame, set before any local rotation) swap only with
  the new toggle; Scale (the robot's own local, pre-rotation axes) swaps with the toggle
  *and* independently with `rotation`, same as before, so the two can cancel out correctly
  when both apply. Stored config keys and their meaning are unchanged in every case — only
  the editor's presentation adapts.

Full suite: 102/102, no regressions (no new geometry — this is editor label/wiring only,
built on the already-tested `isRot90` helper).

## [1.10.1] - 2026-09-17

### Fixed

- **`scale_y` no longer distorts the robot marker/icon into an ellipse.** The integration
  overlay (robot marker + cleaning path) draws in one `<svg viewBox>` that gets the seat's
  full CSS transform, `scale_y`'s extra Y-only `scale(1,r)` included — correct for the path
  and rooms (the whole point), but it also squashed the robot dot/image, which should stay
  visually undistorted. The marker sub-tree now gets a counter-scale by the reciprocal ratio,
  anchored at the robot's own position, so it renders correctly proportioned regardless of
  `scale_y` while the path/room geometry still stretches as configured.

### Changed

- **The Map seating editor's two Scale sliders are now "horizontal"/"vertical", not "X"/"Y".**
  Field report: `scale`/`scale_y` are stored as the robot's own LOCAL axes (the only frame
  simple at any angle), but a person aligning a map by eye thinks in what's on screen — and at
  90°/270° rotation those disagree (local X ends up as the floorplan's *vertical* extent).
  The two sliders now relabel themselves "Scale ↔ (horizontal)" / "Scale ↕ (vertical)" and swap
  which of `scale`/`scale_y` each one reads and writes, based on the current Rotation — so the
  slider labelled "horizontal" always does what it says. The stored config keys and their
  meaning are unchanged (`scale` is still local-X, `scale_y` still local-Y) — only the editor's
  presentation adapts.

New tests: `tests/rect-drag.spec.ts` gains 3 cases for the new `isRot90`/`seatScaleYRatio`
helpers (extracted from `roomBboxToRect`/`seatRotateScaleCss` so the axis-swap test and the
ratio-guard are each defined once, shared by the editor's slider relabelling and the marker
counter-scale). Full suite: 102/102 (99 + 3 new, no regressions).

## [1.10.0] - 2026-09-15

### Added

- **Independent Scale X / Scale Y for manual map seating** (`vacuums[].map.scale_y`) —
  a "Scale Y" slider now sits next to Scale (renamed "Scale X") under Map seating's
  manual sliders. Field report: even a floorplan built precisely in a floorplanner app
  can still disagree with the robot's own raw map proportions (the robot's pixel grid
  isn't necessarily square relative to real-world units) in a way one uniform `scale`
  can't correct. `scale_y` stretches the robot's map along its own local Y axis,
  independently of `scale`'s X axis, *before* `rotation` turns the whole thing into
  place — so at 90°/270° rotation, Scale X/Y end up affecting the floorplan's
  vertical/horizontal extent respectively, not the other way round (they're the
  robot's own axes; rotation is a separate, later step). Undefined `scale_y` (every
  config written before this existed) renders byte-identically to before — this is a
  pure opt-in addition, not a behavior change. Applies everywhere a per-vacuum seat is
  drawn: the map image itself, the robot marker + cleaning path overlay, and room-bbox
  placement (`roomBboxToRect`, used by the "Import missing rooms" button and the
  editor's own live preview) — one shared implementation, not several (docs/14 rule 1).
  Pin & Go / Zone clicks needed no change at all: they already invert the map layer's
  live CSS transform generically (`_clickToContent`'s `DOMMatrix` inversion), which
  handles an anisotropic scale just as correctly as a uniform one.

New tests: `tests/rect-drag.spec.ts` gains 9 cases — `roomBboxToRect` with an
anisotropic seat (isotropic regression pin, Y-only resize, off-centre bbox
repositioning, and the 90°-rotation axis swap, hand-derived and verified against the
implementation) plus `seatRotateScaleCss`, the new small helper that builds the
`rotate()[ scale(1,r)]` CSS fragment shared by every seat-styled element. Full suite:
99/99 (90 + 9 new, no regressions from the `seatProjectPct`/`roomBboxToRect`
refactor).

## [1.9.1] - 2026-09-15

### Fixed

- **Seating sliders are now typeable, not just draggable** — Rotation / Scale / Offset X / Offset Y
  under "Map seating" (and every other slider field in the editor: image base transform, room
  position/size, overlay opacity, path width, clean-time estimates) now show an editable number
  input next to the track instead of a plain readout. Field report: with Scale spanning 20-800%
  or Offset spanning -150 to 150% on a track only a few hundred pixels wide, one drag step moves
  the value by several percent — too coarse to land a precise manual seat. Typed values are
  clamped to the field's min/max but not snapped to its slider `step`, since typing an exact
  number is the point. Commits on blur or Enter, same as the other text fields in the editor.

## [1.9.0] - 2026-09-14

Paired with integration 1.10.0. Docs/40 §5.A.2 — a third, zero-click way to
populate `image_base.home_anchors`, alongside cesta A's identity crop and
1.8.0's manual N-point calibration. Detail: docs/40 §5.A.2.

### Added

**"Fiducial markers" editor flow** (Maps tab, merged mode, positioned as a
last resort below manual calibration): step 1, "Snapshot home frame with
markers" (`_snapshotHomeFrameWithFiducials`), calls
`anyvac.snapshot_map_as_floorplan` with `fiducials: true`, sets the result
as the floorplan `src` and remembers where each marker was placed
(`_fiducialKnown`) — unlike the plain snapshot button, it does NOT record a
`crop_box`, since the whole point is that the file gets edited externally
afterwards. Step 2, "Detect markers in edited file"
(`_detectFiducials`), calls the new `anyvac.detect_floorplan_fiducials`
with that same marker list against the CURRENT `image_base.src` (however
it's since been cropped/resized/rotated), and writes whatever comes back
straight into `image_base.home_anchors`/`home_anchors_frame_id` — the
EXACT same config shape 1.8.0's manual calibration produces, so
`_renderHomeAnchorOverlay`, Pin&Go/zone inversion and room rendering need
zero changes to support this (docs/14 rule 1). Also turns `hide_map: true`
on for every vacuum, same as the other snapshot buttons.

Deliberately the last option offered in the UI, gated behind the same
`!homeFrameCrop && this._anyHomeFrame()` condition as manual calibration —
this only works if the file's alpha channel survives whatever editing
happens to it externally (a flattened image, or one re-exported as JPEG,
loses the markers), which is exactly the "cheap hack" framing the original
docs/40 ratification gave this feature.

No new Playwright coverage for the editor flow itself, consistent with
existing project precedent (the sibling docs/39/§5.B calibration flows have
never had UI-level tests either — both new methods are thin wiring around
already-tested primitives: the backend services themselves, and
`_setEditedImageBase`/`_setConfig`, both exercised elsewhere). Full suite:
90/90 (no regressions — the new code is additively gated and never runs in
any existing test's config).

## [1.8.0] - 2026-09-14

Paired with integration 1.9.0. Docs/40 §5.B ("cesta B" — calibrating a foreign-origin
floorplan against the home frame), delivered alongside the backend's own snap-to-wall-corner
support (integration 1.9.0). Detail: docs/40.

### Added

**N-point calibration of a foreign-origin floorplan (photo/drawing) against the home frame.**
New editor flow ("Calibrate floorplan against home frame", Maps tab, merged mode) mirrors the
existing docs/39 N-point calibration closely, with three differences: the state is card-level,
not per-vacuum; clicks on the frame side go through an on-demand scratch snapshot
(`anyvac.snapshot_map_as_floorplan` with `frame:"home"`, never saved to `image_base`) with each
click snapped to the nearest wall corner via the new `anyvac.snap_wall_corner` service (falls
back to the raw click on a service error, so a click is never lost); and what gets saved is the
raw clicked pairs `image_base.home_anchors: {home_px, floor_pct}[]` (+ `home_anchors_frame_id`),
not a solved seat.

**`homeAnchorFit(anchors, frameDims, ar)` / `projectHomePxThroughFit` /
`unprojectPctThroughFit` (exact inverse) / `outlineThroughFit`** (seatfit.ts) — the fit is
recomputed live against the home frame's *current* canvas size on every render, so calibration
self-heals as the frame's canvas grows (the robots exploring further) without asking the user
to re-click anything. `_renderHomeAnchorOverlay` (anyvac-card.ts) draws through an SVG viewBox
`0 0 100 (100/ar)` with `preserveAspectRatio="none"`, and reuses `roomBboxToRect`/
`outlineThroughFit` with reshaped inputs for rooms — the same functions cesta A (home-frame
identity crop) already uses, so there is no second room-projection implementation (docs/14
rule 1). Pin & Go / zone clicks invert through `unprojectPctThroughFit`, same pattern as cesta
A's `pctToCropPoint`.

### Fixed

**Card-level memoization (`_roomsMemo`/`_seatMemo`, since 1.1.0) was keyed only on `hass`
object identity, never on `_mapAR`.** Both `_effectiveSeat` and `_computeRoomsFor`'s anchor-fit
branch resolve `ar` via `_wrapAspect`, which falls back to `_mapAR` whenever `base_height` isn't
configured — and `_mapAR` only learns the floorplan's real aspect ratio asynchronously, off the
base image's own `load` event, completely independently of `hass` changing. A room computed
before that `load` fires would cache its geometry at the fallback 3.636 ratio forever. Masked in
real HA usage because `hass` is replaced almost every poll (an accidental self-correction, not a
real fix); fully exposed by `tests/home-anchor-render.spec.ts`, whose single static `hass`
object never changes again after mount. Fixed by adding a `_memoMapAR` field, invalidating the
memo on either `hass` or `_mapAR` changing.

New tests: `tests/home-anchor-fit.spec.ts` (6 — `homeAnchorFit`/projection/inverse, pure
function), `tests/home-anchor-render.spec.ts` (6 — viewBox, marker, room rect/outline, Pin&Go,
zone; all expected values hand-derived from the fixture geometry, not checked against the
card's own code). `CONFIGURATION.md` updated (`home_anchors`/`home_anchors_frame_id` table
rows, new "Cesta B" section, new service row). Full suite: 90/90 (77 + 13 new).

## [1.7.1] - 2026-09-14

Paired with integration 1.8.1 (unchanged — card-only release). Docs/40 §5.A.1: hardening the
home-frame canvas-mismatch check, the piece the user picked from Fáze 3's deferred list. Detail:
docs/40 §5.A.1.

### Added

**`canvasScaleForCrop(nat, crop)`** (seatfit.ts, shared by both `crop_box` shapes) tells a real
crop-box mismatch apart from the saved floorplan PNG simply having been uniformly re-exported at
a different resolution (same aspect ratio within ±0.3%, different pixel size — the user opened
the file in an image editor and exported it at 2×, say). Returns `1` for a near-exact match
(today's ±2px absolute tolerance, unchanged), a derived scale for a matching aspect ratio, and
`null` for a genuine mismatch (a 351×1317 vs 352×1308 pair, whose aspect ratio differs by ~1%,
correctly still returns `null` — that's a real crop, not a rescale). Nothing downstream reads
the file's actual pixel dimensions (`pointInCrop` and friends always normalize against
`crop_box`), so this is purely editor-side diagnostics: `cropMismatch` and the new
`homeFrameCropMismatch` (editor.ts) now warn only on a genuine mismatch, showing a quiet
informational note ("File is a 2.00× export…") instead when a clean rescale is recognized. Now
covers BOTH `crop_box` shapes — previously only the legacy `{entity,…}` form had a mismatch
check at all; the home-frame `{frame_id,…}` crop had none (a gap left over from Fáze 3's core
scope, closed now).

5 new tests in `tests/rect-drag.spec.ts` (`canvasScaleForCrop`, including the exact 351×1317 vs
352×1308 example above). Full suite: 77/77 (72 + 5 new).

## [1.7.0] - 2026-09-14

Paired with integration 1.8.1 (registration heading fix landed the same day). Docs/40 Fáze 3 —
merged-mode rendering against the home frame. Detail: docs/40.

### Added

**Merged mode renders a home-frame-registered vacuum through one identity crop instead of a
per-vacuum fitted seat.** `_renderHomeFrameOverlay` (anyvac-card.ts) reads
`vacuum_position_home_px`/`path_dry_home_px`/`path_wet_home_px` through `pointInCrop`/
`outlineInCrop` (seatfit.ts) — no fit, no rotation; a vacuum in the same map that isn't
registered against the home frame automatically falls back to the existing per-vacuum seat.
Rooms draw from `bbox_home_px` (rectangle, via the existing `placeRoomInCrop` — unchanged
function) and, additively, a real outline from `outline_home_px` (`RoomConfig.outline_pct`) —
purely an extra layer over the rectangle, which stays the only click/select target. Pin & Go and
zones for a home-frame vacuum invert the click through `pctToCropPoint` and call
`goto`/`zone_clean` with `frame: "home"` plus `x_home_px`/`y_home_px` (or the zone corner
equivalents) — ambient display rotation (docs/32, `_mapRotationDeg()`) still applies, but the
per-vacuum seat inversion (`_unrotateDelta` via `.map-img`) drops out for this path. Config
`image_base.crop_box` becomes a union of the legacy `{entity,…}` shape and a new
`{frame_id,…}` shape, written automatically by the editor's "Snapshot home frame as floorplan"
button (calls `anyvac.snapshot_map_as_floorplan` with `frame:"home"`, sets `hide_map:true` on
every vacuum). Editor Maps tab simplified for a home-frame floorplan: the auto/manual seating
switch, calibration buttons and manual sliders are hidden, leaving just the registration status
line.

New `tests/home-frame.spec.ts` (7 scenarios: viewBox, marker, room/outline, Pin&Go, zone,
unregistered-vacuum fallback in the same map) — ground truth computed by hand from the crop
numbers, not checked against the card's own code. `CONFIGURATION.md` updated (`crop_box` union,
new "Home frame" section). Full suite: 72/72 (65 + 7 new).

## [1.6.2] - 2026-09-12

Paired with integration 1.4.0 (unchanged) — this release is card-only. Detail: docs/39 §9.

### Fixed

**Manual calibration click precision was capped by how narrow the editor's own
column renders, not by anything in the maths.** Field report: even careful,
well-separated clicks landed with a visible fit error, because the raw-map/
floorplan images were shown at whatever width the surrounding form column
happened to have (a few hundred px, sometimes less on mobile) — every screen
pixel of click imprecision there is several source-image pixels of real
error. The calibration flow now renders as a **fixed full-viewport overlay**
instead of inline in the Maps tab: same click-and-see-fit-error flow, just at
screen size instead of column size. The click math itself
(`_onCalibRawClick`/`_onCalibFloorClick`) is an unchanged ratio of the clicked
element's own on-screen rect, so this is a pure display change with zero risk
to the geometry — a bigger rect just means less real-world distance per
screen pixel of imprecision.

**The manual Scale/Offset X/Offset Y sliders under "Map seating" were capped
at 50–200% / ±50%**, which can't reach a seat a badly-fit auto-fit (or an
unusually cropped floorplan) genuinely needs — the calibration flow itself
was never limited by this (it writes `map.scale`/`offset_x`/`offset_y`
directly, bypassing the slider), but adjusting the result by hand afterwards
could hit the ceiling. Widened to 20–800% / ±150%.

### Note

Downscaling the map or floorplan image does **not** help click precision —
if anything it hurts, since it throws away exactly the pixel detail a
precise click needs. The full-viewport overlay above is the actual fix for
"the editor is too small to click accurately".

## [1.6.1] - 2026-09-12

Paired with integration 1.4.0 (unchanged) — this release is card-only. Detail: docs/39 §8.

### Fixed

**2-point calibration (1.6.0) left no slack to average out click imprecision.**
Field report: a careful, well-separated 2-point click still landed at ~4% fit
error — with exactly 2 points the least-squares fit has zero redundancy, so
any click a few pixels off gets read as if it *were* the true rotation/scale/
offset, with nothing to reveal it as noise. "Calibrate from 2 points" is now
**"Calibrate from clicked points"**: still 2 minimum, but each further point
(up to 6) feeds the *same* fit (`computeSeatFit` already least-squares-fits
any `anchors.length >= 2` — no new maths) and shows the live fit-error effect
of adding it, in the calibration banner itself, before anything is committed.
An **Undo point** button fixes a mis-click without restarting the flow, and a
**Save** button (shown once ≥ 2 pairs exist) commits whenever the user is
happy with the number. Added a regression test demonstrating the fix
directly: the same per-point click wobble, spread over 4 points instead of 2,
solves a seat measurably closer to the true one (`tests/seatfit-calibration.spec.ts`).

## [1.6.0] - 2026-09-12

Paired with integration 1.4.0 (unchanged) — this release is card-only. Detail: docs/39.

### Added

**"Calibrate from 2 points" — a one-time bootstrap for when auto-fit can't
converge on its own.** Auto-seating (docs/15) fits a vacuum's map onto the
floorplan from room anchors matched by name — but if the room rectangles
already drawn on the floorplan don't have the same width:height proportions
as a robot's real rooms, no amount of rotation/scale/offset tuning can fix
the fit (a similarity transform can't reconcile mismatched rectangle
*shapes*), and the resulting paths render far outside the visible floor —
the classic field symptom "no matter what I try, the paths leak through the
walls". The new button walks through 4 clicks: the same physical point
twice on this vacuum's own raw map, then the same two points on the
floorplan photo. Two point-pairs fully determine a similarity transform
(rotation + one uniform scale + offset), solved by the *exact same*
least-squares maths the room-anchor auto-fit already uses
(`computeSeatFit`, `seatfit.ts`) — just fed two clicked points instead of
name-matched room bboxes (`buildCalibrationAnchors`, new pure function,
unit-tested). The solved (not guessed) values are written as
`map.seat: "manual"`, so the existing "Import missing rooms" button can
then place every room correctly in one click — and once the floorplan's
anchors are accurate, every other vacuum's own auto-fit typically self-heals
too, with nothing else to configure.

Deliberately narrow in scope: this is a once-per-floorplan bootstrap that
hands off to the existing auto-fit/room-import pipeline immediately after
solving, not a persistent parallel calibration layer — distinct from the
old 3-point align tool removed when auto-seating (docs/15) was introduced.
Nothing about the calibration flow itself is saved to config; only its
result (a manual seat) is.

## [1.5.0] - 2026-09-12

Paired with integration 1.4.0 (unchanged) — this release is card-only. Detail: docs/38.

### Fixed

**Room rectangles jumped the instant a drag started.** The Maps tab's
pointer handlers wrote the cursor's absolute position straight into
`map_x`/`map_y`, so grabbing a rectangle anywhere off-centre snapped its
centre under the cursor immediately — by as much as the grab offset (up to
~250px on a large rectangle in a tall preview). Drag/resize math moved into a
new pure module, `rectdrag.ts` (`moveRect`/`resizeRect`, unit-tested in
`tests/rect-drag.spec.ts` without a browser): every move/resize is now
computed as a **delta from the pointer's position at drag start**, applied to
the rectangle's state at that same moment — never the pointer's absolute
position, and never an already-updated intermediate state (which would make
a resize's anchor corner itself drift mid-drag).

**Room geometry rounded to whole percent while the geometry it's compared
against (`placeRoomInCrop`/`roomBboxToRect`) writes at 0.1%.** 1% of a typical
floorplan is well over 10px — enough to show up as visible snapping while
dragging/clicking, and to keep the auto-fit's "fit error" hint stuck at ~2%
or more no matter how carefully a rectangle was placed by hand, since the
anchor itself could never land closer than a whole point. Dragging, resizing,
click-to-place, and the room X/Y/Width/Height sliders (step 1 → step 0.1) all
now round to one decimal place (`rectdrag.ts`'s `round1`).

**The native-map overlay in the Maps tab re-fit itself from the very
rectangle being dragged, making it a moving target.** Dragging a room
rectangle is meant to align it against this translucent reference — but every
pointermove wrote into `_config`, and the overlay's seat fit read `_config`
live, so the thing being aligned against moved on every frame right along
with the rectangle chasing it. The seat fit used for the overlay `<img>` is
now captured once at pointerdown and held there for the whole drag; the "✅
Auto-fit from N rooms…" text hint keeps updating live throughout (it's
informational, not something being visually aligned against), and the
overlay re-fits for real the moment the drag ends.

### Added

**`image_base.crop_box`** — records the exact pixel crop (same coordinate
space as the integration's `rooms[].bbox_px`) and vacuum a floorplan image
came from. Written automatically by "Use this vacuum's current map as
floorplan" (when the integration reports one, ≥ 1.5.0) and by a new **"Use
this crop for the floorplan"** button after exporting guide layers. Read back
by a new **"Place rooms from crop box"** button (Maps tab, Custom floorplan
helper section) — re-derives the crop's own vacuum and places every one of
its rooms directly onto that exact crop (`placeRoomsInCrop`, seatfit.ts: pure
px→% re-normalisation, no fit/rotation ambiguity, same principle as the
existing single-room `placeRoomInCrop`) — and by "Export guide layers", which
now sends the current `crop_box` along (when it matches the vacuum being
exported) so guide layers line up with the saved floorplan file even if the
robot has remapped since. A **"Clear"** link removes the crop box, and a
size-mismatch warning appears when the floorplan file's actual pixel
dimensions no longer match the crop box's (e.g. a re-exported or hand-swapped
image file).

Existing rooms placed this way keep every other field (icon, thresholds,
clean-time overrides) — only the geometry (`map_x/y/w/h`) is overwritten,
since a new crop means new geometry but not a new icon.

## [1.4.0] - 2026-09-10

Paired with integration 1.4.0.

### Added

**"Export guide layers" — a tracing aid for building a custom floorplan by
hand.** New button in the Maps tab's Shared floorplan section ("Custom
floorplan helper"), right below "Use this vacuum's current map as floorplan":
calls the new `anyvac.export_map_guide` (integration ≥ 1.4.0) and, on success,
lists links to the produced PNGs plus the canvas size. The service draws room
boundaries and the vacuum's last dry/wet path as transparent layers, cropped
to the exact same box the floorplan snapshot button already produces — open
them over that photo in any image editor, and the gaps inside the drawn path
are where furniture stands. Pure drawing aid: unlike the snapshot button, this
never touches card config — no `image_base`, `hide_map`, or `rooms` change.
Detail: docs/37.

## [1.3.2] - 2026-09-07

### Fixed

**The Dock sheet's debug strip showed `features: [object Object]`.**
`dock_status` was all scalars until 1.3.0 added the nested `features` and
`running` objects, and the strip stringified every value with `String(val)` — so
the two fields worth looking at were the two it could not show. Nested objects
are now flattened one level into `features.is_washable`-style rows.

Their `false` and `null` entries are deliberately kept, unlike the top-level
scalars: for a capability flag "reported false" and "not reported" are different
answers, and telling them apart is the entire reason to open this view.

### Notes

Verified live against the reporting user's four vacuums on HA 2026.9.1 while
fixing this — capability reporting is correct on all of them: S6 `has_dock:
false` (it has no dock, so offering no dock actions is the right answer, and that
is what the screenshot behind this report was actually showing), both S7s
`is_collectable` only, S8 MaxV Ultra all four true. `dock_status.running.wash`
read `true` while that dock really was washing (raw state `washing_the_mop`
behind a `docked` vacuum entity, docs/14 rule 4), so 1.3.0's start/stop toggle is
confirmed on real hardware.

The `features`-vs-`dock_type` reconciliation considered for a possible stale
dock-type cache was NOT added: the two agree on every vacuum here, so there is
nothing to reconcile and no evidence the case occurs. Documented rather than
guarded against speculatively.

## [1.3.1] - 2026-09-03

### Fixed

**Pin & Go and Zone work again on a rotated map.** They had been greyed out with
"Not available while the map is rotated" — a deliberate guard from `docs/13` A5,
because the click inversion undid the map image's own seat transform but not the
`.avc-rot` wrapper the responsive layout puts around it. That guard was written
when only portrait ever rotated; `0.81.1` extended auto-rotation to landscape for
tall, narrow floorplans, and with it the guard, so a floorplan of roughly 1:4
turned both tools permanently off on every screen. Nothing logged an error and
the map looked normal — a tall floorplan rendered rotated is exactly the wide map
you expect to see — so the only symptom was two buttons that had quietly stopped
working.

The guard is gone; the geometry is fixed instead. `_mapRotationDeg()` is now the
single answer to "how far is the map actually turned" — 0, 90, 180 or 270,
folding in the manual flip (`docs/32`) and the fact that the renderer does not
rotate a map region it has not measured yet. The renderer, the on-map assign-chip
anchor and the click inversion all read it, so they cannot drift apart. Clicks
undo that ambient rotation (`_unrotateDelta`) before undoing the vacuum's own
seat matrix: `.avc-rot` applies a pure rotation plus a translate, and a delta
measured from the element's own centre is immune to the translate, so this is
exact rather than an approximation.

Zone drawing had a second, independent instance of the same class of bug: it took
percentages of `getBoundingClientRect()`, whose width and height are swapped at
90°/270° because it is the axis-aligned box of a rotated element. `_wrapPct` /
`_wrapPoint` use `offsetWidth`/`offsetHeight` — always the untransformed layout
box — together with the un-rotated delta.

The maths was verified live against a running dashboard before any of it was
written to source (monkey-patched into the loaded card, with the robot marker as
ground truth: 0.005% agreement), then pinned down in `tests/rotated-map.spec.ts`
— 16 tests across all four angles, checked to fail against the pre-1.3.1 code in
7 places while 0° passes both before and after. Playwright suite 26 -> 42. This
also gives 270° (auto-rotate plus flip) its first real verification; it had been
derived by symmetry and shipped unproven since `docs/32`.

## [1.3.0] - 2026-09-02

Paired with integration 1.3.0, which is where the Home Assistant 2026.9 analysis
landed. The card's share: the Dock sheet stops guessing what a dock can do, and
its three cycle buttons become toggles. New `tests/dock.spec.ts` covers both
(9 tests, Playwright suite now 26).

### Added

**Empty, Wash and Dry are now start/stop toggles.** All three are cycles the dock
ends on its own, and each has always had a stop command that nothing in AnyVac
exposed — so a wash started by accident had to be waited out. While a cycle is
running the button shows Stop and calls `anyvac.dock_*` with `action: "stop"`.
Running state comes from the backend (`dock_status.running`), never re-derived
here; an older paired integration that does not publish it leaves the button as a
plain start rather than offering a Stop that might do nothing.

### Changed

**Dock actions and dock-mounted consumables are gated on the dock's reported
capabilities** (`dock_status.features`) instead of the `dock_type` tier table in
`_dockTier`. That table was a careful guess written when `docs/26` §3 concluded
the information was not available; it is, and HA 2026.9's own dock switches use
it. Practical difference: a dock that can empty and wash but not dry no longer
gets a Dry button, which the three-tier model could not express. `_dockTier`
remains as the fallback for an older paired integration — a coarser answer, not a
wrong one.

### Fixed

**The Dock button no longer opens onto nothing on a room-less config.** The
button is gated on dock capability, but the sheet renders from inside
`_renderDock`, which bails before it when there are no rooms to list — so a
config with a dock but no rooms yet (a fresh install in degraded mode) showed a
button that did nothing. The sheet is about the dock, not the rooms, so it now
comes along with the picker and icon strip on that early return. Found by the
new `tests/dock.spec.ts` while writing it, not in the field.

### Removed

**`_batteryPct`**, dead since it was written (no callers), and its fallback to the
vacuum entity's `battery_level` attribute — removed from the base vacuum entity in
core 2026.9. The battery figure on the status card has always come from the
`device_class: battery` sensor and is unaffected.

## [1.2.3] - 2026-09-02

Paired with integration 1.2.3, which fixes the per-room coverage percentages at
the source (`docs/36-beh-vs-vyjezd-coverage.md`). The card's own share of that
bug is one line of selection logic.

### Fixed

**The room's live % chip no longer lets a still-calibrating vacuum outvote a
calibrated one.** With several vacuums reporting progress for the same room, the
chip took the highest number across the fleet — but the two kinds of number are
not on the same scale. A vacuum that has already learned the room's full-clean
baseline reports "% of a full clean"; one that has not yet reports the raw
bounding-box percentage, which reads high because the box includes furniture and
corners the robot cannot reach. A plain maximum let a raw 78 %~ hide a real 45 %.
A normalised value now always wins; within the same scale the highest still does.

## [1.2.0] - 2026-08-19

Visual language v2 — the largest purely visual change since the responsive
rebuild, and the first release that can run on a light Home Assistant theme.
Spec: `docs/35-vizualni-jazyk-v2.md`.

Tagged as a **pre-release**: it touches every rule in the stylesheet, so it
wants a real field test before it becomes the recommended version. `theme:
legacy` is a one-line way back.

The starting point was a measurement, not a mood. The 1.1.0 stylesheet carried
109 hardcoded `rgba(255,255,255,…)` literals against six `var(--…)` uses in the
whole file, no `prefers-color-scheme` and no `prefers-reduced-motion`, the
stock Ant Design palette, nine corner radii, nine font sizes (three of them
below 11px) and not a single shadow — panels were separated by 1px hairlines
over near-black. That is a consistently designed instrument panel. This release
changes the genre, not the quality.

### Added

- **`theme` option** — `dark` (new default), `light`, `auto` (follows
  `prefers-color-scheme`), `legacy` (the exact pre-1.2.0 appearance). Until now
  the card painted white text and white-alpha panels unconditionally, so on a
  light dashboard it was not merely ugly but unreadable. That was a
  compatibility gap, not a matter of taste.
- **`accent` option** — any hex, with six curated presets in the GUI editor
  (Sage, Ocean, Terracotta, Plum, Amber, Graphite). Drives START, room
  selection and focus rings. Status colours are deliberately excluded: their
  saturation carries meaning (cleaning / mopping / error), not preference. An
  unparseable value is dropped rather than written through — an invalid custom
  property would poison every rule referencing it, START included.
- **`calm_state` option** (default on) — when nothing is running, nothing is
  selected, no map tool is armed and no sheet is open, the leftover map trace
  and the secondary metadata step back so the primary action reads clearly.
  Purely de-emphasis: nothing is hidden, disabled or moved. This is the state
  the card is in most of the time, and the only one that never had a look of
  its own.
- **`reduce_motion` option** — the config-level equivalent of the OS
  `prefers-reduced-motion` setting, which is honoured on its own regardless.
- **Micro-interactions** — press feedback on every button class, a breathing
  glow on CANCEL while a clean runs, a slow highlight travelling along the
  progress bar. Transform/opacity only, pure CSS, nothing per frame: the mobile
  companion app has crash history around anything that takes imperative
  ownership of layout (docs/21 §5b), so this cannot touch that. Room buttons
  are excluded on purpose — they carry their own positioning transform that a
  `scale()` would overwrite and throw them off their anchor.
- **Appearance section** in the editor's Global tab for all four options.
- **`tests/theme.spec.ts`** — seven Playwright tests covering theme selection,
  the on-map channel reset, per-element channel resolution, accent validation,
  calm state and the motion opt-out. 15/15 green together with
  `tests/layout.spec.ts`.

### Changed

- **Design tokens.** Every colour resolves through a small set of channel
  custom properties instead of ~130 hardcoded literals, so a theme is a handful
  of numbers and cannot silently miss a spot. `:host` carries the legacy
  values, which is why the old look is simply what you get when no theme class
  applies. `.map-wrap` pins those channels back to white-on-black, so a light
  theme can never reach the labels drawn on the vacuum's own map bitmap.
- **Surfaces are lifted off pure black and carry soft elevation** instead of
  hairline outlines, and corner radii step up one notch. This is what actually
  changes the card's genre; the colour flip alone would not.
- **START reads as the primary action it is** — gradient fill, stronger edge,
  soft cast, now that the surface underneath is no longer near-black. The sage
  green introduced in 0.73.0 was reported in the field as "looks unchanged":
  at 24% alpha over near-black, the hue simply disappeared.
- **Semantic palette softened** from the inherited Ant Design defaults — same
  hues, same meanings, lower saturation.
- **Type floor raised** to 11px (10px in portrait), and everything whose value
  ticks now uses tabular figures, so a live ETA or battery reading stops
  shoving its neighbours sideways on every poll.
- **Map softened** — the dry trace gets a wide faint pass underneath, so a
  fully covered flat reads as a lit trail rather than a scribble; the room age
  dots lose their hard 1px stroke; rooms and the map wrapper are rounder. The
  field-tuned room selection ring is untouched.
- Four neutral `STATUS_MAP` entries (`charging`, `docked`, `idle`,
  `shutting_down`) resolve through the ink channel instead of a hardcoded
  white, so they stay legible on a light theme. Safe as a CSS variable
  precisely because `_statusInfo(...)[1]` is only ever consumed as a whole
  colour value — the `+ "80"` hex-alpha suffix trick elsewhere operates on the
  vacuum's identity colour, never on this one.

### Accessibility

Contrast was measured on the finished build rather than eyeballed — the real
bundle rendered in a browser, ratios computed by compositing each token's alpha
over the actual surface behind it.

The dark theme passed as built: everything text-bearing at 4.5:1 or better,
most of it above 7:1. The light theme did not, which is exactly where it was
predictable — those alphas were tuned as white-on-near-black, and 45% white on
black reads where 45% black on porcelain does not.

- The dim ink tiers are lifted **only in the light themes, and only on the
  elements that carry text** (0.45 → 0.68; measured, 0.61 is where black on the
  panel crosses 4.5:1). The shared values stay as they are, because they are
  correct for the dark theme they were tuned for.
- `ok` / `warn` / `info` / `hint` darkened for light: 4.05/3.69/4.56/4.64 →
  4.64/4.68/4.63/4.64.
- Room age colours come from `room_thresholds`, a documented user-editable
  default, and are correct where they are mainly used — on the map, which stays
  dark in every theme. They are **not** overridden; they are darkened at the
  point of use in the dock list, where they were sitting at 1.7–1.8:1 on
  porcelain. `brightness(0.45)` is the value at which all four defaults clear
  4.5:1.
- Two things that would have shipped visibly broken on a light theme: the
  primary action's label was `color: white` as a keyword (the conversion pass
  only looked for `#fff`), and the idle START used a hardcoded
  `rgba(60,60,60,0.4)` for its "nothing selected" background. Both go through
  tokens now, and resolve to the same values under `legacy`.

### Fixed

- The card had **no focus styling at all** — zero `:focus-visible` rules. Not
  suppressed, just never considered, so keyboard users got the browser's
  default ring over a design that had moved on, which reads as an oversight
  now that a press state exists. Added for every interactive element, using
  `outline` rather than `box-shadow`: several of these carry a box-shadow of
  their own, some of it inline (the selected room's glow, START's cast), and
  an inline value wins — a box-shadow ring would have been silently missing
  exactly where it matters. `outline` also never disturbs layout, so unlike
  the press feedback it is safe on the room buttons, which carry their own
  positioning transform. On the map the ring switches to white and steps
  further off the element, so it reads against whatever the floorplan and the
  cleaning trace happen to be underneath.

- In landscape the primary action is the dock footer's Start button, not the
  START bar (that one is portrait's) — and it was the only control styled
  inline, so the promoted START treatment could not reach it. Lifted into a
  `.dock-run` rule with identical values (`legacy` unchanged) and promoted the
  same way.

### Notes on `theme: legacy`

Verified mechanically rather than asserted: resolving the new stylesheet's
tokens and diffing against 1.1.0 gives **731 declarations against 731**, with
every difference purely notational except three.

| element | 1.1.0 | 1.2.0 `legacy` |
| --- | --- | --- |
| `.dock-mode-dot` (7px dock-attention dot) | `#e0994a` | `#faad14` |
| `.dock-sheet` border | `rgba(255,255,255,0.1)` | `rgba(255,255,255,0.08)` |
| `.layer-menu` background | `rgb(15,15,18)` | `rgb(18,18,18)` |

So `legacy` is not bit-identical. It is practically indistinguishable, and the
three places it differs are known exactly.

### Size

252.5 -> 284 KiB raw, 66.3 -> 74.7 KiB gzipped (+13%), entirely from the added
stylesheet.

## [1.1.0] - 2026-08-08

Completes the bug-fix and optimisation pass started in 1.0.10, closing out the
full code audit in `docs/34-analyza-kodu-2026-08-08.md`. Paired with integration
1.1.0. No new features and no UI behaviour changes — everything here is either a
silent bug or measured waste.

### Fixed

The editor and the card resolved map seating differently, so the Maps tab
preview could show a placement the card would not actually render — during
room anchoring, the one workflow where that preview is the whole point. Two
independent divergences had crept in: the editor had no first-vacuum
`image_base` fallback (a merged config with the floorplan set on a vacuum,
rather than card-level, auto-seated at runtime but fell back to manual in the
editor), and it selected fit anchors by `map_mode` while the card selected them
by whether card-level `rooms` were defined (so a split config with card-level
rooms disagreed the other way). Both now call one shared `resolveSeat()` in
`seatfit.ts`, along with `resolveImageBaseSrc()`/`resolveStaticRooms()` for the
two inputs that had drifted.

localStorage keys are no longer global, and no longer carry the predecessor
project's name. `roborock-card:shown` / `:flip` / `:sel:<entity>` were shared by
every AnyVac card in the browser, so two cards on different dashboards
overwrote each other's shown-set and flip — directly contradicting the flip
toggle's own premise of being per-screen. They also shared a namespace with
`roborock-vacuum-card`, which is still installed alongside on the setup this
was built against. Keys are now `anyvac-card:<what>:<vacuum entity list>`, which
is stable across restarts and distinct per fleet. Existing values are read once
from the old key on upgrade, so nothing resets; the legacy key is left in place
rather than deleted, so a downgrade still works.

### Changed

The bundle is minified. It shipped unminified until now, costing roughly half
the download on every dashboard load:

| | raw | gzip |
|---|---|---|
| before | 486.3 KiB | 133.7 KiB |
| after | 252.8 KiB | 66.4 KiB |

No source map is emitted, deliberately: HACS installs only `anyvac-card.js`, so
a `sourceMappingURL` would 404 in every user's devtools. `keep_fnames` /
`keep_classnames` buy back readable stack traces for 0.3 KiB gzipped instead —
worth it because field reports on this card routinely arrive as a pasted console
trace. Property mangling stays off, so `setConfig`, `hass` and the `@state`
fields read live from the console during diagnosis keep their names.

`_roomsFor()` / `_effectiveSeat()` are memoised per hass update. One render of a
three-vacuum, ten-room merged card called `_roomsFor()` ~90 times, each redoing
the seat fit and rebuilding the room array. To be clear about the scale: that
was measured at ~0.19 ms on a desktop and ~1 ms on a phone, so this is **not** a
performance fix — the real gain is ~900 fewer allocations per render and one
consistent answer per render instead of 90 independent recomputations. The memo
is keyed on `hass` object identity rather than cleared from a lifecycle hook,
which keeps it correct on the paths where no render happens (`shouldUpdate()`
reaches `_roomsFor()` before `willUpdate()` would run, and not at all when it
returns false).

### Removed

Dead code, all verified to have no caller outside comments:
`_renderRoomList()`, `_renderStatsTrio()`, `_renderBadgesRefresh()` (a stale
comment claimed the legacy render path still used them — it never called any of
the three, so they had been dead since docs/19 A4), `_planVacuums()` (noted at
the deletion site: the docs/28 §3 idea behind it is still open and needs a
decision before it comes back, not a dangling helper), the orphaned
`.stats-trio`/`.stat`/`.badges-refresh`/`.room-list`/`.rl-*` CSS, and the TEMP
split/stack diagnostics chip from 0.73.3 — its model was confirmed in the field
in 0.73.7, and the same numbers stay available behind the `debug` config flag.

## [1.0.10] - 2026-08-08

Paired with integration 1.0.10. Both fixes below come from a full code audit
(`docs/34-analyza-kodu-2026-08-08.md`), not from a field report — they are
silent failures that produce no error anywhere, which is why neither had been
noticed in use.

### Fixed

The "unassigned rooms" warning could never appear. `_unassignedRooms()`
rebuilt the plan-preview cache key inline as `[selKeys, mode, vacuums]`, but
`_fetchPlan()` has stored a four-element key including `room_pins` since
0.67.2 — a three-element key can never equal a four-element one, so the
guard short-circuited on every call and the function returned `[]`
unconditionally. That silently disabled the entire feature added in 0.66.5:
the red `mdi:robot-off` markers on dock rows, the dock footer summary and
the landscape meta bar count. So a "Both" run where the backend cannot
assign a wet robot to a selected room went back to giving no feedback at
all — exactly the failure 0.66.5 existed to surface. Both call sites now
share one `_planKey()` method so they cannot drift apart again.

Auto-resolved entities could be cached wrong permanently. `_intCache`,
`_mapCache`, `_autoCache` and `_careCache` were populated on first use and
never cleared anywhere — not even in `setConfig()` — and two of them derived
their answer from LIVE state rather than the registry, so an answer computed
before the first integration poll stuck until a full page reload:

- `_careItems()` branches on `_dockTier()`, which reads `dock_status.dock_type`
  off the AnyVac sensor. Asked before the first poll it sees tier "none",
  skips the dock-mounted rows (dock brush, strainer, tank sensors) and cached
  that incomplete list forever. It is now keyed on `entity|tier`, so a tier
  change computes a fresh list.
- `_mapEntityFor()` picks between multiple `image.*` candidates by liveness
  (`entity_picture`). A vacuum with 2+ saved maps — the exact case it was
  written for in 0.86.0 — asked before its first poll found nothing live,
  fell through to `undefined` and cached that: no map at all until reload.
  Split in two: the expensive registry-derived candidate list is cached
  (`_mapCandCache`), the cheap liveness check re-runs per call.

All four now also drop when the entity registry itself changes, via a single
`_registry()` accessor every resolver goes through — HA replaces
`hass.entities` only on a real registry change (integration load/reload/
rename), not on ordinary state updates, so this is a precise and cheap
invalidation signal rather than a per-render rescan.

## [1.0.9] - 2026-08-04

### Fixed

Portrait rendered both the vacuum picker (pill list) AND the vacuum icon
strip at once — two redundant controls for the same "show/hide a vacuum"
action, stacked on top of each other. Root cause: the `withPicker` fold
introduced in 1.0.8's sibling change (docs/33 follow-up, "picker" folded
into "dock") was gated on `!("picker" in prof.place)`, which is also true
for both portrait profiles — neither has ever placed a `picker` region,
because portrait deliberately uses the icon strip instead (0.69.0). Fixed
by also requiring `profile === "landscape"`; the room-less early-return
path was updated the same way so a fresh install without rooms yet still
shows the right single control per profile instead of nothing.

## [1.0.8] - 2026-08-04

### Fixed

Landscape layout: row 4 (status column + picker/dock) could balloon to a
full 50% of the grid's height even with modest content (e.g. one vacuum
and a short room list) — leaving dead space between the room list and the
START footer, and starving the map's `1fr` row of height it had no other
claimant for (visible as the map rendering narrower than the card,
letterboxed, since it no longer had enough height for its aspect ratio to
reach full width). Root cause: `minmax(0, 50%)`'s percentage max is a
*growth limit*, not a content cap — CSS Grid's "maximize tracks" step
grows every non-flexible track up to its growth limit before `fr` tracks
get whatever free space is left, regardless of how little that track's
own content needs. Fix: the floor moved from row 4's growth limit onto
the map's own row instead (`minmax(260px, 1fr)`), and row 4 goes back to
bare `"auto"` so it genuinely shrinks to its content again — the map now
gets all the leftover space by default, with a guaranteed minimum even
when status/dock content is unusually tall (many vacuums, long room
list). Manual `layout.landscape.rows` overrides are unaffected.

## [1.0.7] - 2026-08-03

### Fixed

Room assign chip was still landing off-corner under 90°/270° map rotation
(auto-rotate-for-fit, e.g. landscape with a tall/narrow floorplan) — root
cause turned out to be different from 1.0.4/1.0.5's diagnosis: those two
angles ALSO apply a ±90° self-rotation to the chip itself (to keep its
text upright), and that self-rotation swaps the chip's own effective
width/height before the ambient rotation carries it further, so a plain
"2px from local edge" inset landed roughly chip-height pixels off from
the intended corner (0°/180° never had this problem, since neither
rotates the chip's own footprint). Confirmed via live DOM measurement on
the actual reported dashboard, then re-derived and verified with a full
2D affine-matrix simulation of the CSS transform chain (checked against
that live geometry, and against multiple synthetic room/chip sizes)
before writing any code — the corner CHOICE from 1.0.5 was always right,
only the inset mechanism needed to change. New anchoring: a zero-size
point sits at the correct local room corner, and the chip pins to it via
its own bottom-right corner as `transform-origin` (invariant under its
own rotation, unlike an edge inset), with a per-angle pre-solved
translate for the 2px visual gap. Also dropped 1.0.6's max-width/wrap
narrow-room guard — the live measurement that motivated it (~21px
overflow on rooms of very different widths, including a 990px-wide one)
turned out to be fully explained by this same rotation bug, not a real
content-width problem.

## [1.0.6] - 2026-08-03

### Fixed

Room assign chip could visually spill past its own room's left edge —
with no width limit it was a shrink-to-fit box anchored only by its
right/bottom corner, so a room narrower than two 24px-min-width avatar
pills side by side (bathroom/hallway-sized rooms on a merged map
routinely are) let the chip's left edge grow past the room's own
boundary uncontained. Capped to the room's own width (`max-width:
calc(100% - 4px)`), with a second chip that doesn't fit wrapping onto a
row above the anchored one instead of spilling sideways — always grows
away from the pinned bottom-right corner, never past it.

## [1.0.5] - 2026-08-03

### Fixed

Room assign chip still landed in the wrong corner for the 90°/270° map
rotation states (auto-rotate-for-fit combined with flip) — 1.0.4 only
handled the 0°/180° cases and left these on the untouched bottom-right
default, since the translate+rotate transform used for a quarter turn
looked different from the pure `transform-origin:center` 180° case.
Field-caught: translation only moves the whole rotated block, it doesn't
change which direction a local corner vector points after rotation, so
the same corner-cycle math applies regardless. All four right angles are
now covered by the same anchor-picking logic.

## [1.0.4] - 2026-08-03

### Fixed

Room assign chip position shifted to the wrong corner whenever the map
flip (180°) was on — the chip's anchor (bottom-right) was set in the
room's pre-rotation coordinate frame, so the ambient 180° rotation carried
it to the visual top-left instead. Now the anchor corner is picked based
on the actual total rotation (mirrors `_renderResponsive`'s own
`rotate`/`flip` inputs) — pure 180° anchors top-left-local so it lands
bottom-right-visual; the un-rotated (0°) case is unaffected. Not yet
independently verified for the 90°/270° rotate-for-fit + flip combination
(different transform shape, not a simple corner swap) — flagged rather
than guessed, same as the existing docs/32 caveat on that combination.

## [1.0.3] - 2026-08-03

### Changed

Room assign chip (dry/wet vacuum avatar on a selected room) moved from
the bottom-left to the bottom-right corner of the room, per field
feedback, and given a drop shadow so it stays legible sitting on top of
busy path colors on the map.

## [1.0.2] - 2026-08-03

### Fixed

Two field reports right after 1.0.1:
- Room assign chips (dry/wet vacuum avatar) — 1.0.1 hid them entirely
  whenever the map is rotated (any profile) instead of just hiding them in
  portrait; feedback was that hiding lost the info rather than being an
  acceptable tradeoff. Now shown unconditionally and properly counter-
  rotated (same `.avc-rot`/`--map-rot` mechanism as the room icon, gauge,
  and inspect popup) so they stay upright and readable under any rotation.
- The live "Flip map" toggle (meta bar / dock button, session-only by
  design) reset to the config default on every page reload — expected on
  wall-mounted/kiosk tablets that get refreshed often. Now persisted via
  localStorage (same mechanism as the shown-vacuum set and room
  selection) — survives reload, still per-browser rather than backend-
  shared, since "how this screen likes its map" isn't necessarily the same
  preference on a different screen.

## [1.0.1] - 2026-08-03

### Fixed

Room assignment chips (dry/wet vacuum avatar, bottom-left of a selected
room) rendered sideways in landscape whenever the map auto-rotates a
tall/narrow floorplan — the "hide when unreadable" guard was gated on
`_profile !== "portrait"`, a leftover from before landscape could rotate
too (0.81.1). Now gated on `!this._narrow` (is the map currently rotated,
regardless of profile) — same fallback as before (hold-to-inspect still
shows the assignment), just no longer landscape-blind.

## [1.0.0] - 2026-08-03

First stable release. Full responsive layout system (portrait/landscape,
docs/18-21), rooms/seating/coverage sourced live from the integration
(docs/15/20/29/30), sequence-aware orchestrated cleaning with per-room
pinning and progressive wet dispatch (docs/18-19/23), dock control +
consumables (docs/25 §10), map flip/rotation (docs/32), and the compact
landscape cockpit (docs/33). See CHANGELOG history above for the full
path here.

## [0.94.2] - 2026-08-03

### Fixed

Field-caught right after 0.94.1: a visible gap between the landscape
`picker` column (vacuum pills) and the dock/room-list below it. Root cause
— `picker` and `dock` used to be two independent grid rows, with `status`
spanning both so its column height matched them combined; that span made
the grid distribute status's own content height across both rows,
inflating picker's row well past its short actual content. Fixed by
folding `picker` into `dock`'s own template (renders as the first thing
inside it, `_renderDock`'s new `withPicker` param) instead of a separate
grid row — both are now one naturally-stacked flow with no cross-row
sizing to create a gap. `DEFAULT_PROFILES.landscape` collapsed from 5 rows
to 4 accordingly (`status`/`dock` now share a single `minmax(0, 50%)` row
instead of two independent `minmax(0, 26%)` rows). A manual config that
still explicitly places its own `picker` region is unaffected.

## [0.94.1] - 2026-08-03

### Fixed

Field feedback right after 0.94.0's landscape `picker` column screenshot:
- Picker badges (`.vac-picker .badge`) were still full-size (44px avatar,
  same padding as the legacy/portrait horizontal badge row) — shrunk to a
  26px avatar and tighter padding/font, scoped to the picker column only so
  the legacy/portrait badge row is unaffected.
- Vacuum ordering in the status column, picker, and merged-map draw order
  could silently reshuffle after hiding and re-showing a vacuum — `Set`
  preserves insertion order, and re-adding a hidden index moves it to the
  end. New `_shownOrdered()` sorts by configured index everywhere a shown
  list gets displayed, so vacuums always render in their configured order
  (e.g. S6/S7/S8) regardless of show/hide history.

## [0.94.0] - 2026-08-03

### Changed

v1.1.0 — status card compact redesign + landscape grid row cap (docs/33),
user-approved via before/after mockup:
- Status card avatar shrunk from a fixed 150px image column to a 44px
  circular avatar (mirrors `.vac-icon-btn`'s established look) with a new
  info badge marking the tap-to-open-more-info "rescue control" escape
  hatch — smaller, not less discoverable.
- Status/battery/room/last-clean condensed from a wide multi-column row
  into two compact lines beside the avatar; live cleaning % now shown
  inline next to the status label too, not just in the progress bar.
- Preset chips now sit inline beside the START button (horizontally
  scrollable for 3+ presets) instead of stacking above it as their own row.
- The per-room icon strip inside START (read-only, selection happens on
  the map) replaced with a plain "N/M rooms" count — same information,
  none of the height.
- Card roughly 230px → 130px, no functionality lost.
- `layout.landscape` default rows: the status/picker/dock rows (previously
  unbounded `"auto"`) now cap at `minmax(0, 26%)` each, guaranteeing the
  map a real floor regardless of how many vacuums are configured — excess
  content scrolls within its own region instead of squeezing the map.
  Manual `layout.landscape.rows` overrides are unaffected.

## [0.93.3] - 2026-08-03

### Added

Two ways to control map flip (docs/32 follow-up) without hand-editing YAML:
- Editor: "Flip portrait map 180°" / "Flip landscape map 180°" toggles in the
  Global tab's Layout section (shown once "Fit card to available screen
  space" is on) — a GUI equivalent of `layout.<profile>.crop.flip`, merged
  into the existing crop config without clobbering `fit`/`offset_x`/
  `offset_y`/`mapOrientation`.
- Running card: a "Flip map" button in the landscape meta bar and the
  portrait dock's layer-toggle row (only shown with a `layout:` block) flips
  the CURRENT view for this browser tab only — doesn't touch the dashboard
  config, doesn't persist, resets on reload. Useful for quickly checking
  which orientation looks right on a given screen before committing to the
  editor setting. New `_flipEff`/`_toggleFlipLive` — the live override always
  takes priority over the persisted config default when set this session.

## [0.93.2] - 2026-08-01

### Added

New `layout.landscape.crop.flip` / `layout.portrait.crop.flip` (docs/32),
independent of `mapOrientation`: rotates the whole map block (floorplan +
rooms + paths + markers, same `.avc-rot` mechanism that already keeps
rooms clickable under the auto-fit 90° rotation) by an additional 180°.
Fixes a real onboarding-blocker found during the 2026-08-01 field test —
the existing `image_base.rotation` slider only rotates the floorplan
`<img>` itself, not the separately-positioned room buttons next to it, so
using it after rooms are placed visually detaches them from the floorplan.
`.avc-rot`'s counter-rotation CSS (keeps on-map text/icons upright) moved
from six hardcoded `rotate(-90deg)` rules to one `--map-rot` custom
property computed per render, so it covers all four resulting angles
(0/90/180/270) instead of just the old fixed 90° case. Default `false` —
no behavior change without the new key. The 270° case (auto-rotated *and*
flipped together) is derived by symmetry with the field-proven 90° formula
but not yet independently field-verified. Typecheck + build clean (sandbox
`/tmp`).

## [0.93.1] - 2026-07-31

### Fixed

`_vacCleanType()`'s `"auto"` role detection (docs/31) now prefers the
backend's live hardware signal — `mop_signal.water_box_mode`/
`water_mode_name` (same source `planner.py._capable()` already uses
server-side) — over guessing from whether the user happened to fill in
`clean_action.mop_mode`/`mop_intensity`. The old heuristic mis-detected a
wet-capable robot as dry-only whenever its Clean action left
`suction_level` unset (docs/30 §6 finding 4, found during the onboarding
audit). Degraded mode (no integration, or `schema_version < 2`) has no
`mop_signal` and keeps the old config-based guess unchanged, per canon
rule 3. Explicit `clean_type: dry/wet/both` config still overrides
everything, as before — this only changes the `"auto"` fallback.

## [0.93.0] - 2026-07-31

### Added

Two onboarding/multi-vacuum ergonomics fixes raised directly by the user.
`getStubConfig()` (fresh "+ Add card" flow) now auto-loads **every**
discovered `vacuum.*` entity instead of just the first one — Matter-bridged
duplicates are still excluded whenever a native alternative exists (extends
the single-vacuum Matter fix from 0.87.1). New `DEFAULT_VACUUM_PALETTE`
(const.ts, 8 colours, first three match the legacy green/blue/orange) gives
each vacuum without an explicit `color` a distinct default based on its
position in the `vacuums` array — `_color`/`_colorBg`/`_colorBgActive` (and
the editor's "Accent colour" hex-picker placeholder) now derive their
fallback from `_defaultColor(vac)` instead of hardcoding green for everyone.
A single-vacuum config with no `color` set looks exactly as before. Editor's
"Path colour" placeholder swatch also fixed to reflect the real runtime
default (the vacuum's resolved accent colour, matching `_renderIntegrationOverlay`'s
`vac.path_color || color`) instead of a stale unrelated hardcoded hex.

**Investigated, no change:** whether the wet/mop path should default to the
vacuum's own colour like the dry path does, instead of the fixed
`#40a9ff` blue — user decided to keep the fixed blue (universal "here's
where it was wet" cue takes priority over per-vehicle identification for
the mop trace).

## [0.92.0] - 2026-07-30

### Added

Big seating-workflow simplification (docs/30 §8), paired with `anyvac`
0.92.0. `anyvac.snapshot_map_as_floorplan` now returns the exact crop box
it applied; the editor uses it to place the snapshotted vacuum's own rooms
onto the new floorplan immediately, with no dragging — a new
`placeRoomInCrop` (seatfit.ts) re-normalises `bbox_px` directly against the
known crop, bypassing the old identity-seat assumption that broke once
snapshots started being cropped (0.88.1). Since these rooms now carry real
`map_x`/`map_y`, they act as anchors for every other vacuum sharing the
floorplan whose own room names match — the existing anchor auto-fit
(`assembleAnchors`/`computeSeatFit`) then places THEM automatically too,
with no Import click and no dragging, as long as room names agree across
vacuums' native apps. New room-name-mismatch hint (Maps tab) lists a
vacuum's own room names that don't match anything on the shared floorplan
yet, since a silent name mismatch across robots was previously undetectable
in the UI. Map mode select now warns when merged mode has no shared
floorplan set. Net effect for a fresh multi-vacuum setup: click "Use this
vacuum's current map as floorplan" once on the fullest-coverage vacuum,
then just switch the vacuum picker to each other one — no manual anchoring
step left for the common case.

## [0.91.0] - 2026-07-30

### Changed

The "Use this vacuum's current map as floorplan" button now also switches
"Hide vacuum map" on — for every vacuum in merged mode, or just the one
vacuum otherwise. Found while walking through a from-scratch onboarding
test: a freshly snapshotted floorplan with all vacuums' raw maps still
blended on top at 55% opacity looks like noise, since the floorplan photo
already covers what the raw map layer would show. This is a one-shot side
effect of clicking the button, not a changed default — existing configs
that never touch this button are unaffected.

## [0.90.0] - 2026-07-30

### Added

GUI toggle for the responsive layout system (docs/18). Live diagnosis of a
field report ("page renders ~8 screens tall, doesn't use the available
screen space") traced back to the card having no `layout:` config block at
all — the entire portrait/landscape fit-to-available-height system has
been YAML-only since docs/18, completely invisible in the visual editor. A
brand-new card built purely through the GUI (as most users do) had no way
to discover or turn it on.

New "Layout" section at the top of the Global tab: "Fit card to available
screen space" toggle. On sets `layout: {}` (the whole system activates
with its built-in default profiles — no YAML needed for the common case);
off removes the `layout` key entirely, back to the older unbounded
rendering some existing dashboards may still be tuned around. Advanced
per-profile tuning (column/row overrides, map crop, orientation) remains
YAML-only, mentioned in the hint text — this toggle is specifically the
"turn it on with sensible defaults" path, not a full settings UI for every
knob.

## [0.89.0] - 2026-07-30

### Added

Distinct default room icons — field report during a live onboarding walk:
every newly added room defaulted to `mdi:square`, and every room pulled in
by "Import missing rooms from this vacuum" defaulted to `mdi:floor-plan` —
identical for every room, making adjacent/overlapping room rectangles
impossible to tell apart while anchoring them on the floorplan preview.
New rooms (manual add, per-vacuum or merged, and import) now cycle through
a palette of numbered icons (`mdi:numeric-1-circle` … `9-plus`) instead —
neutral rather than thematic (sofa/bed/etc.), since there's no reliable way
to guess a room's real type from its name alone. Purely a starting point;
any room's icon can still be changed afterwards.

## [0.88.0] - 2026-07-30

### Added

"Use this vacuum's current map as floorplan" button (Maps tab, shared
floorplan / image-base section) — docs/30 §4a field follow-up, diagnosed
during a live new-user onboarding walkthrough. Merged mode's per-vacuum
auto-seat fit needs a shared floorplan image to work at all; without one,
the only path forward was manually eyeballing rotation/scale/offset sliders
per vacuum against each robot's own differently-oriented raw map — close to
impossible to get right, since there was no common reference to fit
against. The new button calls the integration's new
`anyvac.snapshot_map_as_floorplan` (requires anyvac ≥ 0.88.0) with the
SAME map entity already resolved for preview (`_mapEntityFor`), and
auto-fills `image_base.src` from the returned path — collapses the old
"find the image URL, save it, upload it to config/www/, type the path"
manual sequence into one click. Once set, the existing Import-then-anchor
workflow (docs/30 §3/§4c) works as designed: import the reference vacuum's
own rooms against its own map-turned-floorplan (near-exact match), then
switch to another vacuum — its auto-fit activates automatically against
the now-shared, anchored rooms.

## [0.87.2] - 2026-07-30

### Fixed

- Room-rectangle editor (Maps tab): grabbing a corner of a not-yet-selected
  room to resize it always moved the whole box instead. The corner-handle
  dots only render once a room is already selected, so the very first
  press near a corner had no handle to land on and fell through to the
  body's plain "move" behaviour. `_onRoomPointerDown` now detects a
  near-corner press on the body itself (same ~16px radius as the visible
  handle) and treats it as a resize of that corner, so the first press
  already works — no need to select-then-drag-again.

## [0.87.1] - 2026-07-30

### Fixed

- `getStubConfig()` (used to prefill config when adding a new card via "+
  Add card") no longer defaults to a Matter-bridged vacuum entity when a
  better one is available. `hass.states` iteration order reflects
  registration order, not any kind of preference, and Matter's vacuum
  feature set is far more limited than a native integration's (no rooms,
  segments, or zones) — it should never win the default pick over a
  regular vacuum entity just because it happened to load first. Falls
  back to whatever's first if entity registry access isn't available, or
  if every vacuum entity really is Matter-only.

## [0.87.0] - 2026-07-30

### Changed

Unifies vacuum accent colour with the free-hex picker already used for
`path_color`/`mop_path_color` — the two were getting harder to reconcile
now that path colours can be any hex while the vacuum's own accent stayed
locked to 3 presets.

- `VacuumColor` (`types.ts`) relaxed from a `"green"|"blue"|"orange"` union
  to a plain `string` — any hex value works now. The three legacy preset
  names are still accepted and resolve to their exact original hex via
  `COLOR_HEX`, so existing configs render identically without any change.
- New `hexToRgba(hex, alpha)` helper in `const.ts` derives a translucent
  background wash for a custom hex colour. The three legacy presets keep
  their exact, independently-tuned `COLOR_BG`/`COLOR_BG_ACTIVE` values
  (these were never a straight alpha-blend of `COLOR_HEX` — `green`'s wash
  in particular uses a visibly different RGB triple — so preserving the
  lookup table for presets avoids a subtle appearance shift for anyone
  currently on the default colour).
- Card: `_colorKey`/direct `COLOR_BG[...]` lookups replaced by
  `_resolveColor`/`_resolveBg` (and thin `_color`/`_colorBg`/
  `_colorBgActive` wrappers) across badges, preset chips, per-vacuum
  action buttons and the global-action badge.
- Editor: "Accent colour" (both per-vacuum and global action) is now a
  `_hexColorField` (native colour swatch + text input), matching Path
  colour/Mop band colour. A stored legacy name is displayed resolved to
  its hex (e.g. `blue` shows as `#2196F3`) so the swatch always previews
  correctly, but the underlying config value is only rewritten if the
  user actually changes it.

## [0.86.0] - 2026-07-30

### Added

Fixes the #1 finding from the onboarding audit (docs/30 §2.1/§6): the map
image entity now auto-resolves, closing the last gap in "just add the
vacuum entity and it works."

- New `_mapEntityFor(vac)` (mirrored in the editor) resolves `map.entity`
  automatically from the entity registry when not explicitly configured —
  previously the only card field with no auto-resolve at all (unlike
  `integration_entity`/status/battery/etc.), meaning a fresh install with
  just `vacuums: [{entity: vacuum.s8}]` showed no map whatsoever until the
  user found and typed in the right `image.*` entity by hand.
- Live-verified against a real multi-vacuum registry (no dedicated
  `translation_key` exists on this entity domain, ruling out the pattern
  `_autoEntities`/`_careItems` use elsewhere): a vacuum can have **one
  `image.*` entity per saved floor** (a 2-map vacuum had
  `image.x_map_0`/`image.x_map_2`), so "the only image entity on this
  device" isn't a safe heuristic on its own. Resolution instead prefers
  whichever candidate is actually **live** — state not
  unavailable/unknown and carrying an `entity_picture` attribute, the same
  liveness signal `_mapUrl` already reads — since only the currently
  selected map's image entity is backed by real state; falls back to "the
  only candidate" when there's just one (covers a freshly added vacuum
  whose first poll hasn't landed yet). Confirmed correct against all 4 of
  the user's live vacuums, including the 2-map disambiguation case.
- Every runtime call site that read `vac.map?.entity` directly (map
  rendering in both split and merged mode, Pin & Go/Zone availability,
  refresh buttons/badges, click-geometry lookups, watched-entities) now
  goes through the resolved value. One deliberate exception: the `base`
  layer default-inference (`image` vs `map` when `base` itself is unset)
  still reads the raw config — it's inferring the user's intent from what
  they explicitly typed, not availability, so auto-resolve shouldn't
  silently flip a floorplan-only setup to also show the raw vacuum map.
- Editor: the "Map image entity" picker now shows a hint naming the
  auto-resolved entity when the field is left blank, and the "Refresh
  reference map" button/preview activate from the resolved entity too
  (previously required the field to be filled in explicitly even though
  the card itself would already auto-resolve at runtime once this ships).

## [0.85.0] - 2026-07-30

### Changed

First pass of a new-user onboarding audit (points 2-4 of that review; the
README rewrite and a fresh single/multi-vacuum install walkthrough follow
once the underlying config surface is settled):

- Room editor: Segment ID and the three legacy fallback fields (Est. clean
  time, Clean time fallback entity, Last clean fallback entity) — none of
  which are ever read once a vacuum has an active AnyVac integration entity
  (verified in `_startClean`: the integration path never touches
  `segment_id` or these fallbacks) — are now hidden entirely for such
  vacuums, replaced by a one-line reassurance that the integration handles
  this server-side. Previously shown unconditionally for every room,
  including a "Find IDs: Developer Tools → Actions → roborock.get_maps"
  nudge that invited new users to spend time on a value the card would
  never use. The collapsed room row's "seg N" badge is likewise hidden
  once the integration is active.
- Vacuums tab "Rooms" section now explains, right where a new user would
  otherwise assume manual entry is required, that rooms with the AnyVac
  integration appear automatically from the vacuum's own map — manual
  entries are only for icon/name overrides or positioning on a custom
  floorplan.
- `getStubConfig()` (the config HA seeds when a card is freshly dropped
  onto a dashboard) now looks up the user's actual first `vacuum.*` entity
  from `hass.states` instead of a placeholder (`vacuum.my_roborock`) that
  never exists — a freshly added card should now already point at a real
  entity instead of requiring an immediate manual fix. Falls back to the
  old placeholder if `hass` isn't supplied.

## [0.84.0] - 2026-07-30

### Changed

Follow-up to 0.83.0's editor cleanup — a closer look at Area mappings and
Notifications (Global tab) surfaced stale/inaccurate copy and one genuinely
dead config option:

- Removed `native-auto` as a selectable Clean action strategy — verified it
  behaves 100% identically to `native` today (segment_id + app_segment_clean),
  both with and without the integration. Its original distinguishing
  behaviour (`roborock.get_maps` dynamic resolve, matching rooms via
  `area_mappings`) was deleted in the docs/14 §3.7 purge, so it had been a
  pure, confusing duplicate. Existing configs with the literal value keep
  working unchanged (runtime already treated it as an alias); the editor now
  displays/writes them as "Native" once touched. `types.ts` docstrings for
  `NativeAreaCleanAction`/`NativeAutoCleanAction` updated to match reality
  (both were describing removed behaviour — a false "software repeat" claim
  on the former, the deleted dynamic-resolve mechanism on the latter).
- Area mappings section now gates on `native-area` only (was incorrectly
  also shown/described for `native-auto`, which never used it). Hint text
  now states plainly that this is degraded-mode-only — irrelevant once the
  AnyVac integration is active for a vacuum (which it always is with the
  START button; `anyvac.clean` ignores the configured strategy entirely).
  The per-room "Effective area" preview is likewise now native-area-only —
  it was misleadingly shown for native-auto rooms too, which are actually
  segment-based like plain Native.
- The room "Key" field hint no longer cites the (already-removed)
  native-auto name-matching behaviour; it now correctly explains the real,
  current reason to match the Roborock app's room name: the AnyVac
  integration's own name-based matching (auto-seating, live room positions,
  room pinning).
- Notifications hint rewritten to accurately describe the three blueprints
  the integration actually ships, since they don't work uniformly the way
  the old text implied: **Clean finished** fires on the real
  `anyvac_clean_finished` event; **Vacuum error** watches the official
  Roborock error sensor's state directly (there is no `anyvac_vacuum_error`
  event — the old text was simply wrong); **Room overdue** polls a per-room
  timestamp sensor hourly. Also notes `anyvac_clean_started` and
  `anyvac_room_done` are real fired events with no shipped blueprint yet.

## [0.83.0] - 2026-07-30

### Changed

UX/GUI editor polish pass, following a full runtime (portrait+landscape) and
GUI editor critique. All English-language now (card + editor):

- Editor: "Clean type (time estimate & layers)" field renamed to "Role" —
  avoids confusion with the run-time Dry/Wet/Both mode picker on the
  controller, which is a separate concept. Hint text clarified.
- Manual per-vacuum START button (`_renderActions`): label now reads
  "Select rooms" when no rooms are selected for that vacuum, reverting to
  "START" once at least one is picked — was static "START" in both states,
  indistinguishable from the (also visually dimmed) disabled look.
- Replaced `mdi:rocket-launch` with `mdi:play` on both START buttons
  (orchestrated START bar and manual per-vacuum START) — unifies the app's
  "start/resume" icon language with the dock's orchestrated run button and
  the per-vacuum Resume button, both of which already used `mdi:play`.
- Editor Maps tab reordered: the room editor (floorplan preview, draggable
  room rectangles, seating status, import, cleaning sequence, add room,
  room positions) now comes before the purely cosmetic rendering fields
  (path colour/width, mop band colour/opacity/width, robot image
  size/rotation, card height), which moved into a new "Appearance" section
  at the end of the tab.
- Editor: hex colour fields (path colour, mop band colour) now show a
  native colour-picker swatch (`<input type="color">`) alongside the
  existing hex text field — either one updates the other.
- Editor: "Debug" removed from the top-level Config tab strip; a
  "🐞 Show debug info" text link at the bottom of the dialog reveals the
  same content instead, keeping the main tab row to Vacuums/Maps/Global.
- Translated the last remaining Czech user-facing strings to English: the
  auto-mode clean-plan preview panel ("PLÁN ÚKLIDU" → "CLEAN PLAN",
  "Sucho"/"Mokro"/"Obojí" → "Dry"/"Wet"/"Both", "Spustit · podrž" →
  "Start · hold") and the global-preset auto bar
  ("CELÝ BYT"/"VYBRANÉ"/"MÍSTNOSTI" → "WHOLE HOME"/"SELECTED"/"ROOMS",
  "SUCHO"/"MOKRO"/"OBOJÍ" → "DRY"/"WET"/"BOTH"), plus example placeholder
  text in the editor (preset/global-preset labels).

## [0.82.0] - 2026-07-29

### Added

Room coverage % (docs/29, spec ratified 2026-07-29). Two related pieces, both
reading data the integration already computed but never fully surfaced:

- Persistent "last completed clean covered X%" chip next to the existing age
  chip (✓1d/💧1d) in dock rows (`.dock-cov`, both the landscape sidebar dock
  and the portrait dense dock) — reads the integration's new `rooms_coverage`
  attribute via `_roomCoverageRec`. Shows "—" when no baseline exists yet
  (first-ever clean of a room), never a misleading 0%/100%.
- The live in-session coverage chip (`_renderProgChip`, shown next to the
  room name while a room is being — or was just — cleaned) is promoted out
  of the `debug_room_progress` gate into production. It's the same
  data/math as the persistent chip above, just live during the session
  instead of a durable snapshot; no reason to show one and hide the other.
  `debug_room_progress` still gates the rest of the debug strip (map corner
  gauges, the status card's mm:ss timer) — unchanged.

## [0.81.1] - 2026-07-27

### Fixed

Map auto-rotation (docs/25 §4) now applies in landscape too, not just portrait.
`_narrow` (the rotation decision) was hard-gated to `this._profile === "portrait"`
— a field report after deploying a new, very tall/narrow floorplan showed it
rendering as a thin letterboxed strip with large black margins in landscape,
because rotation (which would have fit it much better) was structurally
disabled there. `shouldRotateMap()` was already pure geometry independent of
profile, and `_renderResponsive()`/`_mapRegW`/`_mapRegH` were already
profile-agnostic — the fix is purely widening `_narrow` to compute the same
contain-fit comparison for whichever profile is active, reading
`layout.landscape.crop.mapOrientation` as the manual override (mirrors the
existing `layout.portrait.crop.mapOrientation`, same escape-hatch pattern,
`ProfileGridConfig.crop` was already generic to both profiles in the type).
Legacy (no `layout:` block) card-width heuristic is unchanged — it never
rotated in landscape and still doesn't.

**Known trade-off, not a new bug:** Pin & Go / Zone are disabled whenever
`_narrow` is true (docs/13 A5 — the click-coordinate inversion doesn't yet
account for the rotation wrapper). This limitation already existed in
portrait; extending rotation to landscape extends the same limitation there,
whenever a landscape floorplan actually needs rotating. Fixing the underlying
click-inversion gap remains open, unscheduled work.

## [0.81.0] - 2026-07-26

### Added

Room rectangles in the editor's Maps tab can now be dragged directly on the
floorplan preview instead of only through numeric sliders — reported after a
user tried to re-anchor rooms onto a brand new floorplan photo and found
there was no way to see or drag the actual box. Pointer-down on a room's dot
(point mode) or rectangle (`map_w`/`map_h` set) selects it and arms a
move-drag; the selected rectangle also grows four corner handles for a
drag-to-resize (opposite corner stays anchored, mirroring the card's own
zone-clean resize). A plain tap (no real movement) still just
selects/deselects, matching the old click-only behaviour.

Rectangle overlay mode previously rendered only a small centre dot — width
and height existed purely as numbers in two sliders, invisible on the
preview. It now draws the actual box, so its extent is visible while
dragging/resizing.

### Fixed

The Maps tab's map preview (and, in merged mode, its semi-transparent "native
map" reference overlay) used to reload — visibly flashing — on nearly every
edit, since it was bound straight to the live `entity_picture` URL Home
Assistant rotates on nearly every state update, and the editor re-renders on
every dashboard-wide `hass` change, not just edits to this vacuum. Reported
as a real flashing-content concern, not just a cosmetic annoyance.

The preview is now a frozen snapshot (`_refMapUrl`), captured only when the
Maps tab opens or the selected vacuum changes — never on a plain re-render.
A new "Refresh reference map" button lets the snapshot be updated explicitly
(e.g. after the robot re-explores/remaps).

## [0.80.5] - 2026-07-26

### Fixed

In merged map mode (multiple vacuums on one floorplan), one vacuum's robot
marker could disappear underneath ANOTHER vacuum's wide translucent wet-mop
band. Reported: S6's marker invisible under S8's blue wet trace.

Cause: `_renderMergedMap` stacked each shown vacuum's ENTIRE overlay (paths +
marker) as one `<svg>` per vacuum, one after another in DOM order. Within a
single vacuum's own `<svg>`, the marker already drew last (on top of its own
paths) — but that only orders a vacuum against ITSELF. A later vacuum's whole
`<svg>` — its wet band included — still sits on top of an earlier vacuum's
marker, since the earlier vacuum's marker is inside an earlier `<svg>` in the
DOM.

`_renderIntegrationOverlay` now takes an optional `part: "paths" | "marker"`
so merged mode can render it in two full passes across every shown vacuum —
every vacuum's paths first, then every vacuum's markers — instead of one
interleaved pass per vacuum. A marker (and its error halo) is now always on
top of every vacuum's paths, regardless of shown/DOM order. Split mode's
`_renderMap` (one fully independent box per vacuum, no shared stacking
context) is unaffected — it keeps calling the function with its original
default (`"both"`, one combined `<svg>`).

## [0.80.4] - 2026-07-26

### Fixed

Per-vacuum setting presets were silently collapsed into one shared object per
pass when sending the orchestrated `anyvac.clean` intent. `_v2Settings()`
looped dry/wet-capable vacuums but stopped after the FIRST capable one per
kind, so e.g. S6's fan_speed preset won for every dry-capable vacuum
including S7, no matter what S7's own preset said. Reported as: "S7 mám v
presetu nastavené na suction max_plus, ale on se vždy přehodí na max když to
pustím."

`_v2Settings()` now builds a genuinely per-vacuum settings map
(`{kind: {vacuum_entity: {...}}}`, matching the new backend shape — see the
paired `anyvac` integration release) for every capable vacuum, using each
vacuum's own active preset (`_activePreset`) — the same extraction the
single-vacuum manual START (`_startClean`) already used, now applied
consistently to the multi-vacuum orchestrated path too, so the preset chip
the user actually selected is respected instead of a heuristic search over
the vacuum's own preset list. `_startClean`'s own `anyvac.clean` call updated
to the new per-vacuum-keyed settings shape (`{mode: {vac.entity: {...}}}`).

## [0.80.3] - 2026-07-25

### Fixed

Landscape dock room rows (`.dock-row`) looked visually "scattered" —
diagnosed from a field screenshot: the trailing warning icons (unassigned/
unsequenced), age chips, and vacuum avatar chips were flat siblings of the
room icon/name in the row's own flex flow, with no growing element and no
`justify-content`, so they packed left along with the name instead of
anchoring to the row's right edge. A room without the optional unassigned/
unsequenced icon landed its avatars at a different x-position than one
with it, and a short room name left a gap before the info block — avatars
didn't line up row-to-row. Grouped the trailing content into one new
`.dock-info` span with `margin-left: auto`, so icon+name is a fixed left
column and everything else is one right-anchored block regardless of which
optional icons are present or how long the name is. Portrait's centered/
wrapped debug room list (`debug_dense_dock`) neutralises the auto margin
(its own layout, unaffected).

## [0.80.2] - 2026-07-25

### Fixed

Room pins (`anyvac.pin_room`) are now per-pass (dry/wet independent) instead
of one flat vacuum per room. Diagnosed from the HA log: a fleet with no
dual-capable robot (dry-only S6/S7 + wet-only S8, this user's real setup)
pinning a room's dry pass silently clobbered its wet pin and vice versa,
because both were writing the same single `room_pins[room]` value — the
planner then hit its automatic-fallback path (with a WARNING) for whichever
pass no longer matched the stored vacuum, on every plan/clean call for that
room. `_cycleRoomPin` now sends `kind` on `anyvac.pin_room`; deselecting a
room still unpins both passes at once (unchanged UX). Requires integration
0.80.2+ (per-kind `room_pins`/`set_room_pin`/`planner._pin_for_kind`).

## [0.80.1] - 2026-07-25

### Changed

Meta bar panel contrast bumped (docs/28 §2 follow-up): the 0.03/0.08
background/border it shipped with in 0.80.0 (same subtle values as
`.vac-picker`/`.dock` elsewhere) read as flush with the map above and the
gap below it instead of its own panel — field-verified live via three A/B
candidates on the user's own dashboard. `.meta-bar` is now
`rgba(255,255,255,0.06)` background / `rgba(255,255,255,0.16)` border,
`.meta-bar-divider` is `rgba(255,255,255,0.22)`. Only this panel changed;
`.vac-picker`/`.dock` weren't reported as a problem.

## [0.80.0] - 2026-07-25

### Changed

Landscape meta bar redesign and layout (docs/28). The `tools` region meta bar
is now its own panel (background + radius, previously flush with the map
above and the dock below) with two clusters: Pin & Go / Zone on the left, a
flexible spacer, then the unassigned/unsequenced warnings, the dry/wet layer
toggle, a divider, and a borderless "ghost" refresh icon on the right. Room
count and ETA chips are dropped from the bar entirely — the dock footer right
below already shows both, so they were a pure duplicate. Refresh now gives a
brief spin animation as tap feedback (`.mtbtn--spin`), since it previously had
none.

Landscape's `dock`/`picker` column (`DEFAULT_PROFILES.landscape.columns` in
`layout.ts`) changed from a fixed `[70, 30]` split to content-driven sizing —
`minmax(0, 1fr)` for the status-card column (grows to fill whatever's left,
unbounded) and `max-content` for the dock/picker column (only ever as wide as
it needs, never wider). `.dock-row`'s room-name field now wraps to a second
line instead of truncating with an ellipsis when unusually long, via a fixed
`max-width` on just that element — this is what lets the column settle on the
row's typical width instead of the single longest name's unwrapped width.

The orchestrated Start button living in `.dock-foot` (landscape's equivalent
of portrait's dedicated `.start-bar`, since landscape has no separate `start`
region) now uses the same calm sage green from the docs/25 §6 visual-language
pass instead of the old saturated green it never received.

The landscape vacuum picker (`_renderBadge`) ring and glow now derive from
the vacuum's live status color (`_statusInfo`) instead of its configured
identity color, mirroring the portrait icon strip (0.69.0) — one visual
language for "what it's doing", identity stays on the background wash and the
icon/photo. Uses border width and glow radius (not an alpha-blended color) to
distinguish "shown" from "actively cleaning", since several common statuses
(docked/idle/charging) are `rgba(...)` literals in `STATUS_MAP`, not hex, and
the old identity code's hex-alpha-suffix trick would have produced invalid
CSS for those.

## [0.79.4] - 2026-07-25

### Changed

Removed the "all"/"none" quick-select links from each vacuum's status card
START button. With the integration present they mutated the exact same
shared room selection the dock's per-room list already manages — three
identical controls (one per vacuum card) doing the same thing to the same
state, buried as small text inside a button that also starts cleaning.
Cockpit minimalism (docs/25 §5) already made an empty selection mean "whole
home", so "select all" / "select none" add nothing the dock doesn't already
cover more precisely. `_selectAll`/`_deselectAll` removed (dead code, no
other callers). The room-icons glanceable indicator in the START button is
unchanged.

## [0.79.3] - 2026-07-25

### Fixed

Field report: once a room's vacuum was manually pinned (`_cycleRoomPin` →
`anyvac.pin_room`), it stayed pinned forever — the only automatic clear was
after the room was actually cleaned (docs/18 §7e), so re-selecting the same
room later silently kept the stale manual override instead of going back
through the planner. `_toggleRoomAcross` now clears the room's pin
(`anyvac.pin_room` with no `vacuum` — the integration's documented unpin)
the moment the room is DEselected, giving an obvious way back to auto:
untick the room, tick it again.

## [0.79.2] - 2026-07-25

### Fixed

Field report: on Android, swiping up from the screen's bottom edge (system
gesture nav / app switcher, used e.g. to force-close for a hard refresh)
would sometimes start or cancel cleaning, because the gesture's touch begins
on the START bar which sits flush against that edge in portrait. Root cause:
touch pointers get implicit capture to their initial target, so
`pointerleave`/`pointercancel` never fire as the finger slides away during
the swipe — only `pointermove` does, and nothing was listening for it, so
the 600ms hold timer kept running and fired right as the OS took the
gesture over. Fixed in the shared `_holdStart` hold-to-confirm helper (all
9 call sites: START/CANCEL bar, dock run buttons, global-action badge,
per-vacuum resume/pause/start) — a new `_holdMove` pointermove handler
cancels the hold once the pointer has moved more than `HOLD_MOVE_CANCEL_PX`
(12px) from its start position, distinguishing a swipe/drag starting on the
button from a deliberate hold-in-place.

## [0.79.1] - 2026-07-25

### Fixed

Field report: dock sheet consumable reset buttons "don't reset the consumable".
Live-diagnosed against the field-reporting user's real HA (Claude in Chrome,
`button.press` on `button.s7_maxv_reset_sensor_consumable`): the reset itself
works fine — the official `roborock` integration's own consumable sensor
takes up to one poll cycle (~30s, live-measured at 27s) to reflect it. The
actual bug: `_watchedEntities()` never included the dock sheet's care-item
sensor/reset-button/tank-binary entities (`_careItems`, added in 0.75.0), so
`shouldUpdate`'s watched-entity gate silently skipped re-rendering when they
changed — the refreshed value sat in `hass.states` until some unrelated
watched entity (battery tick, status change, ...) happened to trigger a
render, which read as "reset doesn't work" rather than "works with a delay".
Care item entities are now added to the watched set alongside the existing
per-vacuum ones.

### Added

Reset buttons now show a spinner (disabled) from tap until the watched
sensor's `last_changed` moves past the press time, with a 40s hard-timeout
fallback for an offline vacuum whose poll never lands (`_careResetPending`) —
even with the render-gating fix above, a ~30s silent wait after tapping
still reads as broken without some feedback.

## [0.79.0] - 2026-07-25

### Changed

Portrait START bar split into three segments (docs/25 §10 follow-up), mirroring
the manufacturer app's bottom bar (mode / START / Dock). Left segment shows the
current clean type (Dry/Wet/Both icon + label) and opens a small mode-picker
sheet on tap; right segment opens the existing Dock control sheet (Empty/Wash/
Dry/Pump/Self-clean + consumables, unchanged); center keeps the hold-to-start
(and hold-to-cancel while running) button. Both side segments reuse the
existing `.dock-mode` sheet pattern (new `_renderModeSheet`, mirrors
`_renderDockSheet`) rendered in-flow in the `dock` region below the bar; the
two sheets are mutually exclusive (opening one closes the other). The
mode/Dock buttons that used to sit permanently in `.dock-head` above the bar
are now only rendered there when there's no separate `start` region to host
them (landscape, unchanged) — portrait's `.dock-head` row is gone, replaced by
the new segments.

## [0.78.1] - 2026-07-25

### Fixed

Field report: tapping a room's vacuum avatar to reassign it (docs/18 §7e
pin cycling) sometimes did nothing at all no matter how many times it was
tapped (Living room, reproduced live), and on other rooms seemed to need a
manual page refresh to show the change. Root cause, confirmed live against
the user's actual fleet (dry-only S6 + S7, wet-only S8 — no vacuum capable
of both): `_pinCandidates`/`_cycleRoomPin` cycled the dry chip AND the wet
chip through the SAME candidate list — every vacuum that merely knows the
room, not filtered by whether it can actually perform that pass. Cycling
the dry chip could silently pin the room to the wet-only vacuum (the dry
display can't show it, so nothing visibly changes), and if that wet-only
vacuum was already the stored pin, the dry chip's cycle became a permanent
fixed point — tapping it forever recomputed the same "next" candidate,
which was already the current value, so it truly never changed. `_pinCandidates`
now takes a `kind: "dry" | "wet"` parameter and filters candidates by
`_vacCleanType(v)[kind]` — each chip cycles only among vacuums actually
capable of that pass, so a cross-type write (and the stuck fixed point it
could produce) is no longer possible. A room with only one capable vacuum
for a given type (e.g. this fleet's wet pass — only S8) correctly has no
tap handler on that chip, same as before. Both call sites updated
(portrait dock rows, hold-to-inspect popup). Typecheck + build clean;
capability filtering verified live against the reporting user's actual
fleet data via Claude in Chrome.

## [0.78.0] - 2026-07-25

### Changed

Docs/27 — orchestrated multi-sortie clean now renders as one continuous
dry+wet trace on the map instead of resetting at every dock trip between
progressive-dispatch batches (docs/23). `path_wet_px` changes shape from a
flat point array to a list of segments (matching `path_dry_px`, docs/14
§3.9) — `_renderIntegrationOverlay` now draws the wet trace (mop band +
centre line) as one `<polyline>` per segment instead of a single flat
polyline, so a dock trip between two dispatches never draws as a straight
line either. Purely a rendering-side consequence of the backend now
persisting the trace across sorties within one job (see `anyvac`
CHANGELOG) — no card-side accumulation, no new config.

## [0.77.1] - 2026-07-24

### Fixed

0.77.0's dock-tier gating had an over-broad side effect: S6 (tier
`"none"` — no dock at all) dropped out of the Dock sheet's tab list
entirely, taking its own body consumables (main brush, side brush,
filter, sensor — these live on the vacuum's own device and have nothing
to do with dock hardware) down with it. The tab list and the Empty
action are now gated separately: a vacuum stays in the tab list if it
has dock actions OR care rows to show, and the Empty button itself only
renders when the vacuum actually has some dock (tier `"empty"`/`"full"`)
— S6 keeps its own consumables visible, just with no dock actions row at
all (it has none).

## [0.77.0] - 2026-07-24

### Fixed

Field-test feedback on 0.76.0's Dock sheet + Care section (docs/25 §10
third follow-up):

- **Hardware-tier gating.** The Dock sheet/actions/dock-mounted care rows
  used to render identically for every configured vacuum, regardless of
  what dock it actually has. Fixed by reading `dock_status.dock_type`
  (already flowing through the integration sensor — no new backend work)
  and mapping it to `python-roborock`'s `RoborockDockTypeCode` tiers:
  no dock at all (S6 — `dock_type` absent) hides the Dock button
  entirely; an empty-only dock (S7 MaxV — `dock_type: 1`) shows just the
  Empty action and hides Wash/Dry/Pump/Self-clean plus the dock-mounted
  consumables (dock brush, strainer, tank status); a full wash+dry(+
  plumbing) dock (S8 MaxV Ultra — `dock_type: 10`) is unchanged. All
  three tier values were read live off the user's actual HA, not
  inferred — the field report was investigated by walking their real
  entity/device registry before writing any gating logic. Fixes a
  related, subtler bug for free: S7's `dock_maintenance_brush_time_left`/
  `dock_strainer_time_left` sensors exist in HA's registry (created per
  device *model*, not per physically-installed accessory) but always
  report "unavailable" — the card was showing these as dead rows before.
- **Consumable units.** `main_brush_time_left` and friends come back in
  seconds on some vacuums and hours on others (confirmed live: S6 reports
  `s`, S7/S8 report `h`, same sensor type) — the Care section now
  normalizes everything to hours before display. On top of that, the four
  body consumables with a well-established nominal lifespan (main brush
  300h, side brush 200h, filter 150h — matches Roborock's published HEPA
  filter service interval — sensor 30h; triangulated from three
  independent live units converging on the same round totals) now show
  **% remaining** instead of a raw hour count, per the user's request. The
  two dock-mounted consumables (cleaning brush, strainer) keep showing
  hours — only one live data point for each, no round-number pattern to
  anchor a total on, so a % there would be a guess dressed up as a fact.

- Real-hardware polish pass on the landscape cockpit (docs/18/19). Plus this
  release's layout hardening ship as **v1.0.0**.
- Rest of docs/25 (Fáze 3, inserted before v1.0.0): top tab-strip navigation
  (low priority — no second page needs it now that care lives in the Dock
  sheet, see 0.75.0) and the visual language pass — neither shipped yet.

## [0.76.0] - 2026-07-24

### Added

Two more Dock sheet actions (docs/25 §10 second follow-up), next to
Empty/Wash/Dry: **Pump** and **Self-clean**. Both came from a live back-
and-forth with the field-reporting user comparing their manufacturer app's
"Dock Maintenance" screen against `python-roborock`'s `RoborockCommand`
enum:

- **Pump** → `app_empty_rinse_tank_water` (undocumented, found in the
  enum). Maps to the app's "Pump — drain the remaining water from the
  cleaning sink" — the mop-rinse basin every dock has, not the optional
  Fill&Drain plumbing accessory's own tank. User confirmed live (2026-07-24,
  Developer Tools → `vacuum.send_command`): pump audibly ran, matched the
  app's own "Pump" action.
- **Self-clean** → `app_amethyst_self_check` (undocumented, found in the
  enum — "amethyst" appears to be Roborock's internal codename for the
  Fill&Drain accessory). Maps to the app's "Dock and Fill&Drain Element
  Self-Cleaning" ("performs a self-check on the element") — the wording
  match against "self_check" is what pointed here. User confirmed live:
  exactly the action they wanted.

Both call new `anyvac.dock_pump`/`anyvac.dock_self_clean` services
(integration 0.76.0, synced), same `_dock_command` plumbing as the
existing three. Shown unconditionally for every configured vacuum, same
as Empty/Wash/Dry — there's no documented way to detect which dock
accessories (auto-empty, wash+dry, Fill&Drain plumbing) are actually
installed, so gating would mean guessing thresholds, which this project
avoids (docs/26 precedent). `.dock-sheet-actions` now wraps to two rows
on narrow screens (`flex-wrap` + `flex: 1 1 27%`) instead of squeezing
five buttons into one.

**No confirmed command found** for the app's third Dock Maintenance item
("Fill&Drain Element Drain" — drains the accessory's own built-in sewage
tank, distinct from Pump's cleaning-sink drain). Not implemented; revisit
only if a real command turns up.

## [0.75.0] - 2026-07-24

### Added

Consumable/"care" rows in the Dock sheet (docs/25 §10 follow-up) — extends
0.74.0's Dock sheet instead of a separate "Péče" page, since both live
under the same "dock maintenance" concept the user originally described.
Auto-discovered from the official `roborock` integration's own entities —
zero new config keys, zero new backend code, same pattern as the existing
`integration_entity`/status-sensor auto-resolve. Per active tab: main
brush, side brush, filter, and sensor consumables (time-left + reset
button, matched via HA's `translation_key`, robust to user-renamed
entities) from the vacuum's own device; dock-mounted cleaning-brush and
strainer consumables (time-left + reset) plus S7/S8 water-tank binary
status (dirty water tank, clean water tank, cleaning fluid) from the
vacuum's separate `"<name> Dock"` HA device. That second device is found
via its `identifiers` (always the vacuum's own duid + `_dock`, confirmed
live against the field-reporting user's real HA registry — not a
name-match, so it survives renames) rather than by string-matching. A
vacuum/dock missing a given entity (e.g. S6 has no dock device at all; S7's
dock doesn't expose reset buttons for its own consumables) simply omits
that row.

**Correction to 0.74.0:** the Empty/Wash/Dry dock actions were briefly
believed non-functional in the field — turned out the user had only
updated the card, not reloaded the paired `anyvac` integration (0.74.0),
so the `anyvac.dock_*` services didn't exist yet and calls silently failed
client-side. Confirmed working once the integration was actually deployed.

## [0.74.0] - 2026-07-24

### Added

Dock sheet (docs/25 §7 field follow-up) — the manufacturer app's bottom-bar
Dock button, adapted for multi-vacuum: a new "Dock" button in the portrait
`dock-head` row (next to Dry/Wet/Both) opens an in-flow panel with a tab
per configured vacuum (only shown when 2+) and three action buttons —
Empty, Wash, Dry — calling the new `anyvac.dock_empty`/`dock_wash`/
`dock_dry` services (integration 0.74.0, synced). A small dot on the Dock
button flags a real dock error (`dock_error_status`) on any vacuum; other
raw `dock_status` fields are shown only behind the existing `debug` config
flag, since their value encodings aren't documented upstream (Roborock's
API doesn't expose tank-fill percentages the way the app's UI implies —
verified against python-roborock's source before building this).
Deliberately in-flow (not a floating overlay) — the `dock` region already
scrolls (`overflow:auto`), and this avoids adding `position:fixed`/
absolute layering to a region with real mobile-crash history (docs/21
§5b) tied to grid ownership.

**Scope note:** this replaces the docs/25 §2/§3 plan (separate "Péče"
page + top tab-strip navigation) for the dock-control slice specifically.
Consumables status/resets (main/side brush, filter, sensors — the rest of
§2) remain unimplemented, deferred to a later step by explicit user
choice (2026-07-24).

## [0.73.7] - 2026-07-24

### Changed

`shouldStackLayout()`'s `stackBias` raised `1.3` → `1.5`. Live A/B on the
field-reporting user's actual box (360×580 in the dashboard editor,
360×514 on their real phone) — forced `topology: stack` vs the computed
`split` on the identical box, screenshotted side by side via Claude in
Chrome against their running instance — showed stack was still clearly
better even though split "won" the raw metric by only ~4%. Root cause:
for this floorplan's extreme (~0.27) rotated aspect ratio, both
candidates end up giving the map a similarly narrow sliver, so their raw
achieved-size scores are nearly tied — but split's leftover dock column
only ever fills ~250px with real content (avatars/chips/mode row)
regardless of how much width it's handed, so the rest sits empty, while
stack's full-width dock row uses its space properly. That "wasted width"
cost isn't captured by the raw metric at all, so `1.3` never fully
compensated for it. `1.5` was verified by hand against both real reported
boxes (needed > 1.41 for the tighter 514px case) before shipping.

## [0.73.6] - 2026-07-24

### Fixed

Stack topology (0.71.0) rendered ~2 phone-screens tall instead of fitting
the viewport, permanently — not a first-paint flash, a stuck state.
Root cause: `STACK_PORTRAIT_PROFILE`'s map row was a bare `"1fr"`, whose
CSS Grid implicit minimum is `auto` (its content's min-content size), not
`0`. `_renderResponsive()` returns the map template unwrapped/unbounded
until the map region has been measured once — on a brand-new stack render
that unmeasured natural size became the row's forced minimum, blowing the
whole grid out, and the following measurement pass read the ALREADY
blown-out region back as "correct," locking it in for good (the settle
loop only checks "changed by ≥2px," not "too big"). Fixed by changing the
row to `"minmax(0, 1fr)"` — caps it to its fair share of the grid from
frame one, letting the region's existing `overflow:hidden` clip the
oversized first-paint content instead of stretching the grid; the next
measurement then reads the correctly-sized region and the lock-in never
happens. Confirmed live against the field-reporting user's real Home
Assistant instance (Claude in Chrome), both in and out of dashboard edit
mode, before shipping — not just typechecked/built clean.

Also confirmed in the same live session that the split-vs-stack topology
decision itself (0.73.1/0.73.2) is correct: it only looked "stuck on
split" because the debug chip (0.73.3–0.73.5) is edit-mode-only, and
entering dashboard edit mode costs ~120px of vertical space (edit
toolbar + per-card actions bar) — enough on this floorplan to flip the
decision back to split. Outside the editor, stack was already being
chosen correctly.

## [0.73.5] - 2026-07-24

Debug chip follow-up #2: after the 0.73.4 width fix, the second line (the
actual `stack`/`split` decision data) was still effectively invisible —
its translucent (35% opacity) text was overlapping the vacuum avatar photos
below it with too little contrast to read on a compressed phone screenshot.
Chip now has a solid dark background pill (`rgba(0,0,0,0.75)`, rounded,
padded) and brighter text (85% opacity), so it's legible regardless of what
renders underneath it. Also switched from `left+right` (forced full card
width) to `right` + `max-width` so the chip shrinks to its own content
width instead of stretching, and bumped `z-index` to 20 to sit above map/
region content unambiguously. Still TEMP debug instrumentation (docs/25 §4
split/stack diagnosis) — remove once the topology model is confirmed
correct in the field.

## [0.73.4] - 2026-07-24

Debug chip follow-up: it was overflowing past the card's left edge on a
narrow (360px) card, invisible. Chip now wraps onto two explicit lines
within the card's own width instead of shrink-to-fit growing past it.

## [0.73.3] - 2026-07-24

Temporary debug build — 0.73.2's fix didn't change anything for the field
tester despite the math checking out against estimated screenshot pixels,
so estimating from screenshots isn't reliable enough to keep debugging
this blind.

### Debug

- Edit-mode version chip now also shows the exact numbers the split/stack
  decision is computed from: chosen topology, measured box size
  (`_mapAvailW`x`_mapAvailH`), and the effective floorplan aspect ratio
  used. Remove once the topology model is confirmed correct in the field.

## [0.73.2] - 2026-07-24

Second same-day correction to the split/stack topology decision (0.73.1) —
the pixel-based dock estimate alone still wasn't enough.

### Fixed

- Root cause (confirmed with real numbers from the field — 908×1726px
  content box, ~0.185 floorplan aspect ratio): split reserves ZERO height
  for the dock (it sits beside the map), so its "achieved map size" is
  always the box's full height regardless of any dock cost estimate, while
  stack's is always `boxH − dockHeightPx` — strictly less. For a narrow
  enough floorplan, split therefore always wins on raw map size, no matter
  how `dockHeightPx` is tuned — a structural limit of "biggest map wins",
  not a parameter to adjust away. New `stackBias` (default 1.3): stack is
  now the default choice, and split only wins when its raw score beats
  stack's by a clear margin (30%+), not just "any amount more" — matches
  the field observation that a ~9% smaller map with a properly-sized dock
  row looked clearly better than a marginally bigger map next to a mostly
  empty column.

## [0.73.1] - 2026-07-24

Field-caught model correction for the split/stack topology decision
(0.71.0): a user's 4-storey narrow floorplan scored `split` as the
"better fit" and got it automatically, but visually it left the dock
column mostly empty — manually forcing `topology: stack` looked clearly
better once tried.

### Fixed

- `shouldStackLayout()`'s stack candidate reserved a FRACTION of box height
  for the dock, same as split reserves a fraction of width — wrong model.
  A real dock's content (icon strip + layer toggles + mode row, now that
  the room list is hidden by default) is a roughly fixed pixel height
  regardless of box size, so the fractional model made stack's reserved
  space grow with box height, unfairly penalizing it for exactly the
  tall/narrow floorplans where a fixed-height dock row matters most.
  Replaced with a fixed `dockHeightPx` (~150px) estimate for the stack
  candidate; the split candidate keeps its width fraction (a column's width
  genuinely does scale with the box, unlike a stacked row's height).
- New `layout.portrait.topology: stack` config override (added same day as
  0.71.0, unchanged) remains the immediate escape hatch for anyone who
  still disagrees with the computed choice.

## [0.73.0] - 2026-07-24

Docs/25 §6 (visual language pass) — first slice. Direction agreed via a
before/after mockup (not locked-down exact values, per §6's explicit
"iterate on real hardware" note) — this ships the parts of that mockup that
translate directly into the real card's CSS.

### Changed

- START bar: bigger (min-height 44px → 52px), rounder (14px → 18px radius),
  bigger/bolder text, and its own calm sage green instead of the same
  saturated green used for "cleaning" status elsewhere — it's the one
  thing the whole screen is for, so it should unambiguously be the
  heaviest element on it. Room-count/ETA text was already inline in the
  button; unchanged.
- Dock mode row (Dry/Wet/Both): resting weight stepped down (700 → 600),
  active state keeps 700 — a secondary control next to START shouldn't
  compete with it for attention, but active/inactive contrast is preserved.
- Portrait vacuum icon strip ring: thinner (2px → 1.5px) — reads calmer
  without losing the status-color signal.
- Dock container: more internal spacing (gap 6px → 9px, padding 6px → 8px)
  — "generous whitespace" was one of the agreed directions.

### Deferred

- Map path color/opacity — the mockup's path styling was illustrative, not
  a faithful rendering of the real dry/wet path system; changing it has
  real legibility stakes (does it still read clearly where the robot went)
  that need judging against a real floorplan screenshot, not a schematic
  mockup. Revisit with real HW screenshots.
- `STATUS_MAP` colors themselves — unchanged; reserving their saturation
  for actual status meaning (cleaning/error/etc.) rather than diluting it
  card-wide was part of the reasoning for giving START its own color
  instead of reusing green.

## [0.72.5] - 2026-07-24

Fifth field-caught fix, same day: 0.72.4's near-opaque background +
isolation still didn't stop the selected room's ring from showing through
the popup.

### Fixed

- Structural fix instead of another opacity/isolation tweak: the popup now
  renders as a SIBLING of the room's `<button>`, not a child. Nested inside
  the button, it was always going to be at the mercy of that button's own
  border-image/box-shadow paint behavior no matter how opaque its own
  background was. As an independent sibling positioned at the room's own
  `map_x`/`map_y` (the same point its button anchors to), there's no
  parent/child relationship left for the button's selected-state styling to
  interact with.

## [0.72.4] - 2026-07-24

Fourth field-caught fix, same day: on a selected room, the room's own
gradient border/glow visibly bled through the inspect popup.

### Fixed

- `.room-inspect-inner`'s background was 94% opaque, letting the selected
  room's white gradient border/glow (`box-shadow: 0 0 18px`, painted on the
  same button the popup sits centered on top of) show faintly through —
  read as "the ring crosses the age display" even though the popup was
  already the topmost paint layer. Background bumped near-opaque
  (rgba(18,18,18,0.99)) plus `isolation: isolate` so no ancestor glow can
  bleed through at all.

## [0.72.3] - 2026-07-24

Third field-caught fix, same day: on a near-full-map-width room, the
inspect popup rendered ~80% off the left edge of the screen.

### Fixed

- Root cause: the below/above-the-room anchor (`top: 100%` / `bottom: 100%`)
  was sized off the room button's OWN width/height. For a large room, that
  offset is large — and after the map's `.avc-rot` 90° rotation, a large
  local-space offset becomes a large screen-space offset, pushing the
  popup mostly off-screen. Re-anchored to the room's dead center instead
  (`top: 50%; left: 50%; transform: translate(-50%, -50%)`) — a rotation's
  center point never moves under that rotation, so this lands on the same
  screen spot regardless of room size or map orientation, with no separate
  math needed for the rotated case. The popup now briefly covers the room's
  own icon/age-dots instead of floating past its edge; acceptable since the
  popup already names the room. The `--above`/flip logic is gone — nothing
  left to flip once centering doesn't depend on room size.

## [0.72.2] - 2026-07-24

Two more field-caught fixes, same day.

### Fixed

- Inspect popup's border/background/padding were on the outer (unrotated)
  positioning div while only the text content rotated in `.avc-rot` —
  visible box and text disagreed on orientation. Moved the whole visual box
  onto the counter-rotating inner div so it rotates as one rigid unit.
- Hold-to-inspect silently did nothing on large (near full-map-width)
  rooms — `.room-overlay`/`.room-btn` were missing the `touch-action:
  manipulation` / `-webkit-touch-callout: none` / `user-select: none` combo
  already applied to `.vac-icon-btn`/`.badge`/`.layer-btn` earlier this
  session (0.68.1) for the identical class of bug: the browser's own
  long-press handling can win the race against the JS hold timer and fire
  `pointercancel` first. Bigger touch targets appear to make browsers more
  likely to contest the gesture, which is why it only showed up on the
  larger rooms.

## [0.72.1] - 2026-07-24

Field-caught fix, same day as 0.72.0: the inspect popup rendered sideways
in the rotated portrait map.

### Fixed

- Popup content now counter-rotates in `.avc-rot` (rotated portrait map),
  matching the room icon/gauges — a whole popup of text read sideways was
  genuinely unreadable, unlike the small icon/gauges the "no counter-
  rotation" call in 0.72.0 was modeled on. Applied to a nested inner div so
  it doesn't fight the popup's own position/anchor transform.

## [0.72.0] - 2026-07-24

Docs/25 §7b: hold-to-inspect on the map, replacing the per-room detail that
the minimalist portrait cockpit (0.70.0/0.70.1) hid from the dock room list.

### Added

- Hold a room on the map to open a small popup with its name, dry/wet age
  badges and (when the room is selected) the assigned vacuum chips —
  tappable to cycle the pin, same as the old dock row. A tap while the
  popup is open dismisses it instead of toggling selection. Anchors below
  the room by default, flips above for rooms in the bottom half of the map.
- Works in both rectangle and legacy point room modes; reuses the existing
  tap/hold pointer pattern from the vac-icon-strip (not `_holdStart`, so tap
  and hold can do different things reliably across browsers).

### Known limitations (v1)

- Not edge-aware on the horizontal axis, and the map region still clips
  overflow — a room very close to the left/right edge can get its popup
  partly cut off.
- No counter-rotation in the rotated portrait map (`.avc-rot`) — matches
  existing precedent for the assignment chips/gauges, which also render
  sideways there today.

## [0.71.0] - 2026-07-24

Docs/25 §7c: portrait map/dock topology as a computed choice.

### Added

- `shouldStackLayout()` (`layout.ts`) is now wired into the actual grid
  render: portrait picks between **split** (today's default, map/dock side
  by side) and **stack** (map full-width on top, dock/vacuum-row/START
  stacked full-width below) by comparing achieved floorplan fit scale for
  each, same contain-fit-scale technique as `shouldRotateMap()` (§4).
  Targets the field-observed problem where a naturally tall/narrow
  floorplan left the split's dock column wide and mostly empty.
- New `layout.portrait.topology: auto|split|stack` config override — same
  escape-hatch pattern as `crop.mapOrientation`. Any explicit
  `columns`/`rows`/`place` on `layout.portrait` already opts out of the
  computed choice on its own (unchanged rule), regardless of `topology`.
- New measured box (`_mapAvailW`/`_mapAvailH` — the combined map+dock
  content area, independent of which topology is currently applied) feeds
  the decision; settles over 1-2 renders like the existing rotation logic
  (`_lastRotate` → now `_lastStack`).

### Notes

- Touches the grid sizing mechanics that previously caused a mobile
  companion-app crash (0.59.0–0.61.0, docs/21 §5b) — kept to the same
  established layered pattern (declarative `styleMap` fallback + JS
  refinement on top, never sole JS ownership) as a precaution. Field test
  requested before relying on this away from a full-width dashboard card.

## [0.70.1] - 2026-07-24

Field-caught fix, same day as 0.70.0: gating the portrait room list on
`debug_room_progress` meant a user who keeps that flag on for coverage-%
debugging never saw the new minimalist cockpit at all.

### Fixed

- New independent `debug_dense_dock` config flag controls the portrait room
  list; `debug_room_progress` goes back to its original narrow scope (map
  gauges / inline % chips only). The two are unrelated — coverage debugging
  works fine with the minimalist cockpit, since the map gauges don't live in
  the room list.

## [0.70.0] - 2026-07-24

Docs/25 §7c resolved (field diskuze: mode switcher + path-visibility are the
two must-have-before-start controls; room list is not) and its first piece
shipped.

### Changed

- Portrait dock's permanent room list (`dock-rows` — per-room age/pin/avatar
  detail) is now gated behind `debug_room_progress`. Selection stays
  map-tap-only; per-room detail is moving to a hold-to-inspect gesture on the
  room (docs/25 §7b), not yet shipped — until then this detail is only
  reachable via the debug toggle. Landscape's dock/picker sidebar (docs/18/19
  A5) is unaffected, keeps the room list unconditionally.
- `layout.ts`: new `shouldStackLayout()`, generalizing `shouldRotateMap()`
  (§4) to the map/dock topology choice (split vs. stack, docs/25 §7c) — pure
  geometry helper, not yet wired into the card's grid computation.

## [0.69.0] - 2026-07-23

First implementation slice of docs/25 §7 (field diskuze, portrait cockpit
structure/interaction rework). Two self-contained pieces landed; the larger
structural items (top tab-strip navigation, computed split/stack topology,
map→vacuum→START block reorder) are follow-up work, see docs/25 §9.

### Changed

- Vacuum ring color (`.vac-icon-btn` in the portrait icon strip) switched
  from per-vacuum identity color (`_color(v)`) to live status color
  (`_statusInfo(v)` / `STATUS_MAP` — cleaning/error/docked etc., same
  palette as the status cards). One visual language for "what it's doing"
  instead of two competing ones for "what it's doing" + "which one is it" —
  identity still carries via the avatar photo/icon inside the ring. Badges
  (`_renderBadge`, landscape picker) intentionally NOT touched in this pass —
  more entangled visual states (cleaning glow blended with identity color,
  active-selection tinting), deserves its own pass.
- Per-room age indicator reworked: the room border/icon on the map no
  longer carries age color (`_colorForAgeDays`) — that channel is now
  reserved purely for interaction state (normal/whole-home/selected, one
  white-family scale). Age moved to two small corner dots (dry left, wet
  right, same order as everywhere else in the card) via new
  `_renderRoomAgeDots()`, gated on the vacuum's clean-type capability so a
  dry-only setup doesn't grow a permanent "never wet cleaned" dot. A tried
  double-ring alternative (inner = selection, outer = age) was rejected —
  at real room size on a phone the two rings visually merge into one blurry
  edge, doesn't read as two separate signals. Degraded mode (no companion
  integration) keeps working via a single dot from the legacy
  `last_clean_entity` helper. Dead code removed: `_roomBorderColor`.

Sources: field diskuze 2026-07-23 (mockups at real room scale), docs/25 §7a/§7d.

### Changed

- Whole-home map highlight (0.68.2) was too subtle to notice on a real
  floorplan — field feedback: "if I didn't know about it, I wouldn't see it
  at all". Bumped border width (2px → 3px, still below selected's 4px),
  border opacity (45% → 75% white), background tint (7% → 16% white), and
  added a soft glow (absent → `0 0 10px rgba(255,255,255,0.4)`, softer than
  selected's `0 0 18px rgba(255,255,255,0.7)`). Legacy point-mode markers
  bumped similarly. Still a clear step below an explicit selection, just
  actually visible now.

## [0.68.2] - 2026-07-23

### Added

- docs/25 §5 leftover: the map now visually reflects the whole-home
  implicit plan when nothing is explicitly selected, not just the
  START/dock/meta-bar text. Every room rectangle (and legacy point-mode
  marker) gets a soft white border + faint tint — deliberately one weight
  class below an actual explicit selection (no gradient border, no glow, no
  white icon, no per-room vacuum-assignment chip), since whole-home stays a
  glanceable "this is what will run" confirmation, not a stand-in for
  picking rooms. Applies uniformly in merged mode (`_renderMergedRooms`)
  and split/per-vacuum mode (`_renderMap`). Clicking a room while in this
  state behaves exactly as before (starts an explicit single-room
  selection).

## [0.68.1] - 2026-07-23

### Fixed

- Portrait vacuum icon strip hold-to-hide (`.vac-icon-btn`, docs/19
  follow-up) and the older badge-row hold-to-hide (`.badge`) silently did
  nothing on mobile: the fill-ring animation played to completion, but the
  vacuum's shown/hidden state never actually changed. Root cause: neither
  class set `touch-action`/`-webkit-touch-callout`/`user-select`, so on
  iOS/Android WebViews the OS's own long-press affordances (image-save
  callout on the `<img>` avatar, text selection, Haptic Touch preview) race
  our 600ms `pointerdown` timer — the native gesture wins right at the
  deadline and fires `pointercancel` a moment before our `setTimeout`
  callback runs, so `_toggleShownMulti()` never executes even though the
  CSS ring visually finished. Added the same `touch-action: manipulation;
  -webkit-touch-callout: none; user-select: none;` already used on
  `.layer-btn` to both `.vac-icon-btn` and `.badge`, plus `pointer-events:
  none` on their inner `<img>` avatars so the image itself is never
  hit-tested for native gestures. Field verification pending.

## [0.68.0] - 2026-07-23

First installment of docs/25 (Fáze 3, portrait stránkování a cockpit
minimalismus — inserted before v1.0.0 per docs/22). Two of the three pieces
land here; the pages/menu system and the visual language pass are still to
come.

### Changed

- **Map orientation in portrait is now a computed choice, not a fixed rule**
  (docs/25 §4). The old behavior always rotated the map 90° in portrait —
  which only worked because it was tuned against one specific (wide)
  floorplan. `shouldRotateMap()` (`layout.ts`) now compares the contain-fit
  scale of the floorplan upright vs. rotated inside the measured portrait
  map region and picks whichever renders the bigger map; near-square
  floorplans default to not rotating (cheaper — no counter-rotating on-map
  labels). New `layout.portrait.crop.mapOrientation: auto | normal |
  rotated` escape hatch for the cases the computed rule doesn't call the way
  you want. Legacy (no `layout:` block) rendering is untouched.
- **Cockpit minimalism** (docs/25 §5): no explicit room selection is no
  longer a dead end — it now means "whole home". The portrait START bar is
  immediately pressable the moment the card opens (`Start · whole home · ~N
  min`), the landscape dock's run button and the meta bar / stats trio
  glanceable numbers all show the whole-home estimate instead of "0 rooms".
  Explicit room selection still works exactly as before and takes over the
  moment you pick anything; per-room "selected" styling is untouched (only
  the primary-action affordances default to whole-home).

### Known gaps

- The map's "gently highlight the whole floorplan when nothing is picked"
  visual (docs/25 §5) isn't done — the estimate/label reflect whole-home,
  but the map itself doesn't yet show which rooms that implies.
- Pages/menu (care & consumables, docs/25 §2-3) and the visual language pass
  (docs/25 §6) are unstarted.
- In whole-home mode the card shows room/time counts but not per-room
  vacuum assignment (the dock's avatar chips stay tied to an explicit
  selection). Confirmed with the user as an accepted boundary, not a gap to
  close — see the "assignment stays tied to explicit selection" note in
  docs/25 §5.

## [0.67.1] - 2026-07-23

Room-pin UX simplification (field feedback): the old auto → vac1 → vac2 →
auto cycle relied on a "pinned" indicator (a 1.5px box-shadow ring plus a
10px `mdi:pin` glyph inside a 17px chip) that turned out to be practically
unreadable in the dashboard, and the auto/pinned distinction itself wasn't a
concept the user found useful.

### Changed

- Tapping a room's vacuum avatar in the dock now cycles directly and only
  between the room's real candidate vacuums (e.g. two dry-capable vacuums
  alternate on every tap); there is no longer a manual "back to auto" step
  in the UI. The backend's automatic clear-after-cleaning behaviour
  (`anyvac.pin_room`, docs/18 §7e) is unchanged — pins still self-clear once
  the room is next cleaned, only the manual UI cycle changed. A room with
  fewer than two candidate vacuums (e.g. a wet-only room with one wet-capable
  robot) still has no tap handler attached — nothing happens, as expected.
- Removed the `mdi:pin` icon and the `.dock-chip--pinned` ring styling from
  `_vacChip`; the chip is now purely an assignment label everywhere it's
  used (dock room rows and the on-map room overlay).

## [0.67.2] - 2026-07-23

### Fixed

- The dock avatar didn't update after tapping to cycle a room's pin (0.67.1)
  — the plan preview (`anyvac.plan`) is cached by a key of `[selKeys, mode,
  vacuums]`, which pinning doesn't change, so `_fetchPlan` skipped the
  re-fetch even though the backend's `room_pins` had already updated.
  Deselecting/reselecting the room changed `selKeys` and incidentally
  forced a refetch, which is why it "fixed itself" on a second toggle.
  `room_pins` is now part of the cache key, so the avatar updates
  immediately on tap.

## [0.67.3] - 2026-07-23

### Fixed

- Cycling a room's pin (0.67.1) felt inconsistent — the same tap sometimes
  advanced to the next vacuum, sometimes appeared to do nothing
  (`S6→S7→S6→S6→S7`). Cause: `_cycleRoomPin` advanced from the raw
  `room_pins` backend store, not from the vacuum the tapped chip was
  actually displaying. Right after selecting a room there's usually no
  stored pin yet, so the first tap resolved to "no current pin" → candidate
  0 — a no-op whenever candidate 0 already matched the auto-assigned
  vacuum being shown. Cycling now always starts from what the tapped chip
  currently shows (dry and wet chips can differ and are tracked
  independently), so every tap advances by exactly one candidate.

## [0.67.0] - 2026-07-22

Rooms from the integration (docs/20, variant A, ratified 2026-07-22): room
geometry now tracks the Roborock app live, no more manual re-import after
renaming/adding/splitting a room there.

### Added

- **Live room geometry.** `_roomsFor()` now merges each poll's integration
  rooms (`rooms[].bbox_px`) with the static config: a room without an
  explicit `map_x`/`map_y` gets its floorplan rectangle computed on the fly
  via `roomBboxToRect` (the same math the one-shot Import already used,
  reused here instead of duplicated) at the vacuum's current effective seat
  — auto-fitted *or* manual, both work identically, no special-casing.
  Icon/display-name/threshold overrides from a matching static config room
  are still layered on top either way. A config room with no live
  counterpart this poll (custom/manual room, or the integration briefly
  missing data) still renders exactly as configured — nothing silently
  disappears.
- `RoomConfig.map_x`/`map_y` are now optional — omitting them on a room
  entry (while still setting e.g. `icon`) is how you ask for "icon override,
  live position." Setting them (same as today, e.g. via editor drag or the
  Import button) pins the room's position outright and doubles as an
  auto-seating fit anchor, unchanged from before.
- Import button behavior is unchanged (still writes a one-shot pinned
  position for missing rooms) — kept as the fallback for degraded mode (no
  integration) and for placing the anchor room(s) auto-seating needs to
  bootstrap its fit; see docs/20 §5 for the full decision record.

### Fixed

- `_effectiveSeat()`'s auto-seating anchor computation now explicitly reads
  only the static/pinned room list, never the new live-merged view — the
  latter would have been circular (a live room's position IS the fit's
  output, so feeding it back in as a fit anchor would always show ~0
  residual regardless of whether the fit is actually correct).
- `_renderRoomList` and `_mergedRoomDefs` (merged mode) now go through
  `_roomsFor()` instead of reading `vac.rooms`/`_config.rooms` directly, so
  the room status list and merged-map overlay both pick up live rooms too —
  previously only the per-vacuum overlay did.

## [0.66.5] - 2026-07-18

Found in the field: a "Both" clean where the wet pass was config-restricted
to a single vacuum that couldn't take the rooms produced zero visible
feedback — dry finished, wet silently never started, no error anywhere in
the card. No backend change — still pairs with `anyvac` 0.51.0.

### Added

- **Unassigned-room warning.** The card now surfaces rooms the backend plan
  (`anyvac.plan`) couldn't assign a robot to for the current mode — e.g. a
  room needs a wet pass but every vacuum configured with a wet role
  (`_v2Vacuums`, docs/14 §3.7) can't or didn't take it. Shown as a red
  `mdi:robot-off` icon per affected room in the dock rows, an aggregate count
  in the dock footer next to the ETA, and an aggregate stat in the landscape
  meta bar (mirrors the existing amber "unsequenced" hint pattern). Derived
  client-side from the plan preview already fetched for the ETA/avatars — no
  new backend call or event plumbing.

### Investigation notes

- Traced live (2026-07-17 ~17:24 session): dry cleaning completed for all 5
  rooms (S6 + S7 MaxV), but wet never ran. Root cause was **not** a bug —
  the card's config marks S7 MaxV's `clean_type: "dry"` intentionally (a
  hardware-wet-capable robot kept dry-only in this household), so `Both`
  mode restricts the wet pass to S8 alone. The actual problem was that
  nothing in the card would have told the user if S8's assignment came back
  empty — that's the gap this release closes.

## [0.66.4] - 2026-07-17

Found and fixed live, directly on the user's real dashboard again (Claude in
Chrome session, this time with instrumentation + a live prototype patch to
verify the fix before writing it into the build) — the actual mechanism
behind "edit mode only lays out correctly on the second toggle after a hard
refresh", which 0.66.1/0.66.2 did not fully resolve. No backend change —
still pairs with `anyvac` 0.51.0.

### Fixed

- **The edit-mode actions bar's height reservation could get permanently
  stuck at zero.** Instrumented the real dashboard: at the moment
  `hui-card-options` appears in the DOM, its `shadowRoot` can still read
  `null` for a beat (not yet upgraded to a custom element); and once
  `.card-actions` does exist, HA does not give it its full height instantly —
  it CSS-transitions in (confirmed live: bar's own settled height was
  64.8px). A remeasure triggered only once, right when the bar element
  *appears*, races that transition and can capture height 0 — and since
  entering edit mode doesn't change any of the card's own reactive state
  (`_cardW`/`_profile` stay the same), nothing naturally re-triggers another
  remeasure afterwards, so the 0px reservation is permanent until some
  unrelated trigger (like toggling edit again) happens to cause one.
  Fixed with a new `_observeEditBar`: once the bar element is found, a
  `ResizeObserver` watches its own box for as long as it's mounted, so
  whichever remeasure runs last — after the transition settles — wins,
  regardless of transition duration or timing jitter between cold/warm
  loads. Ported/adapted from room-overlay-card v5.0's `_watchEditBar`
  pattern, extended with this ResizeObserver step after live-confirming the
  transition race wasn't otherwise covered.
- **`_setupPanelViewObserver` no longer trusts a once-set observer forever.**
  It now re-verifies the watched `hui-panel-view` node is still connected on
  every call (not just the first), and re-wires from scratch if not — a
  defensive port from room-overlay-card v5.0, which never assumes a
  previously found ancestor is still the live one.
- Playwright suite gained an 8th test that CSS-transitions the mock actions
  bar's height in (0 → 32px over 80ms, matching the live-observed behavior)
  and asserts the final reservation matches the *settled* height, not
  whatever was measured mid-transition — verified to fail (received `0`,
  matching the live bug exactly) without the `ResizeObserver` fix.

## [0.66.3] - 2026-07-17

Found and fixed live, directly on the user's real dashboard (Claude in
Chrome session against a running HA instance) — a genuine CSS Grid bug
distinct from the 0.66.0–0.66.2 timing/detection fixes. No backend change —
still pairs with `anyvac` 0.51.0.

### Fixed

- **Multi-column-spanning grid regions (badges/map/tools in the default
  landscape profile, `start` in portrait) overflowed the card's grid by
  exactly the configured `gap`.** Numeric column/row tracks were rendered
  as CSS `%` (e.g. `columns: [70, 30]` → `"70% 30%"`), which sums to 100%
  and leaves no room for the `gap` between tracks — any region spanning
  2+ tracks (`col: "1/3"`) then rendered `gap`-px wider than the grid
  container. With the default 6px gap this pushed the page into a
  horizontal AND (as a pure cascading side effect) vertical scrollbar,
  even though the card's own pinned height was computed correctly. Fixed
  by rendering numeric tracks as `fr` instead of `%` — CSS Grid's `fr` unit
  distributes space *after* subtracting `gap`, so the same `[70, 30]` still
  renders a 70:30 split, just without the overflow. Confirmed live: fixed
  both the horizontal and vertical scrollbar simultaneously on the exact
  dashboard that showed the bug.
- Playwright suite gained a sixth test asserting a spanning region's right
  edge never exceeds the grid's own right edge — verified to fail (by
  exactly the configured gap) without this fix.

## [0.66.2] - 2026-07-17

Second follow-up to 0.66.0/0.66.1, same source (`room-overlay-card` v5.0).
No backend change — still pairs with `anyvac` 0.51.0.

### Fixed

- **Fresh dashboard loads could leave stale dead scroll space below the
  card, only fixing itself after toggling edit mode twice.** Fonts and
  images (the floorplan `image_base`, per-vacuum `image`, map images) can
  finish loading and shift the card's own position on the page — without
  changing the card's own box size and without any DOM mutation our
  `MutationObserver`/`ResizeObserver` could see. A new one-shot 250ms
  "settle" remeasure runs after every render (cleared and rescheduled each
  time, so it never piles up), catching exactly this class of "nothing we
  observe actually changed, but the layout math needs redoing anyway" case.
- Playwright suite gained a fifth test that grows an untracked sibling
  element above the card (simulating this exact late-arriving-content
  scenario) and confirms the grid self-corrects within the settle window
  with no explicit trigger — verified to fail without this fix.

## [0.66.1] - 2026-07-17

Follow-up to 0.66.0, ported from a sibling project's (`room-overlay-card`
v5.0) battle-tested fixes for the same class of HA edit-mode DOM quirks.
No backend change — still pairs with `anyvac` 0.51.0.

### Fixed

- Edit-mode ancestor lookup now matches `hui-panel-view` OR `hui-view`, not
  just `hui-panel-view`. Which tag actually resolves as the nearest ancestor
  varies by HA dashboard/view type — checking only one meant the
  `MutationObserver` from 0.66.0 could silently never attach on setups where
  the other tag was the real ancestor.
- The `MutationObserver` now also (re-)adopts `hui-card-options`' own shadow
  root on every mutation, not just `hui-panel-view`'s. HA's edit-mode
  actions bar (Move / Edit / Delete) mounts in a separate shadow tree from
  `hui-panel-view` — watching only the latter missed changes inside it.
- **The grid's pinned height (viewport mode) now reserves real room for
  that actions bar.** It renders as a genuine sibling below the card, not
  an overlay — without reserving its height, entering edit mode could push
  it under the fold or overlap it. New `_editBarHeight()` measures the
  bar's actual rendered height (never hardcoded) and both `pickProfile`'s
  input and the final grid height subtract it.
- Playwright suite gained a fourth assertion (mock actions bar height
  reserved, not just "doesn't collapse") — caught a mock-harness ordering
  bug during development (actions bar placed above vs. below the card
  changes whether the reservation is real or double-counted) before it
  could look like a false pass.

## [0.66.0] - 2026-07-17

Layout hardening + real device-independence (docs/21/22, roadmap to v1.0.0
Phase 1). No backend change — still pairs with `anyvac` 0.51.0.

### Fixed

- **Profile picking now measures the card's own box, not the browser
  window.** `pickProfile()` previously received `window.innerWidth`/
  `innerHeight`, so portrait/landscape was decided by the whole browser
  viewport's aspect ratio — correct only when the card happens to fill the
  entire window. On any dashboard where it doesn't (two cards side by side,
  a sections/grid view, a sidebar, split-screen), the wrong profile could
  get picked regardless of how correct that profile's own grid math is. Now
  fed by `_cardW` (already measured) plus a matching height measurement
  (`_availableHeight`, mirrors the `"container"`/`"viewport"` height modes
  `_refineGridHeight` already uses).
- `_scheduleMeasure` no longer hangs on a backgrounded tab.
  `requestAnimationFrame` never fires while `document.hidden` is true (kiosk/
  wall-mounted tablets, `browser_mod` popups, a second window) — confirmed
  live, not just in theory. Falls back to `setTimeout(fn, 0)` while hidden.
- Edit-mode layout refresh no longer depends solely on `ResizeObserver`/
  window resize catching the reparent. HA moves the card into
  `hui-card-options` on edit-mode toggle without firing any event, and the
  host's own box doesn't always change size when that happens. A new
  `MutationObserver` on the nearest `hui-panel-view` ancestor now forces a
  remeasure on any DOM change there. Degrades loudly (one-shot
  `console.warn`) if that ancestor can't be found — internal HA DOM, not
  public API, so a future HA version could rename it.

### Added

- Playwright + mock HA DOM test harness (`tests/`, `npm run test:layout`) —
  four regression tests against a minimal `hui-panel-view`/`hui-card-options`
  DOM mock: profile picked from the card's own box (not the window) in both
  a narrow and a landscape-shaped box, grid height stays healthy across
  simulated edit-mode reparenting (regression guard for the 0.59.0–0.61.0
  companion-app crash class of bug), and measurement completes on a
  backgrounded tab even with `requestAnimationFrame` neutered. Verified to
  actually fail against the pre-0.66.0 `pickProfile` call before merging.
- HACS `release.yml`: asset upload now retries on transient GitHub errors
  (5 attempts, backoff) and a follow-up step verifies the asset landed on
  the release before the workflow reports success.

## [0.65.3] - 2026-07-17

Field feedback: the portrait grid profile has no `tools` region (docs/18
§4), so it never got the dry/wet path visibility toggle that landscape's
consolidated meta bar has — no way to show/hide cleaning paths on the map
in portrait at all. No backend change — still pairs with `anyvac` 0.50.0.

### Added

- Dry/wet path visibility toggle in the portrait dock column (new
  `.dock-layers` row, above the Dry/Wet/Both mode buttons), reusing the same
  `_renderLayerToggleCompact` landscape already uses in its meta bar. This is
  about map path VISIBILITY (`view_layers`), distinct from the Dry/Wet/Both
  row right below it which picks what to clean.

## [0.65.2] - 2026-07-17

Follow-up to 0.65.1: the icon strip stayed fixed at 34px regardless of
vacuum count, so 2 vacuums left the strip mostly empty and 4+ would have
started overflowing. No backend change — still pairs with `anyvac` 0.50.0.

### Changed

- Vac-icon-strip buttons now fill their equal-width flex slot (`width: 100%`
  clamped between 28px and 64px, `aspect-ratio: 1/1` keeps them circular at
  any size) instead of a fixed 34px — fewer vacuums render bigger buttons,
  more vacuums render smaller ones, always spanning the full row width.

## [0.65.1] - 2026-07-17

Field feedback on the portrait vac-icon-strip (docs/19 follow-up): with 3
vacuums merged onto one floorplan, the map gets too cluttered to read in the
cramped portrait column. No backend change — still pairs with `anyvac` 0.50.0.

### Added

- Vac-icon-strip hold gesture: holding a vacuum's icon toggles it in/out of
  `_shownSet`, which `_renderMergedMap` already filters its map/path/room
  layers by — so this actually hides that vacuum's clutter off the shared
  floorplan, not just a focus switch. Tap keeps its existing behavior (opens
  that vacuum's more-info dialog). Hidden vacuums render at reduced opacity
  in the strip. New `_toggleShownMulti()` holds the plain multi-select toggle
  logic, extracted out of `_toggleShown()` so the icon strip doesn't trigger
  its portrait single-focus branch (that branch is for split-mode's
  status-card focus, a different concern — badges still use it unchanged).

### Changed

- Vac-icon-strip now spans the full available width, one equal-width flex
  slot per vacuum, matching the Dry/Wet/Both mode buttons directly below it
  (`.dock-head`/`.dock-mode`) instead of clustering left with unused space.

## [0.65.0] - 2026-07-16

Surfaces a gap the backend already had data for: `anyvac.plan`/`anyvac.clean`
return `unsequenced` (rooms missing from the Roborock app's own cleaning
order, which the firmware follows regardless of what order HA sends,
docs/19) but the card never showed it. No backend change — still pairs with
`anyvac` 0.50.0.

### Added

- Sequence hint: when a selected room has no position in the shared
  `room_sequence`, the card now says so instead of silently showing a time
  estimate the user has no reason to trust. Shown as an amber count in the
  landscape meta bar (next to the ETA stat), as a per-room icon in the dock's
  room rows, and as a summary icon next to the dock's own ETA line — all with
  a tooltip pointing at the card editor's Maps tab, where the order is set.

## [0.64.0] - 2026-07-16

Zone clean: a drawn rectangle can now be adjusted before confirming, instead
of only being redrawn from scratch. No backend change — still pairs with
`anyvac` 0.50.0.

### Added

- Zone clean rectangle is now editable after drawing: drag inside the box to
  move it, drag a corner handle to resize it, in both merged (meta bar,
  multi-candidate) and split/legacy per-vacuum tool flows. Clicking outside
  the box still starts a fresh draw while the tool is actively armed; once a
  zone is pending confirmation, Cancel is the explicit way to discard it
  instead of a stray click silently replacing it.

## [0.63.0] - 2026-07-16

Field-test bugfix from today's zone-clean testing. No backend change —
still pairs with `anyvac` 0.50.0.

### Fixed

- **Zone clean always ran a single pass, ignoring the vacuum's configured
  repeat count** — `_confirmZone` hardcoded `repeat: 1` in the
  `anyvac.zone_clean` call instead of reading `vac.clean_action.repeat`
  (e.g. 2), so a zone clean did one pass even when the vacuum's normal
  setting is two. Zone clean is a WHERE action (docs/07 UX canon) — it
  should still run with the vacuum's normal HOW settings, same as room
  cleaning already does via `_settingPresets`/`clean_action`. Now reads
  `vac.clean_action?.repeat ?? 1`.

## [0.62.0] - 2026-07-16

Portrait dock/map split cosmetics, now that the mobile crash is confirmed
fixed (0.61.0). No backend change — still pairs with `anyvac` 0.50.0.

### Added

- **`layout.portrait.columns` now works as a manual override** for the
  map/dock split — if set, the dynamic height-fit auto-sizing is skipped
  entirely and the declarative value is used as-is. Previously this key
  was silently ignored in portrait once the dynamic fit kicked in.

### Changed

- Gave up on auto-shrinking `dock` to its own "natural" content width
  (attempted in 0.57/0.58, reverted for an unrelated mobile crash in
  0.59–0.61): `.dock-row` uses `flex-wrap: wrap` in portrait by design, so
  long room names/badges reflow instead of overflowing — which means the
  row has no fixed natural width the way non-wrapping content would. Any
  max-content-style measurement returns the *unwrapped* single-line size,
  which is generally wider than the space actually available, so it never
  found "room to spare" — that's almost certainly why 0.57/0.58 measured
  correctly but never changed anything, not a bug in the measurement.
  There isn't a single objectively-right split to compute for wrapping
  content; it's a visual trade-off. Exposing it as a config override (see
  Added above) is the honest fix — dial it in directly instead of chasing
  an auto-computed number that doesn't really exist.

## [0.61.0] - 2026-07-16

**Confirmed crash fix.** User precisely bisected the mobile companion-app
crash to 0.59.0: 0.55.0 through 0.58.0 are all stable, 0.59.0 is the first
to crash (0.60.0, which had already reverted the *clone* measurement but
kept the styleMap change, still crashed — narrowing it down further). No
backend change — still pairs with `anyvac` 0.50.0.

### Fixed

- **Reverted 0.59.0's `gridTemplateColumns`/`height` styleMap removal** —
  that change made `_refineGridHeight`/`_refineGridColumns` the sole JS
  owners of both properties, on the theory that Lit's `styleMap`
  re-applying the static declarative value on every render was fighting
  the measured override (true, and still the reason portrait's column
  split doesn't visibly improve — see the parked dock-capping work). That
  fix is what broke the mobile app; exact mechanism unconfirmed, but the
  user's bisection is unambiguous. Both properties are back in
  `gridRootStyles()`, and the JS refinement goes back to layering a
  measured override on top of that declarative value (0.58.0's approach),
  not replacing it. `resolveHeightCss`/`trackList` imports and the
  landscape/pre-measurement fallback branch added for 0.59.0 are removed
  along with it — back to portrait-only, same as 0.56.0–0.58.0.
- Net result: same simple map-only column fit as 0.56.0 (`mapW = rW`,
  `dock` stays `1fr`) — the sidebar-overshoot cosmetic issue is back,
  deliberately, in exchange for confirmed mobile stability. Do not remove
  `gridTemplateColumns`/`height` from `gridRootStyles()`'s styleMap object
  again without a mobile-companion-app test confirming it doesn't
  reproduce this crash.

## [0.60.0] - 2026-07-16

**Stability fix** — user reported a full crash of the HA mobile companion
app after 0.59.0 (PC still showed the pre-existing layout issue, no crash).
No backend change — still pairs with `anyvac` 0.50.0.

### Fixed

- **Removed the detached-clone dock-width measurement** added in 0.57/0.58 —
  it ran on every `updated()` cycle, including the once-a-second
  `debug_room_progress` clock tick, meaning a full DOM subtree clone
  (create → append → measure → remove) every second for the life of the
  session. Plausible crash source on a memory/CPU-constrained mobile
  WebView, and if anything in that path ever threw before reaching
  `clone.remove()`, it would leak one detached node per tick, unbounded.
  Reverted to the simpler map-only fit that shipped in 0.56 (`dock` back to
  a flat `1fr`) — the sidebar-width-overshoot cosmetic issue returns, but a
  cosmetic issue is preferable to an app crash. The genuinely-confirmed
  0.59.0 fix (removing `gridTemplateColumns`/`height` from Lit's `styleMap`
  so JS is their sole owner) is kept — that part has a concrete root cause,
  not a guess, and doesn't do any per-tick DOM work.
- The dock-width capping (giving surplus width back to the map when the
  room list doesn't need it all) is parked until it can be re-implemented
  behind a `try/finally` and confirmed not to reproduce the crash.

## [0.59.0] - 2026-07-16

Same-day follow-up to 0.58.0: user correctly noticed the map still showed a
large black bar beside it after that fix too — the real, root cause. No
backend change — still pairs with `anyvac` 0.50.0.

### Fixed

- **`_refineGridColumns`'s override was being silently stomped every
  render** — `gridTemplateColumns` (and `height`, same mechanism) was
  listed in `gridRootStyles()`, which is bound via Lit's `styleMap` in
  `render()`. `styleMap` unconditionally re-applies every property in the
  object it's handed on every single render — including ones triggered by
  something unrelated (a hass state update, the debug-progress clock tick,
  ...) — so the declarative 72%/28% fallback kept getting written back,
  fighting this function's measured override on every cycle. This is why
  0.56/0.57/0.58 all computed progressively better numbers but the visible
  result never changed: whichever value actually reached the screen wasn't
  reliably this function's. `gridTemplateColumns` and `height` are now
  removed from `gridRootStyles()`'s styleMap object entirely — `_refineGridHeight`
  / `_refineGridColumns` are the sole owners of both, seeding the same
  static fallback first so there's no unset gap before the first
  measurement lands. Landscape (previously relying on styleMap for its
  fixed 70/30 split) now gets that same fallback applied via JS too, for
  consistency, since styleMap no longer carries it at all.
- This also explains the black bar the user specifically pointed out next
  to the map: with the column override never actually sticking, the map's
  region box stayed at its old (too-wide) size, so the map's own
  contain-fit centered it with empty bars on both sides *inside* that
  oversized cell — visually indistinguishable from "the fix doesn't work"
  even though the fit math itself was correct all along.

## [0.58.0] - 2026-07-16

Same-day follow-up to 0.57.0: field test with the console version banner
confirmed 0.57.0 was actually loaded, but the portrait column split was
pixel-identical to before — the fix itself didn't take effect. No backend
change — still pairs with `anyvac` 0.50.0.

### Fixed

- **`dock`'s natural-width measurement produced no change at all** —
  0.57.0 measured it in place (`width: max-content` on the live,
  still-attached `.dock` node). `.dock` is a column-flex container, its
  `.dock-rows` child is itself a column-flex container of row-flex
  `.dock-row` buttons — max-content sizing through that many nested flex
  levels while still stretched inside a CSS Grid track apparently doesn't
  resolve the way it should. Switched to measuring a **detached clone**:
  `cloneNode(true)`, `position: absolute` (fully out of flow, no ambient
  grid/flex influence at all), appended into the same shadow root (so the
  card's scoped CSS still applies to it), measured, then removed. This is
  the standard reliable pattern for "how wide does this content want to be
  with nothing constraining it" and doesn't depend on intrinsic-sizing
  behavior through nested flex containers.

## [0.57.0] - 2026-07-16

Field-test follow-up to 0.56.0's portrait column split: the sidebar was
grabbing every leftover pixel from the map's fit, even when its own content
needed far less. No backend change — still pairs with `anyvac` 0.50.0.

### Fixed

- **Portrait dock column wider than its content, map narrower than it could
  be** — `_refineGridColumns` gave `dock` a flat `1fr`, i.e. *all* width the
  height-fitted map didn't claim, regardless of whether the room list
  actually needed it (field screenshot: a mostly-empty sidebar next to a
  map that could have been noticeably bigger). It now also measures `dock`'s
  own natural (unconstrained) content width — briefly flips it to
  `width: max-content`, reads it, restores it, same temporary-measure trick
  used elsewhere — and only lets the sidebar keep up to that. Any further
  surplus goes back to the map's column instead, which shows up as centered
  letterbox bars around the map itself (same behavior the landscape
  contain-fit already has) rather than as dead sidebar space.

## [0.56.0] - 2026-07-15

Landscape map height-cropping fix + portrait's map/dock column now sized to
content, from more panel-view field testing. No backend change — still pairs
with `anyvac` 0.50.0.

### Fixed

- **Landscape map cropped vertically after 0.55.0's row-flex change** — the
  map's on-screen box was never actually fit to its grid cell in landscape
  (only portrait's rotated view had that logic); the plain `.map-wrap` CSS
  sizes purely from width, so once the map's row could grow tall (0.55.0),
  its width-driven natural height either fell short of the available space or
  overflowed it — and the region's `overflow: hidden` silently clipped the
  overflow case. The same measured contain/cover fit used for portrait's
  rotated map now applies to landscape too (no rotation, otherwise identical
  math), so the map is always fit to its actual box: height-priority when the
  box is relatively short and wide (typical for a full-width floorplan photo
  in a normal panel), with empty bars on the sides rather than any cropping.
  `layout.landscape.crop` works the same way as portrait's.
- Found and fixed a sign error in my own mental model while re-deriving this:
  the general contain/cover formula is `rW = min/max(boxW, boxH * ar_eff)`
  (multiply, not divide) — verified against the already-shipped portrait
  rotated fit, which was using the correct form all along (`ar_eff = 1/ar`
  there); the landscape case just needed `ar_eff = ar` plugged into the same,
  now-shared, formula.

### Changed

- **Portrait: the map/dock column split now follows the map's actual fitted
  width** instead of a fixed 72/28 — since the map is height-fit and usually
  narrower than 72% of the width, the dock sidebar now picks up whatever the
  map doesn't need (measured and applied in JS post-render, same settle
  pattern as the existing grid-height refinement — a CSS "auto" track can't
  do this on its own here, since the fitted width lives on an
  absolutely-positioned element that carries no intrinsic-size signal for
  track auto-sizing).

## [0.55.0] - 2026-07-15

Landscape row-flex inversion, from panel-view field testing. No backend
change — still pairs with `anyvac` 0.50.0.

### Changed

- **Landscape: the map now gets the leftover height, not the chrome below
  it** — the row flex (`1fr`) used to sit on the status/picker/dock row,
  meaning THEY stretched to fill a tall viewport (panel view especially)
  while the map stayed at its own natural (often comparatively small) size.
  The `1fr` now lives on the map's row instead; badges/tools/status/picker/
  dock all size to their own natural content height, and the map absorbs
  whatever vertical space is left over.

## [0.54.0] - 2026-07-15

Landscape dead-space fix + configurable crop for portrait's rotated map. No
backend change — still pairs with `anyvac` 0.50.0.

### Fixed

- **Landscape: large empty black strip above the map** — the `badges` region's
  row was a hardcoded 9% of height, but badges only ever holds global-action
  badges now (vacuum picking moved to `picker` in 0.50.0's A5) — with none
  configured, that 9% rendered nothing and just sat there empty. The row is
  now `"auto"`-sized like the rows below it, so it collapses to whatever it
  actually contains instead of reserving fixed dead space.

### Added

- **Configurable crop for portrait's rotated map** (`layout.portrait.crop`) —
  the 90°-rotated map has always used a "contain" fit: sized to fit entirely
  inside the measured region, which can leave empty bars alongside it when
  the region's aspect ratio doesn't match the floorplan's (visible as black
  space either side of the map). Setting `crop: { fit: cover }` now fills the
  region completely instead, cropping the overflow; `offset_x`/`offset_y`
  (-100..100, 0 = centered) control what gets cropped rather than it always
  centering. Left as "contain" by default — switching to "cover" isn't safe
  to do silently, since depending on the floorplan image it could crop off a
  real room. As a side effect, "contain" letterboxing is now centered in the
  gap axis instead of pinned to one side (previously top/left-anchored with
  all the empty space on the other side).

## [0.53.0] - 2026-07-15

Portrait layout follow-up + more field-test polish. No backend change — still
pairs with `anyvac` 0.50.0.

### Changed

- **Portrait: dropped the top vacuum-badges row, map goes full height** —
  merged mode's map has no split-mode "shown" focus to switch, so that row
  was only spending height without doing much beyond a path to more-info.
  The map and dock now take the space it used to occupy.
- **Portrait: small icon-only vacuum buttons at the top of the dock
  column** — tapping one opens that vacuum's more-info dialog (emergency
  manual control), replacing what the removed badges row used to offer.
  Landscape is unaffected — it keeps the full `picker` region (name + live
  status).
- **Portrait: per-room dry/wet assignment chips hidden on the map** — same
  assignment is already shown in the dock's room list right next to it, and
  on the rotated portrait map these chips render tiny and sideways. Landscape
  keeps them (more room, no nearby duplicate).
- **Selection gradient sharpened** — the white → light-blue → white border
  is now a crisp blue accent right in the middle instead of a broad 50%
  blend, per feedback that the soft version read as muddy at this size.

### Fixed

- Zone confirm button read "Clean zone here" — shortened to "Clean zone".

## [0.52.0] - 2026-07-15

Second round of field-test fixes on 0.51.0's Pin & Go / Zone, plus a revived
UX idea for room selection. No backend change — still pairs with `anyvac`
0.50.0.

### Fixed

- **Pin & Go / Zone execute stacked a whole new banner on the status card
  instead of taking over START** — 0.51.0's per-vacuum "send/clean here"
  action rendered as a separate bar above the existing START button, so each
  card briefly had two overlapping action rows. The START slot itself is now
  the mode-aware action (hold to confirm, same as START always has been) —
  matches the originally agreed design ("START becomes mode-aware for
  Pin/Zone"), one action element per card instead of two.
- **Drawn zone rectangle vanished the instant you released the pointer** —
  fixing the "won't let go" bug in 0.51.0 by clearing the live drag state on
  drop also made the rectangle disappear immediately, with no visual
  confirmation of what was actually captured while picking a vacuum on the
  status cards below. The box is now frozen in place (from the pending
  capture, not the live drag) until confirmed or cancelled.

### Changed

- **Selected-room highlight is now a gradient** (white → light blue → white)
  instead of a flat white tint, via `border-image` — a revived idea from
  earlier design discussion, applied now that the selection colour is no
  longer tied to vacuum identity (0.50.0's A1).

## [0.51.0] - 2026-07-15

Field-test fixes for the 0.50.0 meta bar's Pin & Go / Zone, caught immediately
after shipping (merged mode, `layout:` grid). No backend change — still pairs
with `anyvac` 0.50.0.

### Fixed

- **Zone drag never released** — releasing the pointer after drawing a zone
  rectangle left the internal drag state set, so `pointermove` (which only
  checked "is a drag in progress", not "is the button still down") kept
  resizing the rectangle on any subsequent mouse movement even after the
  drop/confirm panel had already appeared underneath it. The drag state is
  now always cleared the instant the drag ends.
- **Pin & Go / Zone sent to one auto-picked vacuum with no way to choose** —
  the 0.50.0 meta bar armed Pin & Go / Zone against a single guessed target
  and (for Pin & Go) fired immediately on click. Arming from the meta bar now
  captures the click/drag once on the shared merged map, translates it
  through every candidate vacuum's own map transform, and shows a
  highlighted "send/clean here" action on each candidate's own status
  card — the user picks which specific robot executes it, same as the
  original plan and consistent with how split mode's per-vacuum tools
  already behaved (unchanged there — no ambiguity to begin with, so still
  immediate/single-target).

## [0.50.0] - 2026-07-15

Landscape cockpit rebuild (docs/19, Phase C) + sequence-aware ETA. Ships in
lockstep with `anyvac` 0.50.0 (the new `room_sequence` contract).

### Added

- **Consolidated meta bar** — Pin & Go, Zone, dry/wet layer visibility with
  oldest-age badges, selected-room count, ETA, and a single global map
  refresh now live in one row (`tools` region) instead of a per-vacuum
  Refresh/Pin&Go/Zone block repeated once per robot. Zone's pending-confirm
  and Pin & Go's armed state show as an inline panel under the bar.
  (Superseded by 0.51.0: see below — the single auto-picked target and the
  drag-release bug were caught in the very next field test.)
- **Full-width map + two-column cockpit (landscape)** — the map and the new
  meta bar now span the full card width instead of a 70% column. Below them:
  left column = the existing per-robot status/controller cards (unchanged);
  right column = a new slim vertical vacuum picker (`picker` region, replaces
  the old horizontal badge-row tabs for vacuum selection) with the room list
  (`dock`) docked directly beneath it.
- **Room-selection colour decoupled from vacuum identity** — selected rooms
  now highlight in neutral white instead of the acting vacuum's colour,
  removing the collision with the age-gradient colour (e.g. green identity ==
  green "cleaned recently"). Selected rooms show avatar chips of the
  dry/wet-assigned vacuum instead.
- **Mutual exclusion: room selection vs. Pin & Go / Zone** — room tap targets
  (map overlay, dock rows, legacy room list) disable while Pin & Go or Zone
  mode is armed, and vice versa. Also fixes Pin & Go / Zone never having
  worked in merged map mode (the click/drag capture layer only existed in
  split mode).
- **Sequence-aware ETA** — the estimated clean time (stats trio, dock
  footer, START bar) now comes from `anyvac.plan`'s `eta_min`, which accounts
  for the Roborock app's configured room order (always dominant, regardless
  of HA command order) and per-room wet-after-dry gating, instead of a flat
  sum of per-room estimates.
- **Cleaning-sequence editor** — Maps tab (merged mode) gained a
  drag-to-reorder room list mirroring the sequence configured in the
  Roborock app, pushed to the backend via `anyvac.set_room_sequence`. Flags
  rooms not yet given a position.

## [0.43.0] - 2026-07-15

### Added

- **Robot error halo on the map** — when a vacuum's error entity reports an
  active error, a soft pulsing red glow now renders behind its robot marker
  in the integration vector overlay (`_renderIntegrationOverlay`), not just in
  the status card's error row. Shares the new `_hasError()` helper with the
  status card so both stay in sync. Blurred via a per-vacuum-entity SVG
  filter id (`avc-err-blur-<entity>`) to avoid `<defs>` id collisions when
  multiple vacuums render in merged mode.

## [0.42.4] - 2026-07-15

### Fixed

- **Integration-vector editor fields invisible without an explicit `integration_entity`**
  — "Hide vacuum map", path colour/width, mop band colour/opacity/width, robot
  image options, and "Import missing rooms" were gated in the editor on the raw
  `integration_entity` config key. Since docs/14 Fáze 3 the card (and the editor's
  own auto-seating) auto-resolve the AnyVac sensor from the entity registry, so
  most users never set that key — the whole section silently never appeared.
  The editor now uses the same `_intEntityFor` auto-resolve as rendering/seating,
  so the fields show whenever the integration is actually active.

## [0.42.3] - 2026-07-15

Requires integration ≥ 0.19.1 for the fix to take effect (the segments are built
on the backend; an older integration still sends a flat `path_dry_px`, which the
card still renders correctly as a single segment — no breaking change).

### Fixed

- **Finished dry trace looked like a scribble compared to the clean live trace**
  — `path_dry_px` is now a list of contiguous segments instead of one flat point
  list (integration 0.19.1). The card now draws one `<polyline>` per segment
  instead of one polyline across the whole array, so the straight line the
  browser used to draw across every excluded transit/mop-wash gap (one per room
  transition in a finished multi-room session) is gone.

## [0.42.2] - 2026-07-11

Second field pass (docs/18 §10b).

### Fixed

- **Landscape dead space** — the map track is now `auto` (intrinsic height) with
  tools directly under the map, status cards filling the rest of the left column
  and the dock owning the full right column (`rows: [9, auto, auto, 1fr]`).
- **Refresh moved to the badges row** (right edge) — the floating map-corner
  button sat in dead space next to the centred portrait map.
- **Per-room progress gauges in the dock** — the dry/wet `%` chips
  (`debug_room_progress`) render next to the age badges in dock rows, so live
  cleaning progress is visible in portrait again (status cards are not placed
  there). On-map room gauges are unchanged (upright via `.avc-rot`).

## [0.42.1] - 2026-07-11

First field pass over the 0.42.0 grid profiles — fixes from live screenshots.

### Fixed

- **Floating map tools removed** — per-vacuum tool columns overlaid (and blocked)
  the right side of the map, one column per vacuum. Landscape now places the
  `tools` region UNDER the map (new canonical rows `[9, 56, 35]`, tools row gets a
  per-vacuum name label); portrait gets a single floating refresh-all button
  (pin&go/zone are disabled in the rotated view anyway).
- **Layer toggles moved out of the rotated map** — they now render at map-REGION
  level (upright, top-right), never rotate with the portrait map and no longer
  collide with on-map gauges.
- **On-map chips counter-rotated in portrait** — room gauges, progress chips and
  room icons stay upright inside the 90° rotated map (`.avc-rot` wrapper).
- **Portrait badges row** — no wrapping (it cut off the third vacuum); compact
  badges with horizontal scroll instead. Stats trio renders only in landscape —
  the portrait START bar already shows the count + estimate.
- **Portrait dock** — compact: icon-only mode buttons, room rows without names
  (icon + dry/wet ages + avatars), smaller chips, so the 28 % column actually fits.

## [0.42.0] - 2026-07-11

Phase B of the responsive rebuild (docs/18): the portrait profile per docs/12, the
`dock` and `start` regions, floating map tools, per-room vacuum pinning and the
canonical default profiles. Requires integration ≥ 0.19.0 for pinning.

### Added

- **`dock` region** (docs/12 §3): selection, plan preview and pinning in one block —
  Dry/Wet/Both mode header, room rows (tap = toggle the backend-shared selection,
  compact dry/wet age chips), and per-pass **assignment avatars showing the backend's
  real plan** (`anyvac.plan`). In landscape (no `start` region) the dock carries the
  orchestrated run footer with the hold-to-run button and a rooms/minutes summary.
- **`start` region** (portrait bottom bar, docs/18 §7d): full-width thumb-zone
  hold-to-start that ALWAYS sends the orchestrated `anyvac.clean` intent; while
  anything runs it flips to a hold-to-cancel bar (`anyvac.cancel`; degraded mode
  pauses the cleaning vacuums instead).
- **Per-room vacuum pinning** (docs/18 §7e): tapping a room's assignment avatar in
  the dock cycles auto → vac1 → vac2 → auto via `anyvac.pin_room`; pins are
  backend-shared (`room_pins` sensor attribute), used by the planner as the default,
  highlighted with a pin ring, and auto-cleared after the room's clean.
- **Floating map tools** (grid mode): Refresh / Pin&Go / Zone as an icon-only
  column overlaid on the map edge (Roborock-app style); hint/confirm panels float
  along the bottom of the map region. The `tools` region remains for explicit
  old-style placement.
- **Stats trio** in the grid badges region: selected rooms · estimated minutes
  (max-across-vacuums display aid) · lowest battery.
- **`debug` config flag** (docs/18 §7c): raw geometry readouts in the grid UI hide
  behind it (off by default).

### Changed

- **Canonical docs/18 §4 default profiles**: landscape = map left (scrolls in split
  mode) + dock & status right; portrait = slim badges bar, tall rotated map, right
  thumb dock, full-width START bar (replaces the Phase-A interim defaults).
- **Exact rotated-map fit** (docs/18 §7): in grid mode the 90° rotated map is fitted
  into the measured map-region box — the legacy width × 1.4·viewport cap heuristic
  only applies without a `layout:` block.
- **Portrait single-vacuum focus** (docs/18 §7b): in split mode the portrait grid
  renders one vacuum; a badge tap SWITCHES the focus instead of toggling set
  membership. Landscape/merged behaviour unchanged.

## [0.41.0] - 2026-07-11

Phase A of the responsive rebuild (docs/18, ratified 2026-07-11): the two-profile
percentage-grid layout runtime. Without a `layout:` config block the card renders
exactly as before — the grid is strictly opt-in.

### Added

- **`src/layout.ts`** — layout runtime: profile picker (viewport aspect ratio vs.
  `threshold`, `orientation` force override), grid CSS generator (numeric tracks → `%`,
  strings like `1fr`/`auto`/`120px` pass through), height resolver (`viewport` →
  `calc(100svh - var(--header-height))` with a measured `innerHeight - rootTop`
  refinement; `container`; fixed CSS length), and `pval`/`papply` per-profile scalar
  resolvers (no second breakpoint system).
- **`layout:` config block** (`threshold`, `orientation`, `gap`, `height`,
  `portrait`/`landscape` profiles with `columns`/`rows`/`place`). Each profile is a
  complete design: regions are placed via `{row, col}` (CSS grid-line syntax, spans
  allowed); a region not placed in a profile is not rendered there. Per-region
  `overflow: hidden|auto` and `align`.
- **Named regions** (Phase A set): `badges`, `autobar`, `plan`, `map`, `tools`,
  `status`. The `dock` and `start` regions arrive with Phase B.
- Interim default profiles (documented in `layout.ts`) until the docs/18 §4 canonical
  defaults become possible in Phase B/C.
- `orientationchange` listener (rAF-coalesced with resize) re-picks the profile.

### Changed

- With a `layout:` block, the map's 90° portrait rotation is driven by the **portrait
  profile** instead of the card-width heuristic (`mobile_rotate` still force-overrides;
  legacy width heuristic unchanged without `layout:`).
- Edit-mode version chip shows the active profile in grid mode.

## [0.40.0] - 2026-07-09

Fáze 3 of the backend-first canon (docs/14): the card switches to backend contract v2
(integration ≥ 0.18.0) and loses the last of its client-side smarts. A schema warning
banner appears when the integration is older than the card expects.

### Changed

- **Vector overlay reads px-space attributes** (`vacuum_position_px`, `path_dry_px`,
  `path_wet_px`) — the mm→px affine transform is gone from the card; the robot heading
  is derived in px space (y axis flip).
- **Auto-seating & room import use `rooms[].bbox_px`** — `seatfit.ts` lost `solve3` /
  `affineFromCalibration`; anchors and the editor's room import are built from the
  backend-transformed pixel bboxes.
- **Pin & go / zone clean send image PERCENTAGES** to `anyvac.goto` /
  `anyvac.zone_clean`; the pct→px→mm conversion is backend-side. The zone confirm
  dialog no longer shows mm dimensions (the card no longer knows any).
- **Orchestrated cleans send an INTENT** — `_runOrchestrated` is a thin
  `anyvac.clean` call (rooms + mode + per-kind vacuum roles from the config + settings
  from the presets). The whole client-side plan builder (`_assignByCap`,
  `_cleanCmdFor`, `_settingsForKind`, `_segmentFor`, `_roomCleanableBy`,
  `_roomEstMax`, `_duidOf`, run_job task assembly) was DELETED.
- **Plan preview is the backend's real plan** — fetched from the response-only
  `anyvac.plan` service (debounced), no local approximation.
- **Per-vacuum START uses `anyvac.clean`** restricted to that vacuum when the
  integration is present; direct `vacuum.*` commands remain only for the degraded
  (no-integration) mode.
- **`integration_entity` is auto-resolved** from the entity registry (the AnyVac map
  sensor sits on the vacuum's device); the config key remains as an explicit override.
- **Editor Debug tab** shows `schema_version`, `pipeline_ok` and `bbox_px` geometry.

### Removed

- native-auto dynamic segment resolution via `roborock.get_maps` (docs/14 §3.7) —
  with the integration the backend resolves segments; without it the card only uses
  configured `segment_id`s.
- All client-side affine/mm math (docs/14 §3.6): `solve3`, `affineFromCalibration`,
  `_affine`, `_intAffine`, `_intMapToVac`, `_cmdMm`-era helpers, `_gotoMm`.

## [0.39.0] - 2026-07-02

### Changed

- **Dry/wet layer toggles are now backend-shared** (integration ≥0.14.0): the choice
  survives page refreshes and syncs across browsers/devices, like the room selection.
  Without the integration the local per-tab behaviour remains.

## [0.38.1] - 2026-07-02

### Fixed

- **Room-corner progress gauges finally show up in merged mode.** The gauge read
  `rooms_progress` from the representative (FIRST) vacuum only — with a kitchen-only
  robot first in the config, every other room's gauge stayed empty. Values are now
  aggregated across all shown vacuums.
- **Two gauges per room — dry and wet** (matching the layer menus): dry ring in the best
  dry vacuum's colour, wet ring in wet-blue, `~` while the coverage baseline is still
  calibrating. Pairs with integration 0.13.0, where point-based attribution makes them
  fill from the first poll instead of after a ~60 s confirmation lag.

## [0.38.0] - 2026-07-02

Auto-seating (docs/15): maps align themselves onto the shared floorplan.

### Added

- **Automatic map seating (`seat: auto`, the new default).** Each vacuum's map is fitted
  onto the floorplan by a least-squares similarity transform whose anchors are the room
  rectangles already drawn on the floorplan, paired **by name** with the room bboxes the
  integration reads from that robot's map (key = Roborock room name). No clicking, no
  sliders. Rotation snaps to 90° steps. The fit is recomputed from live sensor data, so
  it **self-heals when the robot remaps** or the map trim changes — the failure mode
  that silently broke manual seating. A robot whose map has only ONE shared room (e.g.
  a kitchen-only robot) is seated from that room's centre + size, with orientation
  estimated from its shape. Robots on a different floor match no rooms and keep manual
  seating. Hand-drawn room differences between robots are fine — each robot is fitted
  independently against the floorplan and the imprecision shows up in the fit error.
- **Fit quality in the editor**: the Maps tab shows anchors used, the computed
  rotation/scale/offset and an RMS fit error (warns above 3 % — usually a wrong room
  key or rectangle). `seat: manual` keeps the old slider behaviour per vacuum.
- **Room import from a vacuum** (editor, Maps tab): adds the rooms this robot's map
  knows that are missing on the floorplan, placed through its current seat — one button
  covers both the initial import from the reference (whole-home) robot and later
  supplementing rooms only another robot has (it gets seated via the rooms you already
  share, or its manual seat).
- Editor map preview now uses the floorplan's real aspect ratio instead of a hard-coded
  27.5 % box, so what you position in the editor matches the card.

### Removed

- Orphaned 3-point align tool remnants (`_alignApply` + handlers + styles) — it was
  never wired into the UI (which is why it never worked); its similarity-fit maths now
  powers the auto-seat in `seatfit.ts`.

## [0.37.0] - 2026-07-02

Backend-first purge (docs/14 canon, Phase 1 + frontend part of Phase 3). The card no longer
tracks cleaning sessions — the `anyvac` integration (≥0.12.0) is the single source of truth.

### Removed (**breaking** — superseded by the integration)

- **Client-side in-flight cleaning tracking.** The card treated the vacuum entity's
  `docked` transition as end-of-clean, but a mid-clean mop wash reports `docked`
  (HA roborock `STATE_CODE_TO_STATE`), so every mop wash prematurely "finished" the
  session — writing timestamps, mis-calibrating room times, clearing the selection and,
  worst, restarting `vacuum.clean_area` repeat passes mid-wash. Session tracking now
  lives in the integration (`in_cleaning` + raw status, mop-wash aware).
- **Software repeat for `native-area`** (unsafe, see above). Configured `repeat` values
  are ignored for `native-area` until server-side repeat lands with `anyvac.clean`.
- **Manual 3-point map calibration** (localStorage, goto-probing). It assumed the dock at
  map origin and trusted commanded targets over the robot's real position. Pin & Go and
  Zone now require the integration sensor (`calibration_points`) plus a map entity.
- **Helper writes**: the card never writes `input_datetime` / `input_number` room helpers
  anymore; they remain read-only display fallbacks. `single_room_time` option removed.
- **Ticker notifications, notify-script caller and the cleaning-tracker blueprint**
  (including the editor deploy UI and helper creators). Build notifications from the
  integration events (`anyvac_clean_started/finished/room_done`) and its bundled
  blueprints. `notify`, `notify_script` and `backend` config keys are ignored.
- The card no longer fires or subscribes to `roborock_card_event`.

### Fixed

- **Click-to-mm used the wrong map with multiple vacuums.** `_clickToContent` grabbed the
  first `.map-img` in the DOM, so Pin & Go / Zone clicks for robot B were computed in robot
  A's map space (different seating). The click now targets the clicked vacuum's own map
  element (`data-entity`), and the floorplan is no longer used as a (geometrically wrong)
  fallback.
- **Merged mode + `hide_map` broke click geometry**: the hidden map is now rendered at
  opacity 0 instead of being skipped, so it can anchor the click transform.
- **Map tools are disabled in the rotated (narrow/mobile) view** — the click inversion
  does not account for the wrapper rotation yet, so commands were misplaced there.
- **Auto-resolved sensors could stay unwatched forever**: the watched-entity cache is no
  longer frozen before the entity registry is loaded.
- Dry trace now prefers the integration's segmented `path_dry` (cleaning-only points; no
  transit / mop-wash / goto driving mixed into the dry layer), falling back to `path` on
  older integrations; wet trace prefers `path_wet`.
- Global preset scope now applies to the backend-shared selection when the integration
  provides one (previously it silently only set the local selection).
- Live clean-type fallback derives from the vacuum's configured role instead of guessing
  "wet" from the mere presence of mop entities.

## [0.36.5] - 2026-06-27

### Fixed

- **Orchestration assigned rooms to vacuums that can't clean them.** In merged mode every vacuum
  nominally "owns" all card-level rooms, so a robot on a different map / home (e.g. an `s6_kitchen`
  robot vs the `jirsikova` apartment) was assigned a room it has no segment for — its task produced no
  command and was silently dropped, so only the other robot ran. Assignment now only picks vacuums
  that can actually clean the room (a resolvable segment, or the room present on the vacuum's own map).
- **Segment lookup matched by display name instead of key.** `_segmentFor` paired the integration's
  room (named by the Roborock app name = the card `key`) against the card *display name*, so a renamed
  room (key `Corridor`, name `Hall`) resolved to no segment. It now matches by `key` first.

## [0.36.4] - 2026-06-27

### Fixed

- **Orchestration only ran the first vacuum.** Two bugs: (1) the plan was built only across the
  *shown* tab's vacuum (`_planVacuums`) instead of all configured robots, so other robots — incl. the
  wet one in a `both` clean — were never assigned; orchestration now spans **all** vacuums. (2) The
  wet pass was gated on each room by its **display name**, but `anyvac_room_done` reports the room by
  its integration name (= the room `key`), so the gate never released; it now gates by `key`. With
  both fixed, a `both` clean splits dry across dry robots and releases the wet robot per room.

## [0.36.3] - 2026-06-27

### Fixed

- **"Cleaning order" field now also in the merged-map room editor.** In `map_mode: merged` rooms are
  defined at the card level (top-level `rooms:`) and edited in the Maps tab, not the per-vacuum
  accordion — so the order field added in 0.36.2 was invisible there. It is now shown in the Maps-tab
  room editor too.

## [0.36.2] - 2026-06-27

### Added

- **Per-room "Cleaning order" field** in the room editor (Vacuums tab). A 1-based sequence number,
  set per room to match the Roborock app's cleaning order. Stored as `seq` on the room config — the
  foundation for sequence-aware multi-room progress and target-aware calibration (it does not change
  behaviour yet).

## [0.36.1] - 2026-06-27

### Fixed

- **Per-second timer didn't tick (jumped every 30 s).** The live interpolation only applied to the
  "current" room, matched by display name against the integration's room — but a room whose card name
  differs from the integration name (e.g. card "Hall" = integration "Corridor") never matched, so the
  timer fell back to the raw 30 s-poll value. The current room is now matched by `key` or `name`, so
  the `mm:ss` clock ticks every second again.

## [0.36.0] - 2026-06-27

### Added

- **Normalised coverage % (~100 % for a fully cleaned room).** The gauges now read the integration's
  baseline-normalised `dry_pct` / `wet_pct` (v0.11.0+). Until a room has been fully cleaned once, the
  raw bbox % is shown with a `~` marker (e.g. `73~`) to flag it is still calibrating.
- **Per-second live timer in `mm:ss / mm:ss` (elapsed / estimate).** The debug strip ticks every
  second (instead of jumping every 30 s) for the room being cleaned. While paused or stuck, both the
  elapsed and the estimate keep ticking up equally, so the timer keeps moving but the progress doesn't
  advance. The clock only runs (and only re-renders this card) while a vacuum is cleaning/paused.

## [0.35.5] - 2026-06-27

### Changed

- **Two coverage gauges per room: dry and wet, side by side.** The debug strip now shows a separate
  dry gauge (vacuum trace, in the vacuum's colour) and wet gauge (mop trace, blue) per room, plus the
  live time spent — reading the new `dry_pct` / `wet_pct` from the integration (v0.10.3+). The per-layer
  menus likewise show the matching layer's coverage.
- **Debug progress is shown permanently again** (no longer hidden when the vacuum is docked) — it is a
  debug aid for now.

## [0.35.4] - 2026-06-27

### Changed

- **Debug room progress only shows while a vacuum is actively cleaning.** A docked / idle robot no
  longer shows a stale coverage % (e.g. "Hall 69%" after the clean finished). The chip, the controller
  strip and the map gauge all hide when the vacuum is not cleaning.
- **Per-layer (dry/wet) menus show only the matching clean type, coloured by the vacuum.** The dry
  menu shows progress from dry-capable vacuums and the wet menu from wet-capable ones (a dual vacuum
  shows in both), and the % is now coloured with the vacuum's own colour instead of a generic scale —
  so wet pass-throughs no longer bleed into the dry list and vice versa.
- **Controller strip shows the time spent in the room again, next to the %** (e.g. `Living room 24%S · 12m30s`).

## [0.35.3] - 2026-06-27

### Added

- **Elapsed-time fallback in the debug progress strip.** When a room has neither spatial coverage nor
  a time ratio (e.g. no learned estimate yet), the strip now shows the live elapsed cleaning time
  (`25m01s`) so the currently-cleaned room still shows a value that changes during a clean.
- **Room geometry in the Debug tab.** A `rooms (geometry)` block lists each room's `x0/y0/x1/y1` +
  `pos_x/pos_y`, to diagnose why spatial coverage is unavailable (the spatial % needs room bounding
  boxes from the parser).

## [0.35.2] - 2026-06-27

### Fixed

- **Broken status-card styling (a build regression in 0.35.1).** A missing CSS brace left the progress
  bar rule unclosed, which cascaded into the status/controller layout. Restored.

### Added

- **Per-room progress strip inside the status card.** With `debug_room_progress` on, the controller
  now shows a per-room % line (spatial coverage, or the time ratio with an `S`/`T` marker when spatial
  is unavailable) — visible right where you watch a vacuum during a clean, not only in the map room
  menus.

## [0.35.1] - 2026-06-27

### Changed

- **Debug room progress is now visible without map room overlays.** The progress % chip is now also
  shown in the room menus (the hold-to-expand layer menu and the room list), next to the dry/wet ages,
  so it appears even when rooms are not placed as overlays on the map. The gauge/chip now **falls back
  to the time ratio** when spatial coverage is unavailable (e.g. the parser does not expose room
  bounding boxes), with an `S`/`T` marker showing which metric is displayed. Still gated behind
  `debug_room_progress`.

## [0.35.0] - 2026-06-27

### Added

- **Debug per-room progress gauge.** With `debug_room_progress: true` (toggle in the editor's Debug
  tab), each room on the map shows a small circular % gauge of cleaning coverage, read live from the
  companion integration's `rooms_progress` (integration v0.10.0+). The Debug tab also lists the full
  `rooms_progress` payload — spatial coverage % and a time ratio (elapsed vs learned estimate) plus the
  raw inputs (visited/total cells, elapsed/est seconds) — so a clean can be watched and cross-checked.
  Off by default; a testing aid, not for everyday cards. Spatial % is approximate (the room box
  includes furniture, so it plateaus below 100%).

## [0.34.3] - 2026-06-27

### Fixed

- **Flaky card-width detection.** The width came solely from a `ResizeObserver` on the host, which
  fires inconsistently inside some Home Assistant containers (panel view, editor preview, masonry
  columns), so the measured width updated only sometimes. Width is now re-measured via
  `getBoundingClientRect()` from both the `ResizeObserver` and a `window` `resize` listener, coalesced
  into a single animation-frame tick, so it tracks the real width reliably.

## [0.34.2] - 2026-06-27

### Fixed

- **Backend room selection did not redraw the card live.** The integration map sensor (which now
  carries `selected_rooms`) was not in the card's watched-entity set, so `shouldUpdate` ignored its
  state changes and the selection only reflected after some other watched entity changed (e.g.
  clicking an active control). The integration entity is now watched, so a selection made on the phone
  or PC redraws everywhere immediately.

## [0.34.1] - 2026-06-27

### Fixed

- **Card width measured 0 (`0w` chip, `mobile_rotate: auto` never triggering).** The host element had
  no block layout box, so the `ResizeObserver` read a `contentRect` width of 0. The host is now
  `display: block` and the width is also seeded from `getBoundingClientRect()` on first render, so the
  measured width is correct and width-based portrait auto-rotation works.

## [0.34.0] - 2026-06-26

### Changed

- **Room selection is now shared via the backend** (integration v0.9.0+). When the companion
  integration is present, selecting rooms reads/writes the backend `selected_rooms` (via the
  `anyvac.select_rooms` service) instead of per-browser local state, so phone and PC show the same
  selection and it feeds the orchestrator. Falls back to local per-browser state when no integration
  is configured.

## [0.33.1] - 2026-06-26

### Added

- **`mobile_rotate: always`** forces the portrait rotation regardless of card width (good for testing
  on desktop), alongside `auto` (default, width-based) and `off`. `on` is treated as `always`.
- The edit-mode version chip now shows the **measured card width** (e.g. `v0.33.1 · 412w`), so you can
  see what the responsive detector reads and why auto did/didn't trigger.

## [0.33.0] - 2026-06-26

### Added

- **Responsive mobile map (experimental).** On a narrow card width (< 500 px, auto-detected via a
  ResizeObserver) the wide floorplan is **rotated to portrait** so it fills the card width and is
  readable on a phone instead of a thin letterbox. The map aspect is learned from the floorplan image
  (falls back to the default landscape ratio); the rotated height is capped so it can't run away on
  small screens. Disable with `mobile_rotate: off`. Controls outside the map (tools, status) stay
  upright; the in-map layer toggles rotate with the map for now (polish to follow).

## [0.32.0] - 2026-06-26

### Added

- **Mop band appearance is configurable in the GUI** (Maps tab, integration mode): Mop band colour,
  **opacity** and **width**. Drives the wet "sheen" on the map (config keys `mop_path_color`,
  `mop_band_opacity`, `mop_band_width`).
- **Debug tab shows calibration diagnostics** from the integration (v0.8.0+): raw path-point counts
  (`path pts (raw)`, `mop pts (raw)`) and `calib` — the last single-room calibration decision
  (confirmed rooms, clean type, duration, whether it wrote and the reason), so you can see exactly
  why an estimate did or didn't get recorded.

## [0.31.0] - 2026-06-26

### Changed

- **Global preset tiles now select, they don't run.** Tapping a tile selects it (highlights it, sets
  the plan mode and applies its room scope) and the plan preview shows the active preset's name; the
  clean is started from the plan's "Spustit · podrž" button. Cleaner separation of choosing vs running.

### Fixed

- **Orchestrated cleans now honour the repeat count.** The `app_segment_clean` command was sent
  without a repeat, so every orchestrated clean did a single pass. It now sends
  `params: [{ segments, repeat }]` with the pass count taken from the matching setting preset (or the
  clean action), so multi-pass cleans work. (native/native-auto; native-area repeat stays software.)

## [0.30.0] - 2026-06-26

### Added

- **Plan preview is now interactive.** The PLÁN ÚKLIDU panel gains a **Sucho / Mokro / Obojí** mode
  toggle (shows only the relevant dry/wet rows and builds the plan for that mode) and a **hold-to-run**
  "Spustit" button that runs exactly the previewed plan.
- **Plan reacts to the selected vacuums.** The orchestrator and the plan now only assign rooms to the
  vacuums whose badge is currently held/shown at the top, so you control which robots take part.

## [0.29.0] - 2026-06-26

### Added

- **Orchestration plan preview (Auto mode).** When rooms are selected in Auto mode, a compact
  "PLÁN ÚKLIDU" panel shows the plan as three rows: room icons (top), the vacuum assigned to the
  **dry** pass (broom row), and the vacuum assigned to the **wet** pass (water row). Each vacuum is a
  colour-coded 2-letter chip matching its accent, so you can see who cleans what — and judge the split
  — before holding a tile to run.

## [0.28.2] - 2026-06-26

### Fixed

- **Status card (the per-vacuum controller) layout restored.** A build-tooling bug dropped the
  `.status-left` / `.vac-img` / `.status-right` / `.status-row` CSS rules, so the controller lost its
  two-column grid (robot image left, status right) and rendered with an oversized image and stacked
  content. The CSS is now intact again.

## [0.28.1] - 2026-06-26

### Fixed

- **Auto global-preset tiles no longer stretch into a full-width banner.** They had `flex: 1`, so a
  single global preset filled the whole row and looked broken. They are now compact, content-sized
  tiles (icon + label + hold hint) that wrap, keeping the controller area tidy.

## [0.28.0] - 2026-06-26

### Fixed

- **A both-capable vacuum in an orchestrated `both` clean now finishes its dry pass before its wet
  pass.** It is assigned to both passes (e.g. S7 = dry+wet runs in the dry group with S6 and the wet
  group with S8), but its wet task now waits for its **own dry session to complete**
  (`anyvac_clean_finished` for itself), since one robot cannot clean dry and wet at the same time.
  Rooms cleaned dry by *other* robots are still gated per room via `anyvac_room_done`.

## [0.27.3] - 2026-06-26

### Fixed

- **A dry orchestrated pass now forces the mop off.** It previously took the mop intensity from the
  matched preset, so a vacuum whose only setting preset is a wet one would turn the water on during a
  dry pass (showing up as `clean_type: wet` on the backend). A dry pass now always sets mop intensity
  to `off` (and skips mop mode), so a `clean_type: dry` vacuum actually cleans dry.

## [0.27.2] - 2026-06-26

### Fixed

- **Work splits across robots even with no time estimates set.** The LPT balancer used a room's
  estimate as its weight; with no estimates configured every weight was 0, so the balancer collapsed
  back onto the first owner. Each room now counts at least 1, giving a round-robin split when
  estimates are absent.

## [0.27.1] - 2026-06-26

### Fixed

- **Orchestrated cleans now split the work across robots.** The assignment dumped every owned room on
  the first capable vacuum (so only one robot ran). It now distributes rooms across the capable owners
  by balancing estimated time (LPT greedy: biggest room → least-loaded robot), so e.g. bathroom + hall
  + kitchen are shared between S6 and S7 instead of all going to S6.

### Changed

- **Global preset tiles activate on hold**, with the same fill-ring animation as the vacuum
  controllers — so an orchestrated whole-home clean isn't triggered by an accidental tap.

## [0.27.0] - 2026-06-26

### Added

- **Auto tiles now run the real orchestrator (plan-builder).** Tapping a global preset no longer does
  the naive client fan-out — the card builds a **capability-aware plan** (each room → a dry-capable
  vacuum that owns it; for `mode: both`, a wet-capable vacuum follows, gated per room on the dry
  robot's `anyvac_room_done`) and calls the backend **`anyvac.run_job`** service, which executes it
  server-side (survives the dashboard closing). Clean commands are built per strategy (`native-area`
  → `vacuum.clean_area`; `native` / `native-auto` → `app_segment_clean` with resolved segment IDs),
  with mop/suction selects taken from the matching setting preset.
- **Global preset Mode** (Global tab): Dry only / Wet only / Dry then wet.

### Notes

- The `mode: both` per-room gate matches `anyvac_room_done` by room **name**, so a room's display
  name must match the Roborock room name. Requires the companion integration v0.7.0+ (`anyvac.run_job`
  + `anyvac_room_done`). `script` clean strategy is not orchestrated yet.

## [0.26.0] - 2026-06-26

### Added

- **Debug tab in the editor.** A new "🐞 Debug" tab shows the live, read-only values each vacuum's
  integration sensor is publishing — `clean_type`, `in_cleaning`, `vacuum_room_name`,
  `water_mode_name`, `fan_speed_name`, path / mop_path point counts, and the full `rooms_estimate` and
  `rooms_last_cleaned` payloads (plus a raw-attributes dump) — so you can verify the backend is
  writing data correctly without digging through Developer Tools.

## [0.25.0] - 2026-06-25

### Added

- **Auto-mode runtime (orchestrated cleans, v1).** When `ui_mode: auto`, a bar of global-preset tiles
  appears at the top of the card. Tapping a tile resolves its scope (whole flat / currently selected
  rooms / fixed room keys) and **fans the rooms out across vacuums**: each room is assigned to the
  first vacuum that owns it, those vacuums are selected and started in parallel. This is the naive v1
  allocation — the smart optimiser (capability match, wet-after-dry timing, collision avoidance) is
  the Level-3 backend orchestrator to follow. Per-vacuum controllers remain visible for room
  selection and manual control.

## [0.24.0] - 2026-06-25

### Added

- **Auto/Manual controller mode + global presets config (step A, config side).** The Global tab gains
  a **Controller Mode** select (Auto / Manual) and a **Global presets** section to add/edit/remove
  card-level targeted cleans (`global_presets`: id, label, icon, scope = whole flat / pick on map).
  These feed the upcoming Auto-mode orchestrated controller (runtime to follow).

### Changed

- **Active preset now drives the time estimate immediately.** For a vacuum with 2+ setting presets,
  picking one flips the shown estimate to that preset's mode (dry/wet) right away, instead of waiting
  for the live water mode to change after the clean starts.

## [0.23.0] - 2026-06-25

### Added

- **Setting presets are editable in the GUI editor** (Vacuums tab → new "Setting presets" section).
  Add / edit / remove named presets per vacuum with Label, Icon, Suction (from the vacuum's
  `fan_speed_list`), Mop mode / Mop intensity (options pulled from the Clean action's mop entities),
  and Repeat passes. Previously presets could only be set via YAML.

## [0.22.0] - 2026-06-25

### Added

- **Per-vacuum setting presets (Manual mode, step B).** A vacuum can now carry named setting bundles
  (`presets: [{id, label, icon, suction_level, mop_mode, mop_intensity, repeat}]`). They render as
  selectable chips above the START button (shown only when 2+ presets exist); the active preset's
  motor/mop settings are applied when the clean starts. When no `presets` are configured, a single
  default is synthesized from the legacy `clean_action`, so existing configs behave identically.
  (Data contract for setting/global presets + Auto/Manual `ui_mode` added to `types.ts`.)

### Changed

- **Mop trace gets a centre line.** The wet `mop_path` now draws a thin centre line on top of the
  translucent sheen band, so the wet trace reads as a path inside the band (matching the dry line).

## [0.21.0] - 2026-06-25

### Added

- **Separate mop (wet) trace as a "wet sheen" band.** The integration overlay now draws the dry
  vacuum trace (`path`) and the wet mop trace (`mop_path`) independently: the vacuum path stays a thin
  line, the mop path is rendered as a wider, translucent band beneath it. A run that vacuums *and*
  mops shows the thin line riding on the band, so a combined run is visually obvious. The dry layer
  toggle controls the line, the wet layer toggle controls the band. Band colour can be set with the
  new optional `mop_path_color` (defaults to a wet blue).

## [0.20.0] - 2026-06-25

### Added

- **Clean type is now editable in the GUI editor** (Vacuums tab, under Accent colour): Auto-detect /
  Dry only / Wet only / Both — follow live mode. Previously `clean_type` could only be set by editing
  YAML. "Auto-detect" keeps the prior heuristic (infers dry/wet from the clean action); the explicit
  options remove the ambiguity for dual-capable vacuums.

## [0.19.0] - 2026-06-25

### Added

- **Reads backend-calibrated clean-time estimates.** When the companion `anyvac` integration
  (v0.5.0+) is present, the per-room time estimate now prefers the value the backend has *learned*
  from real single-room cleans (`rooms_estimate`, per room name and clean type) over the static
  `clean_time_dry` / `clean_time_wet` config. Static values become the seed/fallback used until the
  backend has learned a room, and everything still degrades to config when no integration is set. This
  finally makes single-room time calibration work: the writable, type-aware store lives in the
  backend, so dry and wet estimates no longer fight over one value.

## [0.18.1] - 2026-06-24

### Fixed

- **Dual-capable vacuum showed the wrong time estimate** — a vacuum configured as `clean_type: both`
  (e.g. an S7 MaxV that both vacuums and mops) fell through to the wet estimate even for a dry run,
  so its dry clean borrowed another vacuum's wet `clean_time_wet`. The estimate now resolves a
  dual-capable vacuum to its *current* mode using the live backend `clean_type` (the integration
  sensor that follows the actual water mode), falling back to the configured clean action — so a dry
  run uses `clean_time_dry` and a wet run uses `clean_time_wet`.

## [0.18.0] - 2026-06-20

### Added

- **Per-clean-type time estimates** — rooms can carry a `clean_time_dry` and `clean_time_wet`, and the
  estimated cleaning time shown for a vacuum uses the one matching its clean-type role (dry/wet). So a
  dry vacuum shows the dry estimate and a mop vacuum the wet estimate for the same room; switching a
  vacuum's role flips its estimate. Falls back to `clean_time_mins` / the learned `clean_time_entity`.
  Editor (merged room editor) gains *Dry clean time* and *Wet clean time* fields.

## [0.17.2] - 2026-06-20

### Removed

- **3-point map alignment** — the experimental auto-alignment did not produce reliable results, so it
  was removed. Aligning a vacuum's map to the floorplan is done with the visual *Map seating* sliders
  (the faded overlay shows the alignment as you drag), which works reliably.

## [0.17.1] - 2026-06-20

### Fixed

- **3-point align now computes in the trace's coordinate space** — it derives the seating using the
  integration's `image_dims` (where the robot path is actually drawn) instead of the raw map PNG's
  pixel size. Previously the two had different aspect ratios, so the alignment lined up the map image
  but left the vector trace scattered.

## [0.17.0] - 2026-06-20

### Added

- **Optional 3-point map alignment** (merged) — a *3-point align* button in the Map seating section
  opens two panes (the vacuum map and the floorplan). Click the same recognisable point on both, 2–3
  times, then *Apply* and the card fits a similarity transform and writes the vacuum's
  rotation / scale / offset automatically — no more dragging the seating sliders. Manual sliders remain
  as the alternative. (Assumes the floorplan's own seating is identity.)

## [0.16.0] - 2026-06-20

### Changed

- **Editor UX cleanup + visual map seating (merged)** — the per-vacuum *Base layer* selector is hidden
  in merged mode (it is irrelevant there), the *Calibration* section is renamed *Map seating*, and the
  Maps-tab preview now shows the selected vacuum's native map **as a faded overlay on the shared
  floorplan**, so the seating sliders (rotation / scale / offset) are finally visual — you drag until
  the map lines up with the floorplan. Foundation for the upcoming one-click 3-point alignment.

## [0.15.0] - 2026-06-20

### Added

- **Editor GUI for the card-level merged config** (step 3 of the merged config rebuild) — in the Maps
  tab, when *Map mode* is **Merged**, the floorplan (Image src/rotation/scale/offset), card height and
  the room list are edited **card-level** (once for all vacuums): a *Shared floorplan* section, an
  *Add room* button, per-room Key / Name / Clean time / position / icon, and *Delete room* — all
  writing to the top-level `image_base` / `base_height` / `rooms`. In split mode the editor is
  unchanged (per-vacuum). Per-vacuum map seating, role and integration stay per the selected vacuum.

## [0.14.0] - 2026-06-20

### Added

- **Card-level room list** (step 2 of the merged config rebuild) — define `rooms` once at the top
  level of the card and every vacuum uses them: rectangles, selection (across vacuums), the hold
  dropdown and cleaning all read the shared list, and `native-auto` resolves each vacuum's segment by
  the room `key` (= Roborock name). No more configuring the same rooms per vacuum. Falls back to the
  per-vacuum `rooms` when no card-level list is set (backward compatible; split mode unchanged).

## [0.13.0] - 2026-06-20

### Added

- **Card-level floorplan for merged mode** (step 1 of the merged config rebuild) — `image_base` and
  `base_height` can now be set once at the top level of the card config and are used as the shared
  base in `merged` mode, instead of putting the custom floorplan on a vacuum. Falls back to the
  per-vacuum `image_base` when not set (backward compatible).

## [0.12.0] - 2026-06-19

### Changed

- **Per-room ages moved into the layer toggles** — instead of a permanent list under the map,
  **tap** a Dry/Wet chip to toggle the layer and **hold** it to expand a dropdown of every room's age
  for that layer (tap a row to select the room across vacuums). Cleaner, and compact on mobile.

## [0.11.0] - 2026-06-19

### Fixed

- **Traces follow the vacuum's clean type, not the path field** — a vacuum's trace now shows only under
  the layer matching its role (dry/wet), derived from its `clean_action` (mop settings → wet, suction →
  dry) or an explicit `clean_type` (`dry` / `wet` / `both`). A mop-only vacuum no longer draws a trace
  on the Dry layer.

### Added

- **Per-room status list** — below the merged map, each room is listed once (deduped across vacuums)
  with its **dry and wet age** (coloured by the thresholds). Tapping a row selects the room across all
  vacuums, the same as the map rectangle. This is the calibration-independent home for per-room state.

## [0.10.0] - 2026-06-19

### Added

- **Merged map: one rectangle per room, selected across vacuums** — in `merged` mode the room
  rectangles are now de-duplicated by `key`, so each physical room is drawn once. Clicking it selects
  that room on **every** vacuum that has it, so it lights up in both controllers and you choose who
  cleans it by pressing that vacuum's START (the manual precursor to auto-assign).

## [0.9.2] - 2026-06-19

### Fixed

- **Release workflow attaches the JS asset again** — the GitHub release action now receives the tag
  explicitly (`tag_name: ${{ github.event.release.tag_name }}`), fixing the "GitHub Releases requires a
  tag" failure so `dist/anyvac-card.js` is attached to each release automatically (no manual upload,
  HACS picks it up as before).

## [0.9.1] - 2026-06-19

### Fixed

- **`native-auto` now matches rooms by the Roborock room name** — it resolves each room's segment by
  the room `key` (our convention: the Roborock room name), then the display `name`, and only then an
  explicit `area_mappings` entry. Previously it looked up `area_mappings[key]` first, so a room whose
  HA area differs from its Roborock name (e.g. key `Corridor` mapped to area `hall`) failed to resolve
  a segment — the robot beeped but never went there. Other rooms only worked because their area id
  happened to equal the Roborock name.

## [0.9.0] - 2026-06-19

### Added

- **Dry / Wet view layers** — two toggle chips in the top-right of the map, each with a "how long ago"
  badge (the oldest room for that clean type). Toggling a layer shows that type's trace (Dry = `path`,
  Wet = `mop_path`) and colours the rooms by that type's age; with both on, rooms take the worse
  (more-overdue) of the two. This separates *seeing* (layers) from *acting* (presets).
- **Room age from the integration** — room colouring now reads `last_dry` / `last_wet` / `any` from the
  AnyVac sensor (per the active layer), falling back to the old `last_clean` helper entity when no
  integration sensor is set.

## [0.8.0] - 2026-06-19

### Added

- **Robot image rotation** — a *Robot image rotation* slider corrects the orientation of the robot
  image on the map (added on top of the live heading).

### Changed

- **Merged map renders each robot's own map** — in `merged` mode every shown vacuum now draws its own
  vacuum map over the shared floorplan, each with its **own opacity slider, blend, on/off (Hide map)
  and seating**, so the maps can be stacked and aligned independently. Opacity / blend / image / Hide
  map controls are now shown per vacuum in merged mode.
- **Base layer** — the standalone *Custom image* option was removed from the selector; choices are now
  *Vacuum map* and *Image + map* (a custom floorplan is the base in merged mode).

## [0.7.0] - 2026-06-19

### Added

- **Auto-filled vacuum sensors** — leave Status / Battery / Last clean / Progress / Current room /
  Error blank and the card resolves them automatically from the vacuum's device (matched by
  `translation_key` / `device_class`). Explicit config still wins.
- **Merged map mode** (`map_mode: merged`) — render **one shared map** with all shown vacuums
  overlaid (each robot's position + path in its own colour, seated by its own map transform), instead
  of one map per vacuum. Per-vacuum controls and status stay below the shared map. A *Map mode*
  selector was added to the editor. (First version: display + room overlays; map-click modes
  pin&go/zone stay per-vacuum and are best used in split mode for now.)

## [0.6.0] - 2026-06-19

### Added

- **Path styling** — *Path colour* and *Path width* options for the integration vector (the cleaning
  trail), set from the GUI.
- **Robot image on the map** — a *Robot image on map* toggle reuses the vacuum's configured status
  image (`image`) as the map marker (rotated to the robot's heading), with a *Robot image size*
  slider, instead of the default coloured dot.

### Changed

- **Editor hint on room Key** — the room *Key* field now notes it should match the room's name in the
  Roborock app, which the `native-auto` strategy pairs rooms by.

## [0.5.0] - 2026-06-19

### Added

- **Floorplan-only mode** — with an integration sensor selected, a *Hide vacuum map* toggle hides the
  Roborock map image and shows only your custom floorplan plus the vector robot and path.
- **Pin & Go and Zone cleaning use the integration calibration** — when an AnyVac sensor is selected,
  Pin & Go and the new **Zone** mode convert taps/drags to millimetres via the sensor's
  `calibration_points`, so they work with **no manual calibration**. Manual calibration remains the
  fallback when no integration sensor is set.
- **Zone cleaning** — a new *Zone* map tool: drag a rectangle on the map/floorplan, confirm, and the
  card sends `app_zoned_clean` for that area.

## [0.4.0] - 2026-06-19

### Added

- **Integration mode** — when an AnyVac companion sensor (`sensor.*_anyvac_map`) is selected for a
  vacuum, the card draws the robot (with heading) and the cleaning path as a vector overlay, using the
  `calibration_points` exposed by the sensor to map millimetres to map pixels. No manual calibration.
  In combined mode the vector is seated like the map overlay, so it lands on a custom floorplan.

## [0.3.7] - 2026-06-14

### Added

- **Overlay blend mode** (combined base) — a new *Overlay blend* option (`overlay_blend`:
  normal / lighten / screen / plus-lighter). Because the Roborock map draws the robot and the cleaned
  path as the *lightest* pixels, setting it to **lighten** makes the path and robot "punch through"
  onto a custom floorplan while the room fills blend away — a free, theme-robust way to isolate the
  trail without per-pixel colour keying.

## [0.3.6] - 2026-06-14

### Changed

- **Calibration is more hands-off** — after sending the robot to a calibration point, the card
  auto-refreshes the map several times while it drives (no need to press Refresh), and the third
  point starts closer to the dock so it is reachable more often (fewer "try another spot" retries).

## [0.3.5] - 2026-06-14

### Fixed

- **Calibration could be collinear** — the three calibration points could land on a single line
  (e.g. dock + east + west), leaving the transform unable to resolve one axis (Pin & Go always
  returned the dock's Y). Point 3 is now offered only perpendicular to point 2, and a guard rejects
  nearly collinear points. **Re-calibrate after updating.**

## [0.3.4] - 2026-06-14

### Fixed

- **Calibration anchored to the map layer** — in combined mode, calibration and Pin & Go now resolve
  clicks against the vacuum-map layer (where the robot and the millimetre coordinates actually live),
  undoing only the map's rotation/scale/offset, instead of the custom floorplan's. A small debug
  readout under the map shows the clicked %→mm so issues can be pinpointed. **Re-calibrate after
  updating.**

## [0.3.3] - 2026-06-14

### Fixed

- **Calibration accuracy in combined mode** — calibration and Pin & Go now anchor each click to the
  clicked layer's own content space (undoing its rotation / scale / offset via the element transform)
  instead of raw container coordinates. This removes the drift caused by the image base and the map
  overlay having different seatings (e.g. different scale), which made Pin & Go land off on both axes,
  worse toward the edges. **Re-calibrate after updating** — the stored calibration changes coordinate
  space.

## [0.3.2] - 2026-06-14

### Changed

- **Calibration alignment circle** — during calibration you place a robot-sized circle (with a centre
  dot) and press *Confirm*, instead of blind-tapping. Align the circle with the dock/robot edges for a
  precise point.

## [0.3.1] - 2026-06-14

### Added / Changed

- **Permanent "Refresh map" button** under the map (the official Roborock map refreshes mainly during
  cleaning; this forces an update).
- Calibration probing reworked — **"try another spot"** keeps a good baseline (~2.2 m) and rotates
  through directions instead of shrinking toward the dock, so calibration points stay well-spread and
  accurate; the map auto-refreshes after each move.

## [0.3.0] - 2026-06-14

### Added

- **Map calibration + Pin & Go** (Milestone 2) — an in-card guided wizard establishes a pixel↔mm
  transform (tap the dock; the card auto-drives the robot to two points; you mark it on the map).
  Once calibrated, a **Pin & Go** mode sends the robot to any point you tap. Calibration is stored
  per browser (localStorage).

## [0.2.0] - 2026-06-14

### Added

- **Configurable image base** — use a custom floorplan/photo as the card's base layer
  (`base: map | image | combined`). Point `image src` at a URL (SVG / WebP / PNG / JPG) and seat it
  with its own rotation / scale / offset. In `combined` mode the vacuum map (robot + path) overlays
  the image, with an **adjustable overlay opacity**. Clickable rooms work on any base.
- **Card height control** (`base_height`) — fix the card/stage height independently of the image's
  natural size; the image is fitted inside (`object-fit: contain`) and `scale`/offset seat it within.
- **Editor improvements** — Maps tab gains a *Base layer* selector, *Card height* and *Overlay
  opacity* sliders, and image source + transform fields. The click-to-place preview now shows the
  custom image when the base is image/combined.
- **Reorderable rooms** — drag the grip handle on a room in the Vacuums tab to reorder rooms
  (order propagates everywhere, including the room chips on the Maps tab).

## [0.1.0] - 2026-06-14

Initial release. AnyVac Card is built on the proven `roborock-vacuum-card` codebase (renamed and
re-homed), keeping its polished UI and editor as the foundation.

### Added

- **Multi-vacuum pill badges** — switch between vacuums; active/cleaning glow.
- **Configurable map** — camera/image map entity with rotation / scale / offset seating
  (slider-based in the editor, live preview).
- **Clickable rooms** — rectangle and point overlays; editor "select a room, click the map to place
  it" workflow.
- **Per-room "last cleaned" thresholds** — colour by age (reads helper entities for now; to be
  superseded by the companion integration).
- **Clean strategies** — `native` (`app_segment_clean`), `native-area` (`vacuum.clean_area`),
  `native-auto` (resolve segments via `roborock.get_maps`), `script`.
- **Glassy status card** — robot image, status label + colour, battery, last-clean, current room,
  error, progress.
- **Hold-to-activate actions** — START (per-room icons, time estimate, all/none), Pause / Resume /
  Dock, with a hold-ring fill animation.
- **Global actions** — whole-flat / cross-vacuum action badges.
- **GUI editor** — three tabs (Vacuums / Maps / Global).
