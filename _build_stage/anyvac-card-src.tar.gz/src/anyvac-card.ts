import { LitElement, html, svg, css, nothing, render, type PropertyValues } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { styleMap } from "lit/directives/style-map.js";

import type {
  HomeAssistant,
  VacuumConfig,
  AnyVacCardConfig,
  RoomConfig,
  RoomThreshold,
  NativeCleanAction,
  NativeAreaCleanAction,
  NativeAutoCleanAction,
  ScriptCleanAction,
  SettingPreset,
  GlobalPreset,
  GlobalAction,
  GlobalActionCall,
} from "./types";
import {
  CARD_NAME,
  EDITOR_NAME,
  CARD_VERSION,
  HOLD_DURATION_MS,
  HOLD_MOVE_CANCEL_PX,
  STATUS_MAP,
  COLOR_HEX,
  COLOR_BG,
  COLOR_BG_ACTIVE,
  DEFAULT_VACUUM_PALETTE,
  hexToRgba,
  hexToRgbChannel,
  DEFAULT_THEME,
  CLEANING_STATES,
} from "./const";
import {
  resolveSeat,
  resolveStaticRooms,
  resolveImageBaseSrc,
  roomBboxToRect,
  homeFrameCropFor,
  pointInCrop,
  pctToCropPoint,
  outlineInCrop,
  placeRoomInCrop,
  homeAnchorFit,
  projectHomePxThroughFit,
  unprojectPctThroughFit,
  outlineThroughFit,
  seatRotateScaleCss,
  seatScaleYRatio,
  type SeatParams,
  type SeatFitResult,
  type CropBox,
} from "./seatfit";
import {
  applyFloorplanSeats,
  seatToMatrix,
  translateSeat,
  scaleSeatAbout,
  scaleSeatCornerAniso,
  stretchSeatX,
  stretchSeatY,
  localAxisScaleRatio,
  rotateSeatAbout,
  pinchSeat,
  defaultAlignView,
  defaultAlignLayers,
  nudgeOffset,
  nudgeRotation,
  nudgeScale,
  nudgeTierMultiplier,
  seatToYaml,
  type AlignSession,
  type AlignViewState,
  type FloorplanSeats,
  type NudgeTier,
  type SeatEditConfigLike,
} from "./seatedit";
import { mountAlignOverlay, unmountAlignOverlay, type AnyVacAlignOverlayHost } from "./align-overlay";
import {
  pickProfile,
  resolveProfile,
  gridRootStyles,
  regionStyles,
  shouldRotateMap,
  shouldStackLayout,
  STACK_PORTRAIT_PROFILE,
  type LayoutProfile,
  type LayoutConfig,
  type ProfileGridConfig,
  type ResolvedProfileGrid,
} from "./layout";

/** docs/25 §10 follow-up: one auto-discovered "care" row (consumable time-left +
 *  reset button, or a dock tank binary status). See `_careItems()` for how these
 *  are found — purely from the official `roborock` integration's own entities, no
 *  new config keys. */
type CareRow = {
  key: string;
  label: string;
  entity?: string;
  reset?: string;
  binary?: string;
  /** Nominal total lifespan in hours, when known — enables a % readout
   *  instead of raw remaining time. See `_careItems()` for sourcing. */
  totalHours?: number;
};

/** docs/25 §10 third follow-up: nominal total consumable lifespans, used to
 *  turn a "time left" sensor into a "% remaining" readout. NOT from any
 *  Roborock API field (the protocol only ever reports remaining time) —
 *  triangulated from THREE independent live data points (S6/S7 MaxV/S8
 *  MaxV Ultra all converge on the same round totals once time-left is
 *  divided out) and cross-checked against Roborock's own published HEPA
 *  filter service interval ("every 150 hours of runtime"). Deliberately
 *  covers only the 4 consumables with this convergent evidence — the two
 *  dock-mounted ones (cleaning brush, strainer) had just one data point
 *  each with no round-number pattern to anchor on, so those stay in hours
 *  rather than showing a guessed percentage. */
const CARE_TOTAL_HOURS: Record<string, number> = {
  main_brush_time_left: 300,
  side_brush_time_left: 200,
  filter_time_left: 150,
  sensor_time_left: 30,
};

console.info(
  `%c ANYVAC-CARD %c v${CARD_VERSION} `,
  "background:#2196F3;color:#fff;font-weight:700;padding:2px 4px;border-radius:3px 0 0 3px",
  "background:#1a1a1a;color:#fff;font-weight:400;padding:2px 4px;border-radius:0 3px 3px 0"
);

@customElement(CARD_NAME)
export class AnyVacCard extends LitElement {
  @property({ attribute: false }) hass!: HomeAssistant;
  /** Set by Lovelace when the dashboard is in edit mode */
  @property({ attribute: false }) editMode = false;
  @state() private _config!: AnyVacCardConfig;
  /** docs/41 §4.6: the config exactly as `setConfig()` received it, before
   *  `_syncEffectiveConfig()` merges backend Align-mode overrides on top.
   *  `_config` (above) is what the rest of the card reads everywhere — this
   *  field exists purely so the merge has an un-merged base to recompute
   *  from on every hass update. */
  private _rawConfig?: AnyVacCardConfig;
  @state() private _shownSet = new Set<number>([0]);
  /** ID of the button currently being held — drives the fill animation */
  @state() private _holdId: string | null = null;
  @state() private _mapMode: "normal" | "pin" | "zone" = "normal";
  /** docs/25 §7b: hold-to-inspect on a room — the room key whose detail
   *  popup (age/pin) is currently open, or null. Set by a hold gesture on
   *  the room overlay; a tap while open dismisses it instead of toggling
   *  selection (see `_renderRoomOverlay`'s pointer handlers). */
  @state() private _inspectKey: string | null = null;
  /** docs/25 §7 field follow-up (2026-07-24): dock sheet (Empty/Wash/Dry +
   *  per-vacuum status), opened from a new "Dock" button in the dock-head
   *  row. `_dockSheetIdx` is which vacuum's tab is active — local UI state,
   *  not backend-shared (same reasoning as `_inspectKey`: navigation, not
   *  orchestration input). */
  @state() private _dockSheetOpen = false;
  @state() private _dockSheetIdx = 0;
  /** docs/25 §10 follow-up (2026-07-25): the START bar's left segment mirrors
   *  the manufacturer app's 3-section bottom bar (mode / START / Dock, see
   *  docs/25 §10) — mode picker sheet, same in-flow pattern as `_dockSheetOpen`
   *  right next to it. Mutually exclusive with the dock sheet (toggling one
   *  closes the other) purely to keep the narrow dock column from showing two
   *  panels stacked at once. */
  @state() private _modeSheetOpen = false;
  /** docs/25 §10 field-caught (2026-07-25): reset-button visual feedback.
   *  Live diagnosis on the field-reporting user's real HA found the reset
   *  DOES work — the official `roborock` integration's own consumable
   *  sensor just takes up to one poll cycle (~30s, live-measured) to reflect
   *  it, and (separately, now fixed above in `_watchedEntities`) the card
   *  wasn't even re-rendering on that entity's change. A 30s silent wait
   *  after tapping reads as broken even once the card DOES re-render
   *  promptly — so the tapped button shows a spinner until the watched
   *  sensor's `last_changed` moves past the press time, with a hard-timeout
   *  fallback (`_careResetPending` cleanup in `updated()`) in case the
   *  vacuum is offline and the poll never lands. Keyed by the row's sensor
   *  entity id when there is one (globally unique, unlike `CareRow.key`
   *  which is a translation_key shared across vacuums), else the reset
   *  button's own entity id. */
  @state() private _careResetPending = new Map<string, number>();
  @state() private _modeEntity: string | null = null;
  @state() private _dbg = "";
  @state() private _zoneDrag: { x0: number; y0: number; x1: number; y1: number } | null = null;
  /** Frozen copy of `_zoneDrag` at drop time, in the same wrap-relative % — kept
   *  around purely so the drawn rectangle stays visible while `_zonePending` is
   *  awaiting a per-vacuum confirm (drag itself is cleared right away to fix the
   *  "won't let go" bug, but the box shouldn't just vanish on release). */
  @state() private _zoneRectShown: { x0: number; y0: number; x1: number; y1: number } | null = null;
  /** Pending zone(s) awaiting per-vacuum confirmation, keyed by entity_id (docs/19
   *  §Pin&Go/Zone fix). Legacy single-target flow (split mode / per-vacuum tools)
   *  only ever populates one key; the merged multi-candidate flow (meta bar) may
   *  populate several at once — the user confirms on whichever vacuum's own
   *  status card they want to execute it. */
  /** `frame: "home"` marks a capture taken via `_clickToHomePx` (docs/40 §4.4,
   *  Fáze 3) — x1/y1/x2/y2 are then home-frame PX, not `*_pct`, and
   *  `_confirmZone` calls `zone_clean` with `frame: "home"` + `*_home_px`
   *  instead of the legacy `*_pct` fields. Absent (legacy) for anything
   *  captured through a per-vacuum seat (`_clickToContent`). */
  @state() private _zonePending: Record<string, { x1: number; y1: number; x2: number; y2: number; frame?: "home" }> | null = null;
  /** Whether the current `_zoneRectShown`/`_zonePending` capture is the merged
   *  multi-candidate flow (meta bar, "*") vs. the legacy single-target flow
   *  (per-vacuum tools / split mode). Set once at draw time so post-drop editing
   *  (move/resize, docs/19 follow-up) knows how to recompute `_zonePending`
   *  without depending on `_modeEntity`, which is already reset to null by then. */
  private _zoneMulti = false;
  /** Active move/resize drag on an already-drawn `_zoneRectShown`, distinct from
   *  `_zoneDrag` (drawing a brand new rectangle). `move` carries the grab offset
   *  from the box's top-left corner plus its fixed width/height; the corner
   *  variants just say which corner is being dragged. */
  @state() private _zoneEdit:
    | { type: "move"; offsetX: number; offsetY: number; width: number; height: number }
    | { type: "nw" | "ne" | "sw" | "se" }
    | null = null;
  /** Pending pin(s) awaiting per-vacuum confirmation, keyed by entity_id — same
   *  shape/reasoning as `_zonePending`, but for Pin & Go (`frame: "home"` same
   *  meaning: x/y are home-frame PX, and `_confirmPin` calls `goto` with
   *  `frame: "home"` + `x_home_px`/`y_home_px` instead of `x_pct`/`y_pct`). */
  @state() private _pinPending: Record<string, { x: number; y: number; frame?: "home" }> | null = null;
  @state() private _layers: { dry: boolean; wet: boolean } = { dry: true, wet: false };
  @state() private _layerMenu: "dry" | "wet" | null = null;
  private _layerHoldTimer: number | null = null;
  private _layerHeld = false;
  /** Výběr místností — drží se lokálně v kartě (bez potřeby input_boolean helper entity) */
  @state() private _localRoomSel = new Map<string, boolean>();
  /** Active setting preset per vacuum (Manual mode): vac.entity -> preset id. */
  @state() private _activePresets = new Map<string, string>();
  /** Plan preview mode (Auto): which passes to plan/run. */
  @state() private _planMode: "dry" | "wet" | "both" = "both";
  /** Currently selected global preset id (Auto): tiles select, the plan runs. */
  @state() private _activeGlobalPreset: string | null = null;
  /** Responsive: measured card width + map aspect ratio (W/H) for portrait rotation. */
  @state() private _cardW = 0;
  @state() private _mapAR = 3.636;
  /** docs/41 §4.2/§4.1 — the open Align-mode session (null = overlay closed).
   *  `@state` so opening/closing/gizmo edits re-render the card's own
   *  template, which is what actually produces `_renderAlignOverlay()`'s
   *  markup (the portal itself owns no Lit reactivity of its own). */
  @state() private _alignSession: AlignSession | null = null;
  @state() private _alignView: AlignViewState = defaultAlignView();
  /** In-overlay Cancel confirmation panel (docs/41 §4.4: "s in-overlay
   *  potvrzením při neuloženém draftu — ne window.confirm"). */
  @state() private _alignCancelConfirm = false;
  /** Brief "Copied" flash on the Copy YAML button. */
  @state() private _alignCopiedFlash = false;
  /** The mounted portal host, or null when the overlay is closed. Plain
   *  field, not `@state` — it's DOM plumbing, not render input. */
  private _alignHost: AnyVacAlignOverlayHost | null = null;
  /** In-progress gizmo gesture, if any — `null` between gestures. Pointer ids
   *  are tracked so a two-finger pinch can tell its two live pointers apart
   *  from a stray third touch (docs/41 §4.4/§6 risk 2). */
  private _alignGesture: {
    kind: "drag" | "scale" | "rotate" | "pinch" | "stretchX" | "stretchY";
    /** Seat the gesture (or, for a pinch, the pinch itself) started from —
     *  deltas are computed against this, not accumulated step-by-step, so a
     *  gesture can't drift from floating-point error across many
     *  pointermove events. */
    startSeat: SeatParams;
    /** Layer-space (percent) pivot for scale/rotate — the opposite corner /
     *  the layer's own centre, fixed for the lifetime of one gesture. */
    pivotPct?: { x: number; y: number };
    /** pointerId -> wrap-percent position captured when that pointer joined
     *  the gesture (or when a pinch was (re-)baselined). */
    startPos: Map<number, { x: number; y: number }>;
    /** pointerId -> most recent live wrap-percent position, updated on
     *  every pointermove. */
    livePos: Map<number, { x: number; y: number }>;
  } | null = null;
  /** Active layout profile (docs/18) — picked by viewport aspect ratio. */
  @state() private _profile: LayoutProfile = "landscape";
  /** Measured inner box of the map region (grid mode) for the exact rotated fit. */
  @state() private _mapRegW = 0;
  @state() private _mapRegH = 0;
  /** docs/25 §7c: measured combined map+dock content box (portrait grid root
   *  minus the START row) — the box the split-vs-stack topology choice is
   *  computed against, BEFORE that choice picks map's own (narrower/shorter)
   *  region. Distinct from `_mapRegW`/`_mapRegH`, which measure the map
   *  region AFTER a topology is already applied. */
  @state() private _mapAvailW = 0;
  @state() private _mapAvailH = 0;
  /** docs/25 §7c: last computed split-vs-stack decision, same "keep the
   *  previous answer while unmeasured" convention as `_lastRotate`. Defaults
   *  to `false` (split) — matches today's shipped default until real
   *  measurements correct it. */
  private _lastStack = false;
  /** Portrait only: the map's last computed fitted width (`_renderResponsive`),
   *  fed into `_refineGridColumns` to override the map/dock column split so the
   *  sidebar gets whatever width the height-fitted map doesn't need. Plain
   *  field (not @state) — read post-render in `updated()`, never drives a
   *  render itself. */
  private _lastPortraitFitW = 0;
  /** docs/25 §4: last computed map-rotation decision, kept as the answer while
   *  the map region hasn't been measured yet (`shouldRotateMap` returns
   *  `undefined`) so the map doesn't flicker between orientations on first
   *  paint. Defaults to `true` — matches the old fixed "portrait rotates"
   *  behavior until real measurements correct it, one render later. */
  private _lastRotate = true;
  /** docs/32 follow-up (2026-08-03): ephemeral, per-browser-tab override for
   *  the "this looks upside down on THIS screen" flip — separate from the
   *  persisted `layout.<profile>.crop.flip` config default. Not backend-shared
   *  (unlike `view_layers`) and not written to the dashboard config: a quick
   *  "try it on this device right now" toggle, reset on reload. `null` = no
   *  override, defer to config; `true`/`false` = explicit override for the
   *  current session. Applies to whichever profile is active when tapped. */
  @state() private _flipLive: boolean | null = null;
  private _ro: ResizeObserver | null = null;
  private _onWinResize: (() => void) | null = null;
  private _measureRaf = 0;
  /** docs/21 §5a: `setTimeout` handle used instead of `_measureRaf` when the
   *  tab is backgrounded (`document.hidden`) — `requestAnimationFrame` never
   *  fires on an inactive tab (kiosk/wall-mounted tablets, `browser_mod`
   *  popups), so a card measure scheduled while hidden would otherwise hang
   *  forever. Only one of `_measureRaf`/`_measureTimer` is ever active. */
  private _measureTimer: number | null = null;
  /** docs/21 §5b follow-up (2026-07-17, ported from `room-overlay-card`
   *  v5.0): one late-settling remeasure after every render, NOT tied to any
   *  DOM mutation or resize. Fonts/images (the floorplan `image_base`,
   *  per-vacuum `image`, map images) can finish loading and shift the
   *  card's own position on the page — without changing the card's own box
   *  size and without any observable DOM mutation — leaving the grid pinned
   *  to a stale height (dead scroll space below it) until *something else*
   *  happens to trigger a remeasure. Cleared and rescheduled every render,
   *  so it never piles up timers. */
  private _settleTimer: number | null = null;
  /** docs/21 §5b/§5c: nearest `hui-panel-view` ancestor observer. HA
   *  reparents the card into `hui-card-options` on edit-mode toggle without
   *  firing any event, and the host's own box doesn't always change size
   *  when that happens — `ResizeObserver(this)` alone can miss it. `_warned`
   *  is a one-shot flag so a missing ancestor (internal HA DOM, not public
   *  API) logs once, not on every failed lookup. */
  private _panelViewMo: MutationObserver | null = null;
  private _panelViewWarned = false;
  /** docs/21 §5b third follow-up (2026-07-17): the panel-view node the current
   *  `_panelViewMo` is actually watching. HA can rebuild `hui-panel-view`'s
   *  node identity across a hard refresh in multiple DOM-construction phases
   *  — once `_panelViewMo` was set, the old code never re-checked whether the
   *  watched node was still the live one, so a stale reference silently
   *  stopped receiving edit-mode mutations (fixed only by a second toggle,
   *  which happened to trigger a remeasure some other way). Reported live by
   *  the user after a hard refresh. Ported from room-overlay-card v5.0, which
   *  always re-verifies liveness instead of trusting a once-set flag. */
  private _panelViewNode: Element | null = null;
  /** docs/21 §5b third follow-up: one-shot observer for the edit-mode actions
   *  bar mounting AFTER the transition mutation `_panelViewMo` reacts to (see
   *  `_watchEditBar`). */
  private _barMo: MutationObserver | null = null;
  /** docs/21 §5b third follow-up: watches the actions bar's OWN box once
   *  found, to catch its height CSS-transitioning in after it mounts (see
   *  `_observeEditBar`) — confirmed live, not just in theory. */
  private _editBarRo: ResizeObserver | null = null;
  /** Per-second clock for the debug progress timers (mm:ss). Only ticks while a vacuum is
   *  cleaning/paused and debug_room_progress is on, so it does not re-render otherwise. */
  @state() private _now = Date.now();
  private _tickTimer: number | null = null;
  // NOTE (docs/14 canon): the card holds NO cleaning-session state. Tracking, history,
  // estimates and room detection live in the anyvac integration — the card only renders
  // sensor data and sends intents.

  private _holdTimer: ReturnType<typeof setTimeout> | null = null;
  /** docs/25 §10 field report: pointerdown position for the in-progress hold,
   *  used by `_holdMove` to detect a drag/swipe starting on a hold button
   *  (see `HOLD_MOVE_CANCEL_PX` doc comment). Null when no hold is active. */
  private _holdStartPos: { x: number; y: number } | null = null;
  private _initialized = false;
  /** Entities whose state changes should trigger a re-render */
  private _watched: Set<string> | null = null;

  // ── Lovelace card API ───────────────────────────────────────────────────

  static getConfigElement(): HTMLElement {
    return document.createElement(EDITOR_NAME);
  }

  /** HA passes (hass, entities, entitiesFallback) when building the "+ Add card"
   *  preview — auto-detecting the user's actual first vacuum entity here means a
   *  freshly dropped card already works instead of showing a nonexistent
   *  placeholder the user must find and replace by hand. Falls back to the old
   *  placeholder if hass isn't supplied (defensive — some call sites/older HA
   *  versions may not pass it). */
  static getStubConfig(hass?: HomeAssistant): AnyVacCardConfig {
    const vacuumIds = hass ? Object.keys(hass.states).filter((id) => id.startsWith("vacuum.")) : [];
    // Entity registry, when available, lets us skip Matter-bridged vacuum
    // entities entirely — Matter's vacuum feature set is far more limited
    // than a native integration's (no rooms/segments/zones), so a Matter
    // entity is never useful alongside (or instead of) a native one. This
    // matters more now that the stub auto-loads EVERY vacuum (field report
    // 2026-07-31, extending the single-vacuum Matter fix from 2026-07-30):
    // without it, any physical vacuum with a Matter bridge would show up
    // twice — once crippled.
    const reg = (hass as any)?.entities as Record<string, { platform?: string }> | undefined;
    const nonMatter = reg ? vacuumIds.filter((id) => reg[id]?.platform !== "matter") : vacuumIds;
    const ids = nonMatter.length > 0 ? nonMatter : vacuumIds;
    if (ids.length === 0) {
      return {
        type: `custom:${CARD_NAME}`,
        vacuums: [{ entity: "vacuum.my_roborock", name: "Roborock", rooms: [], clean_action: { type: "native" } }],
      };
    }
    // No explicit `color` here on purpose — leaving it unset means each
    // vacuum picks up its position-based DEFAULT_VACUUM_PALETTE colour
    // (see `_defaultColor`), so a fresh multi-vacuum card gets visually
    // distinct vehicles immediately, and stays that way if the user later
    // reorders the `vacuums` list in YAML.
    return {
      type: `custom:${CARD_NAME}`,
      vacuums: ids.map((id) => ({
        entity: id,
        name: (hass!.states[id]?.attributes["friendly_name"] as string | undefined) ?? id.replace(/^vacuum\./, ""),
        rooms: [],
        clean_action: { type: "native" },
      })),
    };
  }

  setConfig(config: AnyVacCardConfig): void {
    if (!config.vacuums || !Array.isArray(config.vacuums) || config.vacuums.length === 0) {
      throw new Error("[anyvac-card] 'vacuums' must be a non-empty array");
    }
    this._rawConfig = config;
    this._config = config;
    this._watched = null;
    // A config edit can change which entities a vacuum resolves to (explicit
    // `integration_entity`/`map.entity` overrides, a renamed or reordered
    // vacuum), so every auto-resolved answer keyed on `vac.entity` is suspect —
    // these were previously never cleared anywhere at all (2026-08-08 fix).
    this._intCache.clear();
    this._mapCandCache.clear();
    this._autoCache.clear();
    this._careCache.clear();
    // Room geometry and seats derive from the config as well as from hass, so
    // the hass-identity check in `_memoSync()` alone wouldn't catch a config edit.
    this._roomsMemo.clear();
    this._seatMemo.clear();
    if (!this._initialized) {
      this._initialized = true;
      this._shownSet = this._loadShown();
      this._localRoomSel = this._loadRoomSel();
      this._flipLive = this._loadFlipLive();
    } else {
      const valid = new Set<number>();
      for (const i of this._shownSet) { if (i < config.vacuums.length) valid.add(i); }
      this._shownSet = valid.size > 0 ? valid : new Set(config.vacuums.map((_, i) => i));
    }
  }

  getCardSize(): number {
    return 6;
  }

  // ── Lifecycle ───────────────────────────────────────────────────────────

  connectedCallback(): void {
    super.connectedCallback();
    this.style.setProperty("--hold-ms", HOLD_DURATION_MS + "ms");
    if (!this._ro && typeof ResizeObserver !== "undefined") {
      this._ro = new ResizeObserver(() => this._scheduleMeasure());
      this._ro.observe(this);
    }
    if (!this._onWinResize) {
      this._onWinResize = () => this._scheduleMeasure();
      window.addEventListener("resize", this._onWinResize, { passive: true });
      window.addEventListener("orientationchange", this._onWinResize, { passive: true });
    }
    this._setupPanelViewObserver();
    this._scheduleMeasure();
    if (!this._tickTimer) {
      this._tickTimer = window.setInterval(() => {
        // Only re-render (update the clock) when debug progress is on AND a vacuum is
        // mid-clean or paused — otherwise stay idle to avoid needless re-renders.
        if (this._config?.debug_room_progress &&
            (this._config.vacuums ?? []).some((v) => this._isCleaning(v) || this._isPaused(v))) {
          this._now = Date.now();
        }
      }, 1000);
    }
  }

  /** Coalesce all width re-measures into one tick (RO + window resize +
   *  orientationchange + edit-mode reparenting, docs/21 §5b). Also re-picks
   *  the layout profile (docs/18) and refines the grid height.
   *
   *  docs/21 §5a: `requestAnimationFrame` never fires on a backgrounded tab
   *  (kiosk/wall-mounted tablets, `browser_mod` popups, a second window) —
   *  confirmed live, not just in theory. Fall back to `setTimeout(fn, 0)`
   *  while `document.hidden`, so a measure scheduled in the background still
   *  actually runs instead of hanging until the tab regains focus. */
  private _scheduleMeasure(): void {
    if (this._measureRaf || this._measureTimer !== null) return;
    const run = (): void => {
      this._measureRaf = 0;
      this._measureTimer = null;
      this._doMeasure();
    };
    if (typeof document !== "undefined" && document.hidden) {
      this._measureTimer = window.setTimeout(run, 0);
    } else {
      this._measureRaf = requestAnimationFrame(run);
    }
  }

  /** docs/21 §5f: pick the layout profile from the card's OWN measured box,
   *  not `window.innerWidth`/`innerHeight`. The card previously used the
   *  full browser viewport for this — correct only when the card happens to
   *  span the whole window. On any dashboard where it doesn't (two cards
   *  side by side, a sections/grid view, a sidebar, split-screen), the
   *  viewport's aspect ratio can disagree with the card's own box, picking
   *  the wrong profile regardless of how correct the profile's own grid math
   *  is. `_cardW` already tracks the real width (ResizeObserver on `this`);
   *  this adds the matching height side. */
  private _doMeasure(): void {
    const rect = this.getBoundingClientRect();
    const w = Math.round(rect.width);
    if (w && Math.abs(w - this._cardW) >= 2) this._cardW = w;
    const lay = this._config?.layout;
    if (lay) {
      const availW = this._cardW || w || window.innerWidth;
      const availH = this._availableHeight(lay, rect);
      const p = pickProfile(lay, availW, availH);
      if (p !== this._profile) this._profile = p;
      this._refineGridHeight();
    }
  }

  /** Available height for profile picking (docs/21 §5f) — mirrors the height
   *  mode `resolveHeightCss`/`_refineGridHeight` already use, just applied
   *  one tick earlier (profile choice happens before the grid root can be
   *  measured on first paint, so it can't read `.avc-grid` yet). `"container"`
   *  = the card's own rendered height (whatever its parent actually gave
   *  it). `"viewport"` (default) and any custom CSS length: window bottom
   *  minus the card's own top — the same technique `_refineGridHeight` uses
   *  for the grid height itself, so profile picking and final sizing agree. */
  private _availableHeight(lay: LayoutConfig, rect: DOMRect): number {
    if ((lay.height ?? "viewport") === "container") {
      return rect.height > 1 ? Math.round(rect.height) : window.innerHeight;
    }
    const top = rect.top;
    if (top >= 0 && top < window.innerHeight) {
      return Math.max(1, Math.round(window.innerHeight - top - this._editBarHeight()));
    }
    return window.innerHeight;
  }

  /** docs/21 §5b follow-up (2026-07-17, ported from a sibling project's
   *  battle-tested fix — room-overlay-card v5.0): HA's edit-mode "Move /
   *  Edit / Delete" actions bar renders as a REAL sibling inside
   *  `hui-card-options`' OWN shadow root — a separate shadow tree from both
   *  the card's own and `hui-panel-view`'s, and NOT an overlay. A card
   *  pinned to the full viewport height without reserving room for it gets
   *  its content pushed under/behind that bar. Measure the bar's REAL
   *  rendered height (never hardcoded — it isn't a constant across HA
   *  versions/themes) so callers can subtract exactly that much. Internal
   *  HA DOM, best-effort: any miss just returns 0 (today's behavior). */
  private _editBarHeight(): number {
    try {
      const opts = this._findCardOptionsAncestor();
      if (!opts?.shadowRoot) return 0;
      const bar = opts.shadowRoot.querySelector(".card-actions") as HTMLElement | null;
      if (!bar) return 0;
      const br = bar.getBoundingClientRect();
      if (!(br.height > 0)) return 0;
      const bcs = getComputedStyle(bar);
      return Math.ceil(br.height + (parseFloat(bcs.marginTop) || 0) + (parseFloat(bcs.marginBottom) || 0));
    } catch {
      return 0;
    }
  }

  /** docs/21 §5b, widened 2026-07-17: find the nearest `hui-panel-view` OR
   *  `hui-view` ancestor across shadow root boundaries (HA nests the card
   *  several shadow roots deep). Watching both, not just `hui-panel-view`,
   *  is a lesson learned the hard way in a sibling project — which HA
   *  dashboard/view type resolves to which tag varies, and a card that only
   *  ever checks one can silently never find its ancestor. Internal HA DOM,
   *  not public API — callers must degrade loudly (§5c), not assume it's
   *  always found. */
  private _findPanelViewAncestor(): Element | null {
    let node: Node | null = this.parentElement ?? (this.getRootNode() as ShadowRoot).host ?? null;
    let hops = 0;
    while (node && hops++ < 20) {
      if (node instanceof Element && (node.tagName === "HUI-PANEL-VIEW" || node.tagName === "HUI-VIEW")) return node;
      const el = node as Element;
      node = el.parentElement ?? (el.getRootNode() as ShadowRoot)?.host ?? null;
    }
    return null;
  }

  /** Nearest `hui-card-options` ancestor, if the card is currently wrapped
   *  in one (edit mode). Its actions bar lives in ITS OWN shadow root — a
   *  separate tree from `hui-panel-view`'s — so it needs to be watched
   *  (and re-found) independently; see `_setupPanelViewObserver`. */
  private _findCardOptionsAncestor(): Element | null {
    let node: Node | null = this.parentElement ?? (this.getRootNode() as ShadowRoot).host ?? null;
    let hops = 0;
    while (node && hops++ < 12) {
      if (node instanceof Element && node.tagName === "HUI-CARD-OPTIONS") return node;
      const el = node as Element;
      node = el.parentElement ?? (el.getRootNode() as ShadowRoot)?.host ?? null;
    }
    return null;
  }

  /** docs/21 §5b: HA reparents the card into `hui-card-options` on edit-mode
   *  toggle without firing any event, and the host's own box doesn't always
   *  change size when it happens — `ResizeObserver(this)` can miss it. Watch
   *  the nearest panel-view ancestor (and its shadow root, if any) for DOM
   *  mutations and force a remeasure on any change. `_scheduleMeasure` is
   *  itself coalesced, so an extra call here is cheap.
   *
   *  2026-07-17: also (re-)adopt `hui-card-options`' own shadow root on every
   *  mutation — its actions bar (whose height `_editBarHeight` reserves) is
   *  a separate shadow tree that can appear/change after the wrapper itself
   *  shows up, and re-observing an already-observed target is a cheap
   *  no-op, so this is safe to do unconditionally rather than only once. */
  private _setupPanelViewObserver(): void {
    if (typeof MutationObserver === "undefined") return;
    // docs/21 §5b third follow-up: re-verify liveness on every call instead of
    // early-returning forever once `_panelViewMo` is non-null — a stale
    // watched node is otherwise indistinguishable from a healthy one until an
    // edit-mode mutation silently fails to reach it.
    if (this._panelViewMo && this._panelViewNode?.isConnected) return;
    if (this._panelViewMo) {
      this._panelViewMo.disconnect();
      this._panelViewMo = null;
      this._panelViewNode = null;
    }
    const panelView = this._findPanelViewAncestor();
    if (!panelView) {
      if (!this._panelViewWarned) {
        this._panelViewWarned = true;
        try {
          console.warn(
            "[anyvac-card] hui-panel-view/hui-view ancestor not found (HA internal DOM may " +
            "have changed) — edit-mode layout refresh via MutationObserver is disabled; " +
            "resize-based refresh still works."
          );
        } catch { /* noop */ }
      }
      return;
    }
    const mo = new MutationObserver(() => {
      this._scheduleMeasure();
      this._watchEditBar();
      const opts = this._findCardOptionsAncestor();
      if (opts?.shadowRoot) {
        try { mo.observe(opts.shadowRoot, { childList: true, subtree: true }); } catch { /* noop */ }
      }
    });
    try { mo.observe(panelView, { childList: true, subtree: true }); } catch { /* noop */ }
    if (panelView.shadowRoot) {
      try { mo.observe(panelView.shadowRoot, { childList: true, subtree: true }); } catch { /* noop */ }
    }
    const initialOpts = this._findCardOptionsAncestor();
    if (initialOpts?.shadowRoot) {
      try { mo.observe(initialOpts.shadowRoot, { childList: true, subtree: true }); } catch { /* noop */ }
    }
    this._panelViewMo = mo;
    this._panelViewNode = panelView;
    this._watchEditBar();
  }

  /** docs/21 §5b third follow-up (2026-07-17, ported from room-overlay-card
   *  v5.0 + confirmed live, 2026-07-17, on the user's real dashboard): two
   *  separate races around the edit-mode actions bar, not one.
   *
   *  (1) `hui-card-options` itself can appear in the DOM BEFORE it has been
   *  upgraded to a custom element — its `shadowRoot` reads `null` for a beat
   *  even though the wrapper node already exists. Confirmed live: instrumented
   *  the real dashboard and captured `hui-card-options appeared, shadowRoot=
   *  false` at the moment of the reparenting mutation. `_setupPanelViewObserver`
   *  already re-checks on every mutation, but this dedicated one-shot watcher
   *  is what specifically waits for the shadow root (and then the bar inside
   *  it) to actually exist.
   *
   *  (2) Once `.card-actions` exists, HA animates its height in — it does NOT
   *  just appear at full size. Confirmed live: the bar's own settled height
   *  was 64.8px, but the grid only ever reserved 54px and stayed there
   *  indefinitely (no further remeasure was ever triggered, since nothing
   *  else on the card changed state) — a single remeasure right after the bar
   *  *appears* races the transition and can permanently under-reserve. Fixed
   *  by watching the bar's own box with a `ResizeObserver` once found: it
   *  fires on every frame of the height transition, so whichever remeasure
   *  runs last after the transition settles gets the real height — no fixed
   *  delay, no guessing at a transition duration. */
  private _watchEditBar(): void {
    if (this._barMo) { this._barMo.disconnect(); this._barMo = null; }
    const opts = this._findCardOptionsAncestor();
    if (!opts?.shadowRoot) return;
    const existing = opts.shadowRoot.querySelector(".card-actions") as HTMLElement | null;
    if (existing) { this._observeEditBar(existing); return; }
    const root = opts.shadowRoot;
    const mo = new MutationObserver(() => {
      const bar = root.querySelector(".card-actions") as HTMLElement | null;
      if (bar) {
        mo.disconnect();
        this._barMo = null;
        this._observeEditBar(bar);
      }
    });
    try { mo.observe(root, { childList: true, subtree: true }); } catch { return; }
    this._barMo = mo;
  }

  /** Remeasure now, and keep remeasuring on every box change of the actions
   *  bar itself until it's disconnected (edit-mode exit, or the card itself
   *  disconnects) — see `_watchEditBar`'s doc comment for why a one-shot
   *  measurement isn't enough. */
  private _observeEditBar(bar: HTMLElement): void {
    this._scheduleMeasure();
    if (typeof ResizeObserver === "undefined") return;
    if (this._editBarRo) { this._editBarRo.disconnect(); this._editBarRo = null; }
    const ro = new ResizeObserver(() => this._scheduleMeasure());
    try { ro.observe(bar); } catch { return; }
    this._editBarRo = ro;
  }

  /** Measured refinement of the grid height: innerHeight − rootTop beats the raw
   *  `calc(100svh − header)` when the root is offset (padding, safe-area). Applied
   *  directly to the element on top of `gridRootStyles()`'s declarative fallback
   *  (see that function's doc comment re: the 0.59.0 mobile-crash revert — this
   *  layered approach, not sole JS ownership, is the confirmed-stable one).
   *  2026-07-17: also reserves room for the edit-mode actions bar (`_editBarHeight`)
   *  so entering edit mode doesn't push it under/behind the pinned-height grid. */
  private _refineGridHeight(): void {
    const lay = this._config?.layout;
    if (!lay) return;
    const root = this.renderRoot?.querySelector<HTMLElement>(".avc-grid");
    if (!root) return;
    if ((lay.height ?? "viewport") === "viewport") {
      const top = root.getBoundingClientRect().top;
      if (top >= 0 && top < window.innerHeight) {
        const h = Math.round(window.innerHeight - top - this._editBarHeight());
        if (h > 120) root.style.height = h + "px";
      }
    }
    // Measure the map region for the exact rotated-map fit (docs/18 §7). Guarded
    // by a ±2 px threshold so the update→measure cycle settles instead of looping.
    const reg = this.renderRoot?.querySelector<HTMLElement>(".avc-region--map");
    if (reg) {
      const w = Math.round(reg.clientWidth);
      const h2 = Math.round(reg.clientHeight);
      if (w && Math.abs(w - this._mapRegW) >= 2) this._mapRegW = w;
      if (h2 && Math.abs(h2 - this._mapRegH) >= 2) this._mapRegH = h2;
    }
    // docs/25 §7c: measure the combined map+dock box (root minus the START
    // row) for the split-vs-stack topology decision — independent of which
    // topology is currently rendered, so it stays correct across the switch.
    if (this._profile === "portrait") {
      const startEl = this.renderRoot?.querySelector<HTMLElement>(".avc-region--start");
      const gapPx = parseFloat(getComputedStyle(root).rowGap || getComputedStyle(root).gap || "0") || 0;
      const startH = startEl ? Math.round(startEl.getBoundingClientRect().height) : 0;
      const aw = Math.round(root.clientWidth);
      const ah = Math.round(root.clientHeight - startH - (startH ? gapPx : 0));
      if (aw && Math.abs(aw - this._mapAvailW) >= 2) this._mapAvailW = aw;
      if (ah > 0 && Math.abs(ah - this._mapAvailH) >= 2) this._mapAvailH = ah;
    }
  }

  disconnectedCallback(): void {
    super.disconnectedCallback();
    this._cancelHold();
    if (this._measureRaf) { cancelAnimationFrame(this._measureRaf); this._measureRaf = 0; }
    if (this._measureTimer !== null) { clearTimeout(this._measureTimer); this._measureTimer = null; }
    if (this._settleTimer !== null) { clearTimeout(this._settleTimer); this._settleTimer = null; }
    if (this._tickTimer) { clearInterval(this._tickTimer); this._tickTimer = null; }
    if (this._onWinResize) {
      window.removeEventListener("resize", this._onWinResize);
      window.removeEventListener("orientationchange", this._onWinResize);
      this._onWinResize = null;
    }
    if (this._ro) { this._ro.disconnect(); this._ro = null; }
    // _panelViewWarned is intentionally NOT reset here — if the panel-view
    // ancestor lookup already failed once, a reconnect (HA can disconnect +
    // reconnect the card) shouldn't spam a second identical warning.
    if (this._panelViewMo) { this._panelViewMo.disconnect(); this._panelViewMo = null; }
    this._panelViewNode = null;
    if (this._barMo) { this._barMo.disconnect(); this._barMo = null; }
    if (this._editBarRo) { this._editBarRo.disconnect(); this._editBarRo = null; }
    // docs/41 §4.1: the portal lives on `document.body`, outside this
    // element's own DOM subtree — Lit/the browser will never garbage-collect
    // or detach it on their own just because the card itself disconnects
    // (HA can disconnect/reconnect a card, e.g. a dashboard tab switch).
    unmountAlignOverlay(this._alignHost);
    this._alignHost = null;
  }

  protected firstUpdated(): void {
    // Seed the width immediately; the ResizeObserver may not fire before the
    // first paint (and never fires if the host has no layout box yet).
    const w = Math.round(this.getBoundingClientRect().width);
    if (w) this._cardW = w;
    this._scheduleMeasure();
  }

  /** docs/41 §4.1/§4.3 — ALSO mounts/unmounts the Align-mode portal as
   *  `_alignSession` opens/closes, and (whenever the portal is mounted)
   *  Lit-`render()`s the overlay's template straight into its shadow root —
   *  folded into this method (rather than a second `updated()` override,
   *  which Lit/TS won't allow two of anyway) since it belongs in the same
   *  "runs after every render" spot as everything else here. This is the
   *  ONE place that template is ever rendered — the portal has no reactive
   *  lifecycle of its own ("portal je jen hostitel + styly"). Adopted
   *  stylesheets are read off the class once, at mount time — the card's
   *  OWN `static styles` (docs/14 rule 1: one stylesheet, not a forked copy
   *  for the portal). */
  protected updated(): void {
    if (this._alignSession && !this._alignHost) {
      const raw = (this.constructor as typeof AnyVacCard).elementStyles;
      const sheets: CSSStyleSheet[] = [];
      for (const r of raw) {
        const sheet = r instanceof CSSStyleSheet ? r : r.styleSheet;
        if (sheet) sheets.push(sheet);
      }
      this._alignHost = mountAlignOverlay(sheets, this);
    } else if (!this._alignSession && this._alignHost) {
      unmountAlignOverlay(this._alignHost);
      this._alignHost = null;
    }
    if (this._alignHost?.shadowRoot) {
      render(this._renderAlignOverlay(), this._alignHost.shadowRoot);
    }
    // docs/25 §10 field-caught (2026-07-25): clear a reset spinner as soon as
    // the watched sensor/button it's keyed on actually moves past the press
    // time — the 40s timeout in the reset click handler is only the hard
    // fallback for an offline vacuum whose poll never lands. Cheap (a
    // handful of entries at most) so it runs on every render unconditionally
    // rather than gating on `changed.has("hass")` — this override doesn't
    // currently take a `PropertyValues` param and adding one just for this
    // check isn't worth it.
    if (this._careResetPending.size) {
      let next: Map<string, number> | null = null;
      for (const [key, pressedAt] of this._careResetPending) {
        const st = this.hass?.states[key];
        const changedMs = st ? Date.parse(st.last_changed) : NaN;
        if (Number.isFinite(changedMs) && changedMs > pressedAt) {
          if (!next) next = new Map(this._careResetPending);
          next.delete(key);
        }
      }
      if (next) this._careResetPending = next;
    }
    // Grid mode: re-apply the measured height after every render (the declarative
    // svh calc stays as the pre-measure fallback).
    this._refineGridHeight();
    this._refineGridColumns();
    // docs/21 §5b: re-attempt the panel-view observer hookup on every render,
    // not just connectedCallback — HA can disconnect/reconnect the card, and
    // the ancestor may not have been in the tree yet on the very first
    // connectedCallback. docs/21 §5b third follow-up: no longer gated on
    // `!this._panelViewMo` — the call itself now re-verifies liveness (a
    // stale watched node needs the exact same re-hookup as never having
    // found one), so this must run every render, not just until first set.
    this._setupPanelViewObserver();
    // docs/21 §5b follow-up: one 250ms late-settling remeasure, see
    // `_settleTimer`'s doc comment. Cleared + rescheduled every render.
    if (this._settleTimer !== null) clearTimeout(this._settleTimer);
    this._settleTimer = window.setTimeout(() => {
      this._settleTimer = null;
      this._scheduleMeasure();
    }, 250);
  }

  /** Portrait only (docs/19 follow-up): the map is height-fit
   *  (`_renderResponsive`), which usually leaves it narrower than the fixed
   *  72% column — override the actual column split so `dock` picks up
   *  whatever `map` doesn't need, instead of that width sitting empty. A CSS
   *  "auto" track can't do this on its own: the fitted width lives on an
   *  absolutely-positioned inner div specifically so it doesn't feed back
   *  into layout, which also means it carries no intrinsic-size signal for
   *  track auto-sizing — so the split is measured and applied directly, same
   *  as `_refineGridHeight` does for the root height.
   *
   *  History (2026-07-16, all same day): tried capping `dock` to its own
   *  content width (first via live `width:max-content`, then via a detached
   *  clone measurement) because a flat `1fr` handed it every px the map's
   *  fit didn't need. Neither showed any visible effect in the field, which
   *  led to a theory that Lit's `styleMap` (which also lists
   *  `gridTemplateColumns` in `gridRootStyles()`) was re-applying the
   *  static declarative value over this function's override on every
   *  render — so `gridTemplateColumns`/`height` were pulled out of
   *  `gridRootStyles()` entirely to make this function+`_refineGridHeight`
   *  the sole owners. That "fix" (0.59.0) is what crashed the HA mobile
   *  companion app (user-confirmed bisection: 0.55.0–0.58.0 fine, 0.59.0
   *  first to crash) — reverted back to layering on top of the declarative
   *  value (see `gridRootStyles()`'s doc comment), and the dock-content-cap
   *  measurement is dropped too (parked, not reproduced as the crash cause
   *  but not worth the added DOM-clone risk while re-verifying). Net effect
   *  right now: same simple map-only fit as 0.56.0 (`mapW = rW`, `dock`
   *  stays `1fr`) — the sidebar-overshoot cosmetic issue is back, on
   *  purpose, in exchange for confirmed mobile stability. */
  /** 2026-07-16 addendum: dropped the idea of auto-shrinking `dock` to its
   *  own "natural" content width entirely — `.dock-row` uses `flex-wrap:
   *  wrap` in portrait (deliberately, so long room names/badges reflow
   *  instead of overflowing), which means it doesn't HAVE a fixed natural
   *  width the way non-wrapping content would: any max-content-style
   *  measurement returns the *unwrapped* single-line size, which is often
   *  wider than the space actually available, i.e. never smaller than
   *  what's already allocated — that's almost certainly why every earlier
   *  attempt measured "no room to spare" and left the split unchanged, not
   *  a bug in the measurement itself. There's no single objectively-right
   *  split to compute here; it's a visual trade-off. So: respect an
   *  explicit `layout.portrait.columns` in the user's own config as a
   *  manual override (skip the dynamic fit entirely, let the declarative
   *  value stand) — that's the fast, safe way to actually tune this to
   *  taste, instead of chasing an auto-computed number that doesn't really
   *  exist for wrapping content. */
  private _refineGridColumns(): void {
    if (this._profile !== "portrait" || !this._lastPortraitFitW) return;
    if (this._config.layout?.portrait?.columns?.length) return;
    // Stack topology has a single 100%-width column — no split to refine.
    if (this._stackTopology) return;
    const root = this.renderRoot?.querySelector<HTMLElement>(".avc-grid");
    if (!root) return;
    const total = root.clientWidth;
    const gapPx = parseFloat(getComputedStyle(root).columnGap || "0") || 0;
    const avail = total - gapPx;
    let mapW = Math.round(this._lastPortraitFitW);
    if (avail > 0) mapW = Math.min(mapW, avail);
    const want = Math.round(mapW) + "px 1fr";
    if (root.style.gridTemplateColumns !== want) root.style.gridTemplateColumns = want;
  }

  /**
   * Re-render only when a relevant entity changed — the hass object is
   * replaced on every state change anywhere in HA.
   */
  protected shouldUpdate(changed: PropertyValues): boolean {
    // docs/41 §4.6: must run before `_watchedEntities()`/`_roomsFor()` below
    // (and on every path through this method, including the early-return
    // ones) — those already run INSIDE `shouldUpdate`, before `willUpdate`
    // ever would, per `_memoSync`'s own doc comment; `_config` has to carry
    // any backend floorplan_seats override by the time they read it, or a
    // probe-only pass (no full render) would see stale room/seat geometry.
    this._syncEffectiveConfig();
    if (!changed.has("hass") || changed.size > 1) return true;
    const old = changed.get("hass") as HomeAssistant | undefined;
    if (!old || !this._config) return true;
    for (const id of this._watchedEntities()) {
      if (old.states[id] !== this.hass.states[id]) return true;
    }
    return false;
  }

  /** docs/41 §4.6 — applies the backend's per-floorplan Align-mode overrides
   *  on top of `_rawConfig` (precedence: override > config manual > auto).
   *  Pulled from whichever vacuum's integration sensor happens to carry it
   *  first — `floorplan_seats` is coordinator-scoped/shared, so every
   *  vacuum on the same coordinator publishes the identical dict (docs/41
   *  §4.6, same precedent as `view_layers`/`room_pins`). Re-run on every
   *  hass update (cheap: `applyFloorplanSeats` is a pure function that
   *  returns the SAME object when nothing applies) but only actually swaps
   *  `_config` — and clears the memos that are keyed on its identity — when
   *  the merged JSON genuinely differs, so an unrelated hass update (no
   *  floorplan_seats change at all) never forces every `_config`-keyed memo
   *  to be seen as invalidated by callers comparing by reference. */
  private _syncEffectiveConfig(): void {
    // `hass` can still be unset the very first time this runs (setConfig()
    // alone already triggers an update cycle, possibly before HA has handed
    // the card its first `hass`) — every reader below assumes it exists.
    if (!this._rawConfig || !this.hass) return;
    let seats: FloorplanSeats | undefined;
    for (const vac of this._rawConfig.vacuums) {
      const at = this._intAttrs(vac);
      const fs = at?.floorplan_seats as FloorplanSeats | undefined;
      if (fs) { seats = fs; break; }
    }
    // `applyFloorplanSeats` is typed against `seatedit.ts`'s dependency-free
    // structural shapes (SeatEditConfigLike/SeatEditVacuumLike, deliberately
    // NOT importing the real card types — see that module's own doc
    // comment), which carry an open index signature the real, closed
    // `AnyVacCardConfig`/`ImageBaseConfig` interfaces don't — structurally
    // compatible at runtime (every field it actually reads exists), not
    // nominally, hence the cast through `unknown` here rather than loosening
    // the shared module's own types.
    const next = applyFloorplanSeats(this._rawConfig as unknown as SeatEditConfigLike, seats) as unknown as AnyVacCardConfig;
    if (next === this._config) return;
    if (JSON.stringify(next) === JSON.stringify(this._config)) return;
    this._config = next;
    this._roomsMemo.clear();
    this._seatMemo.clear();
  }

  private _watchedEntities(): Set<string> {
    // Before the early return, not after: `_registry()` is what drops `_watched`
    // when the entity registry changes, and every other caller of it sits behind
    // this cache — so without this line a registry change (integration reload,
    // a vacuum gaining its AnyVac sensor) would not reach the watched set until
    // some unrelated render happened to run first.
    this._registry();
    if (this._watched) return this._watched;
    const s = new Set<string>();
    for (const vac of this._config?.vacuums ?? []) {
      for (const id of [vac.entity, vac.status_entity, vac.battery_entity,
        vac.last_clean_entity, vac.progress_entity, vac.current_room_entity,
        vac.error_entity, this._mapEntityFor(vac), this._intEntity(vac),
        ...Object.values(this._autoEntities(vac))]) {
        if (id) s.add(id);
      }
      for (const r of this._roomsFor(vac)) {
        if (r.last_clean_entity) s.add(r.last_clean_entity);
        if (r.clean_time_entity) s.add(r.clean_time_entity);
      }
      // docs/25 §10 field-caught (2026-07-25): the dock sheet's care rows
      // (`_careItems`) are auto-discovered from the official `roborock`
      // integration's OWN entities and were never added here — pressing a
      // reset button DID work (live-verified: the underlying sensor updates
      // within one ~30s roborock poll cycle) but the card only re-renders on
      // a watched-entity change (`shouldUpdate` above), so the refreshed %
      // silently sat in `hass.states` until some UNRELATED watched entity
      // (battery tick, status change, ...) happened to trigger a render —
      // which read as "reset doesn't work". Care items aren't computed yet
      // this early in some code paths (entity registry may still be
      // loading), so this reads `_careItems` defensively — it already
      // no-ops safely without a loaded registry.
      for (const row of this._careItems(vac)) {
        if (row.entity) s.add(row.entity);
        if (row.reset) s.add(row.reset);
        if (row.binary) s.add(row.binary);
      }
    }
    for (const ga of this._config?.global_actions ?? []) {
      for (const e of ga.watch_entities ?? []) if (e) s.add(e);
    }
    // Don't freeze the list before the entity registry is loaded — the auto-resolved
    // sibling sensors (status/battery/room/error) would otherwise never be watched.
    if ((this.hass as any)?.entities) this._watched = s;
    return s;
  }

  // ── Helpers ─────────────────────────────────────────────────────────────

  /** Resolves a VacuumColor (or GlobalAction colour) to a CSS colour string.
   *  The three legacy preset names go through COLOR_HEX unchanged; anything
   *  else (a custom hex the user picked) passes straight through. */
  private _resolveColor(raw: string | undefined, fallback: string): string {
    const c = raw ?? fallback;
    return COLOR_HEX[c] ?? c;
  }

  /** Resolves the translucent background wash for a colour. Legacy presets
   *  keep their exact, independently-tuned COLOR_BG/COLOR_BG_ACTIVE values
   *  (unchanged look for existing configs); a custom hex is tinted on the
   *  fly via hexToRgba so any colour gets a matching wash. */
  private _resolveBg(raw: string | undefined, fallback: string, active: boolean): string {
    const c = raw ?? fallback;
    const table = active ? COLOR_BG_ACTIVE : COLOR_BG;
    return table[c] ?? hexToRgba(this._resolveColor(raw, fallback), active ? 0.3 : 0.18);
  }

  /** Position of `vac` within the configured vacuums array, used to pick its
   *  default palette colour when `color` isn't explicitly set. Matched by
   *  entity id rather than object identity, since that's the only stable key
   *  across any future re-derivation of the vacuum list. */
  private _vacIndex(vac: VacuumConfig): number {
    const i = this._config?.vacuums?.findIndex((v) => v.entity === vac.entity) ?? -1;
    return i < 0 ? 0 : i;
  }

  /** Default accent colour for a vacuum with no explicit `color` — cycles
   *  through DEFAULT_VACUUM_PALETTE by array position, so every vacuum in a
   *  fresh multi-vacuum config is visually distinct instead of all defaulting
   *  to the same green (field report 2026-07-31). */
  private _defaultColor(vac: VacuumConfig): string {
    return DEFAULT_VACUUM_PALETTE[this._vacIndex(vac) % DEFAULT_VACUUM_PALETTE.length];
  }

  private _color(vac: VacuumConfig): string {
    return this._resolveColor(vac.color, this._defaultColor(vac));
  }

  private _colorBg(vac: VacuumConfig): string {
    return this._resolveBg(vac.color, this._defaultColor(vac), false);
  }

  private _colorBgActive(vac: VacuumConfig): string {
    return this._resolveBg(vac.color, this._defaultColor(vac), true);
  }

  /** Single access point for the entity registry, which every auto-resolver below
   *  derives its cached answer from — and the one place those caches are dropped.
   *
   *  HA replaces `hass.entities` only when the entity registry actually changes
   *  (it is not rebuilt on ordinary state updates, unlike `hass` itself), so a
   *  reference comparison is a precise, cheap invalidation signal: it fires on an
   *  integration load/reload/rename and essentially never otherwise. Before this,
   *  `_intCache`/`_mapCandCache`/`_autoCache`/`_careCache` were populated once and
   *  never cleared — not even in `setConfig()` — so anything resolved while the
   *  registry was still filling in (e.g. reloading the anyvac integration with the
   *  dashboard open) stayed wrong until a full page reload. Worst case, if some HA
   *  version did replace the object more eagerly, the cost is a registry rescan
   *  per render — which is what `editor.ts` already does unconditionally today. */
  private _regRef: unknown;
  private _registry(): Record<string, any> | undefined {
    const reg = (this.hass as any)?.entities as Record<string, any> | undefined;
    if (reg !== this._regRef) {
      this._regRef = reg;
      this._intCache.clear();
      this._mapCandCache.clear();
      this._autoCache.clear();
      this._careCache.clear();
      this._watched = null;
    }
    return reg;
  }

  /** Integration sensor for a vacuum: explicit config, else auto-resolved from the
   *  entity registry — the AnyVac map sensor sits on the SAME device as the vacuum
   *  entity (platform "anyvac"), so no manual plumbing is needed (docs/14 Fáze 3). */
  private _intCache = new Map<string, string | undefined>();
  private _intEntity(vac: VacuumConfig): string | undefined {
    if (vac.integration_entity) return vac.integration_entity;
    const reg = this._registry();
    if (!reg || !vac.entity) return undefined;
    if (this._intCache.has(vac.entity)) return this._intCache.get(vac.entity);
    const dev = reg[vac.entity]?.device_id;
    const found = dev
      ? Object.keys(reg).find(
          (id) => reg[id]?.device_id === dev && reg[id]?.platform === "anyvac" && id.startsWith("sensor.")
        )
      : undefined;
    this._intCache.set(vac.entity, found);
    return found;
  }

  /** The vacuum's rendered-map `image.*` entity: explicit config, else auto-resolved
   *  from the entity registry (2026-07-30 onboarding audit, docs/30 §2.1) — this was
   *  previously the one config field with no auto-resolve at all, unlike
   *  `integration_entity`/`_autoEntities` above, so a fresh install showed no map
   *  whatsoever until the user hunted down the right entity by hand.
   *  No `translation_key` to match on here (live-verified: the official `roborock`
   *  integration's map image entities carry none — confirmed empty on a real
   *  registry, 2026-07-30) and a multi-map vacuum can have ONE image entity PER
   *  SAVED FLOOR (e.g. `image.kitchen_map_0` / `image.kitchen_map_2`), so picking
   *  "the only image.* on this device" isn't safe in general. Instead: prefer
   *  whichever candidate is actually live (state isn't unavailable/unknown AND has
   *  `entity_picture` — the same liveness signal `_mapUrl` already reads) since the
   *  Roborock integration only backs the CURRENTLY selected map's image entity with
   *  a live state; the rest sit at "unavailable" (live-verified: a 2-map vacuum's
   *  inactive map entity has no `entity_picture` attribute at all). Falls back to
   *  "the only candidate, whatever its state" when there's exactly one — covers a
   *  freshly added vacuum whose first poll hasn't landed yet. Ambiguous cases (0 or
   *  2+ simultaneously-live candidates) fall through to undefined — same as today,
   *  the user picks manually. */
  /** Only the REGISTRY-derived half is cached (2026-08-08 fix): the candidate
   *  list per vacuum is stable and expensive (a scan of every entity), while
   *  liveness is volatile and cheap (a couple of state lookups), so they must
   *  not share a cache entry. Caching the finished answer meant a vacuum with
   *  2+ saved maps — exactly the S6 case this resolver was written for — that
   *  was first asked before the Roborock integration's first poll saw
   *  `live.length === 0`, fell through to `undefined`, and cached THAT
   *  permanently: no map at all until the page was reloaded. */
  private _mapCandCache = new Map<string, string[]>();
  private _mapEntityFor(vac: VacuumConfig): string | undefined {
    if (vac.map?.entity) return vac.map.entity;
    const reg = this._registry();
    if (!reg || !vac.entity) return undefined;
    let candidates = this._mapCandCache.get(vac.entity);
    if (!candidates) {
      const dev = reg[vac.entity]?.device_id;
      if (!dev) return undefined;  // registry not ready for this vacuum yet — don't cache
      candidates = Object.keys(reg).filter(
        (id) => reg[id]?.device_id === dev && id.startsWith("image.")
      );
      this._mapCandCache.set(vac.entity, candidates);
    }
    if (candidates.length === 1) return candidates[0];  // unambiguous, liveness irrelevant
    const live = candidates.filter((id) => {
      const st = this.hass.states[id];
      return !!st && st.state !== "unavailable" && st.state !== "unknown" && !!st.attributes["entity_picture"];
    });
    return live.length === 1 ? live[0] : undefined;
  }

  /** Kontrakt v2 gate: attributes of the vacuum's integration sensor, only when the
   *  integration speaks schema_version ≥ 2. Older backends → smart features off. */
  private _intAttrs(vac: VacuumConfig): Record<string, any> | undefined {
    const ent = this._intEntity(vac);
    const at = ent ? (this.hass.states[ent]?.attributes as Record<string, any> | undefined) : undefined;
    if (!at) return undefined;
    return (at.schema_version ?? 0) >= 2 ? at : undefined;
  }

  /** Human-readable warning when an integration sensor exists but speaks an old schema. */
  private _schemaWarning(): string | null {
    for (const v of this._config?.vacuums ?? []) {
      const ent = this._intEntity(v);
      const at = ent ? (this.hass.states[ent]?.attributes as Record<string, any> | undefined) : undefined;
      if (at && (at.schema_version ?? 0) < 2) {
        return `AnyVac integration is too old for this card (schema ${at.schema_version ?? 1} < 2). ` +
          "Update the anyvac integration to ≥ 0.18.0.";
      }
    }
    return null;
  }

  private _autoCache = new Map<string, Record<string, string | undefined>>();
  /** Resolve a vacuum's sibling entities (battery/status/last-clean/progress/room/error) from its
   *  device, so the user does not have to fill them in. Matched by translation_key / device_class. */
  private _autoEntities(vac: VacuumConfig): Record<string, string | undefined> {
    const reg = this._registry();
    if (!reg || !vac.entity) return {};
    const cached = this._autoCache.get(vac.entity);
    if (cached) return cached;
    const dev = reg[vac.entity]?.device_id;
    if (!dev) return {};
    const sibs = Object.keys(reg).filter((id) => reg[id]?.device_id === dev);
    const byTk = (tk: string) => sibs.find((id) => reg[id]?.translation_key === tk);
    const byDc = (dc: string) => sibs.find((id) => this.hass.states[id]?.attributes?.device_class === dc);
    const out: Record<string, string | undefined> = {
      status: byTk("status"),
      battery: byDc("battery"),
      last_clean: byTk("last_clean_end"),
      progress: byTk("clean_percent"),
      current_room: byTk("current_room"),
      error: byTk("vacuum_error"),
    };
    this._autoCache.set(vac.entity, out);
    return out;
  }
  private _ent(vac: VacuumConfig, kind: "status" | "battery" | "last_clean" | "progress" | "current_room" | "error"): string | undefined {
    const explicit = (vac as any)[kind + "_entity"] as string | undefined;
    return explicit ?? this._autoEntities(vac)[kind];
  }

  private _statusInfo(vac: VacuumConfig): readonly [string, string] {
    const raw = this.hass.states[this._ent(vac, "status") ?? vac.entity]?.state ?? "unknown";
    return STATUS_MAP[raw] ?? [raw, "rgba(var(--avc-ink-rgb),0.5)"];
  }

  /** docs/25 §10 follow-up (2026-07-24): consumable/"care" rows auto-discovered from
   *  the official `roborock` integration's OWN entities — zero new config keys, zero
   *  new backend code, same spirit as `_intEntity`/`_autoEntities` above. Two device
   *  scopes are involved: the vacuum's own device carries brush/filter/sensor
   *  consumables; dock-mounted consumables (cleaning brush, strainer) and the S7/S8
   *  water-tank binary sensors live on a SEPARATE `"<name> Dock"` HA device. That
   *  second device is found not by name-matching (fragile, user-renamable) but via
   *  its `identifiers` — live-verified on the user's HA (2026-07-24): the dock
   *  device's `roborock` identifier is always the vacuum's own duid with `_dock`
   *  appended (e.g. vacuum id `7bUI4dOp7O1qnECi7UfFW3` → dock id
   *  `7bUI4dOp7O1qnECi7UfFW3_dock`), which is a backend-assigned id, not a slug.
   *  Rows are matched by `translation_key` (not entity_id substring) — the same
   *  robust-to-renaming approach `_autoEntities` already uses, and confirmed stable
   *  across S6/S7 MaxV/S8 MaxV Ultra live registries. A vacuum/dock lacking a given
   *  entity (e.g. S6 has no dock device at all; S7's dock lacks reset buttons for its
   *  own consumables) simply omits that row — no guessing, no placeholders. */
  /** Cache key is `entity|tier`, not just the entity (2026-08-08 fix): the row
   *  set BRANCHES on `_dockCaps(vac)` below, which reads live dock capability
   *  off the integration sensor — live state, not registry data. Before the
   *  first AnyVac poll lands, the tier reads "none", so the dock-mounted rows
   *  (dock brush, strainer, tank sensors) were skipped and that incomplete list
   *  was cached forever: those rows only ever appeared if a page reload happened
   *  to land after a poll. Keying on the tier makes a tier change compute a
   *  fresh list instead, while still caching every distinct answer exactly once. */
  private _careCache = new Map<string, CareRow[]>();
  private _careItems(vac: VacuumConfig): CareRow[] {
    const reg = this._registry();
    const devs = (this.hass as any)?.devices as Record<string, any> | undefined;
    if (!reg || !devs || !vac.entity) return [];
    const caps = this._dockCaps(vac);
    const cacheKey = vac.entity + "|" + this._dockCapsKey(vac);
    if (this._careCache.has(cacheKey)) return this._careCache.get(cacheKey)!;

    const devId = reg[vac.entity]?.device_id as string | undefined;
    const vacDevice = devId ? devs[devId] : undefined;
    const duid = (vacDevice?.identifiers as [string, string][] | undefined)?.find(
      ([domain]) => domain === "roborock"
    )?.[1];
    const dockDevice = duid
      ? Object.values(devs).find((d: any) =>
          (d.identifiers as [string, string][] | undefined)?.some(
            ([domain, id]) => domain === "roborock" && id === `${duid}_dock`
          )
        )
      : undefined;
    const dockDevId = (dockDevice as any)?.id as string | undefined;

    const byTk = (deviceId: string | undefined, tk: string, domain: string) =>
      deviceId
        ? Object.keys(reg).find(
            (id) => reg[id]?.device_id === deviceId && reg[id]?.translation_key === tk && id.startsWith(domain + ".")
          )
        : undefined;

    const rows: CareRow[] = [];
    const consumable = (label: string, tk: string, resetTk: string, deviceId: string | undefined) => {
      const entity = byTk(deviceId, tk, "sensor");
      const reset = byTk(deviceId, resetTk, "button");
      if (entity || reset) rows.push({ key: tk, label, entity, reset, totalHours: CARE_TOTAL_HOURS[tk] });
    };
    consumable("Main brush", "main_brush_time_left", "reset_main_brush_consumable", devId);
    consumable("Side brush", "side_brush_time_left", "reset_side_brush_consumable", devId);
    consumable("Filter", "filter_time_left", "reset_air_filter_consumable", devId);
    consumable("Sensors", "sensor_time_left", "reset_sensor_consumable", devId);
    // Dock-mounted consumables/tank status only apply to a wash-capable dock —
    // an empty-only dock's entities can still exist in HA's registry (created
    // per device model, not per physically-installed accessory) but always
    // report "unavailable"; gate on capability instead of just checking entity
    // presence (docs/25 §10 3rd follow-up, live-confirmed on the field-reporting
    // user's S7 MaxV). Since 2026-09-02 that gate is the dock's own
    // `is_washable` flag where the backend reports it, with the old dock_type
    // tier as fallback — see `_dockCaps`.
    if (caps.wash) {
      consumable("Dock brush", "cleaning_brush_time_left", "reset_dock_cleaning_brush_consumable", dockDevId);
      consumable("Strainer", "strainer_time_left", "reset_dock_strainer_consumable", dockDevId);

      const binary = (label: string, tk: string) => {
        const entity = byTk(dockDevId, tk, "binary_sensor");
        if (entity) rows.push({ key: tk, label, binary: entity });
      };
      binary("Dirty water tank", "dirty_box_full");
      binary("Clean water tank", "clean_box_empty");
      binary("Cleaning fluid", "clean_fluid_empty");
    }

    this._careCache.set(cacheKey, rows);
    return rows;
  }

  /** Formats a consumable row: a % of nominal lifespan when the total is known
   *  (`CARE_TOTAL_HOURS`), else a plain hour figure — always normalized to
   *  hours regardless of the sensor's own unit (HA's `roborock` integration
   *  reports some consumables in seconds and others already in hours for no
   *  documented reason; live-confirmed inconsistent across S6 (`s`) vs S7/S8
   *  (`h`) on the field-reporting user's own entities). Falls back to a dash
   *  when the entity is unavailable/unknown. */
  private _careValue(row: CareRow): string {
    if (!row.entity) return "—";
    const st = this.hass.states[row.entity];
    if (!st || st.state === "unavailable" || st.state === "unknown") return "—";
    const raw = Number(st.state);
    if (Number.isNaN(raw)) return st.state;
    const unit = st.attributes?.unit_of_measurement;
    const hours = unit === "s" ? raw / 3600 : unit === "min" ? raw / 60 : raw;
    if (row.totalHours) {
      const pct = Math.max(0, Math.min(100, Math.round((hours / row.totalHours) * 100)));
      return `${pct} %`;
    }
    return `${Math.round(hours)} h`;
  }

  private _isCleaning(vac: VacuumConfig): boolean {
    return CLEANING_STATES.has(this.hass.states[vac.entity]?.state ?? "");
  }

  /** True when the vacuum's error entity/attribute reports an active error
   *  (shared by the status card error row and the map robot-error halo). */
  private _hasError(vac: VacuumConfig): boolean {
    const erid = this._ent(vac, "error");
    const errState = erid ? this.hass.states[erid]?.state : null;
    return !!errState && errState !== "none" && errState !== "unknown" && errState !== "unavailable";
  }

  private _isPaused(vac: VacuumConfig): boolean {
    return this.hass.states[vac.entity]?.state === "paused";
  }

  private _battery(vac: VacuumConfig): number | null {
    const bid = this._ent(vac, "battery");
    if (!bid) return null;
    const n = parseInt(this.hass.states[bid]?.state ?? "");
    return isNaN(n) ? null : n;
  }

  private _lastCleanStr(vac: VacuumConfig): string {
    const lid = this._ent(vac, "last_clean");
    const raw = lid ? this.hass.states[lid]?.state : undefined;
    if (!raw || raw === "unavailable" || raw === "unknown") return "—";
    const d = new Date(raw);
    const diff = Math.floor((Date.now() - d.getTime()) / 86_400_000);
    const t = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (diff === 0) return "Today · " + t;
    if (diff === 1) return "Yesterday · " + t;
    return d.toLocaleDateString([], { day: "2-digit", month: "2-digit" }) + " · " + t;
  }

  private _progress(vac: VacuumConfig): number | null {
    const pid = this._ent(vac, "progress");
    if (!pid) return null;
    const n = parseInt(this.hass.states[pid]?.state ?? "");
    return isNaN(n) || n === 0 ? null : n;
  }

  /** First integration sensor that exposes the shared (backend) selection. */
  private _selSensor(): string | undefined {
    for (const v of this._config.vacuums) {
      const ent = this._intEntity(v);
      if (ent && Array.isArray(this.hass.states[ent]?.attributes?.selected_rooms)) return ent;
    }
    return undefined;
  }
  /** Shared room selection (card-level, by room key) from the backend, or null when
   *  no integration is available (then the card falls back to local state). */
  private _backendSel(): Set<string> | null {
    const ent = this._selSensor();
    if (!ent) return null;
    return new Set((this.hass.states[ent]?.attributes?.selected_rooms as string[]) ?? []);
  }
  private _setBackendSel(rooms: string[], mode: "set" | "toggle" | "clear"): void {
    this._call("anyvac", "select_rooms", { rooms, mode });
  }

  private _isRoomSelected(room: RoomConfig, vac: VacuumConfig): boolean {
    const be = this._backendSel();
    if (be) return be.has(room.key);
    return this._localRoomSel.get(vac.entity + ":" + room.key) ?? false;
  }

  /** Effective dry/wet layer visibility: the backend-shared state when the integration
   *  provides it (persists refreshes + syncs across devices, like the room selection),
   *  else the local component state. */
  private _layersEff(): { dry: boolean; wet: boolean } {
    const ent = this._selSensor();
    const vl = ent ? (this.hass.states[ent]?.attributes?.view_layers as any) : undefined;
    if (vl && typeof vl.dry === "boolean" && typeof vl.wet === "boolean") {
      return { dry: vl.dry, wet: vl.wet };
    }
    return this._layers;
  }

  /** Static (config-authored) rooms for a vacuum: card-level `rooms` if defined
   *  (merged config), else the vacuum's own. Never touches the integration —
   *  also the anchor source for auto-seating (see `_effectiveSeat`). Shared with
   *  the editor via `seatfit.ts` since 1.1.0 so the two can't drift. */
  private _staticRoomsFor(vac: VacuumConfig): RoomConfig[] {
    return resolveStaticRooms(this._config, vac) as RoomConfig[];
  }

  /** Per-render memo for `_roomsFor`/`_effectiveSeat` (1.1.0).
   *
   *  A single render of a three-vacuum, ten-room merged card calls `_roomsFor()`
   *  around 90 times (`_allRoomKeys()` twice in each of four regions, plus
   *  `_pinCandidates()` per room per pass), each rebuilding the seat fit and a
   *  fresh array of room objects. Measured, that's only ~0.19 ms on a desktop
   *  and ~1 ms on a phone — this is NOT a hot spot and is not being sold as a
   *  performance fix. What it does buy: ~900 fewer object allocations per render
   *  (GC pressure matters with the 1 s debug tick running), and one consistent
   *  answer per render instead of 90 independent recomputations that could in
   *  principle disagree if `hass` changed underneath them.
   *
   *  Keyed on `hass` OBJECT IDENTITY rather than cleared from a lifecycle hook.
   *  HA replaces `hass` wholesale on every state change, so this drops the memo
   *  exactly when its inputs could have changed — and, unlike clearing in
   *  `willUpdate()`, it stays correct on the paths where no render happens at
   *  all: `shouldUpdate()` calls `_watchedEntities()` -> `_roomsFor()` BEFORE
   *  `willUpdate()` would run, and doesn't run it at all when it returns false.
   *  `setConfig()` clears both maps too, for the config half of the inputs.
   *
   *  ALSO keyed on `_mapAR`: both `_effectiveSeat` and (docs/40 §5.B)
   *  `_computeRoomsFor`'s anchor-fit branch resolve `ar` via `_wrapAspect`,
   *  which falls back to `_mapAR` whenever no `base_height` is configured —
   *  and `_mapAR` only learns the floorplan's real aspect asynchronously,
   *  off the base image's own `load` event (`_onFloorplanLoad`), completely
   *  independently of `hass` changing. Without this, a room placed before
   *  that `load` fires would cache its geometry at the fallback 3.636 ratio
   *  and never recompute — masked in real HA usage only because `hass` is
   *  typically replaced again within a poll or two, self-correcting the
   *  memo as an accidental side effect rather than a real fix (caught via
   *  `tests/home-anchor-render.spec.ts`, whose single static `hass` never
   *  changes again after mount). */
  private _memoHass: unknown;
  private _memoMapAR = 0;
  private _roomsMemo = new Map<string, RoomConfig[]>();
  private _seatMemo = new Map<string, ReturnType<typeof resolveSeat>>();
  /** docs/40 §4.4 (Fáze 3) — per-vacuum home-frame identity crop, memoized the
   *  same way as `_seatMemo` (`null` is a valid cached "not home-frame right
   *  now" result, so the map's own `.has()` — not a falsy check — gates the
   *  cache hit; see `_homeFrameCropFor`). */
  private _homeFrameMemo = new Map<string, CropBox | null>();
  private _memoSync(): void {
    if (this.hass !== this._memoHass || this._mapAR !== this._memoMapAR) {
      this._memoHass = this.hass;
      this._memoMapAR = this._mapAR;
      this._roomsMemo.clear();
      this._seatMemo.clear();
      this._homeFrameMemo.clear();
    }
  }

  /** Rooms z integrace (docs/20, RATIFIKOVÁNO 2026-07-22): live-merged view for
   *  RENDERING — a room the integration reports this poll gets its geometry
   *  computed on the fly from `bbox_px` at the vacuum's current effective seat
   *  (`roomBboxToRect`, same maths the one-shot Import already used, just called
   *  every render instead of once) UNLESS a matching static config room pins an
   *  explicit `map_x`/`map_y` — that override always wins outright (and doubles
   *  as an auto-seating anchor, see `_effectiveSeat`). Icon/name/threshold fields
   *  from a matching static room are layered on top either way. A config room
   *  with no live counterpart this poll (custom room, or the integration briefly
   *  missing data) still renders as configured — never silently dropped. Falls
   *  back to the plain static list whenever there's no usable integration data
   *  or no floorplan seat yet (degraded mode, schema < 2, fresh install). */
  private _roomsFor(vac: VacuumConfig): RoomConfig[] {
    this._memoSync();
    const memo = this._roomsMemo.get(vac.entity);
    if (memo) return memo;
    const out = this._computeRoomsFor(vac);
    this._roomsMemo.set(vac.entity, out);
    return out;
  }
  private _computeRoomsFor(vac: VacuumConfig): RoomConfig[] {
    const at = this._intAttrs(vac);
    const intRooms: Array<Record<string, any>> = Array.isArray(at?.rooms) ? at!.rooms : [];
    if (!at || !intRooms.length) return this._staticRoomsFor(vac);
    // docs/40 §4.4 (Fáze 3): a home-frame-registered vacuum places rooms from
    // the shared bbox_home_px/outline_home_px through its own identity crop
    // (placeRoomInCrop/outlineInCrop — the exact same crop-normalise maths the
    // one-shot "place rooms from crop box" import already uses, docs/14 rule 1
    // — no fit/rotation) instead of roomBboxToRect's per-vacuum bbox_px + seat.
    const crop = this._homeFrameCropFor(vac);
    const ar = this._wrapAspect(this._baseHeightFor(vac));
    const anchorFit = crop ? null : this._homeAnchorFitFor(vac, ar);
    const seat = crop || anchorFit ? null : this._effectiveSeat(vac);
    const staticRooms = this._staticRoomsFor(vac);
    const byKey = new Map(staticRooms.filter((r) => r.key).map((r) => [r.key, r]));
    const seen = new Set<string>();
    const out: RoomConfig[] = [];
    for (const ir of intRooms) {
      const nm = ir?.name as string | undefined;
      if (!nm) continue;
      seen.add(nm);
      const cfg = byKey.get(nm);
      if (cfg && cfg.map_x != null && cfg.map_y != null) { out.push(cfg); continue; } // explicit override/anchor wins
      // docs/40 §5.B: reuses `roomBboxToRect` UNCHANGED for a cesta-B room too
      // (docs/14 rule 1) — its bbox-centre-projection maths is exactly what
      // "place a home-px bbox through a solved fit" needs; only the inputs it
      // normally reads off `ir`/`at` are reshaped to source home_px/frame dims
      // instead of a vacuum's own bbox_px/image_dims.
      const rect = crop
        ? (ir?.bbox_home_px ? placeRoomInCrop(ir.bbox_home_px, crop) : null)
        : anchorFit
          ? (ir?.bbox_home_px
              ? roomBboxToRect(
                  { bbox_px: ir.bbox_home_px },
                  { image_dims: { width: anchorFit.dims.NW, height: anchorFit.dims.NH, scale: 1, rotation: 0 } },
                  anchorFit.fit, ar,
                )
              : null)
          : roomBboxToRect(ir, at, seat!, ar);
      if (!rect) { if (cfg) out.push(cfg); continue; } // no seat/frame yet -> whatever static has, if anything
      // Additive only (types.ts `RoomConfig.outline_pct` doc) — the rectangle
      // above stays the click/select hit-target and icon anchor either way;
      // an outline just draws the room's real traced shape on top of it.
      const outline = crop
        ? outlineInCrop(ir?.outline_home_px, crop)
        : anchorFit
          ? outlineThroughFit(ir?.outline_home_px, anchorFit.dims, anchorFit.fit, ar)
          : null;
      out.push({ ...(cfg ?? { key: nm, name: nm, icon: "mdi:floor-plan" }), ...rect, outline_pct: outline ?? undefined });
    }
    for (const cfg of staticRooms) if (cfg.key && !seen.has(cfg.key)) out.push(cfg);
    return out;
  }
  private _hasSelectedRooms(vac: VacuumConfig): boolean {
    return (this._roomsFor(vac)).some((r) => this._isRoomSelected(r, vac));
  }

  /** Resolve a vacuum to a single current clean type ("dry"/"wet").
   *  Prefers the live backend signal (integration sensor `clean_type`, which
   *  follows the actual water mode), then the configured clean_action. This is
   *  what makes a dual-capable vacuum (clean_type: both) pick the right estimate. */
  private _liveCleanType(vac: VacuumConfig): "dry" | "wet" {
    // 1) When the vacuum has selectable presets, the active one is the user's
    //    current intent — derive its mode from its values (so picking "Mokrý"
    //    flips the estimate to wet immediately, before the clean even starts).
    if ((vac.presets?.length ?? 0) >= 2) {
      const ap = this._activePreset(vac);
      const wet = (ap.mop_intensity != null && ap.mop_intensity !== "" && ap.mop_intensity !== "off")
        || (ap.mop_mode != null && ap.mop_mode !== "");
      return wet ? "wet" : "dry";
    }
    // 2) Live backend signal (follows the actual water mode).
    const ct = this._intAttrs(vac)?.clean_type as string | undefined;
    if (ct === "wet" || ct === "dry") return ct;
    // 3) Fallback: the vacuum's configured role (wet-only robots default to wet).
    const role = this._vacCleanType(vac);
    return role.wet && !role.dry ? "wet" : "dry";
  }

  /** Self-calibrated clean-time estimate learned by the backend integration,
   *  per room name + type (dry/wet). Null when no integration / no learned value. */
  private _backendEstimate(vac: VacuumConfig, room: RoomConfig, kind: "dry" | "wet"): number | null {
    const re = this._intAttrs(vac)?.rooms_estimate as Record<string, any> | undefined;
    if (!re) return null;
    const rec = re[room.name ?? ""] ?? re[room.key];
    const v = rec ? rec[kind] : undefined;
    return (typeof v === "number" && v > 0) ? v : null;
  }

  private _roomCleanMins(room: RoomConfig, vac: VacuumConfig): number {
    const ct = this._vacCleanType(vac);
    // Dual-capable vacuum (both dry+wet) must resolve to the CURRENT live mode,
    // otherwise a dry run falls back to the wet estimate (and vice versa).
    const useWet = (ct.wet && !ct.dry) ? true
                 : (ct.dry && !ct.wet) ? false
                 : (this._liveCleanType(vac) === "wet");
    // 1) Backend self-calibrated estimate (learned from real single-room cleans).
    const learned = this._backendEstimate(vac, room, useWet ? "wet" : "dry");
    if (learned != null) return learned;
    // 2) Static config for the matching type, then the other type as a last resort.
    const primary = useWet ? room.clean_time_wet : room.clean_time_dry;
    if (primary != null && primary > 0) return primary;
    const alt = useWet ? room.clean_time_dry : room.clean_time_wet;
    if (alt != null && alt > 0) return alt;
    if (room.clean_time_entity) {
      const val = parseFloat(this.hass.states[room.clean_time_entity]?.state ?? "");
      if (!isNaN(val) && val > 0) return val;
    }
    return room.clean_time_mins ?? 0;
  }

  private _totalCleanMins(vac: VacuumConfig): number {
    return (this._roomsFor(vac)).reduce((sum, r) => {
      if (!this._isRoomSelected(r, vac)) return sum;
      return sum + this._roomCleanMins(r, vac);
    }, 0);
  }

  private _intRoomRec(vac: VacuumConfig, room: RoomConfig): Record<string, string> | null {
    const rlc = this._intAttrs(vac)?.rooms_last_cleaned as Record<string, any> | undefined;
    if (!rlc) return null;
    return (rlc[room.key] ?? rlc[room.name ?? ""] ?? null) as Record<string, string> | null;
  }
  /** Persistent "last completed clean covered X%" per room (docs/29) — durable across
   *  restarts/dock trips, unlike `_roomProgForType`'s live in-session gauge (which reads
   *  `rooms_progress` and goes blank the moment the vacuum docks). Missing kind = no
   *  completed clean with an established baseline yet; the caller renders "—", never a
   *  misleading 0%/100%. */
  private _roomCoverageRec(vac: VacuumConfig, room: RoomConfig): Record<string, number> | null {
    const rc = this._intAttrs(vac)?.rooms_coverage as Record<string, any> | undefined;
    if (!rc) return null;
    return (rc[room.key] ?? rc[room.name ?? ""] ?? null) as Record<string, number> | null;
  }
  private _ageDaysFromIso(iso?: string): number | null {
    if (!iso) return null;
    const t = new Date(iso).getTime();
    return isNaN(t) ? null : (Date.now() - t) / 86_400_000;
  }
  /** Room age in days. With an integration sensor, uses last_dry/last_wet/any per the active
   *  layer(s) (both on -> the worse/older); otherwise falls back to the last_clean helper entity. */
  private _roomAgeDays(room: RoomConfig, vac?: VacuumConfig): number | null {
    if (vac) {
      const rec = this._intRoomRec(vac, room);
      if (rec) {
        const dry = this._ageDaysFromIso(rec.dry);
        const wet = this._ageDaysFromIso(rec.wet);
        const any = this._ageDaysFromIso(rec.any);
        const L = this._layersEff();
        const dOn = L.dry, wOn = L.wet;
        let d: number | null;
        if (dOn && wOn) d = Math.max(dry ?? 9999, wet ?? 9999);
        else if (dOn) d = dry;
        else if (wOn) d = wet;
        else d = any;
        if (d !== null) return d;
      }
    }
    if (!room.last_clean_entity) return null;
    const raw = this.hass.states[room.last_clean_entity]?.state;
    if (!raw || raw === "unavailable" || raw === "unknown") return null;
    return (Date.now() - new Date(raw).getTime()) / 86_400_000;
  }

  private _colorForAgeDays(d: number | null): string {
    if (d === null) return "rgba(255,77,77,0.85)";
    const ths: RoomThreshold[] = this._config.room_thresholds ?? [
      { days: 2, color: "rgba(46,204,113,0.85)" },
      { days: 5, color: "rgba(250,173,20,0.85)" },
      { days: 10, color: "rgba(255,152,0,0.85)" },
    ];
    const sorted = [...ths].sort((a, b) => a.days - b.days);
    for (const th of sorted) { if (d <= th.days) return th.color; }
    return "rgba(255,77,77,0.85)";
  }
  /** A vacuum's clean-type role (dry/wet) — explicit config, else auto-detected.
   *  Auto-detect prefers the backend's live hardware signal (docs/31): a water
   *  box is a HARDWARE fact (`mop_signal.water_box_mode`/`water_mode_name`,
   *  same source `planner.py._capable()` uses server-side), unlike guessing
   *  from whether the user happened to fill in `clean_action.mop_mode`/
   *  `mop_intensity` — that heuristic mis-detected a wet-capable robot as
   *  dry-only whenever its Clean action left `suction_level` unset (docs/30
   *  §6 finding 4). Degraded mode (`_intAttrs` returns undefined — no
   *  integration, or old schema) has no such signal and keeps the old
   *  config-based guess, per canon rule 3 (docs/14). */
  private _vacCleanType(vac: VacuumConfig): { dry: boolean; wet: boolean } {
    if (vac.clean_type === "dry") return { dry: true, wet: false };
    if (vac.clean_type === "wet") return { dry: false, wet: true };
    if (vac.clean_type === "both") return { dry: true, wet: true };
    const sig = this._intAttrs(vac)?.mop_signal as Record<string, any> | undefined;
    if (sig) {
      const wet = sig.water_box_mode != null || !!sig.water_mode_name;
      return { dry: true, wet };
    }
    const ca = vac.clean_action as any;
    const wet = !!(ca && (ca.mop_mode || ca.mop_mode_entity || ca.mop_intensity || ca.mop_intensity_entity));
    const dry = !wet || (ca?.suction_level != null && ca.suction_level !== "off");
    return { dry, wet };
  }

  /** Debug: per-room cleaning progress from the integration (rooms_progress). */
  private _roomProgress(vac: VacuumConfig, room: RoomConfig): {
    spatial_pct: number | null; time_pct: number | null;
    dry_pct?: number | null; wet_pct?: number | null;
    dry_calibrating?: boolean; wet_calibrating?: boolean;
    visited_cells?: number; total_cells?: number; elapsed_s?: number | null; est_s?: number | null;
  } | null {
    const rp = this._intAttrs(vac)?.rooms_progress as Record<string, any> | undefined;
    if (!rp) return null;
    return (rp[room.key] ?? rp[room.name ?? ""] ?? null) as any;
  }

  /** Per-clean-type coverage for a room (dry from the vacuum trace, wet from the mop
   *  trace), taken from whichever vacuum has the highest value and coloured by it. Used
   *  by the per-layer (dry/wet) room menus. */
  private _roomProgForType(
    room: RoomConfig, vacs: VacuumConfig[], type: "dry" | "wet",
  ): { pct: number; kind: "S" | "T"; title: string; color: string; calibrating: boolean } | null {
    let best: number | null = null;
    let bestVac: VacuumConfig | null = null;
    let bestCal = false;
    for (const v of vacs) {
      const p = this._roomProgress(v, room);
      if (!p) continue;
      const val = type === "dry" ? p.dry_pct : p.wet_pct;
      if (val === null || val === undefined) continue;
      const cal = !!(type === "dry" ? p.dry_calibrating : p.wet_calibrating);
      // A normalised value always beats a still-calibrating one (docs/36). The two are
      // different scales — normalised is "% of a full clean", calibrating is the raw
      // bounding-box %, which reads high because the box includes furniture the robot
      // cannot reach — so a plain max() across the fleet let one vacuum's raw 78 %~
      // hide another's real 45 %. Within the same scale the highest still wins.
      if (best === null || (bestCal && !cal) || (bestCal === cal && val > best)) {
        best = val; bestVac = v; bestCal = cal;
      }
    }
    if (best === null || !bestVac) return null;
    return { pct: best, kind: "S", title: `${type} coverage ${best}%`, color: this._color(bestVac), calibrating: bestCal };
  }

  private _progColor(pct: number): string {
    return pct >= 90 ? "rgb(var(--avc-ok-rgb))" : pct >= 50 ? "rgb(var(--avc-warn-rgb))" : "rgb(var(--avc-info-rgb))";
  }

  /** Dry + wet mini gauges in the room's corner (debug_room_progress). Values are
   *  aggregated ACROSS the given vacuums — in merged mode the old single gauge read
   *  only the representative (first) vacuum, so most rooms showed nothing (docs/16 §1).
   *  Dry ring wears the best dry vacuum's colour; wet ring is always wet-blue. */
  private _renderRoomGauge(vacs: VacuumConfig[], room: RoomConfig) {
    if (!this._config.debug_room_progress) return nothing;
    const dry = this._roomProgForType(room, vacs, "dry");
    const wet = this._roomProgForType(room, vacs, "wet");
    if (!dry && !wet) return nothing;
    const g = (pct: number, title: string, ring: string, calibrating: boolean) => html`
      <span class="room-gauge" title=${title}
        style=${styleMap({ background: `conic-gradient(${ring} ${pct * 3.6}deg, rgba(255,255,255,0.12) 0)` })}>
        <span>${pct}${calibrating ? "~" : ""}</span>
      </span>`;
    return html`<div class="room-gauges">
      ${dry ? g(dry.pct, "dry · " + dry.title, dry.color, dry.calibrating) : nothing}
      ${wet ? g(wet.pct, "wet · " + wet.title, "#40a9ff", wet.calibrating) : nothing}
    </div>`;
  }

  /** Inline % chip for the room menus/dock rows — live in-session coverage while a room
   *  is actively (or was just) being cleaned. Promoted out of the debug gate (docs/29
   *  §4.4): it's the same data as the persistent post-clean % (`_roomCoverageRec`), just
   *  live during the session, so there's no reason to show one and hide the other.
   *  `debug_room_progress` still gates the rest of the debug strip (map corner gauges,
   *  the status card's mm:ss timer) — this chip alone is production UI now. Coloured by
   *  the vacuum when provided. */
  private _renderProgChip(p: { pct: number; kind: "S" | "T"; title: string; color?: string; calibrating?: boolean } | null) {
    if (!p) return nothing;
    return html`<span class="rl-prog" title=${p.title}
      style=${styleMap({ color: p.color ?? this._progColor(p.pct) })}>${p.pct}${p.calibrating ? "~" : ""}%<small>${p.kind}</small></span>`;
  }

  private _batIcon(pct: number): string {
    if (pct > 80) return "mdi:battery";
    if (pct > 50) return "mdi:battery-60";
    if (pct > 20) return "mdi:battery-30";
    return "mdi:battery-10";
  }

  private _batColor(pct: number): string {
    if (pct > 50) return "rgb(var(--avc-ok-rgb))";
    if (pct > 20) return "rgb(var(--avc-warn-rgb))";
    return "rgb(var(--avc-err-rgb))";
  }

  private _mapUrl(entity: string): string {
    const state = this.hass.states[entity];
    if (!state) return "";
    const pic = state.attributes["entity_picture"] as string;
    if (!pic) return "";
    const ts = new Date(state.last_updated).getTime();
    const sep = pic.includes("?") ? "&" : "?";
    return this.hass.hassUrl(pic + sep + "_t=" + ts);
  }

  private _timeStr(mins: number): string {
    const total = Math.round(mins);
    if (total <= 0) return "";
    if (total >= 60) {
      const h = Math.floor(total / 60);
      const m = total % 60;
      return m > 0 ? "~" + h + " h " + m + " min" : "~" + h + " h";
    }
    return "~" + total + " min";
  }

  // ── Global action helpers ───────────────────────────────────────────────

  /** True if any watched entity is in a cleaning state */
  private _isGlobalActive(ga: GlobalAction): boolean {
    return (ga.watch_entities ?? []).some((e) =>
      CLEANING_STATES.has(this.hass.states[e]?.state ?? "")
    );
  }

  private async _triggerGlobal(ga: GlobalAction): Promise<void> {
    const action = ga.action;
    try {
      if (action.type === "script") {
        await this.hass.callService("script", "turn_on", {
          entity_id: action.entity_id,
          variables: action.variables ?? {},
        });
      } else {
        const [domain, svc] = action.service.split(".");
        await this.hass.callService(domain, svc, action.data ?? {});
      }
    } catch (err) {
      console.error("[anyvac-card] global action failed:", err);
    }
  }

  // ── Hold-action helpers ─────────────────────────────────────────────────

  private _cancelHold(): void {
    if (this._holdTimer !== null) {
      clearTimeout(this._holdTimer);
      this._holdTimer = null;
    }
    this._holdId = null;
    this._holdStartPos = null;
  }

  /**
   * Returns a pointerdown handler that:
   *  1. Sets _holdId to `id` (triggers fill animation)
   *  2. Fires `action` after HOLD_DURATION_MS
   *  Pair with `@pointermove=${this._holdMove}` alongside the usual
   *  pointerup/leave/cancel bindings — see `HOLD_MOVE_CANCEL_PX` doc comment
   *  for why `pointermove` needs its own explicit cancel path (touch capture
   *  means leave/cancel don't fire during a swipe starting on the button).
   */
  private _holdStart(id: string, action: () => void) {
    return (e: PointerEvent): void => {
      e.preventDefault();
      this._cancelHold();
      this._holdId = id;
      this._holdStartPos = { x: e.clientX, y: e.clientY };
      this._holdTimer = setTimeout(() => {
        this._holdTimer = null;
        this._holdId = null;
        this._holdStartPos = null;
        action();
      }, HOLD_DURATION_MS);
    };
  }

  private _holdEnd = (): void => {
    this._cancelHold();
  };

  /** docs/25 §10 field report (2026-07-25): see `HOLD_MOVE_CANCEL_PX` doc
   *  comment — cancels an in-progress hold once the pointer has moved past
   *  the threshold from its start position, catching the Android
   *  swipe-up-from-bottom-edge case where leave/cancel never fire. */
  private _holdMove = (e: PointerEvent): void => {
    if (!this._holdStartPos || this._holdTimer === null) return;
    const dx = e.clientX - this._holdStartPos.x;
    const dy = e.clientY - this._holdStartPos.y;
    if (dx * dx + dy * dy > HOLD_MOVE_CANCEL_PX * HOLD_MOVE_CANCEL_PX) {
      this._cancelHold();
    }
  };

  private _toggleShown(index: number): void {
    // Portrait grid = single-vacuum focus (docs/18 §7b): a badge tap SWITCHES the
    // focused vacuum instead of toggling set membership — no room for more on a phone.
    if (this._config.layout && this._profile === "portrait") {
      this._shownSet = new Set([index]);
      this._saveShown();
      return;
    }
    this._toggleShownMulti(index);
  }

  /** Plain multi-select membership toggle (add/remove from `_shownSet`, never
   *  collapsing to single-focus) — always keeps at least one vacuum shown.
   *  Used directly by contexts that need "hide just this one" regardless of
   *  profile, e.g. the portrait vac-icon-strip hold gesture, which must be
   *  able to hide one of three merged-map vacuums while leaving the other
   *  two visible (docs/19 follow-up, field feedback 2026-07-17). */
  private _toggleShownMulti(index: number): void {
    const next = new Set(this._shownSet);
    if (next.has(index)) { if (next.size > 1) next.delete(index); }
    else { next.add(index); }
    this._shownSet = next;
    this._saveShown();
  }

  // ── Service calls ───────────────────────────────────────────────────────

  private async _call(domain: string, service: string, data: Record<string, unknown>): Promise<void> {
    try {
      await this.hass.callService(domain, service, data);
    } catch (err) {
      console.error("[anyvac-card] " + domain + "." + service + " failed:", err);
    }
  }

  private _fireMoreInfo(entityId: string): void {
    this.dispatchEvent(new CustomEvent("hass-more-info", {
      bubbles: true, composed: true, detail: { entityId },
    }));
  }

  // ── localStorage persistence ──────────────────────────────────────────────

  /** Per-card storage key (1.1.0).
   *
   *  Two problems with the old flat `roborock-card:*` keys, fixed together:
   *
   *  1. **They were global.** Every AnyVac card in the browser shared one
   *     `shown` set and one `flip` value, so two cards on different dashboards
   *     (different floorplans, different orientations) overwrote each other.
   *     That directly contradicted the flip toggle's own premise — "how THIS
   *     screen likes its map" — since the key was per browser, not per card.
   *  2. **The prefix was the predecessor's name.** `roborock-vacuum-card`, which
   *     AnyVac was rebased on, is still installed alongside on this setup, so a
   *     shared key namespace was a real collision risk, not a cosmetic one.
   *
   *  `scope` is derived from the configured vacuum entities rather than a
   *  position or a random id: it is stable across restarts and dashboard edits,
   *  distinct between cards showing different fleets, and deliberately SHARED
   *  between two cards showing the same fleet (e.g. the same dashboard opened on
   *  phone and tablet) — which is the behaviour you'd want there anyway. */
  private _storeKey(what: string): string {
    const scope = (this._config?.vacuums ?? []).map((v) => v.entity).join(",");
    return `anyvac-card:${what}:${scope}`;
  }

  /** Read a key, falling back once to the pre-1.1.0 global `roborock-card:*`
   *  name so an existing setup keeps its shown-set / selection / flip on
   *  upgrade instead of silently resetting. Write-back happens naturally on the
   *  next change, which is when the new key starts winning; the legacy key is
   *  left in place rather than deleted, so downgrading still works. */
  private _readStored(what: string, legacyKey: string): string | null {
    try {
      return localStorage.getItem(this._storeKey(what)) ?? localStorage.getItem(legacyKey);
    } catch {
      return null;
    }
  }

  private _saveShown(): void {
    try {
      const ids = [...this._shownSet].map(i => this._config.vacuums[i]?.entity).filter(Boolean);
      localStorage.setItem(this._storeKey("shown"), JSON.stringify(ids));
    } catch { /* storage unavailable */ }
  }

  private _loadShown(): Set<number> {
    try {
      const raw = this._readStored("shown", "roborock-card:shown");
      if (raw) {
        const ids: string[] = JSON.parse(raw);
        const indices = ids
          .map(id => this._config.vacuums.findIndex(v => v.entity === id))
          .filter(i => i >= 0);
        if (indices.length > 0) return new Set(indices);
      }
    } catch { /* ignore */ }
    return new Set(this._config.vacuums.map((_, i) => i));
  }

  /** docs/32 §5 follow-up (field feedback, 2026-08-03): the live flip toggle
   *  was deliberately in-memory-only ("try it on this screen right now") —
   *  but a page refresh (common on wall-mounted tablets/kiosk dashboards)
   *  reset it to the config default every time, which read as "doesn't
   *  stick" rather than "session-scoped by design". Persisted via
   *  localStorage instead (same mechanism as `_shownSet`/room selection) —
   *  survives reload, but stays per-BROWSER like those, not backend-shared
   *  like `view_layers`: this is "how THIS screen likes its map", which can
   *  legitimately differ from another screen showing the same dashboard. */
  private _saveFlipLive(): void {
    try {
      if (this._flipLive === null) localStorage.removeItem(this._storeKey("flip"));
      else localStorage.setItem(this._storeKey("flip"), JSON.stringify(this._flipLive));
    } catch { /* storage unavailable */ }
  }

  private _loadFlipLive(): boolean | null {
    const raw = this._readStored("flip", "roborock-card:flip");
    if (raw === null) return null;
    try {
      return JSON.parse(raw) === true;
    } catch {
      return null;
    }
  }

  private _saveRoomSel(vacEntity: string): void {
    try {
      const prefix = vacEntity + ":";
      const sel: Record<string, boolean> = {};
      for (const [k, v] of this._localRoomSel.entries()) {
        if (k.startsWith(prefix)) sel[k.slice(prefix.length)] = v;
      }
      localStorage.setItem(this._storeKey("sel:" + vacEntity), JSON.stringify(sel));
    } catch { /* ignore */ }
  }

  private _loadRoomSel(): Map<string, boolean> {
    const map = new Map<string, boolean>();
    try {
      for (const vac of this._config.vacuums) {
        const raw = this._readStored("sel:" + vac.entity, "roborock-card:sel:" + vac.entity);
        if (raw) {
          const sel: Record<string, boolean> = JSON.parse(raw);
          for (const [k, v] of Object.entries(sel)) {
            if (v) map.set(vac.entity + ":" + k, true);
          }
        }
      }
    } catch { /* ignore */ }
    return map;
  }

  private _pause(vac: VacuumConfig): void {
    this._call("vacuum", "pause", { entity_id: vac.entity });
  }

  private _resume(vac: VacuumConfig): void {
    this._call("vacuum", "start", { entity_id: vac.entity });
  }

  private _dock(vac: VacuumConfig): void {
    this._call("vacuum", "return_to_base", { entity_id: vac.entity });
  }

  private _toggleRoom(room: RoomConfig, vac: VacuumConfig): void {
    if (this._backendSel()) { this._setBackendSel([room.key], "toggle"); return; }
    const k = vac.entity + ":" + room.key;
    const next = new Map(this._localRoomSel);
    next.set(k, !(next.get(k) ?? false));
    this._localRoomSel = next;
    this._saveRoomSel(vac.entity);
  }
  private _isRoomSelectedAny(key: string, vacs: VacuumConfig[]): boolean {
    const be = this._backendSel();
    if (be) return be.has(key);
    return vacs.some((v) => this._localRoomSel.get(v.entity + ":" + key) ?? false);
  }
  /** Merged mode: toggle a room across every shown vacuum that has it (one rectangle -> both controllers). */
  private _toggleRoomAcross(key: string, vacs: VacuumConfig[]): void {
    // docs/18 §7e follow-up (field report 2026-07-25): a manual pin
    // (`_cycleRoomPin` → `anyvac.pin_room`) only ever auto-clears once the
    // room is actually cleaned — pick a vacuum once, and it "sticks" through
    // every future selection until a clean happens, even across
    // deselect/reselect. Clearing it here too — the moment the room is
    // DEselected — gives the user an obvious, always-available way back to
    // auto: untick the room, tick it again. Both `kind` and `vacuum` omitted
    // from the call data is the documented unpin-both-passes shorthand
    // (`coordinator.set_room_pin`: "kind None = unpin the room entirely"),
    // same as a fresh room that was never pinned — deselecting clears
    // whatever dry/wet pins it had, not just one pass.
    // Computed from `_isRoomSelectedAny` BEFORE either selection-storage
    // path below mutates state, so it covers both the backend-tracked and
    // local-selection branches with one check.
    if (this._isRoomSelectedAny(key, vacs) && vacs.some((v) => this._intAttrs(v))) {
      void this._call("anyvac", "pin_room", { room: key });
    }
    if (this._backendSel()) { this._setBackendSel([key], "toggle"); return; }
    const target = !this._isRoomSelectedAny(key, vacs);
    const next = new Map(this._localRoomSel);
    for (const v of vacs) {
      if (this._roomsFor(v).some((r) => r.key === key)) next.set(v.entity + ":" + key, target);
    }
    this._localRoomSel = next;
    for (const v of vacs) this._saveRoomSel(v.entity);
  }

  // ── Auto mode: orchestrated cleans (naive fan-out v1) ─────────────────────
  /** All distinct room keys across vacuums. */
  private _allRoomKeys(): string[] {
    const keys = new Set<string>();
    for (const v of this._config.vacuums) for (const r of this._roomsFor(v)) keys.add(r.key);
    return [...keys];
  }
  // NOTE (docs/28 §3): `_planVacuums()` — "restrict the orchestrated plan to the
  // currently SHOWN vacuums" — lived here without a single caller and was deleted
  // 2026-08-08. The idea itself is still open, deliberately: hiding a robot on the
  // map (a display action) silently dropping it from a whole-home plan is a real
  // footgun in portrait, where hold-to-hide is easy to trigger. If it comes back it
  // needs that decision made first, not a dangling helper waiting to be wired up.
  // ── Clean intent → backend planner (kontrakt v2, docs/14 §3.7) ─────────────
  /** Per-kind vacuum restriction for anyvac.clean/plan, from the configured roles —
   *  preserves the user's dry/wet split even when a robot is both-capable. */
  private _v2Vacuums(): { dry: string[]; wet: string[] } {
    const dry: string[] = [], wet: string[] = [];
    for (const v of this._config.vacuums) {
      const role = this._vacCleanType(v);
      if (role.dry) dry.push(v.entity);
      if (role.wet) wet.push(v.entity);
    }
    return { dry, wet };
  }
  /** Rooms the backend plan (anyvac.plan) could NOT assign a robot to for the
   *  current mode — e.g. the mode needs a wet pass but every vacuum configured
   *  with a wet role (docs/14 §3.7 `_v2Vacuums`) can't/didn't take the room.
   *  Found live 2026-07-18: a "Both" run where the card's `clean_type` config
   *  restricted wet to a single vacuum produced ZERO visible feedback when
   *  that vacuum's assignment came back empty — the user just watched dry
   *  finish and nothing else happen, with no error anywhere. This is derived
   *  from the SAME plan preview already fetched for the ETA/avatars (a
   *  selected room missing from `dryOf`/`wetOf` for a kind the mode requires
   *  IS the unassigned signal) — no new backend call, no new event plumbing.
   *  `plan.unassigned` also exists server-side (planner.py) but isn't needed
   *  here; that field is for `anyvac.plan`/`anyvac.clean` callers outside the
   *  card (automations), not for this. */
  private _unassignedRooms(selKeys: string[], mode: "dry" | "wet" | "both", hasInt: boolean): string[] {
    if (!hasInt || selKeys.length === 0) return [];
    const preview = this._planPreview;
    if (!preview || preview.key !== this._planKey(selKeys, mode)) return [];
    const needDry = mode !== "wet";
    const needWet = mode !== "dry";
    const out: string[] = [];
    for (const k of selKeys) {
      if ((needDry && !preview.dry.has(k)) || (needWet && !preview.wet.has(k))) out.push(k);
    }
    return out;
  }
  /** Per-vacuum, per-pass settings for anyvac.clean (2026-07-26) — every capable
   *  vacuum contributes its OWN active preset's fan speed / mop mode / mop
   *  intensity / repeat, keyed by entity id. Mirrors the extraction already used
   *  for the single-vacuum manual START (`_startClean`): a pass only reads
   *  mop_mode/mop_intensity when it's actually the wet pass (the backend forces
   *  mop off for a dry pass regardless).
   *  Previously this searched each vacuum's own preset LIST for one that
   *  "looked" wet/dry and, worse, stopped after the FIRST capable vacuum per
   *  kind — so one vacuum's fan_speed silently won for every other vacuum doing
   *  that pass (e.g. S6's preset overriding S7's), and the active preset chip
   *  the user actually picked was ignored in favor of that heuristic search. */
  private _v2Settings(): Record<string, Record<string, Record<string, unknown>>> | undefined {
    const out: Record<string, Record<string, Record<string, unknown>>> = {};
    for (const kind of ["dry", "wet"] as const) {
      for (const v of this._config.vacuums) {
        const role = this._vacCleanType(v);
        if (!(kind === "dry" ? role.dry : role.wet)) continue;
        const ap = this._activePreset(v);
        const s: Record<string, unknown> = {};
        if (ap.suction_level) s.fan_speed = ap.suction_level;
        if (kind === "wet" && ap.mop_mode) s.mop_mode = ap.mop_mode;
        if (kind === "wet" && ap.mop_intensity) s.mop_intensity = ap.mop_intensity;
        if (ap.repeat && ap.repeat > 1) s.repeat = ap.repeat;
        if (Object.keys(s).length) (out[kind] ??= {})[v.entity] = s;
      }
    }
    return Object.keys(out).length ? out : undefined;
  }
  /** Backend plan preview (anyvac.plan, response-only): room key -> vacuum entity,
   *  plus the sequence-aware ETA (docs/19) computed server-side from the real
   *  per-robot assignment + the Roborock app's room order (room_sequence). */
  @state() private _planPreview: {
    key: string; dry: Map<string, string>; wet: Map<string, string>;
    eta: number | null; unsequenced: string[];
  } | null = null;
  private _planFetchKey = "";
  /** Identity of a plan preview: everything the backend's answer depends on.
   *
   *  room_pins is part of it (not just selKeys/mode/vacuums) so that tapping an
   *  avatar to cycle a room's pin (_cycleRoomPin → anyvac.pin_room) invalidates
   *  the cached plan and re-fetches as soon as the backend's room_pins attribute
   *  updates — without it the dock avatar stayed stuck on the old assignment
   *  until something else (e.g. deselecting/reselecting the room) happened to
   *  change selKeys and force a refetch (field-caught 2026-07-23).
   *
   *  Extracted into one method 2026-08-08: `_unassignedRooms` built the same key
   *  inline but was never updated when room_pins was added here, so its
   *  three-element key could never equal this four-element one — it returned []
   *  unconditionally, silently disabling the whole unassigned-rooms warning
   *  (card 0.66.5: the red `mdi:robot-off` markers in dock rows, the dock footer
   *  summary and the landscape meta bar count). Both callers now share this, so
   *  they cannot drift apart again. */
  private _planKey(selKeys: string[], mode: "dry" | "wet" | "both"): string {
    return JSON.stringify([selKeys, mode, this._v2Vacuums(), this._pinsAttr()]);
  }
  private _fetchPlan(selKeys: string[], mode: "dry" | "wet" | "both"): void {
    const key = this._planKey(selKeys, mode);
    if (key === this._planFetchKey) return;
    this._planFetchKey = key;
    void (async () => {
      try {
        const res = await (this.hass as any).callService(
          "anyvac", "plan",
          { rooms: selKeys, mode, vacuums: this._v2Vacuums() },
          undefined, false, true,
        ) as { response?: { plan?: Record<string, any> } } | void;
        if (this._planFetchKey !== key) return;  // stale response
        const plan = (res as any)?.response?.plan ?? {};
        const inv = (m: Record<string, string[]> | undefined) => {
          const out = new Map<string, string>();
          for (const [ent, rooms] of Object.entries(m ?? {})) for (const r of rooms) out.set(r, ent);
          return out;
        };
        this._planPreview = {
          key, dry: inv(plan.dry), wet: inv(plan.wet),
          eta: typeof plan.eta_min === "number" ? plan.eta_min : null,
          unsequenced: Array.isArray(plan.unsequenced) ? plan.unsequenced : [],
        };
      } catch (err) {
        console.warn("[anyvac-card] anyvac.plan preview failed:", err);
        if (this._planFetchKey === key) this._planPreview = { key, dry: new Map(), wet: new Map(), eta: null, unsequenced: [] };
      }
    })();
  }
  /** Selection time estimate: prefer the backend's sequence-aware ETA (anyvac.plan,
   *  docs/19) when the integration is present; otherwise (degraded mode — no
   *  backend to ask) fall back to the rough client-side sum (docs/14 §8, direct
   *  vac.* calls / local estimates are the accepted degraded-mode behavior). */
  private _etaFor(selKeys: string[], mode: "dry" | "wet" | "both", hasInt: boolean): number {
    if (hasInt && selKeys.length) this._fetchPlan(selKeys, mode);
    const fromPlan = this._planPreview?.eta;
    if (hasInt && fromPlan != null) return fromPlan;
    return this._selEstMins(selKeys);
  }
  /** Send the clean intent — planning (capability, LPT assignment, segment resolve,
   *  dry→wet gating, repeat) is entirely backend-side now (anyvac.clean, docs/14
   *  §3.7). The old client-side plan builder + run_job assembly was deleted. */
  private async _runOrchestrated(roomKeys: string[], mode: "dry" | "wet" | "both"): Promise<void> {
    if (!roomKeys.length) return;
    await this._call("anyvac", "clean", {
      rooms: roomKeys,
      mode,
      vacuums: this._v2Vacuums(),
      ...(this._v2Settings() ? { settings: this._v2Settings() } : {}),
    });
  }
  /** Select a global preset (does NOT run): set the plan mode + apply its room scope,
   *  so the plan preview reflects it. The user runs it via the plan's "Start · hold". */
  private _selectGlobalPreset(gp: GlobalPreset): void {
    this._activeGlobalPreset = gp.id;
    if (gp.mode) this._planMode = gp.mode;
    if (gp.scope === "all" || Array.isArray(gp.scope)) {
      const keys = gp.scope === "all" ? this._allRoomKeys() : gp.scope;
      // Backend-shared selection first (docs/14 §3.11); local only without integration.
      if (this._backendSel()) { this._setBackendSel(keys, "set"); return; }
      const sel = new Map(this._localRoomSel);
      for (const v of this._config.vacuums) for (const r of this._roomsFor(v)) sel.delete(v.entity + ":" + r.key);
      for (const k of keys) for (const v of this._config.vacuums) {
        if (this._roomsFor(v).some((r) => r.key === k)) sel.set(v.entity + ":" + k, true);
      }
      this._localRoomSel = sel;
      for (const v of this._config.vacuums) this._saveRoomSel(v.entity);
    }
    // scope "select" → keep the user's current room selection
  }
  /** Two-letter abbreviation for a vacuum (fallback when no icon). */
  private _vacAbbrev(vac: VacuumConfig): string {
    const n = vac.name ?? vac.entity.split(".")[1] ?? "";
    return (n.replace(/[^A-Za-z0-9]/g, "").slice(0, 2) || "??").toUpperCase();
  }
  /** Plan preview: per selected room, which vacuum cleans it dry / wet, with a
   *  dry/wet/both mode toggle and a hold-to-run button. Reacts to the selected
   *  (held) vacuum badges and the currently selected rooms. */
  private _renderPlanPreview() {
    if (this._config.ui_mode !== "auto") return nothing;
    const selKeys = this._allRoomKeys().filter((k) => this._isRoomSelectedAny(k, this._config.vacuums));
    if (!selKeys.length) return nothing;
    const mode = this._planMode;
    const apLabel = (this._config.global_presets ?? []).find((g) => g.id === this._activeGlobalPreset)?.label;
    const showDry = mode === "dry" || mode === "both";
    const showWet = mode === "wet" || mode === "both";
    // The preview is the BACKEND's real assignment (anyvac.plan, response-only) —
    // the card no longer computes plans locally (docs/14 §3.7). Debounced by key;
    // until the response lands the cells show "—".
    this._fetchPlan(selKeys, mode);
    const dryOf = this._planPreview?.dry ?? new Map<string, string>();
    const wetOf = this._planPreview?.wet ?? new Map<string, string>();
    const roomDef = (k: string) => {
      for (const v of this._config.vacuums) { const r = this._roomsFor(v).find((x) => x.key === k); if (r) return r; }
      return undefined;
    };
    const cell = (entity?: string) => {
      const v = this._config.vacuums.find((x) => x.entity === entity);
      if (!v) return html`<span style="font-size:11px;opacity:.25">—</span>`;
      const c = this._color(v);
      return html`<span style="display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:17px;padding:0 5px;border-radius:9px;font-size:10px;font-weight:700;color:rgb(var(--avc-ink-rgb));background:${c}30;border:1px solid ${c}">${this._vacAbbrev(v)}</span>`;
    };
    const modeBtn = (m: "dry" | "wet" | "both", label: string) => {
      const on = mode === m;
      return html`<button @click=${(e: Event) => { e.stopPropagation(); this._planMode = m; }}
        style="padding:2px 8px;border-radius:8px;font-size:10px;font-weight:700;cursor:pointer;font-family:inherit;border:1px solid ${on ? "rgba(var(--avc-ink-rgb),0.5)" : "rgba(var(--avc-ink-rgb),0.15)"};background:${on ? "rgba(var(--avc-ink-rgb),0.12)" : "transparent"};color:${on ? "#fff" : "rgba(var(--avc-ink-rgb),0.5)"}">${label}</button>`;
    };
    const runHid = "plan-run";
    return html`
      <div style="margin:0 4px 6px;padding:6px 8px;background:rgba(var(--avc-ink-rgb),0.03);border:1px solid rgba(var(--avc-ink-rgb),0.08);border-radius:12px;display:flex;flex-direction:column;gap:6px">
        <div style="display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:9px;font-weight:600;letter-spacing:.6px;color:rgba(var(--avc-ink-rgb),.35)">CLEAN PLAN${apLabel ? " · " + apLabel.toUpperCase() : ""}</span>
          <div style="display:flex;gap:4px">${modeBtn("dry", "Dry")}${modeBtn("wet", "Wet")}${modeBtn("both", "Both")}</div>
        </div>
        <div style="display:flex;gap:6px;overflow-x:auto;align-items:center">
          <div style="display:flex;flex-direction:column;gap:3px;align-items:center;flex-shrink:0;padding-right:2px">
            <span style="height:18px"></span>
            ${showDry ? html`<ha-icon icon="mdi:broom" style="--mdc-icon-size:14px;color:rgba(var(--avc-ink-rgb),.4)"></ha-icon>` : nothing}
            ${showWet ? html`<ha-icon icon="mdi:water" style="--mdc-icon-size:14px;color:rgba(var(--avc-info-rgb),.7)"></ha-icon>` : nothing}
          </div>
          ${selKeys.map((k) => {
            const r = roomDef(k);
            return html`<div style="display:flex;flex-direction:column;align-items:center;gap:3px;min-width:32px;flex-shrink:0" title=${r?.name ?? k}>
              <ha-icon icon=${r?.icon || "mdi:floor-plan"} style="--mdc-icon-size:18px;color:rgba(var(--avc-ink-rgb),.7)"></ha-icon>
              ${showDry ? cell(dryOf.get(k)) : nothing}
              ${showWet ? cell(wetOf.get(k)) : nothing}
            </div>`;
          })}
        </div>
        <button class="action-btn ${this._holdId === runHid ? "action-btn--holding" : ""}"
          style="flex:0 0 auto;align-self:flex-end;flex-direction:row;gap:6px;padding:7px 16px;background:rgba(var(--avc-ok-rgb),0.14);border:1px solid rgba(var(--avc-ok-rgb),0.55);color:rgb(var(--avc-ink-rgb))"
          @pointerdown=${this._holdStart(runHid, () => this._runOrchestrated(selKeys, this._planMode))}
          @pointermove=${this._holdMove}
          @pointerup=${this._holdEnd}
          @pointerleave=${this._holdEnd}
          @pointercancel=${this._holdEnd}>
          <div class="hold-ring"></div>
          <ha-icon icon="mdi:play" style="--mdc-icon-size:18px"></ha-icon>
          <span style="font-size:12px">Start · hold</span>
        </button>
      </div>
    `;
  }
  private _renderAutoBar() {
    if (this._config.ui_mode !== "auto") return nothing;
    const gps = this._config.global_presets ?? [];
    if (!gps.length) return nothing;
    return html`
      <div style="display:flex;flex-wrap:wrap;gap:8px;padding:2px 4px 4px">
        ${gps.map((gp) => {
          const active = this._activeGlobalPreset === gp.id;
          return html`<button
            @click=${() => this._selectGlobalPreset(gp)}
            style="flex:0 1 auto;min-width:128px;display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:10px;padding:9px 14px;border-radius:14px;cursor:pointer;font-family:inherit;color:white;background:${active ? "rgba(var(--avc-ok-rgb),0.14)" : "rgba(var(--avc-ink-rgb),0.05)"};border:1px solid ${active ? "rgba(var(--avc-ok-rgb),0.6)" : "rgba(var(--avc-ink-rgb),0.12)"}">
            <ha-icon icon=${gp.icon || "mdi:robot-vacuum-variant"} style="--mdc-icon-size:24px"></ha-icon>
            <div style="display:flex;flex-direction:column;align-items:flex-start;line-height:1.15">
              <span style="font-size:13px;font-weight:700">${gp.label}</span>
              <small style="font-size:9px;font-weight:600;letter-spacing:.4px;color:rgba(var(--avc-ink-rgb),0.4)">${
                gp.scope === "all" ? "WHOLE HOME" : gp.scope === "select" ? "SELECTED" : "ROOMS"
              }${gp.mode ? " · " + (gp.mode === "dry" ? "DRY" : gp.mode === "wet" ? "WET" : "BOTH") : ""}</small>
            </div>
          </button>`;
        })}
      </div>
    `;
  }

  // ── Dock & START regions (docs/18 Fáze B) ────────────────────────────────

  /** Shared per-room, per-pass vacuum pins from the integration sensor
   *  (anyvac.pin_room). Per-kind since 2026-07-25 — dry and wet are stored
   *  independently, see `_cycleRoomPin`. Only consumed here as a plan-preview
   *  cache-key input (any change must trigger a refetch), so its exact shape
   *  doesn't otherwise matter to callers. */
  private _pinsAttr(): Record<string, { dry?: string; wet?: string }> {
    const ent = this._selSensor();
    const rp = ent ? (this.hass.states[ent]?.attributes?.room_pins as Record<string, { dry?: string; wet?: string }> | undefined) : undefined;
    return rp && typeof rp === "object" ? rp : {};
  }
  /** Vacuums that could clean this room for the given pass (know the room key
   *  AND are actually capable of that clean type). Field-caught 2026-07-25:
   *  a fleet where no single vacuum can do both (dry-only S6/S7 + a wet-only
   *  S8, this user's real setup) broke pin-cycling if candidates weren't
   *  type-filtered — see `_cycleRoomPin` for the full failure mode. */
  private _pinCandidates(key: string, kind: "dry" | "wet"): VacuumConfig[] {
    return this._config.vacuums.filter(
      (v) => this._roomsFor(v).some((r) => r.key === key) && this._vacCleanType(v)[kind],
    );
  }
  /** Cycle the room's DRY or WET assignment: vac1 → vac2 → … → vac1 (docs/18
   *  §7e, simplified 2026-07-23 — field feedback: the old auto→vac1→vac2→auto
   *  cycle's "pinned" indicator (a 1.5px ring + a 10px pin glyph inside a 17px
   *  chip) was practically unreadable, and the auto/pinned distinction itself
   *  wasn't a concept the user found useful — tap just reassigns to the next
   *  candidate, full stop; a room with only one capable vacuum has nothing to
   *  cycle to, so the tap handler isn't even attached (see `_pinCandidates`).
   *  Still stored backend-side (anyvac.pin_room) so every browser sees the same
   *  override, and the planner still auto-clears it after the room is cleaned
   *  (docs/18 §7e) — only the manual "back to auto" UI step is gone, not the
   *  automatic one.
   *
   *  `kind` (2026-07-25 fix): the dry chip and the wet chip must cycle
   *  independently, each only among vacuums capable of THAT type — before
   *  this fix both chips cycled through every vacuum that merely knows the
   *  room, capability-blind. At the time, `room_pins` was also still a single
   *  per-room override (one vacuum, not one per type), so cycling the dry
   *  chip through a fleet that includes a wet-only vacuum could silently pin
   *  the room to that wet-only vacuum: the dry display ignored it (can't
   *  dry-clean) and kept showing the old assignee — no visible change —
   *  while the wet chip's own display jumped to it unannounced. Worse, if
   *  that wet-only vacuum was ALREADY the stored pin, cycling the dry chip
   *  was a permanent fixed point: shown (dry-capable, one slot before the
   *  wet-only one in candidate order) always resolved to the same "next" =
   *  the wet-only vacuum = the pin's current value already, so nothing ever
   *  changed no matter how many times you tapped (field report 2026-07-25,
   *  reproduced live: dry-only-fleet room stuck on a wet-only pin for Living
   *  room while other rooms merely looked flaky/needed a manual refresh —
   *  same root cause, different coincidence of indices). Filtering
   *  candidates by `kind` up front removed the cross-type write for THIS
   *  chip's own tap.
   *
   *  Same-day follow-up: filtering candidates alone didn't stop the dry and
   *  wet chip from clobbering EACH OTHER, since both still wrote the same
   *  single `room_pins[room]` value — pinning dry then pinning wet (or vice
   *  versa) silently discarded whichever was set first, and the planner's
   *  automatic-fallback WARNING for the now-mismatched pass fired on every
   *  plan/clean call for that room (visible in the HA log as "pin X -> Y not
   *  applicable for Z pass"). `room_pins` and `anyvac.pin_room` are now
   *  per-kind ({room: {dry, wet}}, backend `coordinator.set_room_pin`/
   *  `planner._pin_for_kind`) — dry and wet are genuinely independent, no
   *  fallback needed for a correctly-pinned fleet like this one.
   *
   *  `shown` is the vacuum the tapped chip is CURRENTLY displaying — i.e. the
   *  planner's live assignment (auto or already-pinned), not the raw
   *  `room_pins` store. Cycling from the stored pin instead of the displayed
   *  value was the bug reported 2026-07-23: right after a room is selected
   *  there's usually no stored pin yet, so the first tap resolved index -1 →
   *  candidate 0 — which is a no-op whenever candidate 0 happens to already be
   *  the auto-assigned (displayed) vacuum, making the cycle feel random
   *  (S6→S7→S6→S6→S7). Cycling from what's actually shown always advances by
   *  exactly one candidate on every tap. */
  private _cycleRoomPin(key: string, kind: "dry" | "wet", shown: string | undefined): void {
    const cands = this._pinCandidates(key, kind);
    if (cands.length < 2) return; // nothing to switch to
    const idx = cands.findIndex((v) => v.entity === shown);
    const next = cands[(idx + 1) % cands.length];
    void this._call("anyvac", "pin_room", { room: key, kind, vacuum: next.entity });
  }
  /** Small vacuum-abbrev chip showing who's assigned to clean this room/pass. */
  private _vacChip(entity: string | undefined, onTap?: (e: Event) => void) {
    const v = this._config.vacuums.find((x) => x.entity === entity);
    if (!v) {
      return html`<span class="dock-chip dock-chip--empty" @click=${onTap ?? nothing}>—</span>`;
    }
    const c = this._color(v);
    return html`<span class="dock-chip"
      style="color:rgb(var(--avc-ink-rgb));background:${c}30;border-color:${c}"
      title=${(v.name ?? v.entity) + (onTap ? " · tap to assign a different vacuum" : "")}
      @click=${onTap ?? nothing}>${this._vacAbbrev(v)}</span>`;
  }

  /** DEGRADED-MODE FALLBACK ONLY (no integration → no backend to ask): per room
   *  the worst (max) estimate across vacuums, summed with no notion of sequence,
   *  parallelism or dry→wet gating. With the integration present, `_etaFor` uses
   *  the backend's sequence-aware `eta_min` instead (docs/19) — this function
   *  assumes a simultaneous dry/wet start, which is wrong, but there is no
   *  backend to compute the real timeline for in degraded mode. */
  private _selEstMins(selKeys: string[]): number {
    let sum = 0;
    for (const k of selKeys) {
      let best = 0;
      for (const v of this._config.vacuums) {
        const r = this._roomsFor(v).find((x) => x.key === k);
        if (r) best = Math.max(best, this._roomCleanMins(r, v));
      }
      sum += best;
    }
    return Math.round(sum);
  }
  /** Dock region (docs/12 §3 + docs/18 §3): selection, plan preview and pinning in
   *  one block. Row = room (tap toggles selection); the avatar shows the BACKEND's
   *  real assignment per pass; tapping the avatar cycles the room's vacuum pin.
   *  `withRun` adds the orchestrated run footer (landscape — no `start` region). */
  /** Emergency manual-control strip (portrait-only, docs/19 follow-up): small
   *  icon-only vacuum buttons at the top of the dock column, spread across the
   *  full width (one equal-width slot per vacuum, same idea as the mode
   *  buttons in `.dock-head` right below). Tap opens that vacuum's more-info
   *  dialog (glanceable status, not a pseudo-controller — docs/18 §10b field
   *  note). Hold toggles it in/out of `_shownSet` — merged mode's map DOES
   *  filter its overlaid map/path/room layers by `_shownSet` (`_renderMergedMap`),
   *  so this is a real "hide this robot's clutter off the shared floorplan"
   *  action (field feedback 2026-07-17: 3 overlaid maps in portrait is too
   *  much to read at once), not just a focus switch — deliberately NOT routed
   *  through `_toggleShown`, whose portrait branch collapses to a single
   *  shown vacuum (that's for split mode's per-vacuum status-card focus,
   *  docs/18 §7b, a different concern). Landscape keeps the full `picker`
   *  region instead (name + live status, docs/19 A5). */
  private _renderVacuumIconStrip() {
    if (this._profile !== "portrait") return nothing;
    const vacs = this._config.vacuums;
    if (!vacs.length) return nothing;
    return html`
      <div class="vac-icon-strip">
        ${vacs.map((v, i) => {
          const shown = this._shownSet.has(i);
          const holdId = "vacicon-" + i;
          const holding = this._holdId === holdId;
          return html`
            <div class="vac-icon-slot">
              <button class="vac-icon-btn ${holding ? "vac-icon-btn--holding" : ""} ${shown ? "" : "vac-icon-btn--hidden"}"
                style=${styleMap({ borderColor: this._statusInfo(v)[1] })}
                @pointerdown=${(e: PointerEvent) => {
                  e.preventDefault();
                  this._cancelHold();
                  this._holdId = holdId;
                  this._holdTimer = setTimeout(() => {
                    this._holdTimer = null;
                    this._holdId = null;
                    this._toggleShownMulti(i);
                  }, HOLD_DURATION_MS);
                }}
                @pointerup=${() => {
                  if (this._holdTimer !== null) {
                    this._cancelHold();
                    this._fireMoreInfo(v.entity);
                  } else {
                    this._holdId = null;
                  }
                }}
                @pointerleave=${this._holdEnd}
                @pointercancel=${this._holdEnd}
                title=${v.name ?? v.entity} aria-label=${v.name ?? v.entity}
                aria-pressed=${shown ? "true" : "false"}>
                <div class="hold-ring"></div>
                ${v.image
                  ? html`<img src=${v.image} alt="" />`
                  : html`<ha-icon icon="mdi:robot-vacuum" style=${styleMap({ color: this._color(v) })}></ha-icon>`}
              </button>
            </div>
          `;
        })}
      </div>
    `;
  }

  /** `withPicker` (v1.1.0 follow-up, docs/33): the landscape vacuum picker
   *  used to be its own grid region, sitting in a SEPARATE row above dock —
   *  `status` spanned both rows so its column height matched theirs
   *  combined, but that span inflated the picker's row past its own short
   *  content whenever status was taller, leaving a visible gap between the
   *  picker pills and the room list below (field-caught 2026-08-03). Now
   *  picker renders as the first thing INSIDE dock instead, so both are one
   *  naturally-stacked flow with no cross-row sizing to create a gap.
   *  Gated on the CALLER checking `!("picker" in prof.place)` — a manual
   *  config that still explicitly places its own `picker` region keeps
   *  getting that (unchanged), and doesn't also get a duplicate here. */
  private _renderDock(withRun: boolean, withPicker = false) {
    const vacs = this._config.vacuums;
    const rooms = this._mergedRoomDefs(vacs);
    // Room-less configs (e.g. a fresh install before any rooms exist, docs/30)
    // used to make the WHOLE picker region disappear too, back when picker
    // was its own independent grid region — now that it renders from inside
    // here (see `withPicker` doc above), bail out only on the room-list
    // content, not on the picker/icon-strip above it, so it doesn't regress
    // that case. Mirrors the main return's `withPicker` + icon-strip pair
    // below (each self-gates to its own profile, so exactly one renders).
    // The dock sheet is about the dock, not the rooms, so it comes along too —
    // caught by its own test (2026-09-02): the Dock button is gated on dock
    // capability alone, so on a room-less config it rendered and then opened
    // onto nothing, because this early return happened first.
    if (!rooms.length)
      return html`${withPicker ? this._renderVacuumPicker() : nothing}${this._renderVacuumIconStrip()}${this._renderDockSheet()}`;
    const hasInt = vacs.some((v) => this._intAttrs(v));
    const mode = this._planMode;
    const selKeys = this._allRoomKeys().filter((k) => this._isRoomSelectedAny(k, vacs));
    // docs/25 §5: no explicit selection = whole home, not an empty plan. Feeds
    // the footer run button/ETA below; per-row "selected" styling stays tied
    // to explicit selKeys, so this doesn't make every row look hand-picked.
    const runKeys = selKeys.length ? selKeys : this._allRoomKeys();
    if (hasInt && runKeys.length) this._fetchPlan(runKeys, mode);
    const dryOf = this._planPreview?.dry ?? new Map<string, string>();
    const wetOf = this._planPreview?.wet ?? new Map<string, string>();
    // Sequence hint (docs/19 follow-up, TODO #2) — see _renderMetaBar for the
    // same idea in the landscape meta bar; here it's per-row instead of a count.
    const unsequenced = new Set(hasInt ? (this._planPreview?.unsequenced ?? []) : []);
    const unassigned = new Set(this._unassignedRooms(runKeys, mode, hasInt));
    const showDry = mode !== "wet";
    const showWet = mode !== "dry";
    const badge = (d: number | null) => (d === null ? "—" : d < 1 ? "<1d" : Math.round(d) + "d");
    const modeBtn = (m: "dry" | "wet" | "both", icon: string, label: string) => html`
      <button class="dock-mode ${mode === m ? "on" : ""}"
        @click=${(e: Event) => { e.stopPropagation(); this._planMode = m; }}>
        <ha-icon icon=${icon}></ha-icon><span>${label}</span>
      </button>`;
    const runHid = "dock-run";
    // docs/25 §7c (field diskuze 2026-07-24): portrait cockpit minimalism drops
    // the permanent room list — selection stays map-tap-only, per-room detail
    // (age/pin) moves to hold-to-inspect on the room (§7b, not yet shipped).
    // `debug_dense_dock` (§7e) is the escape hatch back to today's dense view.
    // Deliberately a SEPARATE flag from `debug_room_progress` (field-caught
    // 2026-07-24: a user who keeps `debug_room_progress` on for coverage-%
    // debugging — the map gauges it draws, `_renderRoomGauge`, are dock-
    // independent — would otherwise never see the new minimalist cockpit at
    // all, defeating the point of shipping it). Landscape's dock/picker
    // sidebar is a separate, established design (docs/18/19 A5) and keeps the
    // room list unconditionally — this gate only ever hides it in portrait.
    const showRoomList = this._profile !== "portrait" || !!this._config.debug_dense_dock;
    return html`
      <div class="dock">
        ${withPicker ? this._renderVacuumPicker() : nothing}
        ${this._renderVacuumIconStrip()}
        ${/* Dry/wet PATH visibility on the map (view_layers) — a different concern
             from the dock-mode buttons below (which pick what to CLEAN). Landscape
             already gets this from the meta bar's `tools` region (docs/19 A4), but
             portrait has no `tools` region at all, so it silently had no way to
             toggle path visibility (field feedback 2026-07-17). Reuses the same
             compact toggle, just placed in the dock column instead of a meta bar. */
          this._profile === "portrait" ? html`
            <div class="dock-layers">${this._renderLayerToggleCompact(vacs)}
              ${this._config.layout ? html`<button class="mtbtn ${this._flipEff ? "on" : ""}"
                  title="Flip map 180° for this screen (this session only)"
                  @click=${() => this._toggleFlipLive()}>
                <ha-icon icon="mdi:flip-vertical"></ha-icon>
              </button>` : nothing}
              ${(() => {
                const alignCand = this._alignCandidates(vacs);
                return alignCand.length ? html`<button class="mtbtn" title="Align — full-screen manual floorplan seating"
                    @click=${() => this._openAlign(alignCand[0])}>
                  <ha-icon icon="mdi:vector-square-edit"></ha-icon>
                </button>` : nothing;
              })()}
            </div>
          ` : nothing}
        ${withRun ? html`
          <div class="dock-head">
            ${modeBtn("dry", "mdi:broom", "Dry")}${modeBtn("wet", "mdi:water", "Wet")}${modeBtn("both", "mdi:water-plus", "Both")}
            ${vacs.some((v) => this._dockCaps(v).hasDock || this._careItems(v).length > 0) ? html`
              <button class="dock-mode dock-mode--dock ${this._dockSheetOpen ? "on" : ""}"
                @click=${(e: Event) => { e.stopPropagation(); this._dockSheetOpen = !this._dockSheetOpen; }}>
                <ha-icon icon="mdi:home-outline"></ha-icon><span>Dock</span>
                ${this._dockNeedsAttention() ? html`<span class="dock-mode-dot"></span>` : nothing}
              </button>` : nothing}
          </div>` : nothing}
        ${this._renderModeSheet()}
        ${this._renderDockSheet()}
        ${!showRoomList ? nothing : html`<div class="dock-rows">
          ${rooms.map(({ r, v }) => {
            const rec = this._intRoomRec(v, r);
            const dry = this._ageDaysFromIso(rec?.dry);
            const wet = this._ageDaysFromIso(rec?.wet);
            const cov = this._roomCoverageRec(v, r);
            const covBadge = (pct: number | null | undefined) => (pct == null ? "—" : pct + "%");
            const sel = this._isRoomSelectedAny(r.key, vacs);
            // Cycle relative to what THIS chip currently shows (dry vs. wet
            // can differ), not the raw pin store — see _cycleRoomPin. Each
            // chip cycles only among vacuums capable of ITS OWN type
            // (2026-07-25 fix) — a room with dry-only + wet-only vacuums
            // must not let the dry chip's cycle land on the wet-only one.
            const canCycleDry = this._pinCandidates(r.key, "dry").length > 1;
            const canCycleWet = this._pinCandidates(r.key, "wet").length > 1;
            const pinTap = (kind: "dry" | "wet", shown: string | undefined) =>
              (kind === "dry" ? canCycleDry : canCycleWet)
                ? (e: Event) => { e.stopPropagation(); this._cycleRoomPin(r.key, kind, shown); }
                : undefined;
            const locked = this._mapMode !== "normal";
            return html`
              <button class="dock-row ${sel ? "on" : ""} ${locked ? "room-overlay--locked" : ""}" ?disabled=${locked}
                title=${locked ? "Room selection is off while placing a pin/zone" : ""}
                @click=${() => { if (!locked) this._toggleRoomAcross(r.key, vacs); }}>
                <ha-icon class="dock-ric" icon=${r.icon ?? "mdi:square"}></ha-icon>
                <span class="dock-name">${r.name ?? r.key}</span>
                <span class="dock-info">
                  ${sel && unassigned.has(r.key) ? html`<ha-icon class="dock-unassigned" icon="mdi:robot-off"
                    title="No available robot for this room's ${mode} pass — check that a vacuum is configured with the right role and knows this room."></ha-icon>` : nothing}
                  ${sel && unsequenced.has(r.key) ? html`<ha-icon class="dock-unseq" icon="mdi:sort-variant-off"
                    title="No cleaning order set for this room — the time estimate may be off. Set the order in the card editor's Maps tab."></ha-icon>` : nothing}
                  <span class="dock-ages">
                    <span class="dock-age">${this._renderProgChip(this._roomProgForType(r, vacs, "dry"))}<ha-icon icon="mdi:broom"></ha-icon><b style=${styleMap({ color: this._colorForAgeDays(dry) })}>${badge(dry)}</b><small class="dock-cov" title="Last completed dry clean's coverage">${covBadge(cov?.dry)}</small></span>
                    <span class="dock-age">${this._renderProgChip(this._roomProgForType(r, vacs, "wet"))}<ha-icon icon="mdi:water"></ha-icon><b style=${styleMap({ color: this._colorForAgeDays(wet) })}>${badge(wet)}</b><small class="dock-cov" title="Last completed wet clean's coverage">${covBadge(cov?.wet)}</small></span>
                  </span>
                  ${hasInt && sel ? html`
                    <span class="dock-avatars">
                      ${showDry ? this._vacChip(dryOf.get(r.key), pinTap("dry", dryOf.get(r.key))) : nothing}
                      ${showWet ? this._vacChip(wetOf.get(r.key), pinTap("wet", wetOf.get(r.key))) : nothing}
                    </span>` : nothing}
                </span>
              </button>`;
          })}
        </div>`}
        ${withRun && hasInt ? html`
          <div class="dock-foot">
            <span class="dock-est">${selKeys.length ? selKeys.length + " rooms · ~" + this._etaFor(runKeys, mode, hasInt) + " min" : "Whole home · ~" + this._etaFor(runKeys, mode, hasInt) + " min"}
              ${unassigned.size ? html`<ha-icon class="dock-unassigned" icon="mdi:robot-off"
                title="${unassigned.size} selected room${unassigned.size > 1 ? "s have" : " has"} no available robot for the ${mode} pass — it/they will be silently skipped. Check vacuum roles/config."></ha-icon>` : nothing}
              ${unsequenced.size ? html`<ha-icon class="dock-unseq" icon="mdi:sort-variant-off"
                title="${unsequenced.size} selected room${unsequenced.size > 1 ? "s have" : " has"} no cleaning order set — the time above may be off. Set the order in the card editor's Maps tab."></ha-icon>` : nothing}</span>
            <button class="action-btn dock-run ${this._holdId === runHid ? "action-btn--holding" : ""}"
              ?disabled=${!runKeys.length}
              @pointerdown=${runKeys.length ? this._holdStart(runHid, () => this._runOrchestrated(runKeys, this._planMode)) : nothing}
              @pointermove=${this._holdMove}
              @pointerup=${this._holdEnd}
              @pointerleave=${this._holdEnd}
              @pointercancel=${this._holdEnd}>
              <div class="hold-ring"></div>
              <ha-icon icon="mdi:play" style="--mdc-icon-size:16px"></ha-icon>
              <span style="font-size:12px">Start · hold</span>
            </button>
          </div>` : nothing}
      </div>
    `;
  }

  /** docs/25 §7 field follow-up: true when ANY vacuum's dock reports a real
   *  error (`dock_error_status`, docs/26 §1 vrstva A). Deliberately narrow —
   *  `water_shortage_status`/`dust_collection_status`'s exact value meanings
   *  aren't documented anywhere upstream (verified against python-roborock's
   *  source and docs), so guessing thresholds for THOSE risks a false badge.
   *  `dock_error_status` is the one field where "present, nonzero" is an
   *  unambiguous problem regardless of the exact code. */
  private _dockNeedsAttention(): boolean {
    return this._config.vacuums.some((v) => {
      const dock = this._intAttrs(v)?.dock_status as Record<string, unknown> | undefined;
      const err = dock?.dock_error_status;
      return err !== null && err !== undefined && err !== 0 && err !== "0";
    });
  }

  /** docs/25 §10 third follow-up (2026-07-24): dock hardware tier, read from
   *  `dock_status.dock_type` (already flowing through the integration sensor,
   *  zero new backend work). `dock_type` maps to `python-roborock`'s
   *  `RoborockDockTypeCode` — live-verified against the user's real HA
   *  (dock_type null/absent → S6, `1` → S7 MaxV, `10` → S8 MaxV Ultra):
   *    null/undefined/0  → no dock at all (S6 — not even auto-empty)
   *    1 (auto_empty_dock) / 5 (auto_empty_dock_pure) → empty-only dock
   *    everything else (3 empty_wash_fill, 6 s7_max_ultra, 7 s8, 10
   *      s8_maxv_ultra, ...) → full wash+dry(+plumbing) dock
   *  "empty" tier gets ONLY the Empty action and none of the dock-mounted
   *  consumables (dock brush/strainer) — those entities can technically
   *  exist in HA's registry even on an empty-only unit (the integration
   *  creates them per device *model*, not per physically-installed
   *  accessory) but report "unavailable"; confirmed live on the user's S7
   *  MaxV before this fix shipped. */
  private _dockTier(vac: VacuumConfig): "none" | "empty" | "full" {
    const dt = this._intAttrs(vac)?.dock_status?.dock_type as number | null | undefined;
    if (dt === null || dt === undefined || dt === 0) return "none";
    if (dt === 1 || dt === 5) return "empty";
    return "full";
  }

  /** Which dock cycles this vacuum's dock can actually run (2026-09-02).
   *
   *  Preferred source is `dock_status.features` — the backend reads
   *  `properties_api.device_features.dock_features`, the very same
   *  `RoborockDockFeatures` flags HA 2026.9's own dock switches gate on. That
   *  retires the guesswork docs/26 §3 recorded ("HA has no documented way to
   *  report which dock accessories are installed") and the hand-maintained
   *  `dock_type` tier table it forced (`_dockTier` above).
   *
   *  `_dockTier` stays as the fallback for an older integration paired with this
   *  card — the tier is a coarser answer, not a wrong one, so degrading to it is
   *  honest. `has_dock` is only trusted when the backend actually reported it;
   *  an all-null `features` block (library renamed something) falls back too,
   *  rather than silently hiding every dock button.
   *
   *  Pump and self-clean have no capability flag of their own; both act on the
   *  cleaning sink, which only exists on a washable dock, so they follow `wash`. */
  private _dockCaps(vac: VacuumConfig): { hasDock: boolean; collect: boolean; wash: boolean; dry: boolean } {
    const f = this._intAttrs(vac)?.dock_status?.features as
      | Record<string, boolean | null> | undefined;
    if (f && (f.has_dock !== null && f.has_dock !== undefined)) {
      return {
        hasDock: !!f.has_dock,
        collect: !!f.is_collectable,
        wash: !!f.is_washable,
        dry: !!f.is_dryable,
      };
    }
    const tier = this._dockTier(vac);
    return {
      hasDock: tier !== "none",
      collect: tier !== "none",
      wash: tier === "full",
      dry: tier === "full",
    };
  }

  /** Cache key for anything that branches on dock capabilities — see `_careItems`. */
  private _dockCapsKey(vac: VacuumConfig): string {
    const c = this._dockCaps(vac);
    return `${c.hasDock ? 1 : 0}${c.collect ? 1 : 0}${c.wash ? 1 : 0}${c.dry ? 1 : 0}`;
  }

  /** Is a dock cycle running right now? Backend-derived (`dock_status.running`,
   *  mirroring HA 2026.9's dock switches); `null` when this integration version
   *  does not publish it, which the caller renders as a plain start button. */
  private _dockRunning(vac: VacuumConfig, kind: "empty" | "wash" | "dry"): boolean | null {
    const r = this._intAttrs(vac)?.dock_status?.running as
      | Record<string, boolean | null> | undefined;
    if (!r) return null;
    const v = r[kind];
    return v === null || v === undefined ? null : !!v;
  }

  /** docs/25 §7 field follow-up (2026-07-24): dock sheet — per-vacuum tabs +
   *  Empty/Wash/Dry actions (`anyvac.dock_*`, confirmed commands per docs/26
   *  §3, live-verified against the field-reporting user's real HW). Toggled
   *  from `.dock-head`'s Dock button when it's rendered (landscape), or from
   *  the START bar's right segment when it isn't (portrait, docs/25 §10
   *  follow-up 2026-07-25) — either way `_dockSheetOpen` renders it here,
   *  in-flow inside the `dock` region (which already has its own
   *  `overflow:auto`, docs/18 `regionStyles()`) rather than as a floating
   *  overlay — deliberately avoids `position:fixed`/absolute layering in a
   *  region that's had real mobile-crash history (docs/21 §5b) tied to grid
   *  ownership; an in-flow panel can't touch that class of bug. Raw
   *  `dock_status` fields shown only behind `debug` (§7c precedent) — their
   *  value encodings aren't documented upstream, so surfacing them as
   *  polished UI would overclaim confidence we don't have. */
  private _renderDockSheet() {
    if (!this._dockSheetOpen) return nothing;
    // A vacuum with no dock at all (tier "none", e.g. S6) still belongs in
    // this sheet's tab list if it has its own body consumables to show
    // (main/side brush, filter, sensor — these live on the vacuum's OWN
    // device and have nothing to do with dock hardware). Dropped from the
    // list entirely only when it has neither dock actions nor care rows.
    const vacs = this._config.vacuums.filter(
      (v) => this._dockCaps(v).hasDock || this._careItems(v).length > 0
    );
    if (!vacs.length) return nothing;
    const idx = Math.min(this._dockSheetIdx, vacs.length - 1);
    const vac = vacs[idx];
    const caps = this._dockCaps(vac);
    const dock = this._intAttrs(vac)?.dock_status as Record<string, unknown> | undefined;
    const act = (service: string, action?: "start" | "stop") => () =>
      void this._call("anyvac", service, {
        entity_id: vac.entity,
        ...(action ? { action } : {}),
      });
    /** Empty/wash/dry are cycles the dock ends on its own, so the button is a
     *  toggle: it starts one, and turns into Stop while one is running
     *  (`anyvac.dock_*` grew an `action` parameter for this, mirroring the
     *  start/stop pairs HA 2026.9's own dock switches use). Running state comes
     *  from the backend, never re-derived here (docs/14 rule 1); when the paired
     *  integration is too old to publish it, `_dockRunning` returns null and the
     *  button stays a plain start — no guessing, no dead Stop button. */
    const cycle = (
      service: string,
      kind: "empty" | "wash" | "dry",
      icon: string,
      label: string
    ) => {
      const running = this._dockRunning(vac, kind);
      return html`
        <button class="dock-sheet-action ${running ? "running" : ""}"
          title=${running ? `Stop ${label.toLowerCase()}` : label}
          @click=${act(service, running ? "stop" : "start")}>
          <ha-icon icon=${running ? "mdi:stop" : icon}></ha-icon>
          <span>${running ? "Stop" : label}</span>
        </button>`;
    };
    const care = this._careItems(vac);
    // docs/25 §10 field-caught: `pendingKey` is the entity we actually WATCH
    // for the reset to land (the sensor, when we have one — falls back to
    // the button's own id for binary-only rows with no time-left sensor).
    const reset = (row: CareRow) => (e: Event) => {
      e.stopPropagation();
      const pendingKey = row.entity ?? row.reset!;
      const next = new Map(this._careResetPending);
      next.set(pendingKey, Date.now());
      this._careResetPending = next;
      // Hard fallback: clear the spinner even if the poll never lands
      // (offline vacuum, entity removed, ...) — see `_careResetPending` doc.
      setTimeout(() => {
        if (this._careResetPending.get(pendingKey) === next.get(pendingKey)) {
          const cleared = new Map(this._careResetPending);
          cleared.delete(pendingKey);
          this._careResetPending = cleared;
        }
      }, 40000);
      void this._call("button", "press", { entity_id: row.reset! });
    };
    return html`
      <div class="dock-sheet">
        ${vacs.length > 1 ? html`
          <div class="dock-sheet-tabs">
            ${vacs.map((v, i) => html`
              <button class="dock-sheet-tab ${i === idx ? "on" : ""}"
                style=${styleMap({ borderColor: this._color(v) })}
                title=${v.name ?? v.entity}
                @click=${(e: Event) => { e.stopPropagation(); this._dockSheetIdx = i; }}>
                ${v.image ? html`<img src=${v.image} alt="" />` : html`<ha-icon icon="mdi:robot-vacuum" style=${styleMap({ color: this._color(v) })}></ha-icon>`}
              </button>`)}
          </div>` : nothing}
        ${this._config.debug && dock ? html`
          <div class="dock-sheet-debug">
            ${
              // `dock_status` was all scalars until 1.3.0 added the nested
              // `features` and `running` objects — `String(val)` turned those
              // into "[object Object]", which is exactly the information the
              // debug strip exists to show (field-caught 2026-09-06). Nested
              // objects are flattened one level into `parent.key` rows and
              // their false/null entries are KEPT: for a capability flag,
              // "reported false" and "not reported" are different answers, and
              // telling them apart is the whole point of looking here.
              Object.entries(dock).flatMap(([k, val]) =>
                val !== null && typeof val === "object" && !Array.isArray(val)
                  ? Object.entries(val as Record<string, unknown>)
                      .map(([sk, sv]) => [`${k}.${sk}`, sv] as const)
                  : [[k, val] as const]
              )
                .filter(([k, val]) => val !== undefined && (val !== null || k.includes(".")))
                .map(([k, val]) => html`<span>${k}: ${val === null ? "null" : String(val)}</span>`)
            }
          </div>` : nothing}
        ${caps.hasDock ? html`
          <div class="dock-sheet-actions">
            ${caps.collect ? cycle("dock_empty", "empty", "mdi:delete-empty", "Empty") : nothing}
            ${caps.wash ? cycle("dock_wash", "wash", "mdi:water", "Wash") : nothing}
            ${caps.dry ? cycle("dock_dry", "dry", "mdi:hair-dryer", "Dry") : nothing}
            ${caps.wash ? html`
              <button class="dock-sheet-action" @click=${act("dock_pump")}>
                <ha-icon icon="mdi:water-pump"></ha-icon><span>Pump</span>
              </button>
              <button class="dock-sheet-action" @click=${act("dock_self_clean")}>
                <ha-icon icon="mdi:autorenew"></ha-icon><span>Self-clean</span>
              </button>` : nothing}
          </div>` : nothing}
        ${care.length ? html`
          <div class="dock-sheet-care">
            ${care.map((row) => html`
              <div class="dock-sheet-care-row">
                <span class="dock-sheet-care-label">${row.label}</span>
                ${row.binary
                  ? html`<span class="dock-sheet-care-badge ${this.hass.states[row.binary]?.state === "on" ? "warn" : ""}">
                      ${this.hass.states[row.binary]?.state === "on" ? "⚠" : "OK"}
                    </span>`
                  : html`<span class="dock-sheet-care-value">${this._careValue(row)}</span>`}
                ${row.reset ? (() => {
                  const pending = this._careResetPending.has(row.entity ?? row.reset!);
                  return html`
                    <button class="dock-sheet-care-reset ${pending ? "pending" : ""}"
                      title="Reset" ?disabled=${pending} @click=${reset(row)}>
                      <ha-icon icon=${pending ? "mdi:loading" : "mdi:refresh"}></ha-icon>
                    </button>`;
                })() : nothing}
              </div>`)}
          </div>` : nothing}
      </div>
    `;
  }

  /** docs/25 §10 follow-up (2026-07-25): mode picker sheet — the START bar's
   *  left segment opens this (see `_renderStartBar`), same in-flow panel
   *  pattern as `_renderDockSheet` and reusing the identical `.dock-mode`
   *  button look (dry/wet/both), just three buttons instead of the dock
   *  sheet's actions. Picking a mode closes the sheet immediately — there's
   *  nothing else to configure here, unlike the dock sheet which stays open
   *  for repeated care/action taps. */
  private _renderModeSheet() {
    if (!this._modeSheetOpen) return nothing;
    const mode = this._planMode;
    const pick = (m: "dry" | "wet" | "both") => (e: Event) => {
      e.stopPropagation();
      this._planMode = m;
      this._modeSheetOpen = false;
    };
    const modeBtn = (m: "dry" | "wet" | "both", icon: string, label: string) => html`
      <button class="dock-mode ${mode === m ? "on" : ""}" @click=${pick(m)}>
        <ha-icon icon=${icon}></ha-icon><span>${label}</span>
      </button>`;
    return html`
      <div class="dock-sheet">
        <div class="dock-head">
          ${modeBtn("dry", "mdi:broom", "Dry")}${modeBtn("wet", "mdi:water", "Wet")}${modeBtn("both", "mdi:water-plus", "Both")}
        </div>
      </div>
    `;
  }

  /** START region (portrait bottom bar, docs/18 §7d): ALWAYS the orchestrated
   *  intent (anyvac.clean); while anything runs it flips to a cancel bar.
   *  docs/25 §5 (cockpit minimalism): no explicit room selection is NOT a dead
   *  end — it means "whole home", and START stays immediately pressable from
   *  the moment the card opens. Room selection / Dry-Wet-Both stay on screen
   *  as refinement, not as a gate the user has to clear first.
   *  docs/25 §10 follow-up (2026-07-25): three-segment bar, mirroring the
   *  manufacturer app's bottom bar (mode / START / Dock, docs/25 §10) — the
   *  mode buttons and Dock button that used to live in `.dock-head` above
   *  the bar move down into the bar itself (`_renderDock` only still renders
   *  `.dock-head` when there's no separate `start` region to host them,
   *  i.e. landscape). Both side segments just toggle a sheet rendered back
   *  in the `dock` region (`_renderModeSheet`/`_renderDockSheet`) — the
   *  bar itself stays a fixed-height strip, not an expandable panel. */
  private _renderStartBar() {
    const vacs = this._config.vacuums;
    const hasInt = vacs.some((v) => this._intAttrs(v));
    const selKeys = this._allRoomKeys().filter((k) => this._isRoomSelectedAny(k, vacs));
    const runKeys = selKeys.length ? selKeys : this._allRoomKeys();
    const anyCleaning = vacs.some((v) => this._isCleaning(v));
    const hid = "startbar";
    const modeIcon = { dry: "mdi:broom", wet: "mdi:water", both: "mdi:water-plus" }[this._planMode];
    const modeLabel = { dry: "Dry", wet: "Wet", both: "Both" }[this._planMode];
    const modeSeg = html`
      <button class="start-seg start-seg--mode ${this._modeSheetOpen ? "on" : ""}"
        title="Clean type — tap to change"
        @click=${(e: Event) => { e.stopPropagation(); this._dockSheetOpen = false; this._modeSheetOpen = !this._modeSheetOpen; }}>
        <ha-icon icon=${modeIcon}></ha-icon>
        <span>${modeLabel}</span>
      </button>`;
    const showDock = vacs.some((v) => this._dockCaps(v).hasDock || this._careItems(v).length > 0);
    const dockSeg = showDock ? html`
      <button class="start-seg start-seg--dock ${this._dockSheetOpen ? "on" : ""}"
        title="Dock control"
        @click=${(e: Event) => { e.stopPropagation(); this._modeSheetOpen = false; this._dockSheetOpen = !this._dockSheetOpen; }}>
        <ha-icon icon="mdi:home-outline"></ha-icon>
        ${this._dockNeedsAttention() ? html`<span class="dock-mode-dot"></span>` : nothing}
      </button>` : nothing;
    if (anyCleaning) {
      return html`
        <div class="start-row">
          ${modeSeg}
          <button class="start-bar start-bar--cancel ${this._holdId === hid ? "action-btn--holding" : ""}"
            @pointerdown=${this._holdStart(hid, () => {
              if (hasInt) void this._call("anyvac", "cancel", {});
              else for (const v of vacs) { if (this._isCleaning(v)) void this._pause(v); }
            })}
            @pointermove=${this._holdMove}
            @pointerup=${this._holdEnd} @pointerleave=${this._holdEnd} @pointercancel=${this._holdEnd}>
            <div class="hold-ring"></div>
            <ha-icon icon="mdi:stop"></ha-icon>
            <span>CANCEL · hold</span>
          </button>
          ${dockSeg}
        </div>`;
    }
    const canStart = hasInt && runKeys.length > 0;
    const est = this._etaFor(runKeys, this._planMode, hasInt);
    const scopeLabel = selKeys.length ? selKeys.length + (selKeys.length === 1 ? " room" : " rooms") : "whole home";
    return html`
      <div class="start-row">
        ${modeSeg}
        <button class="start-bar ${canStart && this._holdId === hid ? "action-btn--holding" : ""}"
          ?disabled=${!canStart}
          title=${hasInt ? "" : "Requires the AnyVac integration"}
          @pointerdown=${canStart ? this._holdStart(hid, () => this._runOrchestrated(runKeys, this._planMode)) : nothing}
          @pointermove=${this._holdMove}
          @pointerup=${this._holdEnd} @pointerleave=${this._holdEnd} @pointercancel=${this._holdEnd}>
          <div class="hold-ring"></div>
          <ha-icon icon="mdi:play"></ha-icon>
          <span>START · ${scopeLabel}${est ? " · ~" + est + " min" : ""}</span>
        </button>
        ${dockSeg}
      </div>`;
  }

  /** Setting presets for a vacuum; falls back to a single default synthesized from clean_action. */
  private _settingPresets(vac: VacuumConfig): SettingPreset[] {
    if (vac.presets && vac.presets.length) return vac.presets;
    const ca = vac.clean_action as Partial<NativeAutoCleanAction> | undefined;
    return [{
      id: "default",
      label: "Default",
      suction_level: ca?.suction_level,
      mop_mode: ca?.mop_mode,
      mop_intensity: ca?.mop_intensity,
      repeat: ca?.repeat,
    }];
  }
  private _activePresetId(vac: VacuumConfig): string {
    const presets = this._settingPresets(vac);
    const sel = this._activePresets.get(vac.entity);
    if (sel && presets.some((p) => p.id === sel)) return sel;
    return presets[0]?.id ?? "default";
  }
  private _activePreset(vac: VacuumConfig): SettingPreset {
    const presets = this._settingPresets(vac);
    const id = this._activePresetId(vac);
    return presets.find((p) => p.id === id) ?? presets[0];
  }
  private _setActivePreset(vac: VacuumConfig, id: string): void {
    const next = new Map(this._activePresets);
    next.set(vac.entity, id);
    this._activePresets = next;
  }

  /** v1.1.0 (2026-08-03): sits INLINE beside the START button now
   *  (`.actions--idle`, `_renderActions`) instead of stacked above it as its
   *  own full-width wrapping row — was the single caller (only used from
   *  the idle branch of `_renderActions`), so repurposing its own layout in
   *  place is safe. `overflow-x:auto` degrades gracefully for 3+ presets
   *  (scrolls) instead of wrapping to a second row, which would reintroduce
   *  the extra vertical row this redesign removes; `flex-shrink:0` on each
   *  chip keeps them from being squashed illegibly narrow by the sibling
   *  START button's own `flex:1`. */
  private _renderPresetChips(vac: VacuumConfig) {
    const presets = this._settingPresets(vac);
    if (presets.length < 2) return nothing;  // only when there is a real choice
    const activeId = this._activePresetId(vac);
    const color = this._color(vac);
    return html`
      <div class="preset-chip-row">
        ${presets.map((p) => {
          const active = p.id === activeId;
          return html`<button
            @click=${(e: Event) => { e.stopPropagation(); this._setActivePreset(vac, p.id); }}
            style=${styleMap({
              display: "inline-flex", alignItems: "center", gap: "4px", flexShrink: "0",
              padding: "4px 10px", borderRadius: "14px", cursor: "pointer",
              fontSize: "12px", lineHeight: "1",
              border: "1px solid " + (active ? color : "rgba(var(--avc-ink-rgb),0.15)"),
              background: active ? this._colorBg(vac) : "rgba(var(--avc-ink-rgb),0.04)",
              color: active ? "rgb(var(--avc-ink-rgb))" : "rgba(var(--avc-ink-rgb),0.55)",
            })}
          >
            ${p.icon ? html`<ha-icon icon=${p.icon} style="--mdc-icon-size:14px"></ha-icon>` : nothing}
            <span>${p.label}</span>
          </button>`;
        })}
      </div>
    `;
  }

  private async _startClean(vac: VacuumConfig): Promise<void> {
    const selected = (this._roomsFor(vac)).filter((r) => this._isRoomSelected(r, vac));
    if (selected.length === 0) return;

    // ── Kontrakt v2: with the integration present, the START button sends an
    // INTENT restricted to THIS vacuum — segment resolve, settings application and
    // session tracking are backend-side (anyvac.clean, docs/14 §3.7). No in-flight
    // tracking, events or notifications here (docs/14 §3.1, §3.10).
    if (this._intAttrs(vac)) {
      const ap = this._activePreset(vac);
      const mode = this._liveCleanType(vac);
      const s: Record<string, unknown> = {};
      if (ap.suction_level) s.fan_speed = ap.suction_level;
      if (mode === "wet" && ap.mop_mode) s.mop_mode = ap.mop_mode;
      if (mode === "wet" && ap.mop_intensity) s.mop_intensity = ap.mop_intensity;
      if (ap.repeat && ap.repeat > 1) s.repeat = ap.repeat;
      await this._call("anyvac", "clean", {
        rooms: selected.map((r) => r.key),
        mode,
        vacuums: [vac.entity],
        // Settings are per-vacuum since 2026-07-26 (backend now expects
        // {kind: {vacuum_ref: {...}}}, not a flat {kind: {...}} shared object).
        ...(Object.keys(s).length ? { settings: { [mode]: { [vac.entity]: s } } } : {}),
      });
      return;
    }

    // ── Degraded mode (no integration, docs/14 §8): dumb direct commands. ──
    if (!vac.clean_action) return;

    // Script strategy
    if (vac.clean_action.type === "script") {
      const action = vac.clean_action as ScriptCleanAction;
      const variables: Record<string, unknown> = {};
      for (const [key, template] of Object.entries(action.variables ?? {})) {
        variables[key] = template
          .replace("{{ entity }}", vac.entity)
          .replace("{{ selected_segments }}", JSON.stringify(selected.map((r) => r.segment_id).filter(Boolean)))
          .replace("{{ selected_room_keys }}", JSON.stringify(selected.map((r) => r.key)))
          .replace("{{ selected_area_ids }}", JSON.stringify(selected.map((r) => r.area_id).filter(Boolean)));
      }
      await this._call("script", "turn_on", { entity_id: action.entity_id, variables });
      return;
    }

    // Native variants: pre-set fan / mop from the active setting preset (default
    // preset = the values from clean_action, so behaviour is unchanged when no
    // custom presets are defined), then call vacuum.
    const nativeAction = vac.clean_action as NativeCleanAction | NativeAreaCleanAction | NativeAutoCleanAction;
    const ap = this._activePreset(vac);
    const apMopMode = ap.mop_mode ?? nativeAction.mop_mode;
    const apMopInt = ap.mop_intensity ?? nativeAction.mop_intensity;
    const apSuction = ap.suction_level ?? nativeAction.suction_level;
    if (nativeAction.mop_mode_entity && apMopMode) {
      await this._call("select", "select_option", { entity_id: nativeAction.mop_mode_entity, option: apMopMode });
    }
    if (nativeAction.mop_intensity_entity && apMopInt) {
      await this._call("select", "select_option", { entity_id: nativeAction.mop_intensity_entity, option: apMopInt });
    }
    if (apSuction) {
      await this._call("vacuum", "set_fan_speed", { entity_id: vac.entity, fan_speed: apSuction });
    }

    if (vac.clean_action.type === "native-area") {
      // Uses HA vacuum.clean_area — area_id resolved via area_mappings. No repeat
      // (docs/13 A1); repeat lives server-side in anyvac.clean (docs/14 §3.8).
      try {
        await this.hass.callService(
          "vacuum", "clean_area",
          { cleaning_area_id: selected.map((r) =>
              r.area_id ?? this._config.area_mappings?.[r.key] ?? r.key) },
          { entity_id: vac.entity },
        );
      } catch (err) {
        console.error("[anyvac-card] vacuum.clean_area failed:", err);
      }
    } else {
      // "native" / "native-auto" — segment IDs from the room config. The old
      // native-auto dynamic resolve (roborock.get_maps) was DELETED with the plan
      // builder (docs/14 §3.7): with an integration the backend resolves segments,
      // without one the card only knows its configured segment_ids.
      const action = vac.clean_action as NativeCleanAction | NativeAutoCleanAction;
      const segments = selected.map((r) => r.segment_id).filter((id): id is number => id !== undefined);
      if (!segments.length) {
        console.error("[anyvac-card] no configured segment_ids for the selection; aborting");
        return;
      }
      await this._call("vacuum", "send_command", {
        entity_id: vac.entity,
        command: "app_segment_clean",
        params: [{ segments, repeat: action.repeat ?? 1 }],
      });
    }
  }

  // ── Render: badges ──────────────────────────────────────────────────────

  private _renderBadge(vac: VacuumConfig, index: number) {
    const active = this._shownSet.has(index);
    const cleaning = this._isCleaning(vac);
    const color = this._color(vac);
    const name = vac.name ?? vac.entity.split(".")[1] ?? vac.entity;
    const holding = this._holdId === "badge-" + index;
    // docs/25 §7a / docs/28 §5: ring + glow now read STATE ("what is it
    // doing"), not identity — mirrors the portrait icon strip (0.69.0,
    // `_renderVacuumIconStrip`'s `_statusInfo(v)[1]`). Only this landscape
    // picker badge kept the identity ring until now (0.69.0's changelog
    // explicitly left it alone). Background wash + the icon/photo still
    // carry identity, unchanged — same split as the icon strip: one visual
    // language for "what it's doing", a separate one for "which one is it".
    // Not hex-alpha-suffixed like the old identity `color + "80"` trick was —
    // several very common statuses (docked/idle/charging) are `rgba(...)`
    // literals in STATUS_MAP (const.ts), not hex, so appending a hex alpha
    // suffix to those would produce an invalid CSS value (silently dropped
    // border). Border WIDTH and glow RADIUS carry the active/cleaning
    // distinction instead — works identically for hex or rgba input.
    const statusColor = this._statusInfo(vac)[1];

    const bg = cleaning ? this._colorBgActive(vac) : active ? this._colorBg(vac) : "rgba(var(--avc-scrim-2-rgb),0.85)";
    const border = cleaning
      ? "3px solid " + statusColor
      : active
      ? "2px solid " + statusColor
      : "2px solid rgba(var(--avc-ink-rgb),0.18)";
    const shadow = cleaning
      ? "0 0 18px " + statusColor
      : active
      ? "0 0 6px " + statusColor
      : "none";

    return html`
      <button
        class="badge ${holding ? "badge--holding" : ""}"
        style=${styleMap({ background: bg, border, boxShadow: shadow })}
        @pointerdown=${(e: PointerEvent) => {
          e.preventDefault();
          this._cancelHold();
          this._holdId = "badge-" + index;
          this._holdTimer = setTimeout(() => {
            this._holdTimer = null;
            this._holdId = null;
            this._toggleShown(index);
          }, HOLD_DURATION_MS);
        }}
        @pointerup=${() => {
          if (this._holdTimer !== null) {
            this._cancelHold();
            this._shownSet = new Set([index]);
            this._saveShown();
          } else {
            this._holdId = null;
          }
        }}
        @pointerleave=${this._holdEnd}
        @pointercancel=${this._holdEnd}
        aria-pressed=${active ? "true" : "false"}
        aria-label=${name}
      >
        <div class="hold-ring"></div>
        ${vac.image
          ? html`<img class="badge-img" src=${vac.image} alt=${name} />`
          : html`<ha-icon class="badge-icon" icon="mdi:robot-vacuum" style=${styleMap({ color })}></ha-icon>`}
        <span class="badge-name" style=${styleMap({ color: active ? "rgb(var(--avc-ink-rgb))" : "rgba(var(--avc-ink-rgb),0.55)" })}>
          ${name}
        </span>
      </button>
    `;
  }

  /** Landscape-only `picker` region (docs/19 A5): slim vertical vacuum
   *  selector, right column, directly above the room-list `dock`. Reuses
   *  `_renderBadge` (same tap-to-focus / hold-to-multiselect behaviour as the
   *  old horizontal badge-row tabs) just stacked vertically instead. */
  private _renderVacuumPicker() {
    const vacs = this._config.vacuums;
    if (!vacs.length) return nothing;
    return html`<div class="vac-picker">${vacs.map((v, i) => this._renderBadge(v, i))}</div>`;
  }

  private _renderGlobalBadge(ga: GlobalAction, idx: number) {
    const active = this._isGlobalActive(ga);
    const color = this._resolveColor(ga.color, "orange");
    const holdId = "global-" + idx;
    const holding = this._holdId === holdId;

    const bg = active ? this._resolveBg(ga.color, "orange", true) : "rgba(var(--avc-scrim-2-rgb),0.85)";
    const border = active ? "3px solid " + color : "2px solid rgba(var(--avc-ink-rgb),0.18)";
    const shadow = active ? "0 0 18px " + color + "B0" : "none";

    return html`
      <button
        class="badge badge--global ${holding ? "badge--holding" : ""}"
        style=${styleMap({ background: bg, border, boxShadow: shadow })}
        @pointerdown=${this._holdStart(holdId, () => this._triggerGlobal(ga))}
        @pointermove=${this._holdMove}
        @pointerup=${this._holdEnd}
        @pointerleave=${this._holdEnd}
        @pointercancel=${this._holdEnd}
        aria-label=${ga.name}
        title=${"Hold to trigger: " + ga.name}
      >
        <div class="hold-ring"></div>
        ${ga.image
          ? html`<img class="badge-img" src=${ga.image} alt=${ga.name} />`
          : html`<ha-icon class="badge-icon" icon="mdi:home-floor-a" style=${styleMap({ color })}></ha-icon>`}
        <span class="badge-name" style=${styleMap({ color: active ? "rgb(var(--avc-ink-rgb))" : "rgba(var(--avc-ink-rgb),0.55)" })}>
          ${ga.name}
        </span>
      </button>
    `;
  }

  // ── Render: map ─────────────────────────────────────────────────────────

  // ── Pin & go / zone (integration-only; docs/14 §3.6, kontrakt v2) ────────────
  // The card sends clicks as PERCENT of the map image to anyvac.goto /
  // anyvac.zone_clean; the pct→px→mm conversion is backend-side. All client-side
  // affine math (solve3 / _affine / _intMapToVac / _gotoMm) was deleted — mm no
  // longer exist in the card.
  private _toggleMode(entity: string, mode: "pin" | "zone"): void {
    if (this._mapMode === mode && this._modeEntity === entity) { this._mapMode = "normal"; this._modeEntity = null; }
    else { this._mapMode = mode; this._modeEntity = entity; }
  }
  /** Arm Pin & Go / Zone from the consolidated meta bar (docs/19) — a "*" sentinel
   *  instead of one hard-coded vacuum. In merged mode this defers the target choice:
   *  the capture (click/drag) happens once on the shared map, then the user picks
   *  which vacuum executes it on that vacuum's own status card (`_confirmPin`/
   *  `_confirmZone`). In split mode each vacuum has its own separate map region, so
   *  "*" just means "whichever map you click into" — unambiguous, same immediate
   *  execution as the legacy per-vacuum tools. Distinct from `_toggleMode`, which
   *  still drives the legacy single-target flow untouched. */
  private _armMode(mode: "pin" | "zone"): void {
    if (this._mapMode === mode && this._modeEntity === "*") { this._mapMode = "normal"; this._modeEntity = null; }
    else {
      this._mapMode = mode; this._modeEntity = "*"; this._pinPending = null;
      this._zonePending = null; this._zoneRectShown = null; this._zoneEdit = null;
    }
  }
  /** Candidate vacuums for a merged-mode multi-candidate Pin & Go / Zone capture —
   *  anything with the integration + its own map entity (each has its own
   *  auto-seated transform, so one screen point/rectangle translates independently
   *  per vacuum via `_clickToContent`). */
  private _modeCandidates(): VacuumConfig[] {
    return this._config.vacuums.filter((v) => this._intAttrs(v) && this._mapEntityFor(v));
  }
  /** Whether this vacuum's map should render the click-catch / zone-rect layer:
   *  either it's the legacy hard-coded single target, or mode is armed "*" (meta
   *  bar) and this vacuum is a valid candidate. */
  private _isModeCandidate(v: VacuumConfig): boolean {
    return this._modeEntity === v.entity || (this._modeEntity === "*" && !!this._intAttrs(v) && !!this._mapEntityFor(v));
  }
  /** Whether `v` still has a stake in the current zone capture once arming has
   *  already ended — i.e. it's awaiting confirm (`_zonePending`) or it's still
   *  mid-draw (`_isModeCandidate`). Needed because move/resize editing of an
   *  already-drawn box (below) must keep working after the merged multi-candidate
   *  flow resets `_mapMode`/`_modeEntity` to normal/null on drop. */
  private _hasZoneEditTarget(v: VacuumConfig): boolean {
    return this._isModeCandidate(v) || !!this._zonePending?.[v.entity];
  }
  /** Hit-test a point (wrap-relative %) against a frozen zone box: a corner
   *  (within `H` percent) wins for resize, otherwise inside the box means move,
   *  otherwise null (click missed the box — caller should start a fresh draw). */
  private _zoneHit(
    box: { x0: number; y0: number; x1: number; y1: number }, x: number, y: number
  ): "nw" | "ne" | "sw" | "se" | "move" | null {
    const minX = Math.min(box.x0, box.x1), maxX = Math.max(box.x0, box.x1);
    const minY = Math.min(box.y0, box.y1), maxY = Math.max(box.y0, box.y1);
    const H = 4;
    const corners: Array<["nw" | "ne" | "sw" | "se", number, number]> = [
      ["nw", minX, minY], ["ne", maxX, minY], ["sw", minX, maxY], ["se", maxX, maxY],
    ];
    for (const [name, cx, cy] of corners) {
      if (Math.abs(x - cx) <= H && Math.abs(y - cy) <= H) return name;
    }
    if (x >= minX && x <= maxX && y >= minY && y <= maxY) return "move";
    return null;
  }
  /** Purely visual corner squares on a drawn zone box — the actual drag/resize
   *  hit-testing happens in `_onZoneDown` via `_zoneHit` against the overlaying
   *  `.map-clickcatch`, so these carry no pointer handlers of their own
   *  (`pointer-events: none`, same as `.zone-rect` itself). */
  private _renderZoneHandles() {
    return html`
      <div class="zone-handle zone-handle--nw"></div>
      <div class="zone-handle zone-handle--ne"></div>
      <div class="zone-handle zone-handle--sw"></div>
      <div class="zone-handle zone-handle--se"></div>
    `;
  }
  /** The rectangle to draw for this vacuum's map: the live drag while dragging,
   *  or the frozen box while a zone is pending confirm. Merged mode's multi
   *  candidate capture resets `_mapMode`/`_modeEntity` the instant the drag ends
   *  (§`_onZoneUp`), so the frozen box can't reuse `_isModeCandidate` — it's no
   *  longer "armed", it's "awaiting confirm". All candidates share the exact
   *  same on-screen rect there (that's the premise of merged mode), so it's
   *  drawn once, on the first shown vacuum; split mode draws it on whichever
   *  vacuum's own map it was actually dragged on. */
  private _zoneRectFor(v: VacuumConfig, isFirstShown: boolean): { x0: number; y0: number; x1: number; y1: number } | null {
    if (this._mapMode === "zone" && this._isModeCandidate(v) && this._zoneDrag) return this._zoneDrag;
    if (!this._zoneRectShown) return null;
    if (this._config.map_mode === "merged") return isFirstShown ? this._zoneRectShown : null;
    return this._zonePending?.[v.entity] ? this._zoneRectShown : null;
  }
  private _refreshMap(vac: VacuumConfig): void {
    const ent = this._mapEntityFor(vac);
    if (ent) void this.hass.callService("homeassistant", "update_entity", { entity_id: ent });
  }
  private _clampPct(v: number): number {
    return Math.min(100, Math.max(0, v));
  }
  private _onMapClick(vac: VacuumConfig, e: MouseEvent): void {
    if (this._mapMode !== "pin") return;
    if (!this._isModeCandidate(vac)) return;
    if (this._modeEntity === "*" && this._config.map_mode === "merged") {
      // Merged multi-candidate: capture the SAME screen point through every
      // candidate vacuum's own map transform (docs/40 §4.4: home px through the
      // shared identity crop for a home-frame candidate, legacy per-vacuum seat
      // otherwise — a mixed fleet may have both at once). Nothing is sent yet —
      // the user picks who actually goes there next, on that vacuum's own
      // status card.
      const pts: Record<string, { x: number; y: number; frame?: "home" }> = {};
      for (const cand of this._modeCandidates()) {
        const crop = this._homeFrameCropFor(cand);
        if (crop) {
          const hp = this._clickToHomePx(crop, e.clientX, e.clientY);
          if (hp) pts[cand.entity] = { x: hp.x, y: hp.y, frame: "home" };
          continue;
        }
        // docs/40 §5.B: no identity crop, but a live cesta-B fit exists —
        // invert through IT instead of falling to a legacy per-vacuum seat
        // that has no bearing on a foreign floorplan calibrated this way.
        const af = this._homeAnchorFitFor(cand, this._wrapAspect(this._baseHeightFor(cand)));
        if (af) {
          const hp = this._clickToHomeAnchorPx(af.fit, af.dims, this._wrapAspect(this._baseHeightFor(cand)), e.clientX, e.clientY);
          if (hp) pts[cand.entity] = { x: hp.x, y: hp.y, frame: "home" };
          continue;
        }
        const c = this._clickToContent(cand, e.clientX, e.clientY);
        if (c) pts[cand.entity] = { x: this._clampPct(c.x), y: this._clampPct(c.y) };
      }
      this._pinPending = Object.keys(pts).length ? pts : null;
      this._mapMode = "normal"; this._modeEntity = null;
      return;
    }
    // Legacy single-target immediate send (per-vacuum tools, and "*" in split mode
    // where each map is its own on-screen region — clicking it IS the unambiguous
    // choice of vacuum, so there's nothing to defer). docs/40 §4.4: a home-frame
    // candidate sends home px + frame: "home" instead of x_pct/y_pct.
    const crop = this._homeFrameCropFor(vac);
    const af = crop ? null : this._homeAnchorFitFor(vac, this._wrapAspect(this._baseHeightFor(vac)));
    const homeFrame = !!crop || !!af;
    const content = crop
      ? this._clickToHomePx(crop, e.clientX, e.clientY)
      : af
        ? this._clickToHomeAnchorPx(af.fit, af.dims, this._wrapAspect(this._baseHeightFor(vac)), e.clientX, e.clientY)
        : this._clickToContent(vac, e.clientX, e.clientY);
    this._dbg = content
      ? (homeFrame ? "goto (home) " + content.x.toFixed(1) + "px, " + content.y.toFixed(1) + "px" : "goto " + content.x.toFixed(1) + "%, " + content.y.toFixed(1) + "%")
      : "(map element not found)";
    if (content) {
      void this._call("anyvac", "goto", homeFrame
        ? { entity_id: vac.entity, frame: "home", x_home_px: content.x, y_home_px: content.y }
        : { entity_id: vac.entity, x_pct: this._clampPct(content.x), y_pct: this._clampPct(content.y) });
    }
    this._mapMode = "normal"; this._modeEntity = null;
  }
  /** Total ambient rotation (CSS degrees, clockwise) that `_renderResponsive`
   *  ACTUALLY applies to the map right now — 0, 90, 180 or 270. The single
   *  source of truth for "which way is the map turned": the renderer, the
   *  on-map assign-chip anchor and the click geometry below all read this one
   *  answer, so they can never disagree.
   *
   *  Note the two cases where the answer is 0 even though `_narrow` is true:
   *  the legacy path never flips, and the grid path bails out of rotating
   *  entirely while the map region is still unmeasured (`_mapRegW/_mapRegH`).
   *  Deriving rotation from `_narrow` alone — which several call sites used to
   *  do — is wrong in exactly those windows. */
  private _mapRotationDeg(): number {
    if (!this._config.layout) return this._narrow ? 90 : 0;   // legacy: 90° or nothing
    if (this._mapRegW <= 4 || this._mapRegH <= 4) return 0;   // region unmeasured -> renderer does not rotate
    return (this._narrow ? 90 : 0) + (this._flipEff ? 180 : 0);
  }

  /** Undo the ambient map rotation on a VIEWPORT-SPACE DELTA.
   *
   *  `.avc-rot`'s wrapper applies a pure rotation (plus a translate, which a
   *  delta is immune to, and never a scale), so a screen delta measured from
   *  an element's own centre is the pre-rotation delta turned by
   *  `_mapRotationDeg()`. Turning it back by the same angle recovers the
   *  element's own local frame — that is the whole of what Pin & Go and zone
   *  drawing were missing while the map was rotated (docs/13 A5). */
  private _unrotateDelta(dx: number, dy: number): { dx: number; dy: number } {
    const rot = ((this._mapRotationDeg() % 360) + 360) % 360;
    if (!rot) return { dx, dy };
    const t = (rot * Math.PI) / 180, c = Math.cos(t), s = Math.sin(t);
    return { dx: c * dx + s * dy, dy: -s * dx + c * dy };
  }

  /** Viewport point -> percent of `el`'s OWN, pre-rotation layout box.
   *  `getBoundingClientRect()` is the AXIS-ALIGNED box of the rotated element
   *  (width/height swapped at 90°/270°), so its centre is still the element's
   *  true centre — usable — but its width/height are not. Hence
   *  `offsetWidth`/`offsetHeight`, which are always the untransformed layout
   *  size, together with the un-rotated delta. */
  private _wrapPct(el: HTMLElement, clientX: number, clientY: number): { x: number; y: number } {
    const r = el.getBoundingClientRect();
    const d = this._unrotateDelta(clientX - (r.left + r.right) / 2, clientY - (r.top + r.bottom) / 2);
    const w = el.offsetWidth || 1, h = el.offsetHeight || 1;
    return { x: (d.dx / w + 0.5) * 100, y: (d.dy / h + 0.5) * 100 };
  }

  /** Inverse of `_wrapPct`: percent of `el`'s own box -> viewport point.
   *  Used to hand a drawn zone box back to `_clickToContent` as two screen
   *  corners, the way it has always worked — just rotation-aware now. */
  private _wrapPoint(el: HTMLElement, xPct: number, yPct: number): { x: number; y: number } {
    const r = el.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    const w = el.offsetWidth || 1, h = el.offsetHeight || 1;
    const lx = (xPct / 100 - 0.5) * w, ly = (yPct / 100 - 0.5) * h;
    const rot = ((this._mapRotationDeg() % 360) + 360) % 360;
    if (!rot) return { x: cx + lx, y: cy + ly };
    const t = (rot * Math.PI) / 180, c = Math.cos(t), s = Math.sin(t);
    return { x: cx + (c * lx - s * ly), y: cy + (s * lx + c * ly) };
  }

  // Map a viewport click into THIS vacuum's map content space (undo the ambient
  // map rotation first, then its own seat rotation/scale/offset) so pin&go /
  // zones are both seating-independent AND rotation-independent.
  private _clickToContent(vac: VacuumConfig, clientX: number, clientY: number): { x: number; y: number } | null {
    // The map is the coordinate authority (mm live there). Select this vacuum's own
    // map element — with several vacuums shown there are several .map-img and the
    // first one may belong to a different robot with different seating (docs/13 A4).
    // The floorplan is NOT a valid fallback: its content space has no mm mapping.
    const el = this._mapEntityFor(vac)
      ? (this.renderRoot?.querySelector(
          `.map-img[data-entity="${vac.entity.replace(/"/g, '\\"')}"]`
        ) as HTMLElement | null)
      : null;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    const tr = getComputedStyle(el).transform;
    const m = new DOMMatrix(tr === "none" ? undefined : tr);
    const det = m.a * m.d - m.b * m.c;
    if (Math.abs(det) < 1e-9) return null;
    // Ambient wrapper rotation first (map-wide), then this vacuum's own seat
    // matrix — they compose in that order on screen, so they invert in reverse.
    const d = this._unrotateDelta(clientX - cx, clientY - cy);
    const lx = (m.d * d.dx - m.c * d.dy) / det;
    const ly = (-m.b * d.dx + m.a * d.dy) / det;
    const w = el.offsetWidth || 1, h = el.offsetHeight || 1;
    return { x: (lx / w + 0.5) * 100, y: (ly / h + 0.5) * 100 };
  }
  /** docs/40 §4.4 (Fáze 3) home-frame twin of `_clickToContent`: viewport point
   *  -> floorplan-% (the shared base image's OWN content space — that image
   *  itself may carry a user offset/rotation/scale, `image_base.*`, same
   *  DOMMatrix-inversion technique as `_clickToContent`, just against
   *  `.image-base-img` instead of a per-vacuum `.map-img`) -> home px via
   *  `pctToCropPoint`. No per-vacuum seat enters this at all — every vacuum
   *  sharing `crop` gets the exact same point, which is the whole premise of
   *  the home frame (Fáze 1 registration already agrees them). `crop` is
   *  `_homeFrameCropFor(vac)`'s result for whichever vacuum(s) this capture is
   *  for; the caller re-derives it per candidate since a mixed fleet may have
   *  some vacuums home-frame-eligible and others still on the legacy path. */
  private _clickToHomePx(crop: CropBox, clientX: number, clientY: number): { x: number; y: number } | null {
    const pct = this._clickToImageBasePct(clientX, clientY);
    return pct ? pctToCropPoint(pct, crop) : null;
  }
  /** Shared floorplan-% extraction behind `_clickToHomePx` (cesta A) and
   *  `_clickToHomeAnchorPx` below (cesta B) — same DOMMatrix-inversion
   *  technique as `_clickToContent`, just against the shared `.image-base-
   *  img` instead of a per-vacuum `.map-img`. Factored out so both "known
   *  crop" and "solved fit" paths invert the SAME click geometry, not two
   *  slightly different copies of it (docs/14 rule 1). */
  private _clickToImageBasePct(clientX: number, clientY: number): { x: number; y: number } | null {
    const el = this.renderRoot?.querySelector(".image-base-img") as HTMLElement | null;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    const tr = getComputedStyle(el).transform;
    const m = new DOMMatrix(tr === "none" ? undefined : tr);
    const det = m.a * m.d - m.b * m.c;
    if (Math.abs(det) < 1e-9) return null;
    const d = this._unrotateDelta(clientX - cx, clientY - cy);
    const lx = (m.d * d.dx - m.c * d.dy) / det;
    const ly = (-m.b * d.dx + m.a * d.dy) / det;
    const w = el.offsetWidth || 1, h = el.offsetHeight || 1;
    return { x: (lx / w + 0.5) * 100, y: (ly / h + 0.5) * 100 };
  }
  /** docs/40 §5.B twin of `_clickToHomePx`: viewport point -> floorplan-%
   *  (same shared extraction) -> home px via the INVERSE of the live-solved
   *  cesta-B fit (`unprojectPctThroughFit`, seatfit.ts) instead of a known
   *  crop's inverse. `fit`/`dims`/`ar` must be the SAME triple
   *  `_homeAnchorFitFor` just produced for this vacuum (one render pass). */
  private _clickToHomeAnchorPx(
    fit: SeatFitResult, dims: { NW: number; NH: number }, ar: number, clientX: number, clientY: number,
  ): { x: number; y: number } | null {
    const pct = this._clickToImageBasePct(clientX, clientY);
    return pct ? unprojectPctThroughFit(pct, dims, fit, ar) : null;
  }
  private _onZoneDown(vac: VacuumConfig, e: PointerEvent): void {
    const editing = !!this._zoneRectShown && this._hasZoneEditTarget(vac);
    if (!editing && (this._mapMode !== "zone" || !this._isModeCandidate(vac))) return;
    const el = e.currentTarget as HTMLElement;
    (el as any).setPointerCapture?.(e.pointerId);
    const { x, y } = this._wrapPct(el, e.clientX, e.clientY);
    if (this._zoneRectShown) {
      const hit = this._zoneHit(this._zoneRectShown, x, y);
      if (hit) {
        const b = this._zoneRectShown;
        const minX = Math.min(b.x0, b.x1), maxX = Math.max(b.x0, b.x1);
        const minY = Math.min(b.y0, b.y1), maxY = Math.max(b.y0, b.y1);
        // Normalize to x0<x1 / y0<y1 so resize below can address each corner
        // as one fixed field instead of re-deriving min/max on every move.
        this._zoneRectShown = { x0: minX, y0: minY, x1: maxX, y1: maxY };
        this._zoneEdit = hit === "move"
          ? { type: "move", offsetX: x - minX, offsetY: y - minY, width: maxX - minX, height: maxY - minY }
          : { type: hit };
        return;
      }
      // Missed the box. Once dropped and awaiting confirm, `_mapMode` may
      // already be back to "normal" (merged multi-candidate flow) — a stray
      // click there shouldn't silently discard the pending zone, Cancel is
      // explicit for that. Only actively-armed drawing (`_mapMode === "zone"`)
      // may start a fresh rectangle over an old one.
      if (this._mapMode !== "zone") return;
    }
    // Start a fresh rectangle, same as before move/resize existed.
    this._zonePending = null;
    this._zoneRectShown = null;
    this._zoneEdit = null;
    this._zoneMulti = this._modeEntity === "*" && this._config.map_mode === "merged";
    this._zoneDrag = { x0: x, y0: y, x1: x, y1: y };
  }
  private _onZoneMove(vac: VacuumConfig, e: PointerEvent): void {
    if (this._zoneEdit && this._zoneRectShown) {
      const el = e.currentTarget as HTMLElement;
      const { x, y } = this._wrapPct(el, e.clientX, e.clientY);
      const MIN = 3; // smallest box side, in %, so a resize can't collapse to a point
      const edit = this._zoneEdit;
      if (edit.type === "move") {
        const { offsetX, offsetY, width, height } = edit;
        const nx0 = Math.min(100 - width, Math.max(0, x - offsetX));
        const ny0 = Math.min(100 - height, Math.max(0, y - offsetY));
        this._zoneRectShown = { x0: nx0, y0: ny0, x1: nx0 + width, y1: ny0 + height };
      } else {
        let { x0, y0, x1, y1 } = this._zoneRectShown;
        const cx = this._clampPct(x), cy = this._clampPct(y);
        if (edit.type === "nw") { x0 = Math.min(cx, x1 - MIN); y0 = Math.min(cy, y1 - MIN); }
        else if (edit.type === "ne") { x1 = Math.max(cx, x0 + MIN); y0 = Math.min(cy, y1 - MIN); }
        else if (edit.type === "sw") { x0 = Math.min(cx, x1 - MIN); y1 = Math.max(cy, y0 + MIN); }
        else /* se */ { x1 = Math.max(cx, x0 + MIN); y1 = Math.max(cy, y0 + MIN); }
        this._zoneRectShown = { x0, y0, x1, y1 };
      }
      return;
    }
    if (!this._zoneDrag || this._mapMode !== "zone" || !this._isModeCandidate(vac)) return;
    const el = e.currentTarget as HTMLElement;
    const p = this._wrapPct(el, e.clientX, e.clientY);
    this._zoneDrag = { x0: this._zoneDrag.x0, y0: this._zoneDrag.y0, x1: p.x, y1: p.y };
  }
  private _onZoneUp(vac: VacuumConfig, e: PointerEvent): void {
    const el = e.currentTarget as HTMLElement;
    if (this._zoneEdit) {
      this._zoneEdit = null;
      this._commitZoneRect(vac, el);
      return;
    }
    if (!this._zoneDrag || this._mapMode !== "zone" || !this._isModeCandidate(vac)) return;
    const big = Math.abs(this._zoneDrag.x1 - this._zoneDrag.x0) > 2 || Math.abs(this._zoneDrag.y1 - this._zoneDrag.y0) > 2;
    // Freeze the drawn box (so it stays visible while pending) before dropping
    // the LIVE drag state — the live state is what used to only clear on cancel,
    // so releasing the pointer left `_zoneDrag` set and `_onZoneMove` (which only
    // gates on it being non-null, not on the button still being down) kept
    // resizing the rectangle on every subsequent mouse move (bugfix, docs/19).
    this._zoneRectShown = big ? this._zoneDrag : null;
    this._zoneDrag = null;
    if (!big) return;
    const multi = this._zoneMulti;
    if (multi) { this._mapMode = "normal"; this._modeEntity = null; }
    this._commitZoneRect(vac, el);
  }
  /** Convert the current `_zoneRectShown` (wrap-relative %) back to screen
   *  coordinates via `el`'s rect, then project through each relevant vacuum's
   *  own map transform (`_clickToContent`) into `_zonePending`. Shared by the
   *  initial draw-drop and by every subsequent move/resize edit, so a box can
   *  be nudged into place after the fact without redrawing it from scratch. */
  private _commitZoneRect(vac: VacuumConfig, el: HTMLElement): void {
    const box = this._zoneRectShown; if (!box) return;
    const pa = this._wrapPoint(el, Math.min(box.x0, box.x1), Math.min(box.y0, box.y1));
    const pb = this._wrapPoint(el, Math.max(box.x0, box.x1), Math.max(box.y0, box.y1));
    const ax = pa.x, ay = pa.y, bx = pb.x, by = pb.y;
    if (this._zoneMulti) {
      // Merged multi-candidate: same two screen corners, translated through every
      // candidate vacuum's own map transform (docs/40 §4.4: home px through the
      // shared identity crop for a home-frame candidate, legacy per-vacuum seat
      // otherwise). Nothing sent yet — confirm per vacuum on its own status card.
      const rects: Record<string, { x1: number; y1: number; x2: number; y2: number; frame?: "home" }> = {};
      for (const cand of this._modeCandidates()) {
        const crop = this._homeFrameCropFor(cand);
        if (crop) {
          const ha = this._clickToHomePx(crop, ax, ay);
          const hb = this._clickToHomePx(crop, bx, by);
          if (ha && hb) {
            rects[cand.entity] = {
              x1: Math.min(ha.x, hb.x), y1: Math.min(ha.y, hb.y),
              x2: Math.max(ha.x, hb.x), y2: Math.max(ha.y, hb.y),
              frame: "home",
            };
          }
          continue;
        }
        // docs/40 §5.B: same fallback as `_onMapClick` above.
        const candAr = this._wrapAspect(this._baseHeightFor(cand));
        const af = this._homeAnchorFitFor(cand, candAr);
        if (af) {
          const ha = this._clickToHomeAnchorPx(af.fit, af.dims, candAr, ax, ay);
          const hb = this._clickToHomeAnchorPx(af.fit, af.dims, candAr, bx, by);
          if (ha && hb) {
            rects[cand.entity] = {
              x1: Math.min(ha.x, hb.x), y1: Math.min(ha.y, hb.y),
              x2: Math.max(ha.x, hb.x), y2: Math.max(ha.y, hb.y),
              frame: "home",
            };
          }
          continue;
        }
        const ca = this._clickToContent(cand, ax, ay);
        const cb = this._clickToContent(cand, bx, by);
        if (ca && cb) {
          rects[cand.entity] = {
            x1: this._clampPct(Math.min(ca.x, cb.x)), y1: this._clampPct(Math.min(ca.y, cb.y)),
            x2: this._clampPct(Math.max(ca.x, cb.x)), y2: this._clampPct(Math.max(ca.y, cb.y)),
          };
        }
      }
      this._zonePending = Object.keys(rects).length ? rects : null;
      return;
    }
    // Legacy single-target (per-vacuum tools, and "*" in split mode — each map is
    // its own on-screen region, so the vacuum that received the drag IS the
    // unambiguous choice). docs/40 §4.4: a home-frame vacuum gets home px instead.
    const crop = this._homeFrameCropFor(vac);
    if (crop) {
      const ha = this._clickToHomePx(crop, ax, ay);
      const hb = this._clickToHomePx(crop, bx, by);
      if (ha && hb) {
        this._zonePending = {
          [vac.entity]: {
            x1: Math.min(ha.x, hb.x), y1: Math.min(ha.y, hb.y),
            x2: Math.max(ha.x, hb.x), y2: Math.max(ha.y, hb.y),
            frame: "home",
          },
        };
      }
      return;
    }
    // docs/40 §5.B: same fallback as `_onMapClick` above.
    const vacAr = this._wrapAspect(this._baseHeightFor(vac));
    const af = this._homeAnchorFitFor(vac, vacAr);
    if (af) {
      const ha = this._clickToHomeAnchorPx(af.fit, af.dims, vacAr, ax, ay);
      const hb = this._clickToHomeAnchorPx(af.fit, af.dims, vacAr, bx, by);
      if (ha && hb) {
        this._zonePending = {
          [vac.entity]: {
            x1: Math.min(ha.x, hb.x), y1: Math.min(ha.y, hb.y),
            x2: Math.max(ha.x, hb.x), y2: Math.max(ha.y, hb.y),
            frame: "home",
          },
        };
      }
      return;
    }
    const ca = this._clickToContent(vac, ax, ay);
    const cb = this._clickToContent(vac, bx, by);
    if (ca && cb) {
      this._zonePending = {
        [vac.entity]: {
          x1: this._clampPct(Math.min(ca.x, cb.x)), y1: this._clampPct(Math.min(ca.y, cb.y)),
          x2: this._clampPct(Math.max(ca.x, cb.x)), y2: this._clampPct(Math.max(ca.y, cb.y)),
        },
      };
    }
  }
  private _confirmZone(vac: VacuumConfig): void {
    const z = this._zonePending?.[vac.entity]; if (!z) return;
    // Bugfix 2026-07-16 (field test): this hardcoded `repeat: 1`, silently
    // ignoring the vacuum's own configured pass count (`clean_action.repeat`,
    // e.g. 2) — a zone clean ran with only one pass regardless of what the
    // user set up. Zone clean is a WHERE action (docs/07 UX canon), it should
    // still run with the vacuum's normal HOW settings, same as room cleaning
    // does via `_settingPresets`/`clean_action`.
    const ca = vac.clean_action as Partial<NativeAutoCleanAction> | undefined;
    void this._call("anyvac", "zone_clean", z.frame === "home"
      ? {
          entity_id: vac.entity, frame: "home",
          x1_home_px: z.x1, y1_home_px: z.y1, x2_home_px: z.x2, y2_home_px: z.y2,
          repeat: ca?.repeat ?? 1,
        }
      : {
          entity_id: vac.entity,
          x1_pct: z.x1, y1_pct: z.y1, x2_pct: z.x2, y2_pct: z.y2,
          repeat: ca?.repeat ?? 1,
        });
    if (this._zonePending) {
      const next = { ...this._zonePending };
      delete next[vac.entity];
      this._zonePending = Object.keys(next).length ? next : null;
      if (!this._zonePending) this._zoneRectShown = null;
    }
    this._zoneDrag = null;
    this._zoneEdit = null;
    this._mapMode = "normal"; this._modeEntity = null;
  }
  private _confirmPin(vac: VacuumConfig): void {
    const p = this._pinPending?.[vac.entity]; if (!p) return;
    void this._call("anyvac", "goto", p.frame === "home"
      ? { entity_id: vac.entity, frame: "home", x_home_px: p.x, y_home_px: p.y }
      : { entity_id: vac.entity, x_pct: p.x, y_pct: p.y });
    if (this._pinPending) {
      const next = { ...this._pinPending };
      delete next[vac.entity];
      this._pinPending = Object.keys(next).length ? next : null;
    }
  }
  private _cancelPin(): void { this._pinPending = null; }
  private _cancelZone(): void {
    this._zonePending = null; this._zoneDrag = null; this._zoneRectShown = null; this._zoneEdit = null;
  }

  /** Grid mode's consolidated meta bar (docs/19 A4) — replaces the old per-vacuum
   *  Refresh/Pin & Go/Zone header rows (one row × N vacuums) AND the badges
   *  region's stats-trio + refresh button with ONE row: Pin & Go, Zone, dry/wet
   *  layer visibility + oldest age, selected room count, ETA, refresh. Legacy
   *  (no `layout:` block) keeps `_renderMapTools`; the old `_renderStatsTrio`/
   *  `_renderBadgesRefresh`/`_renderRoomList` were deleted 2026-08-08 — the
   *  comment here claimed legacy still used them, but `render()`'s legacy path
   *  never called any of the three, so they had been dead since docs/19 A4. */
  private _renderMetaBar(vacs: VacuumConfig[]) {
    const withMap = vacs.filter((v) => this._mapEntityFor(v));
    if (!withMap.length) return nothing;
    // Pin & Go / Zone here is armed for ALL candidates at once ("*", `_armMode`) —
    // in merged mode the capture (click/drag) happens once on the shared map and
    // the choice of WHICH vacuum executes it is made afterwards on that vacuum's
    // own status card (`_confirmPin`/`_confirmZone`, docs/19). No single
    // auto-picked target here anymore — that was the bug (immediate send with no
    // way to choose the robot).
    const candidates = this._modeCandidates();
    // No longer gated on `_narrow`: the click geometry undoes the ambient map
    // rotation itself now (`_unrotateDelta`), so a rotated map is just a map.
    const canCmd = candidates.length > 0;
    const cmdTitle = canCmd ? "" : "Requires the AnyVac integration (≥ 0.18) + map entity";
    const mode = this._modeEntity === "*" ? this._mapMode : "normal";
    // docs/28 §2: room count + ETA dropped from this bar — the dock footer right
    // below already carries both (`_renderDock`'s `.dock-foot`), so this was a
    // pure duplicate. `_fetchPlan` still runs here (cheap no-op once the dock's
    // own call already populated `_planPreview` for the same key) purely so
    // `unassigned`/`unsequenced` — genuine WARNINGS, not stats, kept here on
    // purpose — don't flash empty on a render where dock hasn't fired yet.
    const selKeys = this._allRoomKeys().filter((k) => this._isRoomSelectedAny(k, vacs));
    const runKeys = selKeys.length ? selKeys : this._allRoomKeys();
    const hasInt = vacs.some((v) => this._intAttrs(v));
    if (hasInt && runKeys.length) this._fetchPlan(runKeys, this._planMode);
    // Sequence hint (docs/19 follow-up, TODO #2): the backend's ETA is only as
    // good as `room_sequence` (the Roborock app's own room order, which the
    // firmware follows regardless of what order HA sends). Rooms missing from
    // it come back in `plan.unsequenced` — surface that instead of silently
    // showing a number the user has no reason to trust.
    const unsequenced = hasInt ? (this._planPreview?.unsequenced ?? []) : [];
    // Unassigned-rooms warning (found live 2026-07-18): see `_unassignedRooms`'s
    // doc comment — a "Both" run silently skipped wet cleaning with zero
    // feedback when the config-restricted wet vacuum couldn't take the rooms.
    const unassigned = this._unassignedRooms(runKeys, this._planMode, hasInt);
    const pinCount = this._pinPending ? Object.keys(this._pinPending).length : 0;
    const zoneCount = this._zonePending ? Object.keys(this._zonePending).length : 0;
    // docs/28 §2: brief spin on tap as press feedback — refresh has no other
    // observable completion signal (unlike the care-reset spinner, 0.79.1,
    // which waits for a confirmed sensor change), so a pure "tap registered"
    // acknowledgement is all it needs. Toggled imperatively on the actual DOM
    // node rather than via `@state` — a one-shot cosmetic effect that doesn't
    // need to survive/react to the next render.
    const refreshTap = (e: Event) => {
      const btn = e.currentTarget as HTMLElement;
      btn.classList.remove("mtbtn--spin");
      void btn.offsetWidth;
      btn.classList.add("mtbtn--spin");
      for (const v of withMap) this._refreshMap(v);
    };
    return html`
      <div class="meta-bar">
        <div class="meta-bar-cluster">
          <button class="mtbtn ${mode === "pin" ? "on" : ""}" ?disabled=${!canCmd}
            @click=${() => this._armMode("pin")} title=${cmdTitle || "Pin & Go"}>
            <ha-icon icon="mdi:map-marker-radius"></ha-icon><span>Pin &amp; Go</span>
          </button>
          <button class="mtbtn ${mode === "zone" ? "on" : ""}" ?disabled=${!canCmd}
            @click=${() => this._armMode("zone")} title=${cmdTitle || "Zone clean"}>
            <ha-icon icon="mdi:select-drag"></ha-icon><span>Zone</span>
          </button>
        </div>
        <div class="meta-bar-spacer"></div>
        <div class="meta-bar-cluster meta-bar-cluster--right">
          ${unassigned.length ? html`<span class="mtbtn mtbtn--stat mtbtn--err"
              title="${unassigned.length} selected room${unassigned.length > 1 ? "s have" : " has"} no available robot for the ${this._planMode} pass — it/they will be silently skipped. Check vacuum roles/config.">
            <ha-icon icon="mdi:robot-off"></ha-icon><b>${unassigned.length}</b>
          </span>` : nothing}
          ${unsequenced.length ? html`<span class="mtbtn mtbtn--stat mtbtn--warn"
              title="${unsequenced.length} selected room${unsequenced.length > 1 ? "s have" : " has"} no cleaning order set — the time may be off. Set the order in the card editor's Maps tab.">
            <ha-icon icon="mdi:sort-variant-off"></ha-icon><b>${unsequenced.length}</b>
          </span>` : nothing}
          ${this._renderLayerToggleCompact(vacs)}
          ${this._config.layout ? html`<button class="mtbtn ${this._flipEff ? "on" : ""}"
              title="Flip map 180° for this screen (this session only — the card editor's Layout section sets a permanent default)"
              @click=${() => this._toggleFlipLive()}>
            <ha-icon icon="mdi:flip-vertical"></ha-icon>
          </button>` : nothing}
          ${(() => {
            const alignCand = this._alignCandidates(vacs);
            return alignCand.length ? html`<button class="mtbtn" title="Align — full-screen manual floorplan seating"
                @click=${() => this._openAlign(alignCand[0])}>
              <ha-icon icon="mdi:vector-square-edit"></ha-icon>
            </button>` : nothing;
          })()}
          <div class="meta-bar-divider"></div>
          <button class="mtbtn mtbtn--ghost" title="Refresh maps" @click=${refreshTap}>
            <ha-icon icon="mdi:refresh"></ha-icon>
          </button>
        </div>
      </div>
      ${/* Capture finishes (and resets _mapMode to normal) the instant a click/drag
           lands — so pending state, not the armed mode, drives this panel. Only the
           "arm but haven't captured yet" hint depends on `mode`. */
        zoneCount ? html`<div class="calib-panel">
          <div>Zone ready for ${zoneCount} vacuum${zoneCount > 1 ? "s" : ""} — drag the box or its corners to adjust, then pick one on its status card below.</div>
          <div class="calib-actions"><button class="mtbtn" @click=${() => this._cancelZone()}>Cancel</button></div>
        </div>` : mode === "zone" ? html`<div class="calib-panel">Drag a rectangle on the map to set a cleaning zone.</div>` : nothing}
      ${pinCount ? html`<div class="calib-panel">
          <div>Pin ready for ${pinCount} vacuum${pinCount > 1 ? "s" : ""} — pick one on its status card below.</div>
          <div class="calib-actions"><button class="mtbtn" @click=${() => this._cancelPin()}>Cancel</button></div>
        </div>` : mode === "pin" ? html`<div class="calib-panel">Tap the map to drop a pin.</div>` : nothing}
    `;
  }

  private _renderMapTools(vac: VacuumConfig) {
    if (!vac.map && !vac.image_base && !this._mapEntityFor(vac)) return nothing;
    // Map commands need the integration's calibration AND this vacuum's map
    // element for the click geometry. A rotated map is no longer a blocker
    // (docs/13 A5 lifted) — the click inversion undoes the wrapper rotation.
    const mapEnt = this._mapEntityFor(vac);
    const canCmd = !!this._intAttrs(vac) && !!mapEnt;
    const cmdTitle = canCmd ? "" : "Requires the AnyVac integration (≥ 0.18) + map entity";
    const mode = this._modeEntity === vac.entity ? this._mapMode : "normal";
    return html`
      <div class="map-tools">
        ${this._config.layout && this._config.vacuums.length > 1
          ? html`<span class="map-tools-label">${vac.name ?? vac.entity}</span>` : nothing}
        ${mapEnt ? html`<button class="mtbtn" @click=${() => this._refreshMap(vac)} title="Refresh map">
          <ha-icon icon="mdi:refresh"></ha-icon><span>Refresh</span>
        </button>` : nothing}
        <button class="mtbtn ${mode === "pin" ? "on" : ""}" ?disabled=${!canCmd}
          @click=${() => this._toggleMode(vac.entity, "pin")} title=${cmdTitle || "Pin & Go"}>
          <ha-icon icon="mdi:map-marker-radius"></ha-icon><span>Pin &amp; Go</span>
        </button>
        <button class="mtbtn ${mode === "zone" ? "on" : ""}" ?disabled=${!canCmd}
          @click=${() => this._toggleMode(vac.entity, "zone")} title=${cmdTitle || "Zone clean"}>
          <ha-icon icon="mdi:select-drag"></ha-icon><span>Zone</span>
        </button>
        ${this._dbg && (this._config.debug || !this._config.layout) ? html`<span style="font-size:11px;opacity:0.65;align-self:center;font-family:monospace">${this._dbg}</span>` : nothing}
      </div>
      ${mode === "pin" ? html`<div class="calib-panel">Tap the map to send the robot there.</div>` : nothing}
      ${mode === "zone" ? html`<div class="calib-panel">
        ${this._zonePending?.[vac.entity]
          ? html`<div>Clean this zone? Drag the box or its corners to adjust.</div>
              <div class="calib-actions">
                <button class="mtbtn on" @click=${() => this._confirmZone(vac)}>Clean zone</button>
                <button class="mtbtn" @click=${() => this._cancelZone()}>Cancel</button>
              </div>`
          : html`Drag a rectangle on the map to set a cleaning zone.`}
      </div>` : nothing}
    `;
  }

  // ── Auto-seating (docs/15) ──────────────────────────────────────────────

  /** Configured base_height for a vacuum's map wrap (merged config wins, mirrors
   *  every other merged/per-vacuum config fallback in this file). */
  private _baseHeightFor(vac: VacuumConfig): number | undefined {
    const merged = this._config.map_mode === "merged";
    return merged
      ? (this._config.base_height ?? this._config.vacuums.find((v) => v.base_height)?.base_height)
      : vac.base_height;
  }

  /** Aspect ratio (W/H) of the map wrap, for the seat fit's unit conversions. */
  private _wrapAspect(baseHeight?: number): number {
    if (typeof baseHeight === "number" && baseHeight > 0 && this._cardW > 0) {
      return Math.max(0.2, (this._cardW - 16) / baseHeight);
    }
    return this._mapAR > 0.1 ? this._mapAR : 3.636;
  }

  /** Effective map seating: auto-fitted from room anchors (rooms drawn on the
   *  floorplan matched by name against the integration's room bboxes) whenever
   *  possible, else the manual slider values. Recomputed from live attributes,
   *  so it self-heals when the robot remaps / the map trim changes. */
  private _effectiveSeat(vac: VacuumConfig): SeatParams & {
    auto: boolean; residual?: number; anchorCount?: number;
  } {
    this._memoSync();
    const memo = this._seatMemo.get(vac.entity);
    if (memo) return memo;
    // Kontrakt v2: anchors come from rooms[].bbox_px (integration ≥ 0.18), which
    // `_intAttrs` already gates on schema_version. The fit itself lives in
    // `seatfit.ts` so the editor's preview resolves it identically (1.1.0).
    const out = resolveSeat(
      this._config, vac, this._intAttrs(vac), this._wrapAspect(this._baseHeightFor(vac)),
    );
    this._seatMemo.set(vac.entity, out);
    return out;
  }

  // ── Align mode (docs/41, Fáze C / Krok 2, C2a batch) ──────────────────────
  // Portal shell, view transform, entry gating and a basic transform gizmo
  // (drag/scale/rotate/pinch) wired straight onto the already-shipped pure
  // math in `seatedit.ts`. Deliberately NOT here yet (C2b): numeric side-panel
  // fields, keyboard nudges, undo/redo, Save/Reset/Cancel/Copy-YAML, and
  // integration-version degradation handling — see docs/41 §7. The overlay
  // NEVER reads `_effectiveSeat`/`_seatMemo` for the draft (docs/41 risk #5):
  // `_alignSession.start` is captured once, in `_openAlign`, and `draft`
  // evolves independently from there for the life of the session.

  /** Vacuums the "Align" entry button should even be offered for (docs/41
   *  §4.7): a floorplan to align against AND a live integration (no
   *  integration → no trases/bboxy → nothing to seat), gated off entirely by
   *  `align_mode: false` (kiosk tablets). */
  private _alignCandidates(vacs: VacuumConfig[]): VacuumConfig[] {
    if (this._config.align_mode === false) return [];
    return vacs.filter((v) => !!resolveImageBaseSrc(this._config, v) && !!this._intAttrs(v));
  }

  private _alignVac(): VacuumConfig | undefined {
    const s = this._alignSession;
    return s ? this._config.vacuums.find((v) => v.entity === s.vacuum) : undefined;
  }

  private _openAlign(vac: VacuumConfig): void {
    if (this._alignSession) return;
    const src = resolveImageBaseSrc(this._config, vac);
    if (!src || !this._intAttrs(vac)) return;
    // ONE-TIME read of the effective seat — the draft below is an independent
    // copy from this point on (docs/41 risk #5).
    const s = this._effectiveSeat(vac);
    const seat: SeatParams = {
      rotation: s.rotation, scale: s.scale, scaleY: s.scaleY,
      offset_x: s.offset_x, offset_y: s.offset_y,
    };
    this._alignSession = {
      vacuum: vac.entity, floorplan: src,
      start: { ...seat }, draft: { ...seat },
      history: [], future: [],
      layers: defaultAlignLayers(),
      snap90: false,
      nudgeTier: "normal",
    };
    this._alignView = defaultAlignView();
    this._alignGesture = null;
    // Autofocus so keyboard nudges (docs/41 SS4.4, this session's C2b) work
    // immediately without the user first clicking into the overlay.
    requestAnimationFrame(() => this._alignRefocusOverlay());
  }

  /** Returns keyboard focus to the overlay root so `_alignKeyDown`'s nudges
   *  keep working — called once on open (above) and again at the START of
   *  every canvas/gizmo pointer gesture (`_alignStartGesture`,
   *  `_alignBgPointerDown`). Needed because those both call
   *  `e.preventDefault()` on the pointerdown, which ALSO suppresses the
   *  browser's own default "clicking elsewhere blurs the focused input"
   *  behavior — so a side-panel field (e.g. the opacity slider, field
   *  report 2026-09-18: had to be dragged down just to see the floorplan
   *  at all) kept keyboard focus even once the user started interacting
   *  with the canvas/gizmo again, silently eating arrow-key nudges with no
   *  visible feedback that anything was wrong. */
  private _alignRefocusOverlay(): void {
    const el = this._alignHost?.shadowRoot?.querySelector(".align-overlay") as HTMLElement | null;
    el?.focus();
  }

  /** Unconditional close — no confirmation. Used after a successful Save,
   *  and by the in-overlay Cancel-confirmation panel's own "Discard"
   *  action. Anything the USER triggers directly (the toolbar × / Esc)
   *  goes through `_alignCancel()` instead, which decides whether to ask
   *  first. */
  private _closeAlign(): void {
    this._alignSession = null;
    this._alignGesture = null;
    this._alignCancelConfirm = false;
  }

  /** docs/41 §4.8: a home-frame registered vacuum is shown as a read-only
   *  ghost in Align mode (MVP has no home-frame edit path yet — Faze G).
   *  Single source of truth for every gesture/keyboard/Save guard below, so
   *  the three can't drift out of sync with each other. */
  private _alignReadOnly(): boolean {
    const vac = this._alignVac();
    return !!vac && !!this._homeFrameCropFor(vac);
  }

  private _alignHasChanges(): boolean {
    const s = this._alignSession;
    if (!s) return false;
    const a = s.draft, b = s.start;
    return a.rotation !== b.rotation || a.scale !== b.scale || (a.scaleY ?? null) !== (b.scaleY ?? null)
      || a.offset_x !== b.offset_x || a.offset_y !== b.offset_y;
  }

  /** Toolbar ×/Esc entry point (docs/41 §4.4's "Cancel"): closes right away
   *  when the draft never diverged from the opening seat, otherwise shows
   *  the in-overlay confirmation panel instead of an OS `window.confirm`
   *  (docs/41 risk #3: a bottom-edge swipe/back gesture must not be
   *  mistaken for confirming a destructive dialog). */
  private _alignCancel(): void {
    if (this._alignHasChanges()) this._alignCancelConfirm = true;
    else this._closeAlign();
  }
  private _alignConfirmDiscard(): void {
    this._closeAlign();
  }
  private _alignDismissCancelConfirm(): void {
    this._alignCancelConfirm = false;
  }

  private _alignReset(): void {
    const session = this._alignSession;
    if (!session || this._alignReadOnly()) return;
    this._alignSession = {
      ...session, draft: { ...session.start },
      history: [...session.history, session.draft], future: [],
    };
  }

  private async _alignCopyYaml(): Promise<void> {
    const session = this._alignSession;
    if (!session) return;
    const yaml = seatToYaml(session.draft);
    try {
      await navigator.clipboard.writeText(yaml);
      this._alignCopiedFlash = true;
      setTimeout(() => { this._alignCopiedFlash = false; }, 1500);
    } catch (err) {
      // Copy YAML is the docs/41 §4.6 ALWAYS-available fallback (works with
      // no service, no HA version requirement) — a silent failure here
      // would leave the user thinking it worked, so at least log it.
      console.warn("[anyvac-card] Align: clipboard write failed", err);
    }
  }

  /** docs/41 §4.6/§4.8 degradation gate: Save needs an integration new
   *  enough to speak `anyvac.set_floorplan_seat` — `hass.services` is the
   *  same existence-check HA's own more-info dialogs use for "is this
   *  service registered right now". */
  private _alignServiceAvailable(): boolean {
    return !!this.hass.services?.["anyvac"]?.["set_floorplan_seat"];
  }

  private async _alignSave(): Promise<void> {
    const session = this._alignSession;
    const vac = this._alignVac();
    if (!session || !vac || !this._alignServiceAvailable() || this._alignReadOnly()) return;
    const d = session.draft;
    const map: Record<string, number> = {
      rotation: Math.round(d.rotation * 100) / 100,
      scale: Math.round(d.scale * 100) / 100,
      offset_x: Math.round(d.offset_x * 100) / 100,
      offset_y: Math.round(d.offset_y * 100) / 100,
    };
    if (d.scaleY != null) map.scale_y = Math.round(d.scaleY * 100) / 100;
    try {
      await this.hass.callService("anyvac", "set_floorplan_seat", {
        floorplan: session.floorplan, vacuum: vac.entity, map,
      });
      this._closeAlign();
    } catch (err) {
      // Left open on failure (network blip, HA restart mid-save) — the
      // draft is not lost, the user can just try Save again.
      console.warn("[anyvac-card] Align: set_floorplan_seat call failed", err);
    }
  }

  /** Numeric side-panel commit (docs/41 §4.3 "side panel: numerika"). Bound
   *  to each `<input>`'s `change` event (fires on blur/Enter), not `input`
   *  — same one-push-per-commit philosophy as gestures/keyboard bursts, so
   *  a user retyping a value doesn't spam `history` per keystroke. A NaN
   *  (mid-edit empty field, stray text) or a no-op value is silently
   *  ignored rather than corrupting the draft. */
  private _alignSetField(
    field: "rotation" | "scale" | "scaleY" | "offset_x" | "offset_y", raw: string,
  ): void {
    const session = this._alignSession;
    if (!session || this._alignReadOnly()) return;
    const n = parseFloat(raw);
    if (!Number.isFinite(n)) return;
    const d = session.draft;
    if (d[field] === n) return;
    const next: SeatParams = { ...d, [field]: n };
    this._alignSession = { ...session, draft: next, history: [...session.history, d], future: [] };
  }

  /** The "Independent Y scale" checkbox — on, `scaleY` starts at the
   *  current `scale` (so toggling it never itself changes what's on
   *  screen); off, `scaleY` is cleared back to isotropic (`undefined`,
   *  per `SeatParams`'s own doc comment on the field). */
  private _alignToggleScaleY(on: boolean): void {
    const session = this._alignSession;
    if (!session || this._alignReadOnly()) return;
    const d = session.draft;
    const next: SeatParams = { ...d };
    if (on) {
      if (next.scaleY == null) next.scaleY = next.scale;
    } else {
      delete next.scaleY;
    }
    this._alignSession = { ...session, draft: next, history: [...session.history, d], future: [] };
  }

  /** Live view-only layer opacity (docs/41 SS4.2/SS4.3 `layers.floor` /
   *  `layers.rawMap`) — 0..1 multipliers applied straight to the floorplan's
   *  and the edited vacuum's raw-map <img> opacity, so both layers can be
   *  seen through each other while eyeballing the alignment. Purely a
   *  display preference: NOT pushed onto history/future (no undo, same as
   *  `_alignView`) and NOT gated by `_alignReadOnly()` — seeing through the
   *  raw map is just as useful in a read-only (home-frame) session. */
  private _alignSetLayerOpacity(field: "floor" | "rawMap", raw: string): void {
    const session = this._alignSession;
    if (!session) return;
    const n = parseFloat(raw);
    if (!Number.isFinite(n)) return;
    const v = Math.min(1, Math.max(0, n / 100));
    if (session.layers[field] === v) return;
    this._alignSession = { ...session, layers: { ...session.layers, [field]: v } };
  }

  /** Contain-fits the floorplan's own aspect ratio (`_mapAR`) into the
   *  viewport at view zoom = 1 (docs/41 §4.3). The overlay is always
   *  full-screen (docs/41 §4.1), so the viewport itself is the available
   *  box; a live ResizeObserver refinement (rotation/resize while open) is
   *  left for C2b along with the rest of the toolbar/side-panel chrome. */
  private _alignSceneSize(): { w: number; h: number } {
    const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
    const availW = Math.max(100, window.innerWidth - 32);
    const availH = Math.max(100, window.innerHeight - 140);
    let w = availW, h = w / ar;
    if (h > availH) { h = availH; w = h * ar; }
    return { w, h };
  }

  private _alignViewTransformCss(): string {
    const v = this._alignView;
    return `translate(${v.panX}px,${v.panY}px) scale(${v.zoom}) rotate(${v.rot}deg)`;
  }

  private _alignRotateView(): void {
    this._alignView = { ...this._alignView, rot: (((this._alignView.rot + 90) % 360) as 0 | 90 | 180 | 270) };
  }

  /** Pointer (client px) -> wrap-relative PERCENT (same units as
   *  `offset_x`/`offset_y`: x = %wrap-width, y = %wrap-height) — inverts the
   *  scene's own view transform first (docs/41 §4.3: "`new
   *  DOMMatrix(getComputedStyle(scene).transform).inverse()` +
   *  `getBoundingClientRect()`"), same approach `_clickToContent` already
   *  uses for pin&go clicks. `.align-scene`'s OWN layout box (no extra
   *  chrome around it) is exactly the wrap these percentages are relative
   *  to, so its `offsetWidth`/`offsetHeight` double as wrapW/wrapH. */
  private _alignPointToWrapPct(clientX: number, clientY: number): { x: number; y: number } | null {
    // The overlay lives in the `_alignHost` PORTAL's own shadow root, not
    // this card's `renderRoot` (docs/41 §4.1) — a C2a bug (fixed in C2b,
    // caught by tests/align-overlay.spec.ts) had this querying `renderRoot`
    // instead, which meant `.align-scene` could never be found and every
    // gizmo gesture silently no-opped (`_alignStartGesture` bails on a
    // `null` point below).
    const scene = this._alignHost?.shadowRoot?.querySelector(".align-scene") as HTMLElement | null;
    if (!scene) return null;
    const r = scene.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    const tr = getComputedStyle(scene).transform;
    const m = new DOMMatrix(tr === "none" ? undefined : tr);
    const det = m.a * m.d - m.b * m.c;
    if (Math.abs(det) < 1e-9) return null;
    const dx = clientX - cx, dy = clientY - cy;
    const lx = (m.d * dx - m.c * dy) / det;
    const ly = (-m.b * dx + m.a * dy) / det;
    const sw = scene.offsetWidth || 1, sh = scene.offsetHeight || 1;
    return { x: (lx / sw + 0.5) * 100, y: (ly / sh + 0.5) * 100 };
  }

  /** A corner of the seated layer's own unit box (`cx`/`cy` in 0..1, (0,0) =
   *  NW .. (1,1) = SE) projected through `seat`, in wrap-relative PERCENT.
   *  Reuses `seatToMatrix` (docs/14 rule 1 — the one shared geometry
   *  primitive, not a second implementation) with a 1×1 "natural size" so
   *  its content coordinates ARE the unit box directly. */
  private _alignCornerPct(
    seat: SeatParams, cx: number, cy: number, wrapW: number, wrapH: number,
  ): { x: number; y: number } {
    const m = seatToMatrix(seat, wrapW, wrapH, 1, 1);
    const p = m.transformPoint({ x: cx, y: cy });
    return { x: (p.x / wrapW) * 100, y: (p.y / wrapH) * 100 };
  }

  /** A resize cursor for a side handle whose UNROTATED axis is horizontal
   *  (`baseAxisDeg` 0, the west/east — Scale X — handles) or vertical (90,
   *  north/south — Scale Y). Scale X/Y are the seat's own LOCAL axes
   *  (`seatToMatrix` rotates them with the seat, docs/41 §4.2), so at a
   *  rotation like 90° the "Scale X" handles sit top/bottom on screen and
   *  actually drag vertically — a fixed `ew-resize`/`ns-resize` CSS class
   *  would then point the wrong way (field report 2026-09-18, the same
   *  "which arrow is really X once you've rotated" confusion the new
   *  handle icons below fix visually).
   *
   *  Callers must pass `draft.rotation + this._alignView.rot` combined, not
   *  `draft.rotation` alone: `_alignView.rot` is the separate, screen-only
   *  "Rotate view 90°" toolbar rotation applied to the whole `.align-scene`
   *  via CSS `transform`. A `transform: rotate()` on a handle's own `<ha-icon>`
   *  composes with that ancestor transform automatically (CSS transforms
   *  nest), so the icon's own `rotate(draft.rotation)` already looks right
   *  on screen without listing `_alignView.rot` explicitly — but `cursor`
   *  is a plain CSS property, not a transform, and does not compose with
   *  ancestor transforms at all. Omitting `_alignView.rot` here left the
   *  cursor (and, before this fix, nothing else) pointing the pre-view-
   *  rotation direction once the user rotated the view — a real gap in the
   *  1.11.4 fix (field report 2026-09-18 follow-up), distinct from
   *  `nudgeOffset` in seatedit.ts, which already un-rotates keyboard nudges
   *  by `_alignView.rot` for exactly the same reason. Snapped to the 4
   *  cursor shapes CSS actually has (`ew`/`nwse`/`ns`/`nesw`), 45° each. */
  private _alignResizeCursor(baseAxisDeg: number, rotationDeg: number): string {
    const eff = (((baseAxisDeg + rotationDeg) % 180) + 180) % 180;
    if (eff < 22.5 || eff >= 157.5) return "ew-resize";
    if (eff < 67.5) return "nwse-resize";
    if (eff < 112.5) return "ns-resize";
    return "nesw-resize";
  }

  /** A small rotation-aware arrow icon for a side-panel field LABEL (field
   *  report 2026-09-19: the user didn't want the static "Scale X"/"Offset Y"
   *  TEXT — that's fixed and doesn't reflect what the field actually does on
   *  screen once anything is rotated — they want "Scale"/"Offset" plus an
   *  arrow that always points the way that field actually moves the seat on
   *  screen, in ANY combination of the seat's own `rotation` and the
   *  separate view rotation (`_alignView.rot`). Continuous `rotate()`, not
   *  the 4-bucket snap `_alignResizeCursor` uses — CSS `cursor` only has 4
   *  shapes to snap into, but an `<ha-icon>` can point at the exact angle.
   *  `horizontal` is the field's own axis at rotation 0: true for Scale X /
   *  Offset X (mdi:arrow-left-right), false for Scale Y / Offset Y
   *  (mdi:arrow-up-down). `rotationDeg` is the CALLER's job to get right:
   *  Scale X/Y are the seat's own local axes, so they rotate with BOTH
   *  `draft.rotation` and `_alignView.rot` combined; Offset X/Y are wrap-
   *  relative (never rotated by the seat itself, docs/41 §4.2), so only
   *  `_alignView.rot` applies — same split `_alignResizeCursor`'s callers
   *  and `nudgeOffset()` already observe. The side panel lives OUTSIDE
   *  `.align-scene` (it's not a descendant), so — unlike the on-canvas
   *  handle icons — no ancestor transform does any of this for free; the
   *  full angle has to be passed in explicitly every time. */
  private _alignFieldArrow(horizontal: boolean, rotationDeg: number) {
    return html`<ha-icon class="align-field-arrow" icon=${horizontal ? "mdi:arrow-left-right" : "mdi:arrow-up-down"}
      style=${styleMap({ transform: "rotate(" + rotationDeg + "deg)" })}></ha-icon>`;
  }

  /** Isotropic (aspect-corrected) distance/angle between two wrap-percent
   *  points — the same "divide y by `ar`" convention `seatedit.ts`'s
   *  internal `pctToFrac` uses, so a corner-handle scale factor or a
   *  rotation-handle angle delta agrees with what `scaleSeatAbout`/
   *  `rotateSeatAbout` themselves expect. */
  private _alignIsoDist(a: { x: number; y: number }, b: { x: number; y: number }, ar: number): number {
    return Math.hypot(a.x - b.x, (a.y - b.y) / ar);
  }
  private _alignIsoAngleDeg(pivot: { x: number; y: number }, p: { x: number; y: number }, ar: number): number {
    return (Math.atan2((p.y - pivot.y) / ar, p.x - pivot.x) * 180) / Math.PI;
  }

  /** Starts (or upgrades an existing single-pointer gesture to) a gizmo
   *  gesture. `kind` drives which `seatedit.ts` primitive `_alignApplyGesture`
   *  below calls; `pivotPct` is fixed for the whole gesture (the opposite
   *  corner for scale, the layer's own centre for rotate). */
  private _alignStartGesture(
    e: PointerEvent, kind: "drag" | "scale" | "rotate" | "stretchX" | "stretchY",
    pivotPct?: { x: number; y: number },
  ): void {
    const session = this._alignSession;
    if (!session || this._alignReadOnly()) return;
    this._alignRefocusOverlay();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    e.stopPropagation();
    e.preventDefault();
    const pt = this._alignPointToWrapPct(e.clientX, e.clientY);
    if (!pt) return;
    const g = this._alignGesture;
    if (g && g.startPos.size === 1 && !g.startPos.has(e.pointerId)) {
      // Second finger landing on the layer mid-gesture -> upgrade to pinch,
      // re-baselined from the CURRENT draft (docs/41 §4.4).
      const [[firstId, firstPos]] = g.startPos;
      this._alignGesture = {
        kind: "pinch", startSeat: { ...session.draft },
        startPos: new Map([[firstId, g.livePos.get(firstId) ?? firstPos], [e.pointerId, pt]]),
        livePos: new Map([[firstId, g.livePos.get(firstId) ?? firstPos], [e.pointerId, pt]]),
      };
      return;
    }
    // A NEW gesture (not a pinch upgrade, handled above) is the point to
    // snapshot for undo — one history entry per drag/scale/rotate/pinch,
    // not per pointermove (docs/41 SS4.4 undo/redo).
    this._alignPushHistory(session.draft);
    this._alignGesture = {
      kind, startSeat: { ...session.draft }, pivotPct,
      startPos: new Map([[e.pointerId, pt]]),
      livePos: new Map([[e.pointerId, pt]]),
    };
  }

  private _alignGestureMove(e: PointerEvent): void {
    const session = this._alignSession, g = this._alignGesture;
    if (!session || !g || !g.startPos.has(e.pointerId)) return;
    const pt = this._alignPointToWrapPct(e.clientX, e.clientY);
    if (!pt) return;
    g.livePos.set(e.pointerId, pt);
    const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
    let next: SeatParams | null = null;
    if (g.kind === "drag") {
      const id = e.pointerId;
      const s0 = g.startPos.get(id)!, s1 = g.livePos.get(id)!;
      next = translateSeat(g.startSeat, s1.x - s0.x, s1.y - s0.y);
    } else if (g.kind === "scale" && g.pivotPct) {
      const id = e.pointerId;
      const s0 = g.startPos.get(id)!, s1 = g.livePos.get(id)!;
      if (g.startSeat.scaleY != null) {
        // Independent Y scale is on -> corner handles unlock into an
        // anisotropic (X/Y independent) drag instead of staying
        // aspect-locked (field report 2026-09-18).
        next = scaleSeatCornerAniso(g.startSeat, s0, s1, g.pivotPct, ar);
      } else {
        const d0 = this._alignIsoDist(s0, g.pivotPct, ar);
        const d1 = this._alignIsoDist(s1, g.pivotPct, ar);
        if (d0 > 1e-6) next = scaleSeatAbout(g.startSeat, d1 / d0, g.pivotPct, ar);
      }
    } else if (g.kind === "stretchY") {
      const id = e.pointerId;
      const s0 = g.startPos.get(id)!, s1 = g.livePos.get(id)!;
      next = stretchSeatY(g.startSeat, localAxisScaleRatio(g.startSeat, "y", s0, s1, ar));
    } else if (g.kind === "stretchX") {
      const id = e.pointerId;
      const s0 = g.startPos.get(id)!, s1 = g.livePos.get(id)!;
      next = stretchSeatX(g.startSeat, localAxisScaleRatio(g.startSeat, "x", s0, s1, ar));
    } else if (g.kind === "rotate" && g.pivotPct) {
      const id = e.pointerId;
      const s0 = g.startPos.get(id)!, s1 = g.livePos.get(id)!;
      const a0 = this._alignIsoAngleDeg(g.pivotPct, s0, ar);
      const a1 = this._alignIsoAngleDeg(g.pivotPct, s1, ar);
      next = rotateSeatAbout(g.startSeat, a1 - a0, g.pivotPct, ar);
    } else if (g.kind === "pinch" && g.startPos.size === 2) {
      const ids = [...g.startPos.keys()];
      const p0a = g.startPos.get(ids[0])!, p0b = g.startPos.get(ids[1])!;
      const p1a = g.livePos.get(ids[0])!, p1b = g.livePos.get(ids[1])!;
      next = pinchSeat(g.startSeat, p0a, p0b, p1a, p1b, ar);
    }
    if (next) this._alignSession = { ...session, draft: next };
  }

  private _alignGestureEnd(e: PointerEvent): void {
    const g = this._alignGesture;
    if (!g) return;
    g.startPos.delete(e.pointerId);
    g.livePos.delete(e.pointerId);
    if (g.startPos.size === 0) {
      this._alignGesture = null;
    } else if (g.kind === "pinch" && g.startPos.size === 1) {
      // Down to one finger -> back to a plain drag, re-baselined so the
      // remaining finger doesn't jump the layer (docs/41 §4.4).
      const [[id, pos]] = g.startPos;
      const session = this._alignSession;
      this._alignGesture = {
        kind: "drag", startSeat: session ? { ...session.draft } : g.startSeat,
        startPos: new Map([[id, pos]]), livePos: new Map([[id, pos]]),
      };
    }
  }

  /** Snapshots `seat` onto the undo stack and clears redo (any new edit
   *  invalidates a previously-undone future, same convention every other
   *  undo/redo stack uses). Called once per user-initiated change — a whole
   *  gesture (`_alignStartGesture`) or a whole keyboard nudge burst
   *  (`_alignKeyDown`, gated on `!e.repeat`) — never per intermediate step,
   *  so one Undo reverts the WHOLE gesture/burst, not one pixel of it. */
  private _alignPushHistory(seat: SeatParams): void {
    const session = this._alignSession;
    if (!session) return;
    this._alignSession = { ...session, history: [...session.history, seat], future: [] };
  }

  private _alignUndo(): void {
    const session = this._alignSession;
    if (!session || !session.history.length) return;
    const prev = session.history[session.history.length - 1];
    this._alignSession = {
      ...session, draft: prev,
      history: session.history.slice(0, -1),
      future: [session.draft, ...session.future],
    };
  }

  private _alignRedo(): void {
    const session = this._alignSession;
    if (!session || !session.future.length) return;
    const next = session.future[0];
    this._alignSession = {
      ...session, draft: next,
      history: [...session.history, session.draft],
      future: session.future.slice(1),
    };
  }

  private _alignSetNudgeTier(tier: NudgeTier): void {
    const session = this._alignSession;
    if (session) this._alignSession = { ...session, nudgeTier: tier };
  }

  /** `Ctrl`/`Shift` held MOMENTARILY override the toolbar's persistent
   *  Jemně/Krok/Skok selection to fine/jump — see `NudgeTier`'s doc comment
   *  in `seatedit.ts` for why this replaced a Ctrl+WASD-style scheme. */
  private _alignEffectiveNudgeTier(e: KeyboardEvent): NudgeTier {
    if (e.ctrlKey || e.metaKey) return "fine";
    if (e.shiftKey) return "jump";
    return this._alignSession?.nudgeTier ?? "normal";
  }

  /** Keyboard nudges (docs/41 SS4.4): arrows = offset, `[`/`]` = rotation,
   *  `,`/`.` = scale — base step 0.1%/0.5deg/0.5%, scaled by the effective
   *  tier. `Ctrl+Z`/`Ctrl+Y` undo/redo are guarded off whenever focus is in
   *  an actual form field (the numeric side-panel inputs, in C2b) so typing
   *  there keeps the browser's own normal text-undo instead of hijacking it
   *  for the seat. `Escape` routes through `_alignCancel()`, same as the
   *  toolbar's X button, so an in-progress edit asks for confirmation
   *  instead of silently discarding it. */
  private _alignKeyDown(e: KeyboardEvent): void {
    const session = this._alignSession;
    if (!session) return;
    const target = e.target as HTMLElement | null;
    const inField = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");

    if (e.key === "Escape") {
      e.preventDefault();
      this._alignCancel();
      return;
    }
    const mod = e.ctrlKey || e.metaKey;
    if (mod && !e.shiftKey && !e.altKey && (e.key === "z" || e.key === "Z")) {
      if (inField) return;
      e.preventDefault();
      this._alignUndo();
      return;
    }
    if (mod && !e.shiftKey && !e.altKey && (e.key === "y" || e.key === "Y")) {
      if (inField) return;
      e.preventDefault();
      this._alignRedo();
      return;
    }
    // Arrow keys have real native meaning in a focused number/range
    // input (caret move / value step) — defer to that. `,`/`.`/`[`/`]`
    // don't, so they still reach the gizmo below even while a side-panel
    // field has focus (field report 2026-09-18 — see `_alignRefocusOverlay`
    // for the other half of this fix).
    if (inField && e.key.startsWith("Arrow")) return;
    if (this._alignReadOnly()) return;

    const mult = nudgeTierMultiplier(this._alignEffectiveNudgeTier(e));
    const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
    const d = session.draft;
    let next: SeatParams | null = null;
    switch (e.key) {
      case "ArrowUp": next = nudgeOffset(d, 0, -0.1 * mult, this._alignView.rot, ar); break;
      case "ArrowDown": next = nudgeOffset(d, 0, 0.1 * mult, this._alignView.rot, ar); break;
      case "ArrowLeft": next = nudgeOffset(d, -0.1 * mult, 0, this._alignView.rot, ar); break;
      case "ArrowRight": next = nudgeOffset(d, 0.1 * mult, 0, this._alignView.rot, ar); break;
      case "[": next = nudgeRotation(d, -0.5 * mult); break;
      case "]": next = nudgeRotation(d, 0.5 * mult); break;
      case ",": next = nudgeScale(d, -0.5 * mult); break;
      case ".": next = nudgeScale(d, 0.5 * mult); break;
      default: return;
    }
    e.preventDefault();
    const history = e.repeat ? session.history : [...session.history, d];
    this._alignSession = { ...session, draft: next, history, future: [] };
  }

  /** Background pan (view, not seat) — drag anywhere on the canvas OUTSIDE
   *  the seated layer/gizmo. Kept separate from the gizmo's own pointer
   *  tracking (`_alignGesture`) since it moves `_alignView`, never the
   *  draft. */
  private _alignViewDrag: { pointerId: number; x0: number; y0: number; panX0: number; panY0: number } | null = null;
  private _alignBgPointerDown(e: PointerEvent): void {
    if (this._alignGesture) return;
    this._alignRefocusOverlay();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    this._alignViewDrag = {
      pointerId: e.pointerId, x0: e.clientX, y0: e.clientY,
      panX0: this._alignView.panX, panY0: this._alignView.panY,
    };
  }
  private _alignBgPointerMove(e: PointerEvent): void {
    const d = this._alignViewDrag;
    if (!d || d.pointerId !== e.pointerId) return;
    this._alignView = { ...this._alignView, panX: d.panX0 + (e.clientX - d.x0), panY: d.panY0 + (e.clientY - d.y0) };
  }
  private _alignBgPointerUp(e: PointerEvent): void {
    if (this._alignViewDrag?.pointerId === e.pointerId) this._alignViewDrag = null;
  }

  /** Wheel = zoom of the VIEW (docs/41 §5 bod 3), anchored on the cursor —
   *  the point under the pointer stays put as you zoom (field report
   *  2026-09-19: with a huge/offset seat, zooming in to inspect one edge or
   *  corner in detail — and reach its handles — used to always re-centre on
   *  the viewport middle, pulling the very spot you zoomed in on back out
   *  of view; this was flagged as a deferred "C2b gesture refinement" in
   *  this docstring from the start).
   *
   *  Standard "zoom to point" algebra: `_alignViewTransformCss` applies
   *  `translate(panX,panY) scale(zoom) rotate(rot)`, and CSS composes
   *  transform functions left-to-right as nested application of the
   *  RIGHTMOST first (`rotate` then `scale` then `translate`), so
   *  `translate` is the OUTERMOST step — a plain screen-space pixel offset,
   *  never itself scaled or rotated. That makes "keep screen point S fixed
   *  while zoom goes old→new" reduce to one line, independent of the
   *  current rotation: `pan' = pan + (S − centre) * (1 − zoomNew/zoomOld)`
   *  (`centre` = the scene's on-screen centre with the CURRENT, pre-change
   *  pan already applied, i.e. its live `getBoundingClientRect()` centre).
   *  Falls back to the old centre-anchored behaviour if the scene node
   *  isn't found (shouldn't happen — wheel only fires once it's mounted). */
  private _alignWheel(e: WheelEvent): void {
    e.preventDefault();
    const zoomOld = this._alignView.zoom;
    const k = Math.exp(-e.deltaY * 0.001);
    const zoom = Math.min(8, Math.max(0.25, zoomOld * k));
    const scene = this._alignHost?.shadowRoot?.querySelector(".align-scene") as HTMLElement | null;
    if (!scene || zoom === zoomOld) {
      this._alignView = { ...this._alignView, zoom };
      return;
    }
    const r = scene.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    const ratio = zoom / zoomOld;
    const panX = this._alignView.panX + (e.clientX - cx) * (1 - ratio);
    const panY = this._alignView.panY + (e.clientY - cy) * (1 - ratio);
    this._alignView = { ...this._alignView, zoom, panX, panY };
  }

  private _renderAlignOverlay() {
    const session = this._alignSession;
    if (!session) return nothing;
    const vac = this._alignVac();
    if (!vac) return nothing;
    const { w: wrapW, h: wrapH } = this._alignSceneSize();
    const others = this._config.vacuums.filter(
      (v) => v.entity !== vac.entity && resolveImageBaseSrc(this._config, v) === session.floorplan && this._intAttrs(v),
    );
    // Match by `src` against the identity captured at `_openAlign` time
    // rather than re-deriving merged-vs-split precedence here (docs/14 rule
    // 1 — `resolveImageBaseSrc` already owns that logic; this only needs
    // to find WHICH `image_base` object produced the src it returned).
    const ib = this._config.image_base?.src === session.floorplan
      ? this._config.image_base
      : (this._config.vacuums.find((v) => v.image_base?.src === session.floorplan)?.image_base ?? vac.image_base);
    const mapEnt = this._mapEntityFor(vac);
    const mapUrl = mapEnt ? this._mapUrl(mapEnt) : null;
    const draft = session.draft;
    const corner = (cx: number, cy: number) => this._alignCornerPct(draft, cx, cy, wrapW, wrapH);
    const nw = corner(0, 0), ne = corner(1, 0), sw = corner(0, 1), se = corner(1, 1);
    const nMid = corner(0.5, 0), sMid = corner(0.5, 1), wMid = corner(0, 0.5), eMid = corner(1, 0.5);
    const centre = { x: 50 + draft.offset_x, y: 50 + draft.offset_y };
    const rotateHandle = this._alignCornerPct(draft, 0.5, -0.18, wrapW, wrapH);
    const candidates = this._alignCandidates(this._config.vacuums);
    const readOnly = this._alignReadOnly();
    const canSave = !readOnly && this._alignServiceAvailable();
    const canUndo = session.history.length > 0;
    const canRedo = session.future.length > 0;
    const tier = session.nudgeTier;
    const tierBtn = (t: NudgeTier, label: string, title: string) => html`
      <button class="align-tier-btn ${tier === t ? "on" : ""}" title=${title}
        @click=${() => this._alignSetNudgeTier(t)}>${label}</button>`;
    return html`
      <div class="align-overlay ${this._rootClasses()}" tabindex="0" @keydown=${(e: KeyboardEvent) => this._alignKeyDown(e)}>
        <div class="align-toolbar">
          <div class="align-toolbar-title">
            <ha-icon icon="mdi:vector-square-edit"></ha-icon>
            <span>Align — ${vac.name ?? vac.entity}</span>
          </div>
          ${candidates.length > 1 ? html`<div class="align-vac-picker">
            ${candidates.map((v) => html`
              <button class="align-vac-chip ${v.entity === vac.entity ? "on" : ""}"
                @click=${() => { this._closeAlign(); this._openAlign(v); }}>
                ${v.name ?? v.entity}
              </button>
            `)}
          </div>` : nothing}
          <div class="align-toolbar-spacer"></div>
          <div class="align-tier-group" title="Nudge step size — hold Ctrl for Jemně, Shift for Skok">
            ${tierBtn("fine", "Jemně", "Fine step (0,1×) — or hold Ctrl")}
            ${tierBtn("normal", "Krok", "Normal step (1×)")}
            ${tierBtn("jump", "Skok", "Jump step (10×) — or hold Shift")}
          </div>
          <button class="align-btn" title="Undo (Ctrl+Z)" ?disabled=${!canUndo} @click=${() => this._alignUndo()}>
            <ha-icon icon="mdi:undo"></ha-icon>
          </button>
          <button class="align-btn" title="Redo (Ctrl+Y)" ?disabled=${!canRedo} @click=${() => this._alignRedo()}>
            <ha-icon icon="mdi:redo"></ha-icon>
          </button>
          <button class="align-btn" title="Rotate view 90°" @click=${() => this._alignRotateView()}>
            <ha-icon icon="mdi:screen-rotation"></ha-icon>
          </button>
          <button class="align-btn" title="Reset to the values Align mode was opened with"
            ?disabled=${readOnly} @click=${() => this._alignReset()}>
            <ha-icon icon="mdi:restore"></ha-icon>
          </button>
          <button class="align-btn ${this._alignCopiedFlash ? "align-btn--flash" : ""}"
            title="Copy as YAML (map: block, paste into the card config)" @click=${() => this._alignCopyYaml()}>
            <ha-icon icon=${this._alignCopiedFlash ? "mdi:check" : "mdi:content-copy"}></ha-icon>
          </button>
          <button class="align-btn align-close-btn" title="Cancel" @click=${() => this._alignCancel()}>
            <ha-icon icon="mdi:close"></ha-icon>
          </button>
          <button class="align-btn align-save-btn" ?disabled=${!canSave}
            title=${canSave ? "Save" : readOnly ? "Read-only — aligned by home frame" : "Update the AnyVac integration to 2.0.0 — or Copy YAML"}
            @click=${() => this._alignSave()}>
            <ha-icon icon="mdi:content-save"></ha-icon><span>Save</span>
          </button>
        </div>
        <div class="align-body">
          <div class="align-canvas"
            @wheel=${(e: WheelEvent) => this._alignWheel(e)}
            @pointerdown=${(e: PointerEvent) => this._alignBgPointerDown(e)}
            @pointermove=${(e: PointerEvent) => this._alignBgPointerMove(e)}
            @pointerup=${(e: PointerEvent) => this._alignBgPointerUp(e)}
            @pointercancel=${(e: PointerEvent) => this._alignBgPointerUp(e)}>
            <div class="align-scene" style=${styleMap({
              width: wrapW + "px", height: wrapH + "px",
              transform: this._alignViewTransformCss(),
            })}>
              ${ib?.src ? html`<img class="align-floorplan-img" src=${ib.src} alt="Floorplan"
                  @load=${this._onFloorplanLoad}
                  style=${styleMap({
                    opacity: String(session.layers.floor),
                    transform: "translate(" + (ib.offset_x ?? 0) + "%," + (ib.offset_y ?? 0) + "%) rotate(" + (ib.rotation ?? 0) + "deg) scale(" + ((ib.scale ?? 100) / 100) + ")",
                  })} />` : nothing}
              ${others.map((v) => {
                const gm = this._mapEntityFor(v);
                const gUrl = gm ? this._mapUrl(gm) : null;
                const gs = this._effectiveSeat(v);
                return html`
                  <div class="align-ghost">
                    ${gUrl ? html`<img class="align-seat-img" src=${gUrl} alt=""
                        style=${styleMap({
                          left: (50 + gs.offset_x) + "%", top: (50 + gs.offset_y) + "%", width: gs.scale + "%",
                          transform: "translate(-50%,-50%) " + seatRotateScaleCss(gs.rotation, gs.scale, gs.scaleY),
                        })} />` : nothing}
                    ${this._renderIntegrationOverlay(v, gs, "both")}
                  </div>`;
              })}
              <div class="align-seat-layer ${readOnly ? "align-seat-layer--readonly" : ""}"
                @pointerdown=${(e: PointerEvent) => this._alignStartGesture(e, "drag")}
                @pointermove=${(e: PointerEvent) => this._alignGestureMove(e)}
                @pointerup=${(e: PointerEvent) => this._alignGestureEnd(e)}
                @pointercancel=${(e: PointerEvent) => this._alignGestureEnd(e)}>
                ${mapUrl ? html`<img class="align-seat-img" src=${mapUrl} alt="Vacuum map"
                    style=${styleMap({
                      opacity: String(session.layers.rawMap),
                      left: (50 + draft.offset_x) + "%", top: (50 + draft.offset_y) + "%", width: draft.scale + "%",
                      transform: "translate(-50%,-50%) " + seatRotateScaleCss(draft.rotation, draft.scale, draft.scaleY),
                    })} />` : nothing}
                ${this._renderIntegrationOverlay(vac, draft, "both")}
              </div>
              ${readOnly ? html`
                <div class="align-readonly-note">
                  <ha-icon icon="mdi:lock-outline"></ha-icon>
                  <span>aligned by home frame — nothing to adjust</span>
                </div>
              ` : html`
                <svg class="align-gizmo" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <line x1=${centre.x} y1=${centre.y} x2=${rotateHandle.x} y2=${rotateHandle.y} class="align-gizmo-arm" />
                  <polygon points="${nw.x},${nw.y} ${ne.x},${ne.y} ${se.x},${se.y} ${sw.x},${sw.y}" class="align-gizmo-box" />
                </svg>
                ${([["nw", nw], ["ne", ne], ["se", se], ["sw", sw]] as const).map(([key, pos]) => html`
                  <div class="align-handle align-handle--corner" data-corner=${key}
                    style=${styleMap({ left: pos.x + "%", top: pos.y + "%" })}
                    @pointerdown=${(e: PointerEvent) => {
                      const opp = key === "nw" ? se : key === "ne" ? sw : key === "se" ? nw : ne;
                      this._alignStartGesture(e, "scale", opp);
                    }}
                    @pointermove=${(e: PointerEvent) => this._alignGestureMove(e)}
                    @pointerup=${(e: PointerEvent) => this._alignGestureEnd(e)}
                    @pointercancel=${(e: PointerEvent) => this._alignGestureEnd(e)}>
                  </div>
                `)}
                ${([
                  ["n", nMid, "stretchY", 90, "mdi:arrow-up-down"],
                  ["s", sMid, "stretchY", 90, "mdi:arrow-up-down"],
                  ["w", wMid, "stretchX", 0, "mdi:arrow-left-right"],
                  ["e", eMid, "stretchX", 0, "mdi:arrow-left-right"],
                ] as const).map(([key, pos, kind, baseAxisDeg, icon]) => html`
                  <div class="align-handle align-handle--side align-handle--${key}" data-side=${key}
                    title=${kind === "stretchX" ? "Scale X" : "Scale Y"}
                    style=${styleMap({
                      left: pos.x + "%", top: pos.y + "%",
                      cursor: this._alignResizeCursor(baseAxisDeg, draft.rotation + this._alignView.rot),
                    })}
                    @pointerdown=${(e: PointerEvent) => this._alignStartGesture(e, kind)}
                    @pointermove=${(e: PointerEvent) => this._alignGestureMove(e)}
                    @pointerup=${(e: PointerEvent) => this._alignGestureEnd(e)}
                    @pointercancel=${(e: PointerEvent) => this._alignGestureEnd(e)}>
                    <ha-icon icon=${icon} style=${styleMap({ transform: "rotate(" + draft.rotation + "deg)" })}></ha-icon>
                  </div>
                `)}
                <div class="align-axis-hint align-axis-hint--x" title="Offset X"
                  style=${styleMap({ left: (centre.x + 7) + "%", top: centre.y + "%" })}>
                  <ha-icon icon="mdi:arrow-left-right"></ha-icon>
                </div>
                <div class="align-axis-hint align-axis-hint--y" title="Offset Y"
                  style=${styleMap({ left: centre.x + "%", top: (centre.y - 7) + "%" })}>
                  <ha-icon icon="mdi:arrow-up-down"></ha-icon>
                </div>
                <div class="align-handle align-handle--rotate"
                  style=${styleMap({ left: rotateHandle.x + "%", top: rotateHandle.y + "%" })}
                  @pointerdown=${(e: PointerEvent) => this._alignStartGesture(e, "rotate", centre)}
                  @pointermove=${(e: PointerEvent) => this._alignGestureMove(e)}
                  @pointerup=${(e: PointerEvent) => this._alignGestureEnd(e)}
                  @pointercancel=${(e: PointerEvent) => this._alignGestureEnd(e)}>
                  <ha-icon icon="mdi:rotate-3d-variant"></ha-icon>
                </div>
              `}
            </div>
          </div>
          <div class="align-side-panel">
            <div class="align-field-row align-field-row--opacity">
              <label>Floorplan<span>%</span></label>
              <input type="range" min="0" max="100" step="5"
                .value=${String(Math.round(session.layers.floor * 100))}
                @input=${(e: Event) => this._alignSetLayerOpacity("floor", (e.target as HTMLInputElement).value)}
                @change=${() => this._alignRefocusOverlay()} />
            </div>
            <div class="align-field-row align-field-row--opacity">
              <label>Vacuum map<span>%</span></label>
              <input type="range" min="0" max="100" step="5"
                .value=${String(Math.round(session.layers.rawMap * 100))}
                @input=${(e: Event) => this._alignSetLayerOpacity("rawMap", (e.target as HTMLInputElement).value)}
                @change=${() => this._alignRefocusOverlay()} />
            </div>
            <div class="align-field-row">
              <label>Rotation<span>°</span></label>
              <input type="number" step="0.1" .value=${String(Math.round(draft.rotation * 100) / 100)}
                ?disabled=${readOnly} @change=${(e: Event) => this._alignSetField("rotation", (e.target as HTMLInputElement).value)} />
            </div>
            <div class="align-field-row">
              <label>Scale${draft.scaleY != null ? this._alignFieldArrow(true, draft.rotation + this._alignView.rot) : nothing}<span>%</span></label>
              <input type="number" step="0.1" min="1" .value=${String(Math.round(draft.scale * 100) / 100)}
                ?disabled=${readOnly} @change=${(e: Event) => this._alignSetField("scale", (e.target as HTMLInputElement).value)} />
            </div>
            <div class="align-field-row align-field-row--check">
              <label>
                <input type="checkbox" .checked=${draft.scaleY != null} ?disabled=${readOnly}
                  @change=${(e: Event) => this._alignToggleScaleY((e.target as HTMLInputElement).checked)} />
                Independent Y scale
              </label>
            </div>
            ${draft.scaleY != null ? html`
              <div class="align-field-row">
                <label>Scale${this._alignFieldArrow(false, draft.rotation + this._alignView.rot)}<span>%</span></label>
                <input type="number" step="0.1" min="1" .value=${String(Math.round(draft.scaleY * 100) / 100)}
                  ?disabled=${readOnly} @change=${(e: Event) => this._alignSetField("scaleY", (e.target as HTMLInputElement).value)} />
              </div>
            ` : nothing}
            <div class="align-field-row">
              <label>Offset${this._alignFieldArrow(true, this._alignView.rot)}<span>%</span></label>
              <input type="number" step="0.01" .value=${String(Math.round(draft.offset_x * 10000) / 10000)}
                ?disabled=${readOnly} @change=${(e: Event) => this._alignSetField("offset_x", (e.target as HTMLInputElement).value)} />
            </div>
            <div class="align-field-row">
              <label>Offset${this._alignFieldArrow(false, this._alignView.rot)}<span>%</span></label>
              <input type="number" step="0.01" .value=${String(Math.round(draft.offset_y * 10000) / 10000)}
                ?disabled=${readOnly} @change=${(e: Event) => this._alignSetField("offset_y", (e.target as HTMLInputElement).value)} />
            </div>
          </div>
        </div>
        ${this._alignCancelConfirm ? html`
          <div class="align-confirm-backdrop">
            <div class="align-confirm-panel">
              <div class="align-confirm-title">Discard changes?</div>
              <div class="align-confirm-body">The alignment you made in this session hasn't been saved.</div>
              <div class="align-confirm-actions">
                <button class="align-btn align-confirm-keep" @click=${() => this._alignDismissCancelConfirm()}>Keep editing</button>
                <button class="align-btn align-confirm-discard" @click=${() => this._alignConfirmDiscard()}>Discard</button>
              </div>
            </div>
          </div>
        ` : nothing}
      </div>
    `;
  }

  /** docs/40 §4.4 (Fáze 3): is `vac` currently rendered via the shared home
   *  frame (one identity crop, no per-vacuum fit) instead of `_effectiveSeat`?
   *  `null` whenever not — different/no frame, not registered yet, or the
   *  config simply doesn't name one (`homeFrameCropFor`, seatfit.ts, is the
   *  single source of truth for the eligibility check; this just memoizes
   *  it the same way `_effectiveSeat` memoizes `resolveSeat`). */
  private _homeFrameCropFor(vac: VacuumConfig): CropBox | null {
    this._memoSync();
    if (this._homeFrameMemo.has(vac.entity)) return this._homeFrameMemo.get(vac.entity)!;
    const out = homeFrameCropFor(this._config, vac, this._intAttrs(vac));
    this._homeFrameMemo.set(vac.entity, out);
    return out;
  }

  /** docs/40 §5.B: the home frame's own CURRENT `{width_px, height_px}` —
   *  read live off whatever configured vacuum's `home_frame` sensor
   *  attribute reports it, so `homeAnchorFit` always fits against the
   *  frame's present size, not a stale one (the whole self-healing point of
   *  storing raw anchor pairs instead of a solved seat). `image_base.
   *  home_anchors_frame_id` picks a specific frame by id when more than one
   *  is active (a real multi-floor home); omitted, this picks whichever
   *  frame the most configured vacuums are currently registered into — the
   *  same default policy the backend's `_select_home_frame` uses for
   *  `frame: "home"` calls with no explicit `frame_id` (docs/14 rule 1: one
   *  selection policy, mirrored here since the card has no service call to
   *  delegate this particular choice to). */
  private _homeFrameDims(): { NW: number; NH: number } | null {
    const wantId = this._config.image_base?.home_anchors_frame_id;
    const byId = new Map<string, { w: number; h: number; count: number }>();
    for (const v of this._config.vacuums ?? []) {
      const hf = this._intAttrs(v)?.home_frame as
        | { id?: string; width_px?: number; height_px?: number }
        | null
        | undefined;
      if (!hf?.id || !(hf.width_px! > 0) || !(hf.height_px! > 0)) continue;
      const cur = byId.get(hf.id);
      if (cur) cur.count++;
      else byId.set(hf.id, { w: hf.width_px!, h: hf.height_px!, count: 1 });
    }
    if (wantId) { const f = byId.get(wantId); if (f) return { NW: f.w, NH: f.h }; }
    let best: { w: number; h: number; count: number } | null = null;
    for (const f of byId.values()) if (!best || f.count > best.count) best = f;
    return best ? { NW: best.w, NH: best.h } : null;
  }

  /** docs/40 §5.B: `vac`'s live cesta-B fit — a FOREIGN-origin floorplan
   *  (`image_base.home_anchors`) calibrated against the home frame, used
   *  only when cesta A's identity crop does NOT already apply (that always
   *  takes priority — no fit needed there at all) and `vac` is currently
   *  registered into a home frame (so its `*_home_px` fields are valid).
   *  `null` whenever ineligible or under 2 anchors — caller falls back to
   *  `_effectiveSeat`, same automatic "no extra config" fallback chain
   *  cesta A already established. Re-solved on every call (a 2-6 point
   *  least-squares fit is negligible cost — no memo needed, unlike
   *  `_effectiveSeat`/`_homeFrameCropFor`, which cache to skip a live
   *  integration-attribute walk on every access instead). */
  private _homeAnchorFitFor(
    vac: VacuumConfig, ar: number,
  ): { fit: SeatFitResult; dims: { NW: number; NH: number } } | null {
    // docs/40 §4.4/§5.B: cesta B, like cesta A, is a MERGED-mode-only concept
    // (a home frame is inherently shared across vacuums) — split mode stays
    // untouched ("Split mód beze změny"), so this never reads a per-vacuum
    // `image_base` as if it were the card-level one.
    if (this._config.map_mode !== "merged") return null;
    if (this._homeFrameCropFor(vac)) return null;
    if (!this._intAttrs(vac)?.home_frame) return null;
    const anchors = this._config.image_base?.home_anchors;
    const dims = this._homeFrameDims();
    const fit = homeAnchorFit(anchors, dims, ar);
    return fit && dims ? { fit, dims } : null;
  }

  /** Integration mode: draw the robot + cleaning path as a vector overlay from the
   *  px-space attributes (kontrakt v2: vacuum_position_px, path_dry_px, path_wet_px
   *  — already in rendered-map pixels, no client-side mm math). */
  /** `part` lets merged mode (multiple vacuums stacked in one map, docs/19)
   *  z-order paths and markers as two separate GROUPS across ALL vacuums,
   *  instead of interleaved per vacuum. Each vacuum's own <svg> already put
   *  its robot marker after its own paths (top within itself), but merged
   *  mode stacks a whole such <svg> per vacuum one after another in DOM
   *  order — so vacuum #2's translucent wet-mop band (~28% opacity, wide)
   *  still visually sat OVER vacuum #1's robot marker, since #1's entire
   *  <svg> (marker included) is earlier in the DOM than #2's paths (field
   *  report 2026-07-26: S6's marker disappearing under S8's wet trace).
   *  Split mode's `_renderMap` renders one fully independent box per vacuum
   *  (no shared stacking context), so it keeps using the default "both". */
  private _renderIntegrationOverlay(vac: VacuumConfig, m: any, part: "both" | "paths" | "marker" = "both") {
    const at = this._intAttrs(vac);
    if (!at) return nothing;
    const dims = at.image_dims;
    if (!dims) return nothing;
    const sc = dims.scale ?? 1;
    let NW = (dims.width ?? 0) * sc;
    let NH = (dims.height ?? 0) * sc;
    const rot = dims.rotation ?? 0;
    if (rot === 90 || rot === 270) { const tmp = NW; NW = NH; NH = tmp; }
    if (!NW || !NH) return nothing;
    const color = this._color(vac);
    const rr = Math.max(NW, NH) / 55;
    const toPts = (arr: any) => (Array.isArray(arr) ? arr : []).map((p: any) => p.x.toFixed(1) + "," + p.y.toFixed(1)).join(" ");
    const ct = this._vacCleanType(vac);
    // Dry layer draws the SEGMENTED dry trace (path_dry_px — cleaning-only points,
    // no transit / mop-wash driving). Wet layer draws the mop trace as a wider
    // translucent "wet sheen" band under the line.
    const layersOn = this._layersEff();
    const showDry = layersOn.dry && ct.dry;
    const showWet = layersOn.wet && ct.wet;
    // path_dry_px / path_wet_px are both lists of contiguous segments (docs/14 §3.9
    // for dry; docs/27 extends the same shape to wet) — the backend never bridges an
    // excluded gap (transit/mop-wash for dry, a dock trip between two dispatches of
    // the same orchestrated job for wet) with a straight line, so the card must not
    // either. One <polyline> per segment; a single flat polyline across all segments
    // used to draw a spurious diagonal line at every gap, which is why a finished
    // multi-room dry trace used to look like a scribble while the live in-progress
    // trace (still one segment) looked clean (fixed 2026-07-15) — same class of bug
    // docs/27 avoids for a multi-sortie wet trace by segmenting it the same way.
    const drySegs: string[] = showDry && Array.isArray(at.path_dry_px)
      ? at.path_dry_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const wetSegs: string[] = showWet && Array.isArray(at.path_wet_px)
      ? at.path_wet_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const vp = at.vacuum_position_px;
    const rob = vp ? { x: vp.x as number, y: vp.y as number } : null;
    let head: { x: number; y: number } | null = null;
    if (rob && vp.a != null) {
      // Heading: the angle is reported in vacuum space; the mm→px transform flips
      // the y axis, so the px-space direction is (cos a, −sin a).
      const arad = (vp.a * Math.PI) / 180;
      head = { x: rob.x + rr * 1.3 * Math.cos(arad), y: rob.y - rr * 1.3 * Math.sin(arad) };
    }
    const seat = {
      left: (50 + (m?.offset_x ?? 0)) + "%",
      top: (50 + (m?.offset_y ?? 0)) + "%",
      width: (m?.scale ?? 100) + "%",
      aspectRatio: NW + " / " + NH,
      transform: "translate(-50%,-50%) " + seatRotateScaleCss(m?.rotation ?? 0, m?.scale ?? 100, m?.scaleY),
    };
    const pw = rr * 0.35 * ((vac.path_width ?? 100) / 100);
    const sw = pw.toFixed(2);
    const bw = (pw * 2.6 * ((vac.mop_band_width ?? 100) / 100)).toFixed(2);
    const bandOp = ((vac.mop_band_opacity ?? 28) / 100).toFixed(2);
    const wetColor = vac.mop_path_color || "#40a9ff";
    const mopBand = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${bw} stroke-linejoin="round" stroke-linecap="round" opacity=${bandOp}></polyline>`)}`
      : nothing;
    // Thin centre line down the mop band, so the wet trace reads as a path inside the sheen.
    const mopLine = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.9"></polyline>`)}`
      : nothing;
    // v1.2.0 (docs/35 §6): the dry trace was a single hairline, which reads as
    // a scribble once a whole flat has been covered. A much wider, very faint
    // pass underneath turns it into a lit trail instead — same geometry drawn
    // twice, so the cost is one extra <polyline> per segment (the points are
    // already RDP-simplified server-side, integration 0.67.0) and nothing else.
    // Skipped on `legacy` so that theme stays exactly as it was, and so there
    // is a way back if the doubled node count ever bites on weak hardware.
    const dryColor = vac.path_color || color;
    const softMap = (this._config.theme ?? DEFAULT_THEME) !== "legacy";
    const glowW = (pw * 3).toFixed(2);
    const traceT = drySegs.length
      ? svg`${softMap ? drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${glowW} stroke-linejoin="round" stroke-linecap="round" opacity="0.12"></polyline>`) : nothing}${drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.85"></polyline>`)}`
      : nothing;
    const useImg = !!(vac.robot_image_on_map && vac.image);
    const robSize = rr * 2.6 * ((vac.robot_size ?? 100) / 100);
    const robA = (vp && vp.a != null ? vp.a : 0) + (vac.robot_image_rotation ?? 0);
    const robotT = rob
      ? (useImg
          ? svg`<image href=${vac.image!} x=${(rob.x - robSize / 2).toFixed(1)} y=${(rob.y - robSize / 2).toFixed(1)} width=${robSize.toFixed(1)} height=${robSize.toFixed(1)} preserveAspectRatio="xMidYMid meet" transform=${"rotate(" + robA + " " + rob.x.toFixed(1) + " " + rob.y.toFixed(1) + ")"}></image>`
          : svg`${head ? svg`<line x1=${rob.x.toFixed(1)} y1=${rob.y.toFixed(1)} x2=${head.x.toFixed(1)} y2=${head.y.toFixed(1)} stroke="#ffffff" stroke-width=${(rr * 0.3).toFixed(2)} stroke-linecap="round"></line>` : nothing}<circle cx=${rob.x.toFixed(1)} cy=${rob.y.toFixed(1)} r=${rr.toFixed(1)} fill=${color} stroke="#ffffff" stroke-width=${(rr * 0.18).toFixed(2)}></circle>`)
      : nothing;
    // Robot-error halo: a soft pulsing red glow behind the robot marker, so an
    // active error is visible directly on the map, not just in the status card.
    // Filter id is per-vacuum-entity to avoid collisions between multiple <svg>
    // overlays (merged mode renders one per vacuum, all in the same shadow root).
    const hasErr = rob && this._hasError(vac);
    const errFilterId = "avc-err-blur-" + vac.entity.replace(/[^a-zA-Z0-9]/g, "-");
    const errHalo = hasErr
      ? svg`<defs><filter id=${errFilterId} x="-150%" y="-150%" width="400%" height="400%">
              <feGaussianBlur stdDeviation=${(rr * 0.5).toFixed(2)}></feGaussianBlur>
            </filter></defs>
            <circle class="avc-err-halo" cx=${rob!.x.toFixed(1)} cy=${rob!.y.toFixed(1)} r=${(rr * 2.2).toFixed(1)}
              fill="#ff3b30" filter=${"url(#" + errFilterId + ")"}></circle>`
      : nothing;
    // 2026-09-17 field report: the extra Y-only `scale(1,r)` `scaleY` adds to
    // the SVG's OWN CSS transform (`seatRotateScaleCss`, in `seat` below)
    // stretches EVERYTHING drawn in its `viewBox` space uniformly — paths
    // and rooms are meant to stretch (that's the whole point of `scaleY`),
    // but the robot marker/icon is not: a plain circle would render as an
    // ellipse, and `robot_image_on_map` would visibly squash. Counter-scale
    // just the marker group by the reciprocal ratio, anchored at the robot's
    // own position so it neither shifts nor distorts, while the path stretch
    // (`pathsInner`, left alone) still does its job. `seatScaleYRatio` is 1
    // (a no-op) for every non-`_renderIntegrationOverlay` caller and every
    // config written before `scale_y` existed, so this is additive only.
    const scaleYRatio = seatScaleYRatio(m?.scale ?? 100, m?.scaleY);
    const markerContent = svg`${errHalo}${robotT}`;
    const markerInner = (scaleYRatio !== 1 && rob)
      ? svg`<g transform=${"translate(" + rob.x.toFixed(1) + "," + rob.y.toFixed(1) + ") scale(1," + (1 / scaleYRatio).toFixed(4) + ") translate(" + (-rob.x).toFixed(1) + "," + (-rob.y).toFixed(1) + ")"}>${markerContent}</g>`
      : markerContent;
    const pathsInner = svg`${mopBand}${mopLine}${traceT}`;
    const inner = part === "paths" ? pathsInner : part === "marker" ? markerInner : svg`${pathsInner}${markerInner}`;
    return html`<svg class="map-vector" viewBox="0 0 ${NW} ${NH}" preserveAspectRatio="none" style=${styleMap(seat)}>${inner}</svg>`;
  }

  /** docs/40 §4.4 (Fáje 3) home-frame twin of `_renderIntegrationOverlay` —
   *  same visual language (dry/wet trace, marker, error halo) but sourcing
   *  the ALREADY-CO-REGISTERED `*_home_px` fields through `crop` (this
   *  vacuum's own `homeFrameCropFor` result) instead of this vacuum's own
   *  `*_px`/seat. No fit, no rotation, no per-vacuum CSS seat at all — the
   *  crop already agrees across every vacuum sharing this frame (Fáze 1
   *  registration), so it's the exact same "known crop, no rotation"
   *  re-normalisation `placeRoomInCrop`/`outlineInCrop` do for rooms
   *  (seatfit.ts), just for a point/polyline. The `<svg>`'s own viewBox is
   *  the crop's OWN px extent (not a 0..100 square) so it inherits the
   *  wrap's aspect ratio exactly (that wrap was itself sized off the same
   *  crop's `image_base`, docs/40 §4.5) — keeping the robot-marker circle
   *  actually circular instead of stretched.
   *
   *  Heading: `vacuum_position_home_px.a` is `_home_px_heading`'s OWN
   *  self-consistent convention (coordinator.py, integration 1.8.1 bugfix)
   *  — standard atan2 in this exact px space (0°=+x/right, 90°=+y/down) —
   *  unlike the legacy `vacuum_position_px` contract, where the card negates
   *  `sin` to undo a flip baked into THAT contract's solved affine. Since
   *  home-px space needs no such correction, this uses `+sin`. */
  private _renderHomeFrameOverlay(vac: VacuumConfig, crop: CropBox, part: "both" | "paths" | "marker" = "both") {
    const at = this._intAttrs(vac);
    if (!at) return nothing;
    const cropW = crop.x1 - crop.x0;
    const cropH = crop.y1 - crop.y0;
    if (!(cropW > 0) || !(cropH > 0)) return nothing;
    const color = this._color(vac);
    const rr = Math.max(cropW, cropH) / 55;
    const local = (p: { x: number; y: number }) => ({ x: p.x - crop.x0, y: p.y - crop.y0 });
    const toPts = (seg: any) =>
      (Array.isArray(seg) ? seg : [])
        .map((p: any) => { const q = local(p); return q.x.toFixed(1) + "," + q.y.toFixed(1); })
        .join(" ");
    const ct = this._vacCleanType(vac);
    const layersOn = this._layersEff();
    const showDry = layersOn.dry && ct.dry;
    const showWet = layersOn.wet && ct.wet;
    const drySegs: string[] = showDry && Array.isArray(at.path_dry_home_px)
      ? at.path_dry_home_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const wetSegs: string[] = showWet && Array.isArray(at.path_wet_home_px)
      ? at.path_wet_home_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const vp = at.vacuum_position_home_px;
    const rob = vp ? local(vp) : null;
    let head: { x: number; y: number } | null = null;
    if (rob && vp.a != null) {
      const arad = (vp.a * Math.PI) / 180;
      head = { x: rob.x + rr * 1.3 * Math.cos(arad), y: rob.y + rr * 1.3 * Math.sin(arad) };
    }
    const style = { left: "0", top: "0", width: "100%", height: "100%" };
    const pw = rr * 0.35 * ((vac.path_width ?? 100) / 100);
    const sw = pw.toFixed(2);
    const bw = (pw * 2.6 * ((vac.mop_band_width ?? 100) / 100)).toFixed(2);
    const bandOp = ((vac.mop_band_opacity ?? 28) / 100).toFixed(2);
    const wetColor = vac.mop_path_color || "#40a9ff";
    const mopBand = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${bw} stroke-linejoin="round" stroke-linecap="round" opacity=${bandOp}></polyline>`)}`
      : nothing;
    const mopLine = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.9"></polyline>`)}`
      : nothing;
    const dryColor = vac.path_color || color;
    const softMap = (this._config.theme ?? DEFAULT_THEME) !== "legacy";
    const glowW = (pw * 3).toFixed(2);
    const traceT = drySegs.length
      ? svg`${softMap ? drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${glowW} stroke-linejoin="round" stroke-linecap="round" opacity="0.12"></polyline>`) : nothing}${drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.85"></polyline>`)}`
      : nothing;
    const useImg = !!(vac.robot_image_on_map && vac.image);
    const robSize = rr * 2.6 * ((vac.robot_size ?? 100) / 100);
    const robA = (vp && vp.a != null ? vp.a : 0) + (vac.robot_image_rotation ?? 0);
    const robotT = rob
      ? (useImg
          ? svg`<image href=${vac.image!} x=${(rob.x - robSize / 2).toFixed(1)} y=${(rob.y - robSize / 2).toFixed(1)} width=${robSize.toFixed(1)} height=${robSize.toFixed(1)} preserveAspectRatio="xMidYMid meet" transform=${"rotate(" + robA + " " + rob.x.toFixed(1) + " " + rob.y.toFixed(1) + ")"}></image>`
          : svg`${head ? svg`<line x1=${rob.x.toFixed(1)} y1=${rob.y.toFixed(1)} x2=${head.x.toFixed(1)} y2=${head.y.toFixed(1)} stroke="#ffffff" stroke-width=${(rr * 0.3).toFixed(2)} stroke-linecap="round"></line>` : nothing}<circle cx=${rob.x.toFixed(1)} cy=${rob.y.toFixed(1)} r=${rr.toFixed(1)} fill=${color} stroke="#ffffff" stroke-width=${(rr * 0.18).toFixed(2)}></circle>`)
      : nothing;
    const hasErr = rob && this._hasError(vac);
    const errFilterId = "avc-hf-err-blur-" + vac.entity.replace(/[^a-zA-Z0-9]/g, "-");
    const errHalo = hasErr
      ? svg`<defs><filter id=${errFilterId} x="-150%" y="-150%" width="400%" height="400%">
              <feGaussianBlur stdDeviation=${(rr * 0.5).toFixed(2)}></feGaussianBlur>
            </filter></defs>
            <circle class="avc-err-halo" cx=${rob!.x.toFixed(1)} cy=${rob!.y.toFixed(1)} r=${(rr * 2.2).toFixed(1)}
              fill="#ff3b30" filter=${"url(#" + errFilterId + ")"}></circle>`
      : nothing;
    const pathsInner = svg`${mopBand}${mopLine}${traceT}`;
    const markerInner = svg`${errHalo}${robotT}`;
    const inner = part === "paths" ? pathsInner : part === "marker" ? markerInner : svg`${pathsInner}${markerInner}`;
    return html`<svg class="map-vector" viewBox="0 0 ${cropW} ${cropH}" preserveAspectRatio="none" style=${styleMap(style)}>${inner}</svg>`;
  }

  /** docs/40 §5.B ("cesta B") twin of `_renderHomeFrameOverlay` above — for a
   *  FOREIGN-origin floorplan (photo/drawing) calibrated against the home
   *  frame instead of snapshotted from it, so there is no identity crop:
   *  every `*_home_px` point is projected through the live-solved
   *  `homeAnchorFit` (seatfit.ts) onto the floorplan wrap directly, one
   *  point at a time, via `projectHomePxThroughFit` — no CSS-transformed
   *  "raw content rectangle" the way a per-vacuum seat or an identity crop
   *  both place, since there is no single rectangle of raw content here to
   *  place, only individual points.
   *
   *  The `<svg>` covers the WHOLE wrap (`viewBox="0 0 100 ${100/ar}"`,
   *  `preserveAspectRatio="none"`, full-cover style) rather than being
   *  itself positioned/sized/rotated by CSS — that viewBox's own aspect
   *  ratio is chosen to equal `ar` (the wrap's own), so the anisotropic CSS
   *  stretch to 100%/100% is actually a UNIFORM scale on both axes and
   *  circles (the robot marker, its error halo) stay circular, same
   *  motivation as `_renderHomeFrameOverlay`'s crop-shaped viewBox, just
   *  achieved by picking the viewBox's shape directly instead of inheriting
   *  it from a crop. `projectHomePxThroughFit`'s output is plain 0..100
   *  wrap-percent, so a projected point's own SVG coordinate is `(pct.x,
   *  pct.y / ar)` — dividing y by `ar` is the same "wrap units" convention
   *  `seatfit.ts` already uses internally (`SeatAnchor.a`), just carried
   *  one step further out into this file.
   *
   *  Heading: home-px space's own heading convention already composes
   *  cleanly with the fit's rotation — `fit.rotation` (snapped to 0/90/
   *  180/270 by `computeSeatFit`) rotates every point/vector the SAME way,
   *  so a heading direction `(cos a, sin a)` in home-px axes becomes
   *  `(cos(a+rot), sin(a+rot))` in the projected (also x-right/y-down)
   *  output axes — no separate point projection needed for the heading
   *  tick, just this one angle addition. */
  private _renderHomeAnchorOverlay(
    vac: VacuumConfig,
    fit: SeatFitResult,
    dims: { NW: number; NH: number },
    ar: number,
    part: "both" | "paths" | "marker" = "both",
  ) {
    const at = this._intAttrs(vac);
    if (!at || !(ar > 0)) return nothing;
    const color = this._color(vac);
    const proj = (p: { x: number; y: number }) => {
      const pct = projectHomePxThroughFit(p, dims, fit, ar);
      return { x: pct.x, y: pct.y / ar };
    };
    const rr = Math.max(100, 100 / ar) / 55;
    const toPts = (seg: any) =>
      (Array.isArray(seg) ? seg : [])
        .map((p: any) => { const q = proj(p); return q.x.toFixed(2) + "," + q.y.toFixed(2); })
        .join(" ");
    const ct = this._vacCleanType(vac);
    const layersOn = this._layersEff();
    const showDry = layersOn.dry && ct.dry;
    const showWet = layersOn.wet && ct.wet;
    const drySegs: string[] = showDry && Array.isArray(at.path_dry_home_px)
      ? at.path_dry_home_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const wetSegs: string[] = showWet && Array.isArray(at.path_wet_home_px)
      ? at.path_wet_home_px.map((seg: any) => toPts(seg)).filter((s: string) => s.length > 0)
      : [];
    const vp = at.vacuum_position_home_px;
    const rob = vp ? proj(vp) : null;
    let head: { x: number; y: number } | null = null;
    if (rob && vp.a != null) {
      const arad = ((vp.a + fit.rotation) * Math.PI) / 180;
      head = { x: rob.x + rr * 1.3 * Math.cos(arad), y: rob.y + rr * 1.3 * Math.sin(arad) };
    }
    const style = { left: "0", top: "0", width: "100%", height: "100%" };
    const pw = rr * 0.35 * ((vac.path_width ?? 100) / 100);
    const sw = pw.toFixed(2);
    const bw = (pw * 2.6 * ((vac.mop_band_width ?? 100) / 100)).toFixed(2);
    const bandOp = ((vac.mop_band_opacity ?? 28) / 100).toFixed(2);
    const wetColor = vac.mop_path_color || "#40a9ff";
    const mopBand = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${bw} stroke-linejoin="round" stroke-linecap="round" opacity=${bandOp}></polyline>`)}`
      : nothing;
    const mopLine = wetSegs.length
      ? svg`${wetSegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${wetColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.9"></polyline>`)}`
      : nothing;
    const dryColor = vac.path_color || color;
    const softMap = (this._config.theme ?? DEFAULT_THEME) !== "legacy";
    const glowW = (pw * 3).toFixed(2);
    const traceT = drySegs.length
      ? svg`${softMap ? drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${glowW} stroke-linejoin="round" stroke-linecap="round" opacity="0.12"></polyline>`) : nothing}${drySegs.map((s) => svg`<polyline points=${s} fill="none" stroke=${dryColor} stroke-width=${sw} stroke-linejoin="round" stroke-linecap="round" opacity="0.85"></polyline>`)}`
      : nothing;
    const useImg = !!(vac.robot_image_on_map && vac.image);
    const robSize = rr * 2.6 * ((vac.robot_size ?? 100) / 100);
    const robA = (vp && vp.a != null ? vp.a + fit.rotation : 0) + (vac.robot_image_rotation ?? 0);
    const robotT = rob
      ? (useImg
          ? svg`<image href=${vac.image!} x=${(rob.x - robSize / 2).toFixed(2)} y=${(rob.y - robSize / 2).toFixed(2)} width=${robSize.toFixed(2)} height=${robSize.toFixed(2)} preserveAspectRatio="xMidYMid meet" transform=${"rotate(" + robA + " " + rob.x.toFixed(2) + " " + rob.y.toFixed(2) + ")"}></image>`
          : svg`${head ? svg`<line x1=${rob.x.toFixed(2)} y1=${rob.y.toFixed(2)} x2=${head.x.toFixed(2)} y2=${head.y.toFixed(2)} stroke="#ffffff" stroke-width=${(rr * 0.3).toFixed(2)} stroke-linecap="round"></line>` : nothing}<circle cx=${rob.x.toFixed(2)} cy=${rob.y.toFixed(2)} r=${rr.toFixed(2)} fill=${color} stroke="#ffffff" stroke-width=${(rr * 0.18).toFixed(2)}></circle>`)
      : nothing;
    const hasErr = rob && this._hasError(vac);
    const errFilterId = "avc-ha-err-blur-" + vac.entity.replace(/[^a-zA-Z0-9]/g, "-");
    const errHalo = hasErr
      ? svg`<defs><filter id=${errFilterId} x="-150%" y="-150%" width="400%" height="400%">
              <feGaussianBlur stdDeviation=${(rr * 0.5).toFixed(2)}></feGaussianBlur>
            </filter></defs>
            <circle class="avc-err-halo" cx=${rob!.x.toFixed(2)} cy=${rob!.y.toFixed(2)} r=${(rr * 2.2).toFixed(2)}
              fill="#ff3b30" filter=${"url(#" + errFilterId + ")"}></circle>`
      : nothing;
    const pathsInner = svg`${mopBand}${mopLine}${traceT}`;
    const markerInner = svg`${errHalo}${robotT}`;
    const inner = part === "paths" ? pathsInner : part === "marker" ? markerInner : svg`${pathsInner}${markerInner}`;
    return html`<svg class="map-vector" viewBox=${"0 0 100 " + (100 / ar).toFixed(3)} preserveAspectRatio="none" style=${styleMap(style)}>${inner}</svg>`;
  }

  private _onLayerDown(type: "dry" | "wet"): void {
    this._layerHeld = false;
    this._layerHoldTimer = window.setTimeout(() => {
      this._layerHeld = true;
      this._layerMenu = this._layerMenu === type ? null : type;
    }, 380);
  }
  private _onLayerUp(): void {
    if (this._layerHoldTimer !== null) { window.clearTimeout(this._layerHoldTimer); this._layerHoldTimer = null; }
  }
  private _onLayerClick(type: "dry" | "wet"): void {
    if (this._layerHeld) { this._layerHeld = false; return; }
    const cur = this._layersEff();
    const next = { ...cur, [type]: !cur[type] };
    const ent = this._selSensor();
    if (ent && this.hass.states[ent]?.attributes?.view_layers) {
      // Backend-shared view state — persists refreshes, syncs across devices.
      this._call("anyvac", "set_layers", next);
    } else {
      this._layers = next;
    }
    this._layerMenu = null;
  }
  /** Hold-expanded per-room ages for one layer (dry/wet). */
  private _renderLayerMenu(vacs: VacuumConfig[], type: "dry" | "wet") {
    const rooms = this._mergedRoomDefs(vacs);
    const badge = (d: number | null) => (d === null ? "\u2014" : d < 1 ? "<1d" : Math.round(d) + "d");
    return html`
      <div class="layer-menu">
        <div class="layer-menu-head">
          <ha-icon icon=${type === "dry" ? "mdi:broom" : "mdi:water"}></ha-icon>
          <span>${type === "dry" ? "Dry" : "Wet"} \u00b7 last cleaned</span>
        </div>
        ${rooms.map(({ r, v }) => {
          const rec = this._intRoomRec(v, r);
          const d = this._ageDaysFromIso(rec?.[type]);
          const sel = this._isRoomSelectedAny(r.key, vacs);
          return html`
            <button class="layer-menu-row ${sel ? "on" : ""}" @click=${() => this._toggleRoomAcross(r.key, vacs)}>
              <ha-icon icon=${r.icon ?? "mdi:square"}></ha-icon>
              <span class="lm-name">${r.name ?? r.key}</span>
              ${this._renderProgChip(this._roomProgForType(r, vacs, type))}
              <b style=${styleMap({ color: this._colorForAgeDays(d) })}>${badge(d)}</b>
            </button>
          `;
        })}
      </div>
    `;
  }

  /** Oldest per-type (dry/wet) last-cleaned age across a set of vacuums \u2014 shared
   *  by the legacy floating pill and the grid meta bar's compact toggle. */
  private _oldestAgeDays(vacs: VacuumConfig[], type: "dry" | "wet"): number | null {
    let max: number | null = null;
    for (const v of vacs) {
      if (!this._intAttrs(v)) continue;
      const rlc = this._intAttrs(v)?.rooms_last_cleaned as Record<string, any> | undefined;
      if (!rlc) continue;
      for (const rec of Object.values(rlc)) {
        const d = this._ageDaysFromIso((rec as any)?.[type]);
        if (d !== null && (max === null || d > max)) max = d;
      }
    }
    return max;
  }
  private _ageBadgeStr(d: number | null): string {
    return d === null ? "\u2014" : d < 1 ? "<1d" : Math.round(d) + "d";
  }
  /** Compact dry/wet visibility toggle for the grid meta bar (docs/19 A4) \u2014 a
   *  plain click-to-toggle icon+age chip, no hold-to-open per-room menu: that
   *  menu duplicated the always-visible dock room list in landscape. The
   *  legacy floating `_renderLayerToggles` (below) keeps its hold-menu \u2014 the
   *  canon commitment is that render without a `layout:` block never changes. */
  private _renderLayerToggleCompact(vacs: VacuumConfig[]) {
    const withInt = vacs.filter((v) => this._intAttrs(v));
    if (!withInt.length) return nothing;
    const L = this._layersEff();
    return html`
      <button class="mtbtn ${L.dry ? "on" : ""}" title="Dry layer visibility \u2014 tap to toggle"
        @click=${() => this._onLayerClick("dry")}>
        <ha-icon icon="mdi:broom"></ha-icon><span>${this._ageBadgeStr(this._oldestAgeDays(withInt, "dry"))}</span>
      </button>
      <button class="mtbtn ${L.wet ? "on" : ""}" title="Wet layer visibility \u2014 tap to toggle"
        @click=${() => this._onLayerClick("wet")}>
        <ha-icon icon="mdi:water"></ha-icon><span>${this._ageBadgeStr(this._oldestAgeDays(withInt, "wet"))}</span>
      </button>
    `;
  }

  private _renderLayerToggles(vacs: VacuumConfig[]) {
    const withInt = vacs.filter((v) => this._intAttrs(v));
    if (!withInt.length) return nothing;
    const oldest = (type: "dry" | "wet") => this._oldestAgeDays(withInt, type);
    const badge = (d: number | null) => this._ageBadgeStr(d);
    const L = this._layersEff();
    return html`
      <div class="layer-toggles">
        <button class="layer-btn ${L.dry ? "on" : ""}" title="Dry \u2014 tap to toggle, hold for rooms"
          @pointerdown=${() => this._onLayerDown("dry")} @pointerup=${() => this._onLayerUp()} @pointerleave=${() => this._onLayerUp()}
          @click=${() => this._onLayerClick("dry")}>
          <ha-icon icon="mdi:broom"></ha-icon><span>${badge(oldest("dry"))}</span>
        </button>
        <button class="layer-btn ${L.wet ? "on" : ""}" title="Wet \u2014 tap to toggle, hold for rooms"
          @pointerdown=${() => this._onLayerDown("wet")} @pointerup=${() => this._onLayerUp()} @pointerleave=${() => this._onLayerUp()}
          @click=${() => this._onLayerClick("wet")}>
          <ha-icon icon="mdi:water"></ha-icon><span>${badge(oldest("wet"))}</span>
        </button>
        ${this._layerMenu ? this._renderLayerMenu(withInt, this._layerMenu) : nothing}
      </div>
    `;
  }

  /** Merged mode rooms: one rectangle per room key (deduped across vacuums); click selects across all. */
  /** Deduped room defs for merged mode: card-level rooms (rep = first vacuum) or per-vacuum dedup by key. */
  private _mergedRoomDefs(shown: VacuumConfig[]): Array<{ r: RoomConfig; v: VacuumConfig }> {
    const rep = shown[0];
    if (this._config.rooms?.length && rep) return this._roomsFor(rep).map((r) => ({ r, v: rep }));
    const seen = new Set<string>();
    const out: Array<{ r: RoomConfig; v: VacuumConfig }> = [];
    for (const v of shown) for (const r of this._roomsFor(v)) {
      if (r.key && !seen.has(r.key)) { seen.add(r.key); out.push({ r, v }); }
    }
    return out;
  }
  private _renderMergedRooms(shown: VacuumConfig[]) {
    const defs = this._mergedRoomDefs(shown);
    const wholeHome = !defs.some(({ r }) => this._isRoomSelectedAny(r.key, shown));
    return defs.map(({ r, v }) => this._renderRoomOverlay(r, v, { vacs: shown, wholeHome }));
  }

  /** docs/40 §4.4 (Fáze 3) — additive layer drawing each room's REAL traced
   *  shape (`outline_pct`, only ever set for a home-frame-rendered room, see
   *  `_computeRoomsFor`) on top of the existing rectangle buttons. Its own
   *  full-wrap `<svg>` (0..100 viewBox, matching `outline_pct`'s own units)
   *  rather than nested inside each room's `<button>` — `outline_pct` is
   *  already wrap-relative percent, so no per-room re-basing is needed, and
   *  `pointer-events: none` keeps it purely visual: the rectangle stays the
   *  one and only click/select hit-target either way. */
  private _renderRoomOutlines(defs: Array<{ r: RoomConfig; v: VacuumConfig }>, vacs: VacuumConfig[]) {
    const withOutline = defs.filter(({ r }) => r.outline_pct && r.outline_pct.length >= 3);
    if (!withOutline.length) return nothing;
    const polys = svg`${withOutline.map(({ r }) => {
      const selected = this._isRoomSelectedAny(r.key, vacs);
      const pts = r.outline_pct!.map((p) => p.x.toFixed(2) + "," + p.y.toFixed(2)).join(" ");
      return svg`<polygon points=${pts}
        fill=${selected ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.05)"}
        stroke=${selected ? "#ffffff" : "rgba(255,255,255,0.35)"}
        stroke-width="0.35" stroke-linejoin="round"></polygon>`;
    })}`;
    return html`<svg class="room-outline-layer" viewBox="0 0 100 100" preserveAspectRatio="none"
      style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;">${polys}</svg>`;
  }

  /** Narrow → rotate the map 90° (auto, unless disabled). With a `layout:`
   *  block this is a COMPUTED choice (docs/25 §4) in BOTH profiles —
   *  whichever orientation (upright vs. rotated) fits the floorplan bigger
   *  inside the measured map region — not just portrait. A very tall/narrow
   *  floorplan on a wide landscape box benefits from this exactly the same
   *  way a wide floorplan on a portrait phone does (field report 2026-07-27:
   *  a new tall floorplan rendered as a thin letterboxed strip in landscape
   *  because rotation was hard-gated to portrait only). `layout.portrait
   *  .crop.mapOrientation` / `layout.landscape.crop.mapOrientation` override
   *  the computed choice manually, per profile. Without a `layout:` block
   *  the legacy card-width heuristic applies, completely unchanged (that
   *  path never rotated in landscape either, and still doesn't). NOTE: this
   *  getter answers "would rotating fit better", NOT "is the map rotated right
   *  now" — for the latter (click geometry, on-map chip anchors) read
   *  `_mapRotationDeg()`, which also folds in flip and the still-unmeasured
   *  map region. Pin & Go / Zone used to be hard-disabled whenever this was
   *  true (docs/13 A5); that limitation is lifted — the click inversion now
   *  undoes the rotation wrapper itself. */
  private get _narrow(): boolean {
    const mr = this._config.mobile_rotate as string | undefined;
    if (mr === "off") return false;
    if (mr === "always" || mr === "on") return true;  // force (good for testing)
    if (this._config.layout) {
      const profileCfg = this._profile === "portrait" ? this._config.layout.portrait : this._config.layout.landscape;
      const override = profileCfg?.crop?.mapOrientation;
      if (override === "normal") return false;
      if (override === "rotated") return true;
      const computed = shouldRotateMap(this._mapAR, this._mapRegW, this._mapRegH);
      if (computed !== undefined) { this._lastRotate = computed; return computed; }
      return this._lastRotate;   // region not measured yet — keep the previous answer
    }
    return this._cardW > 0 && this._cardW < 500;       // auto: by card width
  }

  /** docs/32 follow-up: effective flip for the CURRENT profile — `_flipLive`
   *  override if set this session, otherwise the persisted config default.
   *  Only meaningful with a `layout:` block (legacy render never flips). */
  private get _flipEff(): boolean {
    if (this._flipLive !== null) return this._flipLive;
    if (!this._config.layout) return false;
    const profileCfg = this._profile === "portrait" ? this._config.layout.portrait : this._config.layout.landscape;
    return profileCfg?.crop?.flip === true;
  }

  /** Meta bar / dock-layers "Flip map" button handler — toggles `_flipLive`
   *  off the CURRENTLY DISPLAYED orientation (not the raw config value), so
   *  one tap always visibly flips regardless of whether a config default or
   *  an earlier tap this session set the current state. Purely local — never
   *  touches the dashboard config or backend, resets on reload (docs/32). */
  private _toggleFlipLive(): void {
    this._flipLive = !this._flipEff;
    this._saveFlipLive();
  }

  /** docs/25 §7c: split (today's default) vs. stack portrait topology, computed
   *  from `shouldStackLayout()` — mirrors `_narrow`'s structure (manual override
   *  → computed → settle-on-previous-answer while unmeasured). Only active with
   *  a `layout:` config block; only meaningful in portrait. A manual `topology`
   *  override, or any explicit `columns`/`rows`/`place` on `layout.portrait`
   *  (the user has already hand-tuned the split), opts out of the computed
   *  choice entirely — same "manual config wins" rule `resolveProfile` already
   *  applies to columns/rows/place individually. */
  private get _stackTopology(): boolean {
    if (this._profile !== "portrait" || !this._config.layout) return false;
    const p = this._config.layout.portrait;
    if (p?.topology === "split") return false;
    if (p?.topology === "stack") return true;
    if (p?.columns?.length || p?.rows?.length || (p?.place && Object.keys(p.place).length)) return false;
    const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
    // Effective floorplan AR honoring the current rotation state (`_narrow`) —
    // shouldStackLayout wants "whatever will actually get rendered", not the
    // raw un-rotated floorplan. Same bootstrapping approximation as `_narrow`
    // itself: on the very first render this reads last render's decision, not
    // this one's, and converges within a render or two, same as elsewhere in
    // this settle-based system.
    const effAr = this._narrow ? 1 / ar : ar;
    const computed = shouldStackLayout(effAr, this._mapAvailW, this._mapAvailH);
    if (computed !== undefined) { this._lastStack = computed; return computed; }
    return this._lastStack;
  }

  /** Learn the floorplan's aspect ratio once it loads, for the rotation maths. */
  private _onFloorplanLoad = (e: Event): void => {
    const img = e.target as HTMLImageElement;
    if (img?.naturalWidth && img.naturalHeight) {
      const ar = img.naturalWidth / img.naturalHeight;
      if (ar > 0.1 && Math.abs(ar - this._mapAR) > 0.01) this._mapAR = ar;
    }
  };
  /** Wrap a map render in a 90° portrait rotation when the card is narrow. The map
   *  fills the card width and goes tall (capped), so the floorplan is readable on a
   *  phone instead of a thin letterbox. Controls outside the map-wrap stay upright.
   *  In grid mode (docs/18 §7) the rotated map is fitted EXACTLY into the measured
   *  map-region box instead of the legacy width × cap heuristic — no scroll, no cap. */
  private _renderResponsive(mapHtml: unknown) {
    if (!this._config.layout) {
      // Legacy (no `layout:` block) — completely unchanged, width×cap heuristic.
      if (!this._narrow) return mapHtml;
      const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
      const W = this._cardW || this.clientWidth || 360;
      const capH = (typeof window !== "undefined" ? window.innerHeight : 800) * 1.4;
      const visH = W * ar;
      const scale = visH > capH ? capH / visH : 1;
      const rW = Math.round(W * scale);
      const rH = Math.round(visH * scale);
      return html`
        <div class="avc-rot" style="position:relative;width:${rW}px;height:${rH}px;margin:0 auto;overflow:hidden;--map-rot:90deg">
          <div style="position:absolute;top:0;left:0;width:${rH}px;height:${rW}px;transform-origin:top left;transform:translateX(${rW}px) rotate(90deg)">
            ${mapHtml}
          </div>
        </div>
      `;
    }

    // Grid mode (docs/19 follow-up): fit the map into the measured region box —
    // exact, since the box is whatever the grid ACTUALLY allocated, not a guess
    // (this is what fixes landscape cropping content that didn't fit the "auto"
    // row's real height). Either profile rotates 90° first when `_narrow`
    // computes it fits better that way (docs/25 §4, extended to landscape
    // 2026-07-27) — `rotate` below already carries the right answer either way.
    if (this._mapRegW <= 4 || this._mapRegH <= 4) return mapHtml; // not measured yet
    const ar = this._mapAR > 0.1 ? this._mapAR : 3.636;
    // Single source for "how far is the map actually turned" — the click
    // geometry reads the same `_mapRotationDeg()`, so the renderer and the
    // hit-testing can never disagree (they did, silently, at every angle
    // other than 0 — which is why Pin & Go was simply disabled here instead).
    const totalRotationDeg = this._mapRotationDeg();
    const rotate = totalRotationDeg === 90 || totalRotationDeg === 270;
    // Content aspect AS IT SITS IN THE BOX: rotating a wide (ar > 1) floorplan
    // makes it tall, i.e. 1/ar. General contain/cover formula below is the same
    // shape either way with this one term swapped (verified against the
    // previously-shipped rotated-only version, which is the ar_eff = 1/ar case).
    const arEff = rotate ? 1 / ar : ar;
    // "contain" (default) sizes the content to exactly fit the box — no
    // cropping, but a mismatched aspect ratio leaves empty bars on whichever
    // axis isn't the constraining one. "cover" makes the content the box's
    // size or BIGGER in both axes so it always fills the region; offset_x/
    // offset_y then pick what gets cropped (0 = centered) — note this can
    // ONLY move the crop, not remove it: filling the previously-short axis
    // necessarily overflows the other one when the aspect ratios don't match
    // (uniform scaling can't do otherwise without distorting the image).
    const crop = this._config.layout[this._profile]?.crop;
    const cover = crop?.fit === "cover";
    const boxW = this._mapRegW, boxH = this._mapRegH;
    let rW: number, rH: number;
    if (cover) { rW = Math.max(boxW, boxH * arEff); rH = Math.max(boxH, rW / arEff); }
    else { rW = Math.min(boxW, boxH * arEff); rH = Math.min(boxH, rW / arEff); }
    rW = Math.floor(rW);
    rH = Math.floor(rH);
    // The content (rW×rH on screen) may now be bigger than the clipping box
    // (boxW×boxH) in one axis — center it there by default, offset by the
    // configured pan. When rW===boxW and rH===boxH (the default contain case,
    // whichever axis is the constraining one) this is exactly 0, so nothing
    // shifts.
    const panX = -(rW - boxW) / 2 + ((crop?.offset_x ?? 0) / 100) * ((rW - boxW) / 2);
    const panY = -(rH - boxH) / 2 + ((crop?.offset_y ?? 0) / 100) * ((rH - boxH) / 2);

    // docs/32 — `rotate` (90°-for-fit, above) and `flip` (180°, manual "this
    // is upside down for me") are independent and compose into one of the
    // four right angles. `.avc-rot`'s counter-rotation CSS reads the total
    // back off `--map-rot` (single computed source, not per-angle classes).
    if (totalRotationDeg !== 0) {
      if (rotate) {
        // Stashed for `_refineGridColumns` (portrait's map/dock column
        // split) — only meaningful when the axes actually swap (90°/270°);
        // a flip-only 180° keeps native width/height and already fits the
        // static grid template on its own, same as the unrotated 0° case.
        this._lastPortraitFitW = rW;
      }
      // Content div dimensions: swapped (rH×rW) for a quarter turn (90°/
      // 270°, same as the original 90°-only code), native (rW×rH) for a
      // flip-only 180° (no axis swap — rotating 180° maps a box onto
      // itself, centered rotation needs no translate at all).
      const innerW = rotate ? rH : rW;
      const innerH = rotate ? rW : rH;
      let rotTransform: string;
      if (totalRotationDeg === 90) {
        rotTransform = "transform-origin:top left;transform:translateX(" + rW + "px) rotate(90deg)";
      } else if (totalRotationDeg === 180) {
        rotTransform = "transform-origin:center;transform:rotate(180deg)";
      } else {
        // 270° = 90° (rotate) + 180° (flip) combined — derived by symmetry
        // with the field-proven 90° formula (translateX↔translateY mirrors
        // the clockwise↔counter-clockwise direction); not yet field-verified
        // on its own, unlike 90°/180° individually.
        rotTransform = "transform-origin:top left;transform:translateY(" + rH + "px) rotate(270deg)";
      }
      // .avc-rot lets CSS counter-rotate small on-map chips (gauges, prog
      // chips, room icons) so their text stays upright while the map itself
      // is rotated — `--map-rot` feeds the same counter-rotation to all
      // four angles from one place (anyvac-card.ts CSS block).
      return html`
        <div class="avc-rot" style="position:relative;width:${boxW}px;height:${boxH}px;margin:0 auto;overflow:hidden;--map-rot:${totalRotationDeg}deg">
          <div style="position:absolute;top:0;left:0;width:100%;height:100%;transform:translate(${panX}px,${panY}px)">
            <div style="position:absolute;top:0;left:0;width:${innerW}px;height:${innerH}px;${rotTransform}">
              ${mapHtml}
            </div>
          </div>
        </div>
      `;
    }
    return html`
      <div style="position:relative;width:${boxW}px;height:${boxH}px;margin:0 auto;overflow:hidden">
        <div style="position:absolute;top:0;left:0;width:${rW}px;height:${rH}px;transform:translate(${panX}px,${panY}px)">
          ${mapHtml}
        </div>
      </div>
    `;
  }

  private _renderMergedMap() {
    const shown = this._shownOrdered().map((i) => this._config.vacuums[i]);
    if (!shown.length) return nothing;
    const primary = shown.find((v) => v.image_base?.src) ?? shown[0];
    const ib = this._config.image_base ?? primary.image_base;
    const hasImage = !!ib?.src;
    const bh = this._config.base_height ?? primary.base_height;
    const fixedH = typeof bh === "number" && bh > 0;
    const wrapClass = fixedH ? "map-wrap--fixed" : (hasImage ? "map-wrap--image" : "");
    const wrapStyle = styleMap(fixedH ? { height: (bh ?? 0) + "px" } : {});
    const imgClass = "image-base-img" + (fixedH ? " image-base-img--fit" : "");
    return html`
      <div class="map-wrap ${wrapClass}" style=${wrapStyle}>
        ${hasImage ? html`
          <img class="${imgClass}" src=${ib!.src!} alt="Floorplan" @load=${this._onFloorplanLoad}
            style=${styleMap({
              transform: "translate(" + (ib?.offset_x ?? 0) + "%," + (ib?.offset_y ?? 0) + "%) rotate(" + (ib?.rotation ?? 0) + "deg) scale(" + ((ib?.scale ?? 100) / 100) + ")",
            })} />
        ` : nothing}
        ${shown.map((v, idx) => {
          const mapEnt = this._mapEntityFor(v);
          const mUrl = mapEnt ? this._mapUrl(mapEnt) : null;
          if (!mUrl) return nothing;
          const seat = this._effectiveSeat(v);
          const overlay = hasImage || idx > 0;
          // hide_map renders the element at opacity 0 instead of skipping it — the
          // element IS the click-geometry anchor for pin&go / zones (docs/13 A4).
          return html`<img class="map-img ${overlay ? "map-img--overlay" : ""}" src=${mUrl} alt="Vacuum map"
            data-entity=${v.entity}
            style=${styleMap({
              left: (50 + seat.offset_x) + "%",
              top: (50 + seat.offset_y) + "%",
              width: seat.scale + "%",
              transform: "translate(-50%,-50%) " + seatRotateScaleCss(seat.rotation, seat.scale, seat.scaleY),
              opacity: v.hide_map ? "0" : String((v.overlay_opacity ?? (overlay ? 55 : 100)) / 100),
              mixBlendMode: v.overlay_blend ?? "normal",
            })} />`;
        })}
        ${/* docs/40 §4.4 (Fáze 3): a home-frame-registered vacuum draws from
           `*_home_px` through its own identity crop (no fit/rotation) instead
           of `_effectiveSeat` — automatic per vacuum (`_homeFrameCropFor`),
           so a mixed fleet (some registered, some not yet) renders each with
           whichever path is actually valid for it right now. */
          shown.map((v) => {
            if (!this._intAttrs(v)) return nothing;
            const crop = this._homeFrameCropFor(v);
            if (crop) return this._renderHomeFrameOverlay(v, crop, "paths");
            const af = this._homeAnchorFitFor(v, this._wrapAspect(this._baseHeightFor(v)));
            if (af) return this._renderHomeAnchorOverlay(v, af.fit, af.dims, this._wrapAspect(this._baseHeightFor(v)), "paths");
            return this._renderIntegrationOverlay(v, this._effectiveSeat(v), "paths");
          })}
        ${/* Markers in their OWN pass, after every vacuum's paths (not one
           interleaved pass per vacuum) — a vacuum's wide translucent wet-mop
           band can no longer sit on top of ANOTHER vacuum's robot marker
           regardless of shown/DOM order (field report 2026-07-26). */
          shown.map((v) => {
            if (!this._intAttrs(v)) return nothing;
            const crop = this._homeFrameCropFor(v);
            if (crop) return this._renderHomeFrameOverlay(v, crop, "marker");
            const af = this._homeAnchorFitFor(v, this._wrapAspect(this._baseHeightFor(v)));
            if (af) return this._renderHomeAnchorOverlay(v, af.fit, af.dims, this._wrapAspect(this._baseHeightFor(v)), "marker");
            return this._renderIntegrationOverlay(v, this._effectiveSeat(v), "marker");
          })}
        ${this._config.layout ? nothing : this._renderLayerToggles(shown)}
        ${this._renderRoomOutlines(this._mergedRoomDefs(shown), shown)}
        ${this._renderMergedRooms(shown)}
        ${/* Pin & Go / Zone interaction layer — merged mode used to render NONE of
           this (only split-mode _renderMap had it), so clicks fell straight through
           to room-select regardless of the active mode (bugfix, docs/19). Mirrors
           _renderMap 1:1, just scoped per shown vacuum since merged mode overlays
           several .map-img elements in one wrapper. Also stays mounted once a zone
           box exists and is still awaiting confirm (`_hasZoneEditTarget`), even
           after mode resets to normal, so the box can still be dragged/resized. */
        shown.map((v) => (this._mapMode !== "normal" && this._isModeCandidate(v)) || (this._zoneRectShown && this._hasZoneEditTarget(v))
          ? html`<div class="map-clickcatch" style="touch-action:none"
              @click=${(e: MouseEvent) => this._onMapClick(v, e)}
              @pointerdown=${(e: PointerEvent) => this._onZoneDown(v, e)}
              @pointermove=${(e: PointerEvent) => this._onZoneMove(v, e)}
              @pointerup=${(e: PointerEvent) => this._onZoneUp(v, e)}></div>`
          : nothing)}
        ${shown.map((v, idx) => {
          const box = this._zoneRectFor(v, idx === 0);
          return box ? html`<div class="zone-rect" style=${styleMap({
              left: Math.min(box.x0, box.x1) + "%",
              top: Math.min(box.y0, box.y1) + "%",
              width: Math.abs(box.x1 - box.x0) + "%",
              height: Math.abs(box.y1 - box.y0) + "%",
            })}>${this._renderZoneHandles()}</div>` : nothing;
        })}
      </div>
    `;
  }

  private _renderMap(vac: VacuumConfig) {
    // Deliberately the RAW config value here (not the auto-resolved one below) —
    // this infers intent when `base` itself is unset: "configured a floorplan but
    // never mentioned a map entity" should still default to showing just the
    // floorplan, even though `_mapEntityFor` would now likely find one anyway.
    const base = vac.base ?? (vac.image_base?.src && !vac.map?.entity ? "image" : "map");
    const ib = vac.image_base;
    const imgSrc = ib?.src;
    const mapEntity = this._mapEntityFor(vac);
    const mapUrl = mapEntity ? this._mapUrl(mapEntity) : null;
    const showImage = (base === "image" || base === "combined") && !!imgSrc;
    const showMap = (base === "map" || base === "combined") && !!mapUrl;
    if (!showImage && !showMap) return nothing;

    const seat = this._effectiveSeat(vac);
    const fixedH = typeof vac.base_height === "number" && vac.base_height > 0;
    const wrapClass = fixedH ? "map-wrap--fixed" : (showImage ? "map-wrap--image" : "");
    const wrapStyle = styleMap(fixedH ? { height: (vac.base_height ?? 0) + "px" } : {});
    const imgClass = "image-base-img" + (fixedH ? " image-base-img--fit" : "");
    return html`
      <div class="map-wrap ${wrapClass}" style=${wrapStyle}>
        ${showImage ? html`
          <img class="${imgClass}" src=${imgSrc!} alt="Floorplan" @load=${this._onFloorplanLoad}
            style=${styleMap({
              transform: "translate(" + (ib?.offset_x ?? 0) + "%," + (ib?.offset_y ?? 0) + "%) rotate(" + (ib?.rotation ?? 0) + "deg) scale(" + ((ib?.scale ?? 100) / 100) + ")",
            })} />
        ` : nothing}
        ${showMap ? html`
          <img class="map-img ${showImage ? "map-img--overlay" : ""}" src=${mapUrl!} alt="Vacuum map"
            data-entity=${vac.entity}
            style=${styleMap({
              left: (50 + seat.offset_x) + "%",
              top:  (50 + seat.offset_y) + "%",
              width: seat.scale + "%",
              transform: "translate(-50%,-50%) " + seatRotateScaleCss(seat.rotation, seat.scale, seat.scaleY),
              ...(vac.hide_map ? { opacity: "0" } : (showImage ? { opacity: String((vac.overlay_opacity ?? 55) / 100), mixBlendMode: vac.overlay_blend ?? "normal" } : {})),
            })} />
        ` : nothing}
        ${showMap ? this._renderIntegrationOverlay(vac, seat) : nothing}
        ${this._config.layout ? nothing : this._renderLayerToggles([vac])}
        ${(() => {
          const rooms = this._roomsFor(vac);
          const wholeHome = !rooms.some((r) => this._isRoomSelected(r, vac));
          return rooms.map((r) => this._renderRoomOverlay(r, vac, { wholeHome }));
        })()}
        ${(this._mapMode !== "normal" && this._isModeCandidate(vac)) || (this._zoneRectShown && this._hasZoneEditTarget(vac))
          ? html`<div class="map-clickcatch" style="touch-action:none"
              @click=${(e: MouseEvent) => this._onMapClick(vac, e)}
              @pointerdown=${(e: PointerEvent) => this._onZoneDown(vac, e)}
              @pointermove=${(e: PointerEvent) => this._onZoneMove(vac, e)}
              @pointerup=${(e: PointerEvent) => this._onZoneUp(vac, e)}></div>`
          : nothing}
        ${(() => {
          const box = this._zoneRectFor(vac, true);
          return box ? html`<div class="zone-rect" style=${styleMap({
              left: Math.min(box.x0, box.x1) + "%",
              top: Math.min(box.y0, box.y1) + "%",
              width: Math.abs(box.x1 - box.x0) + "%",
              height: Math.abs(box.y1 - box.y0) + "%",
            })}>${this._renderZoneHandles()}</div>` : nothing;
        })()}
      </div>
    `;
  }

  /** docs/25 §7d: per-room dry/wet age as two small corner dots, replacing
   *  the old age-colored border/icon. Dry always left, wet always right —
   *  same order as everywhere else in the card. Gated on the representative
   *  vacuum's clean-type capability, not on whether a timestamp happens to
   *  exist yet, so a dry-only vacuum's rooms don't grow a permanent "never
   *  wet cleaned" red dot they can never clear.
   *
   *  KNOWN ISSUE (field-reported 2026-07-23, deferred — not root-caused
   *  yet): in merged mode, `vac` here is `_mergedRoomDefs`'s representative
   *  owner of the room definition, not necessarily every vacuum that can
   *  actually clean it (same class of gap already noted elsewhere in this
   *  file re: identity color). If the representative happens to be
   *  dry-only, `_vacCleanType` gates off the wet dot even when another
   *  configured vacuum does mop the room — user saw one dot where two were
   *  expected. Likely fix: gate on capability across `opts.vacs`, not just
   *  `vac` — needs its own pass, not bundled into this one. */
  private _renderRoomAgeDots(room: RoomConfig, vac: VacuumConfig) {
    const rec = this._intRoomRec(vac, room);
    if (rec) {
      const ct = this._vacCleanType(vac);
      if (!ct.dry && !ct.wet) return nothing;
      const dry = this._ageDaysFromIso(rec.dry);
      const wet = this._ageDaysFromIso(rec.wet);
      return html`
        <span class="room-age-dots">
          ${ct.dry ? html`<span class="room-age-dot" style=${styleMap({ background: this._colorForAgeDays(dry) })}></span>` : nothing}
          ${ct.wet ? html`<span class="room-age-dot" style=${styleMap({ background: this._colorForAgeDays(wet) })}></span>` : nothing}
        </span>
      `;
    }
    // Degraded mode (no integration rec, docs/14 §8 — card still works
    // without the companion integration, just loses the dry/wet split):
    // a single dot from the legacy `last_clean_entity` helper, if configured.
    if (!room.last_clean_entity) return nothing;
    return html`
      <span class="room-age-dots">
        <span class="room-age-dot" style=${styleMap({ background: this._colorForAgeDays(this._roomAgeDays(room)) })}></span>
      </span>
    `;
  }

  /** docs/25 §7b: pointerdown for hold-to-inspect on a room overlay — raw
   *  pointer events (not `_holdStart`), same reason as the vac-icon-strip
   *  hold gesture: tap and hold drive genuinely different actions, and
   *  mixing `_holdStart`'s `preventDefault()` with a separate `@click`
   *  handler is unreliable across browsers. */
  private _onRoomPointerDown(room: RoomConfig, locked: boolean) {
    return (e: PointerEvent): void => {
      if (locked) return;
      e.preventDefault();
      this._cancelHold();
      this._holdId = "room-" + room.key;
      this._holdTimer = setTimeout(() => {
        this._holdTimer = null;
        this._holdId = null;
        this._inspectKey = this._inspectKey === room.key ? null : room.key;
      }, HOLD_DURATION_MS);
    };
  }

  /** Released before the hold fired → tap. If an inspect popup is open
   *  (for this room or another), the tap just dismisses it instead of
   *  toggling selection — avoids an accidental selection change on the
   *  same tap that closes the popup. Released after the hold already fired
   *  (popup just opened by the timer above) → swallow it, nothing to do. */
  private _onRoomPointerUp(room: RoomConfig, vac: VacuumConfig, vacs: VacuumConfig[] | undefined, locked: boolean) {
    return (): void => {
      if (locked) return;
      if (this._holdTimer !== null) {
        this._cancelHold();
        if (this._inspectKey !== null) { this._inspectKey = null; return; }
        if (vacs) this._toggleRoomAcross(room.key, vacs); else this._toggleRoom(room, vac);
      } else {
        this._holdId = null;
      }
    };
  }

  /** docs/25 §7b: the per-room detail (age, assigned vacuum) that used to
   *  live permanently in the portrait dock room list, which the minimalist
   *  cockpit now hides by default (§7c/§7e). `stopPropagation` on the popup
   *  itself so a tap inside it (e.g. the pin-cycle chip) doesn't also reach
   *  the room button underneath and re-toggle/dismiss.
   *
   *  Field-caught (2026-07-24, third round): rendered as a SIBLING of the
   *  room's `<button>`, not a child — earlier attempts nested it inside the
   *  button and fought the selected room's own border-image/box-shadow
   *  (glow visibly bleeding through even at 99% opaque background +
   *  `isolation: isolate`, see 0.72.4's doc comment for the failed
   *  theory). Positioning it as an independent sibling at the room's own
   *  `map_x`/`map_y` point (same coordinates the button itself uses)
   *  sidesteps the whole question — there is no parent/child relationship
   *  left for the button's paint to interact with, by construction, not by
   *  fighting z-index/stacking-context edge cases.
   *  KNOWN LIMITATION (v1): not edge-aware on the horizontal axis, and the
   *  map region still clips overflow — a room very close to the left/right
   *  edge can get its popup partly cut off. Revisit after field feedback. */
  private _renderRoomInspect(room: RoomConfig, vac: VacuumConfig, selected: boolean, opts?: { vacs?: VacuumConfig[] }) {
    const rec = this._intRoomRec(vac, room);
    const dry = this._ageDaysFromIso(rec?.dry);
    const wet = this._ageDaysFromIso(rec?.wet);
    const badge = (d: number | null) => (d === null ? "—" : d < 1 ? "<1d" : Math.round(d) + "d");
    const dryEnt = selected ? this._planPreview?.dry.get(room.key) : undefined;
    const wetEnt = selected ? this._planPreview?.wet.get(room.key) : undefined;
    // Each chip cycles only among vacuums capable of ITS OWN type — see the
    // 2026-07-25 fix note on `_cycleRoomPin`.
    const canCycleDry = this._pinCandidates(room.key, "dry").length > 1;
    const canCycleWet = this._pinCandidates(room.key, "wet").length > 1;
    const pinTap = (kind: "dry" | "wet", shown: string | undefined) =>
      (kind === "dry" ? canCycleDry : canCycleWet)
        ? (e: Event) => { e.stopPropagation(); this._cycleRoomPin(room.key, kind, shown); }
        : undefined;
    // Same point the room's own <button> is anchored at (see the doc comment
    // above) — centering here, rather than below/above the room, is ALSO
    // still correct for size/rotation reasons (0.72.3): a rotation's center
    // point never moves under that rotation, so this lands on the same
    // screen spot regardless of room size or map orientation.
    return html`
      <div class="room-inspect" style=${styleMap({ left: (room.map_x ?? 0) + "%", top: (room.map_y ?? 0) + "%" })}
        @click=${(e: Event) => e.stopPropagation()}>
        <div class="room-inspect-inner">
          <div class="room-inspect-name">${room.name ?? room.key}</div>
          <div class="room-inspect-ages">
            <span class="dock-age"><ha-icon icon="mdi:broom"></ha-icon><b style=${styleMap({ color: this._colorForAgeDays(dry) })}>${badge(dry)}</b></span>
            <span class="dock-age"><ha-icon icon="mdi:water"></ha-icon><b style=${styleMap({ color: this._colorForAgeDays(wet) })}>${badge(wet)}</b></span>
          </div>
          ${dryEnt || wetEnt ? html`
            <div class="dock-avatars">
              ${dryEnt ? this._vacChip(dryEnt, pinTap("dry", dryEnt)) : nothing}
              ${wetEnt ? this._vacChip(wetEnt, pinTap("wet", wetEnt)) : nothing}
            </div>` : nothing}
        </div>
      </div>
    `;
  }

  private _renderRoomOverlay(room: RoomConfig, vac: VacuumConfig, opts?: { vacs?: VacuumConfig[]; wholeHome?: boolean }) {
    const selected = opts?.vacs ? this._isRoomSelectedAny(room.key, opts.vacs) : this._isRoomSelected(room, vac);
    // docs/25 §5: nothing explicitly selected = whole home is the implicit
    // plan (START is already meaningful, see _renderDock/_renderStartBar).
    // The map should say so too, but *gently* — this is a glanceable "this is
    // what will run", one weight class below an actual selected room (no
    // gradient border, no glow, no white icon — those stay reserved for
    // explicit picks so "who's assigned" info isn't implied here).
    const wholeHome = !selected && !!opts?.wholeHome;
    // docs/25 §7d: border/icon color is reserved for interaction state only
    // (normal/whole-home/selected, one white-family channel) — age used to
    // share this channel (`_colorForAgeDays` painting the border/icon) and
    // fought both the selection highlight and the room icon's own stable
    // identity (an icon painted a different color every day by how stale
    // the room is isn't actually recognizable at a glance). Age moved to
    // `_renderRoomAgeDots` below.
    const NEUTRAL_BORDER = "rgba(255,255,255,0.22)";
    const NEUTRAL_ICON = "rgba(255,255,255,0.55)";
    const anchor = room.icon_anchor ?? "c";
    // Mutual exclusion (docs/19 A3): while Pin & Go / Zone is active, room
    // selection is a different, contradictory intent (targeting a point/zone,
    // not a whole room) — disable it entirely rather than let both interpret
    // the same click.
    const locked = this._mapMode !== "normal";
    // Selection = a neutral highlight, never a vacuum's identity color (docs/19
    // A1): the old `this._color(vac)` fill collided with the age-gradient (S6's
    // green == "cleaned <2 days ago" green) and, in merged mode, was arbitrary
    // anyway — `vac` here is whichever vacuum's room list happened to define
    // this room, not necessarily who actually cleans it. Who's assigned is now
    // shown via avatar chips (reused from the dock) instead of area tinting.
    const SEL = "#ffffff";
    // Selected border as white with a crisp light-blue accent right in the
    // middle (user's revived idea, refined: a thin bright seam reads better at
    // this size than a broad 50% blend) — via `border-image` (needs a real
    // border shorthand for width/style first; unselected rooms keep a flat colour).
    const SEL_GRADIENT = "linear-gradient(135deg, #ffffff 0%, #ffffff 46%, #8ecbff 50%, #ffffff 54%, #ffffff 100%) 1";

    if (room.map_w !== undefined && room.map_h !== undefined) {
      // ── Rectangle mód ──────────────────────────────────────────
      const ANCHOR: Record<string, [string, string]> = {
        tl: ["flex-start","flex-start"], t:  ["center","flex-start"], tr: ["flex-end","flex-start"],
        l:  ["flex-start","center"],     c:  ["center","center"],     r:  ["flex-end","center"],
        bl: ["flex-start","flex-end"],   b:  ["center","flex-end"],   br: ["flex-end","flex-end"],
      };
      const [jc, ai] = ANCHOR[anchor] ?? ["center", "center"];
      const borderW = (selected
        ? (this._config.room_border_selected ?? 4)
        : wholeHome ? Math.max(3, this._config.room_border_normal ?? 2)
        : (this._config.room_border_normal ?? 2)) + "px";
      // First pass at this (0.68.2) was too subtle to read at a glance on a
      // real floorplan image (field feedback 2026-07-23: "if I didn't know
      // about it, I wouldn't see it at all") — bumped border/bg opacity and
      // added a soft glow so whole-home clearly reads as "highlighted",
      // while still staying a visible notch below `selected`'s crisp
      // gradient border + strong glow.
      const borderC = selected ? SEL + "E0" : wholeHome ? "rgba(255,255,255,0.75)" : NEUTRAL_BORDER;
      const bg = selected ? SEL + "22" : wholeHome ? "rgba(255,255,255,0.16)" : "rgba(0,0,0,0.06)";
      const shadow = selected ? "0 0 18px rgba(255,255,255,0.7)" : wholeHome ? "0 0 10px rgba(255,255,255,0.4)" : "none";
      // Who's assigned (dry/wet), from the backend plan preview — only known
      // once selected (the preview is computed for the current selection).
      const dryEnt = selected ? this._planPreview?.dry.get(room.key) : undefined;
      const wetEnt = selected ? this._planPreview?.wet.get(room.key) : undefined;
      const holdId = "room-" + room.key;
      return html`
        <button
          class="room-overlay ${locked ? "room-overlay--locked" : ""} ${this._holdId === holdId ? "room-overlay--holding" : ""}"
          ?disabled=${locked}
          style=${styleMap({
            left: (room.map_x ?? 0) + "%", top: (room.map_y ?? 0) + "%",
            width: room.map_w + "%", height: room.map_h + "%",
            border: borderW + " solid " + borderC,
            borderImage: selected ? SEL_GRADIENT : "none",
            background: bg, boxShadow: shadow,
            justifyContent: jc, alignItems: ai,
          })}
          @pointerdown=${this._onRoomPointerDown(room, locked)}
          @pointerup=${this._onRoomPointerUp(room, vac, opts?.vacs, locked)}
          @pointerleave=${this._holdEnd}
          @pointercancel=${this._holdEnd}
          title=${locked ? "Room selection is off while placing a pin/zone" : room.name} aria-label=${room.name}
          aria-pressed=${selected ? "true" : "false"}
        >
          <div class="hold-ring"></div>
          ${!this._config.room_icon_hidden && anchor !== "none" && room.icon ? html`
            <ha-icon icon=${room.icon}
              style=${styleMap({ color: selected ? "white" : NEUTRAL_ICON, "--mdc-icon-size": "16px" })}>
            </ha-icon>
          ` : nothing}
          ${this._renderRoomAgeDots(room, vac)}
          ${/* Field fixes same day (2026-08-03), full history in CHANGELOG
               1.0.1-1.0.6: the edge-anchored approach (CSS top/bottom/left/
               right, counter-rotated via .avc-rot's --map-rot rule) picked
               the CORRECT local room corner for all four right angles
               (verified by matrix simulation, see below — that part was
               never wrong) but was still off for 90°/270° specifically:
               those two ALSO apply a ±90° SELF-rotation to the chip itself
               (to cancel the ambient rotation and keep its text upright),
               and a ±90° self-rotation SWAPS the chip's own effective
               width/height before the ambient rotation carries it further —
               a "2px from local top/right" edge inset doesn't account for
               that swap, so the chip landed roughly chip-height px off from
               the intended corner (matches the field-reported "overflows
               past the top/right of the map" symptom exactly: ~21px
               overshoot ≈ 2px inset + 19px chip height). 0°/180° never had
               this problem (a 0° or 180° self-rotation never swaps width/
               height), which is why 1.0.4/1.0.5 field-tested fine for those
               two despite the same root gap existing latently for 90/270.
               Fix: a rotation-proof anchoring trick instead of edge insets.
               A zero-size OUTER anchor point sits at the local room corner
               that maps to visual bottom-right (same corner table as
               before, just expressed as a point instead of a CSS edge).
               The INNER chip pins to that point via its OWN bottom-right
               corner as transform-origin (100% 100%) — the pivot a
               rotation turns around is invariant under that SAME rotation
               regardless of angle, sidestepping the width/height-swap
               problem entirely — plus a small translate for the 2px visual
               inset, pre-solved per angle so it always reads as "2px up-
               and-left of the room's true corner" in FINAL screen space.
               Verified by simulating the full CSS transform chain as 2D
               affine matrices (Python), checked against the live-measured
               DOM geometry from the actual bug report, for all four angles
               and multiple room/chip sizes — not just reasoned by hand, since
               the earlier hand-derived fixes (1.0.4/1.0.5) had already gone
               wrong twice. Dropped 1.0.6's max-width/wrap-reverse narrow-room
               guard: the live measurement that motivated it (~21px overflow
               on rooms of very different widths, including a 990px-wide one)
               turned out to be fully explained by this same rotation bug,
               not a real content-width problem — simplifying back out rather
               than keep an untested fix for an invalidated hypothesis. */
            (dryEnt || wetEnt) ? (() => {
              const totalRot = this._mapRotationDeg();
              // Local room corner that maps to visual bottom-right — same
              // table as 1.0.5, now a point instead of an edge inset.
              const outerPos =
                totalRot === 90  ? { top: "0%", left: "100%" }    // local TR
                : totalRot === 180 ? { top: "0%", left: "0%" }      // local TL
                : totalRot === 270 ? { top: "100%", left: "0%" }    // local BL
                : { top: "100%", left: "100%" };                    // local BR (0°)
              // 2px visual inset, pre-solved per angle (dx,dy in the chip's
              // own pre-ambient-rotation local frame) so it lands as exactly
              // 2px up-and-left of the room's true corner on screen — see
              // comment above for how this was derived/verified.
              const INSET = 2;
              const rad = (totalRot * Math.PI) / 180;
              const dx = (-INSET * (Math.cos(rad) + Math.sin(rad))).toFixed(2);
              const dy = (-INSET * (Math.cos(rad) - Math.sin(rad))).toFixed(2);
              return html`
                <span class="room-overlay-assign-anchor" style=${styleMap(outerPos)}>
                  <span class="room-overlay-assign"
                    style=${styleMap({ transform: `translate(${dx}px, ${dy}px) rotate(calc(-1 * var(--map-rot)))` })}>
                    ${dryEnt ? this._vacChip(dryEnt) : nothing}
                    ${wetEnt ? this._vacChip(wetEnt) : nothing}
                  </span>
                </span>
              `;
            })() : nothing}
          ${this._renderRoomGauge(opts?.vacs ?? [vac], room)}
        </button>
        ${this._inspectKey === room.key ? this._renderRoomInspect(room, vac, selected, opts) : nothing}
      `;
    }

    // ── Point mód (legacy) ──────────────────────────────────────
    const bg = selected ? SEL + "A8" : wholeHome ? "rgba(255,255,255,0.32)" : "rgba(0,0,0,0.55)";
    const shadow = selected ? "0 0 12px rgba(255,255,255,0.8)" : wholeHome ? "0 0 8px rgba(255,255,255,0.45)" : "none";
    const holdIdPt = "room-" + room.key;
    return html`
      <button
        class="room-btn ${locked ? "room-overlay--locked" : ""} ${this._holdId === holdIdPt ? "room-overlay--holding" : ""}"
        ?disabled=${locked}
        style=${styleMap({
          left: (room.map_x ?? 0) + "%", top: (room.map_y ?? 0) + "%",
          background: bg,
          border: "4px solid " + (selected ? SEL : wholeHome ? "rgba(255,255,255,0.7)" : NEUTRAL_BORDER),
          borderImage: selected ? SEL_GRADIENT : "none",
          boxShadow: shadow,
        })}
        @pointerdown=${this._onRoomPointerDown(room, locked)}
        @pointerup=${this._onRoomPointerUp(room, vac, opts?.vacs, locked)}
        @pointerleave=${this._holdEnd}
        @pointercancel=${this._holdEnd}
        title=${locked ? "Room selection is off while placing a pin/zone" : room.name} aria-label=${room.name}
        aria-pressed=${selected ? "true" : "false"}
      >
        <div class="hold-ring"></div>
        ${!this._config.room_icon_hidden ? html`
          <ha-icon icon=${room.icon || "mdi:square"}
            style=${styleMap({ color: selected ? "white" : "rgba(255,255,255,0.5)" })}>
          </ha-icon>
        ` : nothing}
        ${this._renderRoomAgeDots(room, vac)}
        ${this._renderRoomGauge(opts?.vacs ?? [vac], room)}
      </button>
      ${this._inspectKey === room.key ? this._renderRoomInspect(room, vac, selected, opts) : nothing}
    `;
  }

  // ── Render: status card ─────────────────────────────────────────────────

  /** v1.1.0 (2026-08-03, user-approved mockup): condensed two-line info block
   *  that sits BESIDE the small circular avatar (`.status-avatar`,
   *  `_renderStatusCard`) instead of the old wide `.status-left`/`.status-right`
   *  split — name+status on line 1, room+battery+last-clean on line 2. The
   *  live cleaning percentage folds into line 1 next to the status label
   *  (`_renderProgress` below still renders the actual bar; this is just the
   *  number, so it's visible even where the bar's thin track is easy to miss). */
  private _renderStatusRow(vac: VacuumConfig) {
    const [label, labelColor] = this._statusInfo(vac);
    const bat = this._battery(vac);
    const lastClean = this._lastCleanStr(vac);
    const name = vac.name ?? vac.entity.split(".")[1] ?? vac.entity;
    const prog = this._progress(vac);

    // Current room
    const crid = this._ent(vac, "current_room");
    const roomState = crid ? this.hass.states[crid]?.state : null;
    const currentRoom = roomState && roomState !== "unknown" && roomState !== "unavailable"
      ? roomState : null;

    // Error
    const erid = this._ent(vac, "error");
    const errState = erid ? this.hass.states[erid]?.state : null;
    const hasError = this._hasError(vac);

    return html`
      ${hasError ? html`
        <div class="error-row">
          <ha-icon icon="mdi:alert-circle" style="color:rgb(var(--avc-err-rgb))"></ha-icon>
          <span style="color:rgb(var(--avc-err-rgb));font-size:11px;font-weight:600">${errState}</span>
        </div>
      ` : nothing}
      <div class="status-line1">
        <span class="model-label">${name}</span>
        <span class="status-label" style=${styleMap({ color: labelColor })}>
          ${label}${prog !== null ? html` &middot; ${prog}&thinsp;%` : nothing}
        </span>
      </div>
      <div class="status-line2">
        ${currentRoom ? html`
          <span class="current-room">
            <ha-icon icon="mdi:map-marker" style="--mdc-icon-size:12px;color:rgba(var(--avc-ink-rgb),0.4)"></ha-icon>
            ${currentRoom}
          </span>
        ` : html`<span></span>`}
        <span class="status-meta">
          ${bat !== null ? html`
            <span class="battery">
              <ha-icon icon=${this._batIcon(bat)} style=${styleMap({ color: this._batColor(bat) })}></ha-icon>
              <span style=${styleMap({ color: this._batColor(bat) })}>${bat}&thinsp;%</span>
            </span>
          ` : nothing}
          <span class="last-clean">
            <ha-icon icon="mdi:history"></ha-icon>
            <span>${lastClean}</span>
          </span>
        </span>
      </div>
    `;
  }

  private _renderProgress(vac: VacuumConfig) {
    const prog = this._progress(vac);
    if (prog === null) return nothing;
    const color = this._color(vac);
    return html`
      <div class="progress">
        <div class="progress-track">
          <div class="progress-fill" style=${styleMap({ width: prog + "%", background: color })}></div>
        </div>
        <span class="progress-label" style=${styleMap({ color })}>${prog}&thinsp;%</span>
      </div>
    `;
  }

  private _renderActions(vac: VacuumConfig, vacIdx: number) {
    const color = this._color(vac);

    // Pending Pin & Go / Zone for THIS vacuum (docs/19 meta bar fix): the START
    // slot itself becomes the mode-aware action — "send here" / "clean zone
    // here" — instead of a separate banner stacked above the controller. Takes
    // priority over the normal start/pause/resume states: picking a vacuum for
    // a pin/zone is itself the intent, and in practice the vacuum is idle
    // whenever this is relevant.
    const pin = this._pinPending?.[vac.entity];
    const zone = this._zonePending?.[vac.entity];
    if (pin || zone) {
      const hId = "modeaction-" + vacIdx;
      const label = zone ? "Clean zone" : "Send here";
      const icon = zone ? "mdi:select-drag" : "mdi:map-marker-radius";
      const action = () => { if (zone) this._confirmZone(vac); else this._confirmPin(vac); };
      return html`
        <div class="actions">
          <button
            class="action-btn ${this._holdId === hId ? "action-btn--holding" : ""}"
            style=${styleMap({ background: this._colorBg(vac), border: "1px solid " + color + "80" })}
            @pointerdown=${this._holdStart(hId, action)}
            @pointermove=${this._holdMove}
            @pointerup=${this._holdEnd}
            @pointerleave=${this._holdEnd}
            @pointercancel=${this._holdEnd}
          >
            <div class="hold-ring"></div>
            <ha-icon icon=${icon} style=${styleMap({ color })}></ha-icon>
            <span>${label}</span>
          </button>
        </div>
      `;
    }

    const cleaning = this._isCleaning(vac);
    const paused = this._isPaused(vac);
    const hasRooms = this._hasSelectedRooms(vac);
    const mins = this._totalCleanMins(vac);
    const timeStr = this._timeStr(mins);


    if (paused) {
      const hId = "resume-" + vacIdx;
      return html`
        <div class="actions">
          <button
            class="action-btn ${this._holdId === hId ? "action-btn--holding" : ""}"
            style=${styleMap({ background: this._colorBg(vac), border: "1px solid " + color + "80" })}
            @pointerdown=${this._holdStart(hId, () => this._resume(vac))}
            @pointermove=${this._holdMove}
            @pointerup=${this._holdEnd}
            @pointerleave=${this._holdEnd}
            @pointercancel=${this._holdEnd}
          >
            <div class="hold-ring"></div>
            <ha-icon icon="mdi:play" style=${styleMap({ color })}></ha-icon>
            <span>Resume</span>
          </button>
          <button
            class="action-btn action-btn--secondary"
            @click=${() => this._dock(vac)}
          >
            <ha-icon icon="mdi:home" style="color:rgba(var(--avc-info-rgb),0.6)"></ha-icon>
            <span>Dock</span>
          </button>
        </div>
      `;
    }

    if (cleaning) {
      const hId = "pause-" + vacIdx;
      return html`
        <div class="actions">
          <button
            class="action-btn action-btn--warn ${this._holdId === hId ? "action-btn--holding" : ""}"
            @pointerdown=${this._holdStart(hId, () => this._pause(vac))}
            @pointermove=${this._holdMove}
            @pointerup=${this._holdEnd}
            @pointerleave=${this._holdEnd}
            @pointercancel=${this._holdEnd}
          >
            <div class="hold-ring"></div>
            <ha-icon icon="mdi:pause" style="color:rgb(var(--avc-warn-rgb))"></ha-icon>
            <span>Pause</span>
          </button>
        </div>
      `;
    }

    const hId = "start-" + vacIdx;
    const startBg = hasRooms ? this._colorBg(vac) : "var(--avc-disabled)";
    const startBorder = hasRooms ? "1px solid " + color + "80" : "1px solid rgba(var(--avc-ink-rgb),0.1)";
    const startIconColor = hasRooms ? color : "rgba(var(--avc-ink-rgb),0.2)";
    const startTextColor = hasRooms ? "rgb(var(--avc-ink-rgb))" : "rgba(var(--avc-ink-rgb),0.25)";
    // v1.1.0 (2026-08-03, user-approved mockup): the old per-room icon strip
    // (every configured room as its own tiny icon, colored if selected) was
    // read-only display, not a control — replaced with a plain "N/M rooms"
    // count. Selection itself still happens on the map / via the room list,
    // unchanged; this just stopped being the tallest thing in the idle state.
    const rooms = this._roomsFor(vac);
    const selCount = rooms.filter((r) => this._isRoomSelected(r, vac)).length;
    const roomsStr = rooms.length > 0 ? `${selCount}/${rooms.length} rooms` : "";
    const metaStr = [roomsStr, timeStr].filter(Boolean).join(" · ");

    return html`
      <div class="actions actions--idle">
        ${this._renderPresetChips(vac)}
        <button
          class="action-btn ${hasRooms && this._holdId === hId ? "action-btn--holding" : ""}"
          style=${styleMap({ background: startBg, border: startBorder, flex: "1" })}
          ?disabled=${!hasRooms}
          @pointerdown=${hasRooms ? this._holdStart(hId, () => this._startClean(vac)) : nothing}
          @pointermove=${this._holdMove}
          @pointerup=${this._holdEnd}
          @pointerleave=${this._holdEnd}
          @pointercancel=${this._holdEnd}
        >
          <div class="hold-ring"></div>
          <ha-icon icon="mdi:play" style=${styleMap({ color: startIconColor })}></ha-icon>
          <div class="start-body">
            <span style=${styleMap({ color: startTextColor })}>${hasRooms ? "START" : "Select rooms"}</span>
            ${metaStr ? html`<small style="color:rgba(var(--avc-ink-rgb),0.4)">${metaStr}</small>` : nothing}
          </div>
        </button>
      </div>
    `;
  }

  /** v1.1.0 (2026-08-03): compact header replaces the old 150px-image /
   *  1fr-info grid split — a small circular avatar (mirrors `.vac-icon-btn`'s
   *  established look, docs/25 §7) beside the condensed two-line info block
   *  (`_renderStatusRow`). The avatar keeps the SAME click target as before
   *  (`_fireMoreInfo`, opens HA's stock more-info dialog) — user-requested
   *  "rescue control" for whatever this card's own actions don't cover — but
   *  a small `.avatar-info-badge` now marks it visually so shrinking the
   *  avatar doesn't also make that escape hatch less discoverable. */
  private _renderStatusCard(vac: VacuumConfig, vacIdx: number) {
    const cleaning = this._isCleaning(vac);
    const color = this._color(vac);
    const name = vac.name ?? vac.entity.split(".")[1] ?? vac.entity;

    // v1.2.0: the resting border goes through the panel-line token so a theme
    // can drop the hairline entirely and let elevation do the separating
    // (docs/35 §2). `legacy` resolves it back to the old literal. The active
    // border stays the vacuum's identity colour — that one carries meaning.
    const cardBorder = cleaning ? "2px solid " + color : "1px solid var(--avc-panel-line)";
    const cardShadow = cleaning ? "0 0 22px " + color + "40" : "var(--avc-elev-1)";
    const imgFilter = cleaning
      ? "drop-shadow(0 0 8px " + color + "D8)"
      : "drop-shadow(0 2px 5px " + color + "33)";

    return html`
      <div class="status-card" style=${styleMap({ border: cardBorder, boxShadow: cardShadow })}>
        <div class="status-header">
          <div class="status-avatar" style=${styleMap({ borderColor: color })}
            @click=${() => this._fireMoreInfo(vac.entity)}
            title="Open ${name} info — native controls, in case this card can't do something">
            ${vac.image ? html`
              <img src=${vac.image} alt=${name}
                style=${styleMap({ opacity: cleaning ? "0.9" : "0.6", filter: imgFilter })}
              />
            ` : html`
              <ha-icon icon="mdi:robot-vacuum"
                style=${styleMap({ color, fontSize: "22px", opacity: cleaning ? "0.9" : "0.5" })}
              ></ha-icon>
            `}
            <span class="avatar-info-badge"><ha-icon icon="mdi:information-outline"></ha-icon></span>
          </div>
          <div class="status-info">
            ${this._renderStatusRow(vac)}
          </div>
        </div>
        ${this._renderProgress(vac)}
        ${this._renderActions(vac, vacIdx)}
        ${this._renderDebugProgress(vac)}
      </div>
    `;
  }

  /** Small circular gauge for the debug strip (dry / wet coverage). `calibrating` adds a
   *  ~ to mark that it is still the raw bbox % (no learned baseline yet). */
  private _renderMiniGauge(pct: number, color: string, icon: string, calibrating: boolean) {
    return html`
      <span class="mini-gauge-wrap">
        <ha-icon class="mini-gauge-ico" icon=${icon} style=${styleMap({ color })}></ha-icon>
        <span class="mini-gauge" style=${styleMap({ background: `conic-gradient(${color} ${pct * 3.6}deg, rgba(var(--avc-ink-rgb),0.12) 0)` })}>
          <span>${pct}${calibrating ? "~" : ""}</span>
        </span>
      </span>`;
  }

  /** Room the vacuum is currently in, per the integration (for live-ticking its timer). */
  private _currentRoomName(vac: VacuumConfig): string | undefined {
    return this._intAttrs(vac)?.vacuum_room_name as string | undefined;
  }

  private _mmss(sec: number): string {
    const s = Math.max(0, Math.round(sec));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }

  /** Debug strip inside the status card: per-room dry + wet coverage gauges and the live
   *  time spent (mm:ss / mm:ss estimate). Shown whenever debug_room_progress is on. */
  private _renderDebugProgress(vac: VacuumConfig) {
    if (!this._config.debug_room_progress) return nothing;
    const rows = (this._roomsFor(vac))
      .map((r) => ({ r, p: this._roomProgress(vac, r) }))
      .filter((x) => x.p && (x.p!.dry_pct != null || x.p!.wet_pct != null || x.p!.elapsed_s != null));
    if (!rows.length) return nothing;
    const color = this._color(vac);
    const ent = this._intEntity(vac);
    const sensorTs = ent ? Date.parse(this.hass.states[ent]?.last_updated ?? "") : NaN;
    const curRoom = this._currentRoomName(vac);
    const cleaning = this._isCleaning(vac);
    const paused = this._isPaused(vac);
    // Seconds since the sensor last updated — while cleaning this is live cleaning time;
    // while paused the sensor is frozen so it measures the pause length.
    const since = (cleaning || paused) && !isNaN(sensorTs) ? Math.max(0, (this._now - sensorTs) / 1000) : 0;
    return html`
      <div class="dbg-prog">
        ${rows.map(({ r, p }) => {
          const isCur = (r.key === curRoom || r.name === curRoom) && (cleaning || paused);
          // Elapsed ticks every second for the active room (and keeps moving while paused);
          // the estimate grows equally during a pause so "remaining" stays put.
          const elapsed = (p!.elapsed_s ?? 0) + (isCur ? since : 0);
          let est = p!.est_s ?? null;
          if (isCur && paused && est != null) est = est + since;
          const timeStr = est != null ? `${this._mmss(elapsed)}/${this._mmss(est)}` : this._mmss(elapsed);
          return html`
            <span class="dbg-prog-item" title=${`dry ${p!.dry_pct ?? "—"}% · wet ${p!.wet_pct ?? "—"}%`}>
              ${r.icon ? html`<ha-icon icon=${r.icon}></ha-icon>` : nothing}
              <span class="dbg-prog-name">${r.name ?? r.key}</span>
              ${p!.dry_pct != null ? this._renderMiniGauge(p!.dry_pct, color, "mdi:broom", !!p!.dry_calibrating) : nothing}
              ${p!.wet_pct != null ? this._renderMiniGauge(p!.wet_pct, "rgb(var(--avc-info-rgb))", "mdi:water", !!p!.wet_calibrating) : nothing}
              ${p!.elapsed_s != null ? html`<small>${timeStr}</small>` : nothing}
            </span>
          `;
        })}
      </div>
    `;
  }

  // ── Main render ─────────────────────────────────────────────────────────

  /** Ordered, deduped snapshot of `_shownSet` as configured-array indices.
   *  `Set` preserves INSERTION order, not numeric order — `_toggleShownMulti`
   *  deletes then later re-`add`s an index when a vacuum is hidden and shown
   *  again, which moves it to the END of the set's iteration order (field
   *  feedback 2026-08-03: "S7 hidden then shown again jumps to last place").
   *  Every place that turns `_shownSet` into a displayed list should go
   *  through this instead of spreading the Set directly, so the vacuums
   *  always render in their configured order regardless of show/hide
   *  history. */
  private _shownOrdered(): number[] {
    return [...this._shownSet].filter((i) => i < this._config.vacuums.length).sort((a, b) => a - b);
  }

  /** Vacuum indexes shown in the grid. Portrait split = single-vacuum focus
   *  (docs/18 §7b): only the first of the shown set renders; badges switch it. */
  private _gridShown(): number[] {
    const shown = this._shownOrdered();
    if (this._profile === "portrait" && this._config.map_mode !== "merged" && shown.length > 1) {
      return shown.slice(0, 1);
    }
    return shown;
  }

  /** Named region template (docs/18 §3), built on demand — a region not placed
   *  in the active profile is never even computed. */
  private _regionTemplate(name: string, prof: ResolvedProfileGrid): unknown {
    const shown = this._gridShown();
    const merged = this._config.map_mode === "merged";
    const vacsOf = (idxs: number[]) => idxs.map((i) => this._config.vacuums[i]);
    switch (name) {
      case "badges":
        // Stats/refresh/layer-toggles moved into the consolidated meta bar
        // (docs/19 A4, `tools` region). Landscape also moves vacuum picking
        // into the vertical `picker` region (docs/19 A5) — badges there is
        // global actions only; portrait keeps vacuum badges as its
        // single-focus switcher (no `picker` region placed there).
        return html`<div class="badges-row badges-row--grid">
          ${this._profile === "landscape" ? nothing : this._config.vacuums.map((v, i) => this._renderBadge(v, i))}
          ${(this._config.global_actions ?? []).map((ga, i) => this._renderGlobalBadge(ga, i))}
        </div>`;
      case "autobar":
        return this._renderAutoBar();
      case "plan":
        return this._renderPlanPreview();
      case "picker":
        return this._renderVacuumPicker();
      case "map": {
        // Layer toggles + refresh + Pin&go/zone all moved into the `tools`
        // region's consolidated meta bar (docs/19 A4) — the map region is
        // just the map(s) now.
        return merged
          ? this._renderResponsive(this._renderMergedMap())
          : html`${shown.map((i) => this._renderResponsive(this._renderMap(this._config.vacuums[i])))}`;
      }
      case "tools":
        return this._renderMetaBar(vacsOf(shown));
      case "dock":
        // The dock carries the orchestrated run footer when no `start` region is
        // placed in this profile (landscape, docs/18 §7d). `withPicker`:
        // fold the vacuum picker into dock's own flow (docs/33 follow-up)
        // UNLESS this profile still explicitly places its own `picker`
        // region (manual config, kept working unchanged).
        // Field-caught 2026-08-04: `!("picker" in prof.place)` alone is also
        // true for BOTH portrait profiles (`DEFAULT_PROFILES.portrait` and
        // `STACK_PORTRAIT_PROFILE`) — neither has ever placed a `picker`
        // region, because portrait deliberately uses the vacuum ICON STRIP
        // instead (0.69.0, docs/25 §7a) as its single "show/hide vacuums"
        // control. Without the `_profile === "landscape"` guard, portrait
        // rendered the pill-list picker AND the icon strip at once — two
        // redundant controls for the same thing, stacked on top of each
        // other. Only landscape (and a manual profile that structurally
        // mirrors it) gets the auto-folded picker; portrait keeps relying
        // on the icon strip alone, same as before docs/33.
        return this._renderDock(!("start" in prof.place), this._profile === "landscape" && !("picker" in prof.place));
      case "start":
        return this._renderStartBar();
      case "status":
        return html`${shown.map((i) => this._renderStatusCard(this._config.vacuums[i], i))}`;
      default:
        return null;
    }
  }

  /* ── Theming (v1.2.0, docs/35) ───────────────────────────────────────── */

  /**
   * Class list for the card root. `legacy` deliberately yields an EMPTY string:
   * the stylesheet's `:host` block already carries the pre-1.2.0 values, so the
   * old look is what you get when none of the theme classes apply. That makes
   * `theme: legacy` an escape hatch with no code path of its own to rot —
   * there is nothing to keep in sync, only something to leave off.
   *
   * `avc-still` is the config-level motion opt-out; `prefers-reduced-motion`
   * covers the OS-level one on its own, in CSS.
   */
  private _rootClasses(): string {
    const theme = this._config.theme ?? DEFAULT_THEME;
    const cls: string[] = [];
    if (theme !== "legacy") cls.push("avc-theme", "avc-theme--" + theme);
    if (this._config.reduce_motion) cls.push("avc-still");
    if (this._isCalm()) cls.push("avc-calm");
    return cls.join(" ");
  }

  /**
   * Inline custom properties for the card root: just the accent channel, and
   * only when it actually differs from the token default. Anything that fails
   * to parse as a hex is dropped rather than written through — an invalid
   * custom-property value would poison every rule referencing it, which on
   * this card includes START itself.
   */
  private _rootVars(): Record<string, string> {
    const accent = this._config.accent;
    if (!accent) return {};
    const ch = hexToRgbChannel(accent);
    return ch ? { "--avc-accent-rgb": ch } : {};
  }

  /**
   * Resting state (docs/35 §7): nothing is running, nothing is explicitly
   * selected, no map tool is armed and no sheet is open. Read as "the user is
   * looking at the card, not operating it" — the CSS then steps the leftover
   * trace and the secondary metadata back so the primary action is the one
   * thing that reads. Deliberately NOT a state machine: it is derived fresh on
   * every render from state the card already tracks, so it can never get stuck
   * out of sync with what is actually happening.
   */
  private _isCalm(): boolean {
    if (this._config.calm_state === false) return false;
    if (this._mapMode !== "normal") return false;
    if (this._dockSheetOpen || this._modeSheetOpen) return false;
    const vacs = this._config.vacuums;
    if (vacs.some((v) => this._isCleaning(v) || this._hasError(v))) return false;
    return !this._allRoomKeys().some((k) => this._isRoomSelectedAny(k, vacs));
  }

  /** Grid render path (docs/18): active only with a `layout:` config block. */
  private _renderGrid(lay: LayoutConfig) {
    // docs/25 §7c: stack topology substitutes the whole resolved profile —
    // `_stackTopology` already refuses to fire when the user has hand-set
    // columns/rows/place, so this never overrides a manual layout.
    const stack = this._profile === "portrait" && this._stackTopology;
    const prof = stack ? STACK_PORTRAIT_PROFILE : resolveProfile(lay, this._profile);
    const schemaWarn = this._schemaWarning();
    // The split/stack line that used to sit in this chip was TEMP diagnostics
    // for the 0.73.1–0.73.7 topology work (screenshots weren't precise enough
    // to debug it); the model was confirmed in the field in 0.73.7, so it went
    // away with the 2026-08-08 cleanup. The `debug` config flag still exposes
    // the same numbers where they're actually useful, and it isn't limited to
    // edit mode the way this chip was.
    return html`
      <ha-card class=${this._rootClasses()} style=${styleMap({ padding: "0", display: "block", ...this._rootVars() })}>
        ${this.editMode ? html`<div class="version-chip">
          <div>v${CARD_VERSION} · ${Math.round(this._cardW)}w · ${this._profile}</div>
          ${this._config.debug ? html`<div>${stack ? "stack" : "split"} · box:${Math.round(this._mapAvailW)}x${Math.round(this._mapAvailH)}</div>` : nothing}
        </div>` : nothing}
        <div class="avc-grid avc-grid--${this._profile}" style=${styleMap(gridRootStyles(lay, prof))}>
          ${schemaWarn ? html`<div class="avc-schemawarn">
            <ha-icon icon="mdi:alert" style="--mdc-icon-size:18px"></ha-icon><span>${schemaWarn}</span>
          </div>` : nothing}
          ${Object.entries(prof.place).map(([name, pl]) => {
            const tpl = this._regionTemplate(name, prof);
            if (tpl == null || tpl === nothing) return nothing;
            return html`<div class="avc-region avc-region--${name}" style=${styleMap(regionStyles(pl))}>${tpl}</div>`;
          })}
        </div>
      </ha-card>
    `;
  }

  render() {
    if (!this._config || !this.hass) return nothing;
    if (this._config.layout) return this._renderGrid(this._config.layout);

    const schemaWarn = this._schemaWarning();
    return html`
      <ha-card class=${this._rootClasses()} style=${styleMap(this._rootVars())}>
        ${this.editMode ? html`<div class="version-chip">v${CARD_VERSION} · ${Math.round(this._cardW)}w</div>` : nothing}
        ${schemaWarn ? html`<div style="margin:0 4px;padding:8px 12px;border-radius:12px;border:1px solid rgba(var(--avc-warn-rgb),0.55);background:rgba(var(--avc-warn-rgb),0.12);color:rgb(var(--avc-warn-rgb));font-size:12px;display:flex;align-items:center;gap:8px">
          <ha-icon icon="mdi:alert" style="--mdc-icon-size:18px"></ha-icon><span>${schemaWarn}</span>
        </div>` : nothing}
        <div class="badges-row">
          ${this._config.vacuums.map((v, i) => this._renderBadge(v, i))}
          ${(this._config.global_actions ?? []).map((ga, i) => this._renderGlobalBadge(ga, i))}
        </div>
        ${this._renderAutoBar()}
        ${this._renderPlanPreview()}
        ${this._config.map_mode === "merged"
          ? html`
              ${this._renderResponsive(this._renderMergedMap())}
              ${this._shownOrdered().map(i => html`
                ${this._renderMapTools(this._config.vacuums[i])}
                ${this._renderStatusCard(this._config.vacuums[i], i)}
              `)}
            `
          : this._shownOrdered()
              .map(i => html`
                ${this._renderResponsive(this._renderMap(this._config.vacuums[i]))}
                ${this._renderMapTools(this._config.vacuums[i])}
                ${this._renderStatusCard(this._config.vacuums[i], i)}
              `)}
      </ha-card>
    `;
  }

  // ── Styles ──────────────────────────────────────────────────────────────

  static styles = css`
    /* ══ Design tokens (v1.2.0, docs/35) ═══════════════════════════════════
     * Every colour in this stylesheet resolves through one of the channel
     * bases below, so a theme is a handful of numbers rather than the ~130
     * literals this file used to carry — and, more importantly, a theme can
     * no longer MISS a spot the way a find-and-replace pass would.
     *
     * :host holds the LEGACY values verbatim: with no theme class applied
     * the card renders exactly as 1.1.0 did. .avc-theme-* further down
     * layers the real themes on top of that baseline, so theme: legacy
     * costs nothing but the absence of a class name.
     *
     * The one deliberate exception is .map-wrap, which pins the ink/shade
     * channels back to white-on-black regardless of theme — everything
     * inside it is painted on the vacuum's own map bitmap, not on the card's
     * surface, so a light theme must not reach in there (it would turn every
     * on-map label invisible). Derived tokens re-resolve per element, so
     * that one reset covers all of them without listing any.
     */
    :host {
      display: block;
      width: 100%;

      /* Channel bases */
      --avc-ink-rgb: 255, 255, 255;
      --avc-shade-rgb: 0, 0, 0;
      --avc-scrim-rgb: 18, 18, 18;
      --avc-scrim-2-rgb: 30, 30, 30;

      /* Semantic palette. accent is intent (START, selection, focus);
       * ok/warn/err/hint/tool/info are meaning and stay out of the accent's
       * reach on purpose (docs/25 §6). */
      --avc-accent-rgb: 111, 191, 115;
      --avc-ok-rgb: 82, 196, 26;
      --avc-warn-rgb: 250, 173, 20;
      --avc-err-rgb: 255, 77, 79;
      --avc-hint-rgb: 212, 160, 23;
      --avc-tool-rgb: 59, 130, 246;
      --avc-info-rgb: 64, 169, 255;
      /* Only the CHANNELS live here, never a ready-made
       * --avc-ink: rgb(var(--avc-ink-rgb)) alias. A custom property whose
       * value contains var() is substituted at computed-value time on the
       * element it is DECLARED on, and the already-substituted result is what
       * inherits — so such an alias would freeze at the :host value and quietly
       * ignore both the theme classes and the .map-wrap reset below. Rules
       * therefore spell out rgb(var(--avc-x-rgb)) at the point of use, where it
       * resolves against that element's channels. Caught by
       * tests/theme.spec.ts, not by reading the spec. */

      /* Surfaces — named separately from the raw shade channel so a theme can
       * LIFT a panel off the background instead of only tinting it. */
      --avc-surface: rgba(var(--avc-shade-rgb), 0.6);
      --avc-panel: rgba(var(--avc-ink-rgb), 0.03);
      --avc-panel-line: rgba(var(--avc-ink-rgb), 0.08);
      --avc-panel-strong: rgba(var(--avc-ink-rgb), 0.06);
      --avc-panel-strong-line: rgba(var(--avc-ink-rgb), 0.16);
      --avc-sunken: rgba(var(--avc-shade-rgb), 0.25);
      --avc-disabled: rgba(60, 60, 60, 0.4);

      /* Elevation. Legacy has none: hairline borders did the whole job, which
       * is the single loudest "instrument panel" tell in the old look. */
      --avc-elev-1: none;
      --avc-elev-2: none;

      /* Motion. --avc-press is the scale a pressable element takes while
       * held — 1 means no feedback at all, i.e. 1.1.0's behaviour. */
      --avc-ease: cubic-bezier(0.2, 0.8, 0.2, 1);
      --avc-press: 1;
      --avc-press-ms: 0s;
      --avc-live: none;
    }

    ha-card {
      position: relative;
      background: transparent;
      border: none;
      box-shadow: none;
      padding: 8px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .version-chip {
      position: absolute;
      top: 4px;
      right: 8px;
      max-width: calc(100% - 16px);
      text-align: right;
      font-size: 10px;
      line-height: 1.5;
      font-weight: 600;
      color: rgba(var(--avc-ink-rgb), 0.85);
      background: rgba(var(--avc-shade-rgb), 0.75);
      border-radius: 6px;
      padding: 3px 6px;
      pointer-events: none;
      z-index: 20;
    }

    /* ── Grid layout (docs/18) ───────────────────────────────────────── */
    .badges-row--grid {
      align-items: center;
      padding: 4px 6px;
    }

    /* Emergency manual-control icon strip (docs/19 follow-up, portrait only).
       Full-width, one flex slot per vacuum (mirrors .dock-head/.dock-mode
       below it). The slot shares available width equally (n=2 → wide slots,
       n=4 → narrower) and the button fills its slot (width: 100%, capped by
       min/max-width) with aspect-ratio 1:1 keeping it a circle at any size —
       so the strip actually uses the space it has instead of staying pinned
       at a fixed 34px regardless of vacuum count (field feedback
       2026-07-17). */
    .vac-icon-strip { display: flex; gap: 6px; margin-bottom: 6px; }
    .vac-icon-slot { flex: 1; min-width: 0; display: flex; justify-content: center; }
    .vac-icon-btn {
      position: relative;
      width: 100%; min-width: 28px; max-width: 64px; aspect-ratio: 1 / 1; height: auto;
      border-radius: 50%; padding: 0; overflow: hidden;
      display: flex; align-items: center; justify-content: center;
      /* docs/25 §6: thinner ring (was 2px) — reads calmer, still clearly a
       * status indicator, without competing for visual weight with START. */
      background: rgba(var(--avc-ink-rgb), 0.05); border: 1.5px solid rgba(var(--avc-ink-rgb), 0.2); cursor: pointer;
      transition: opacity 0.15s ease;
      /* Mobile hold-gesture fix: without these, iOS/Android WebViews race our
       * 600ms pointerdown timer against their own long-press affordances
       * (image-save callout, text selection, Haptic Touch preview) — the
       * native gesture wins right at the deadline, firing pointercancel a
       * moment before our setTimeout callback, so the ring animation still
       * visually completes but _toggleShownMulti() never runs. Mirrors the
       * fix already applied to .layer-btn. */
      touch-action: manipulation;
      -webkit-touch-callout: none;
      user-select: none;
    }
    .vac-icon-btn img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; -webkit-touch-callout: none; user-select: none; pointer-events: none; }
    .vac-icon-btn ha-icon { --mdc-icon-size: 20px; }
    .vac-icon-btn--hidden { opacity: 0.35; }

    /* Vacuum picker (docs/19 A5): landscape's vertical replacement for the
     *  horizontal badge-row tabs, sits right above the dock room-list. */
    .vac-picker {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding: 5px;
      box-sizing: border-box;
      background: var(--avc-panel);
      border: 1px solid var(--avc-panel-line);
      border-radius: 12px;
    }
    /* v1.1.0 follow-up (2026-08-03): field feedback that the picker column's
     * full-size badges (same .badge used by the legacy/portrait horizontal
     * badge row, 44px avatar + generous padding) were too large for what's
     * just a vertical vacuum switcher, right above an already-compact dock.
     * Scoped to .vac-picker only — the legacy/portrait badge row keeps its
     * established size unchanged. */
    .vac-picker .badge { width: 100%; box-sizing: border-box; padding: 4px 12px 4px 4px; gap: 8px; }
    .vac-picker .badge-img, .vac-picker .badge-icon { width: 26px; height: 26px; --mdc-icon-size: 18px; }
    .vac-picker .badge-name { font-size: 12px; }

    /* Dock (docs/12 §3): selection + plan + pinning in one column */
    .dock {
      display: flex;
      flex-direction: column;
      /* docs/25 §6 (visual language pass, 2026-07-24): a bit more breathing
       * room between the icon strip / layer toggle / mode row — "generous
       * whitespace" was one of the agreed directions, mocked up and
       * confirmed against the card's actual dark theme before landing here. */
      gap: 9px;
      height: 100%;
      padding: 8px;
      box-sizing: border-box;
      background: var(--avc-panel);
      border: 1px solid var(--avc-panel-line);
      border-radius: 12px;
    }
    /* Portrait-only dry/wet path visibility row (see _renderDock) — reuses
       .mtbtn from the meta bar, wrapped to full width like .dock-head below. */
    .dock-layers { display: flex; gap: 4px; margin-bottom: 4px; }
    .dock-layers .mtbtn { flex: 1; justify-content: center; }
    .dock-head { display: flex; gap: 4px; }
    .dock-mode {
      flex: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      padding: 7px 4px;
      border-radius: 10px;
      cursor: pointer;
      font-family: inherit;
      font-size: 11px;
      /* docs/25 §6: 700 read as one more hard-edged/technical accent among
       * several — the mode row is a secondary control next to START, not a
       * second primary action, so its resting weight steps down a notch.
       * The .on state keeps its own distinct (bolder) weight below, so the
       * active/inactive contrast doesn't shrink. */
      font-weight: 600;
      color: rgba(var(--avc-ink-rgb), 0.5);
      background: transparent;
      border: 1px solid rgba(var(--avc-ink-rgb), 0.15);
    }
    .dock-mode ha-icon { --mdc-icon-size: 15px; }
    .dock-mode.on {
      color: rgb(var(--avc-ink-rgb));
      font-weight: 700;
      background: rgba(var(--avc-ink-rgb), 0.12);
      border-color: rgba(var(--avc-ink-rgb), 0.5);
    }
    /* docs/25 §7 field follow-up: Dock button — same base as the mode
     * buttons (visually one row), but a flex-0 fixed width since it's an
     * icon + short label, not a mode choice competing for equal space. */
    .dock-mode--dock { flex: 0 0 auto; padding: 7px 10px; position: relative; }
    .dock-mode-dot {
      position: absolute;
      top: 4px;
      right: 4px;
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: rgb(var(--avc-warn-rgb));
    }
    .dock-sheet {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 8px;
      background: var(--avc-sunken);
      border: 1px solid var(--avc-panel-line);
      border-radius: 10px;
    }
    .dock-sheet-tabs { display: flex; gap: 6px; }
    .dock-sheet-tab {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      overflow: hidden;
      padding: 0;
      cursor: pointer;
      background: rgba(var(--avc-ink-rgb), 0.05);
      border: 1.5px solid rgba(var(--avc-ink-rgb), 0.2);
      opacity: 0.55;
    }
    .dock-sheet-tab.on { opacity: 1; }
    .dock-sheet-tab img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .dock-sheet-tab ha-icon { --mdc-icon-size: 16px; }
    .dock-sheet-debug {
      display: flex;
      flex-direction: column;
      gap: 2px;
      font-size: 10px;
      color: rgba(var(--avc-ink-rgb), 0.4);
    }
    .dock-sheet-actions { display: flex; flex-wrap: wrap; gap: 8px; }
    .dock-sheet-action {
      flex: 1 1 27%;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      padding: 10px 0;
      border-radius: 9px;
      cursor: pointer;
      font-family: inherit;
      font-size: 11px;
      color: rgba(var(--avc-ink-rgb), 0.8);
      background: rgba(var(--avc-ink-rgb), 0.05);
      border: 1px solid rgba(var(--avc-ink-rgb), 0.12);
    }
    .dock-sheet-action ha-icon { --mdc-icon-size: 18px; }
    /* A dock cycle that is currently running: the button now stops it, so it
       reads as active rather than as another thing to start. */
    .dock-sheet-action.running {
      color: rgba(var(--avc-ink-rgb), 0.95);
      background: rgba(var(--avc-accent-rgb), 0.18);
      border-color: rgba(var(--avc-accent-rgb), 0.5);
    }
    .dock-sheet-care {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid rgba(var(--avc-ink-rgb), 0.08);
    }
    .dock-sheet-care-row {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
    }
    .dock-sheet-care-label {
      flex: 1;
      color: rgba(var(--avc-ink-rgb), 0.75);
    }
    .dock-sheet-care-value {
      color: rgba(var(--avc-ink-rgb), 0.5);
      font-variant-numeric: tabular-nums;
    }
    .dock-sheet-care-badge {
      font-size: 10px;
      font-weight: 600;
      padding: 2px 7px;
      border-radius: 20px;
      background: rgba(var(--avc-ok-rgb), 0.18);
      color: rgb(var(--avc-ok-rgb));
    }
    .dock-sheet-care-badge.warn {
      background: rgba(var(--avc-warn-rgb), 0.2);
      color: rgb(var(--avc-warn-rgb));
    }
    .dock-sheet-care-reset {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 26px;
      height: 26px;
      border-radius: 50%;
      cursor: pointer;
      color: rgba(var(--avc-ink-rgb), 0.6);
      background: rgba(var(--avc-ink-rgb), 0.06);
      border: 1px solid rgba(var(--avc-ink-rgb), 0.1);
    }
    .dock-sheet-care-reset ha-icon { --mdc-icon-size: 14px; }
    /* docs/25 §10 field-caught (2026-07-25): spinner while waiting for the
     * roborock integration's own poll to reflect the reset — see
     * _careResetPending's doc comment for why this is needed. */
    .dock-sheet-care-reset.pending { cursor: default; opacity: 0.55; }
    .dock-sheet-care-reset.pending ha-icon { animation: avc-spin 0.9s linear infinite; }
    @keyframes avc-spin { to { transform: rotate(360deg); } }
    .dock-rows {
      display: flex;
      flex-direction: column;
      gap: 3px;
      overflow-y: auto;
      min-height: 0;
      flex: 1;
    }
    .dock-row {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 7px;
      border-radius: 9px;
      cursor: pointer;
      font-family: inherit;
      text-align: left;
      color: rgba(var(--avc-ink-rgb), 0.85);
      background: rgba(var(--avc-ink-rgb), 0.03);
      border: 1px solid rgba(var(--avc-ink-rgb), 0.07);
    }
    .dock-row.on {
      background: rgba(var(--avc-ok-rgb), 0.1);
      border-color: rgba(var(--avc-ok-rgb), 0.5);
    }
    .dock-ric { --mdc-icon-size: 16px; color: rgba(var(--avc-ink-rgb), 0.55); flex-shrink: 0; }
    /* docs/28 §4: wraps to a second line instead of truncating — an unusually
     * long room name stays fully readable, it just costs that one row a bit
     * more height. Deliberately NOT flex:1 (that would make this the
     * growable part of the row, fighting the landscape column's own
     * content-driven max-content sizing, docs/28 §4) — a fixed max-width
     * bounds this element's own max-content contribution, which is what lets
     * the grid column settle on the row's TYPICAL width instead of whatever
     * the single longest name would need unwrapped. */
    .dock-name {
      flex: 0 1 auto;
      max-width: 128px;
      min-width: 0;
      overflow-wrap: break-word;
      white-space: normal;
      font-size: 12px;
      font-weight: 600;
      line-height: 1.25;
    }
    /* Sequence hint (docs/19 follow-up, TODO #2) — amber, not red: it's a
       heads-up about ETA accuracy, not an error blocking the clean. */
    .dock-unseq { --mdc-icon-size: 13px; color: rgb(var(--avc-hint-rgb)); flex-shrink: 0; margin: 0 2px; }
    .dock-unassigned { --mdc-icon-size: 13px; color: rgb(var(--avc-err-rgb)); flex-shrink: 0; margin: 0 2px; }
    /* 2026-07-25 field feedback: the trailing warning icons + ages + avatars
     * used to be flat siblings of .dock-ric/.dock-name in the row's own
     * flex flow — with no growing element and no justify-content, they
     * packed left along with the name instead of anchoring to the row's
     * right edge, so a room WITHOUT the optional unassigned/unsequenced
     * icon (extra width before .dock-ages) landed its avatars at a
     * different x-position than a room WITH one, and a short room name left
     * a gap before the info block on rows narrower than the column's
     * settled width (docs/28 §4) — looked "scattered" row-to-row instead of
     * two clean columns. Grouping them into one .dock-info block with
     * margin-left: auto makes icon+name the fixed left column and
     * everything else one right-anchored block, regardless of which
     * optional icons are present or how long the name is. */
    .dock-info { display: inline-flex; align-items: center; gap: 6px; margin-left: auto; flex-shrink: 0; }
    .dock-ages { display: inline-flex; gap: 6px; flex-shrink: 0; }
    .dock-age { display: inline-flex; align-items: center; gap: 2px; font-size: 10px; }
    .dock-age ha-icon { --mdc-icon-size: 12px; color: rgba(var(--avc-ink-rgb), 0.3); }
    /* Persistent last-clean coverage % (docs/29) — deliberately dimmer/smaller than the
       age badge next to it: age is the primary "should I clean this?" signal, coverage
       is supporting detail. */
    .dock-cov { font-size: 9px; opacity: 0.45; margin-left: 1px; }
    .dock-avatars { display: inline-flex; gap: 3px; flex-shrink: 0; }
    .dock-chip {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 1px;
      min-width: 24px;
      height: 17px;
      padding: 0 5px;
      border-radius: 9px;
      font-size: 10px;
      font-weight: 700;
      border: 1px solid transparent;
      cursor: pointer;
    }
    .dock-chip--empty { color: rgba(var(--avc-ink-rgb), 0.25); border-color: rgba(var(--avc-ink-rgb), 0.15); }
    .dock-foot {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      border-top: 1px solid rgba(var(--avc-ink-rgb), 0.08);
      padding-top: 6px;
    }
    .dock-est { font-size: 11px; color: rgba(var(--avc-ink-rgb), 0.45); }
    .dock-run {
      flex: 0 0 auto;
      padding: 7px 14px;
      background: rgba(var(--avc-accent-rgb), 0.24);
      border: 1px solid rgba(var(--avc-accent-rgb), 0.65);
      color: rgb(var(--avc-ink-rgb));
    }

    /* START bar (portrait bottom, docs/18 §7d). docs/25 §6 (visual language
     * pass, 2026-07-24): the one thing this whole screen is FOR, so it
     * should read as unambiguously the heaviest element on it — bigger,
     * rounder, and a calmer sage green instead of the same saturated
     * "technical" green used for status accents elsewhere (cleaning state,
     * battery, etc.) — reserving that vivid green for status meaning and
     * giving START its own, purely intentional color instead of borrowing
     * one. Mocked up and confirmed against the actual dark card theme
     * before landing here; the room-count/ETA text stays inline in the
     * button (already was — the mockup's separate line under the button
     * was an artifact of the mockup, not a real proposal to split it out). */
    /* docs/25 §10 follow-up (2026-07-25): the START bar is now a 3-segment
     * row (mode / START / Dock, mirrors the manufacturer app's bottom bar) —
     * .start-row is the flex container, .start-bar keeps its own look
     * but stretches to fill the middle slot instead of the whole region. */
    .start-row {
      display: flex;
      align-items: stretch;
      width: 100%;
      height: 100%;
      min-height: 52px;
      gap: 8px;
    }
    .start-row .start-bar { width: auto; flex: 1; min-width: 0; }
    .start-bar {
      position: relative;
      overflow: hidden;
      width: 100%;
      height: 100%;
      min-height: 52px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      border-radius: 18px;
      cursor: pointer;
      font-family: inherit;
      font-size: 16px;
      font-weight: 700;
      color: rgb(var(--avc-ink-rgb));
      background: rgba(var(--avc-accent-rgb), 0.24);
      border: 1px solid rgba(var(--avc-accent-rgb), 0.65);
    }
    .start-bar:disabled {
      cursor: default;
      color: rgba(var(--avc-ink-rgb), 0.25);
      background: var(--avc-disabled);
      border-color: rgba(var(--avc-ink-rgb), 0.1);
    }
    .start-bar ha-icon { --mdc-icon-size: 22px; position: relative; z-index: 1; }
    .start-bar span { position: relative; z-index: 1; }
    .start-bar--cancel {
      background: rgba(var(--avc-warn-rgb), 0.16);
      border-color: rgba(var(--avc-warn-rgb), 0.6);
    }
    /* Side segments (mode / dock) — same family as .start-bar but a fixed
     * narrow width so the middle START segment keeps most of the bar. */
    .start-seg {
      flex: 0 0 auto;
      width: 54px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 2px;
      border-radius: 16px;
      cursor: pointer;
      font-family: inherit;
      font-size: 10px;
      font-weight: 600;
      color: rgba(var(--avc-ink-rgb), 0.65);
      background: rgba(var(--avc-ink-rgb), 0.05);
      border: 1px solid rgba(var(--avc-ink-rgb), 0.15);
    }
    .start-seg ha-icon { --mdc-icon-size: 20px; }
    .start-seg.on {
      color: rgb(var(--avc-ink-rgb));
      font-weight: 700;
      background: rgba(var(--avc-ink-rgb), 0.14);
      border-color: rgba(var(--avc-ink-rgb), 0.5);
    }
    .start-seg--dock { position: relative; }

    .map-tools-label {
      font-size: 11px;
      font-weight: 700;
      color: rgba(var(--avc-ink-rgb), 0.45);
      align-self: center;
      min-width: 64px;
    }

    /* Counter-rotate small on-map chips inside the rotated map so their text
     *  stays upright (the rotation wrapper adds .avc-rot). --map-rot is set
     *  inline on the .avc-rot wrapper to the actual total angle (docs/32 —
     *  90/180/270 degrees, not just the old fixed 90° case), so one rule now
     *  covers all of them instead of a hardcoded -90deg. */
    .avc-rot .room-gauge { transform: rotate(calc(-1 * var(--map-rot))); }
    .avc-rot .rl-prog { transform: rotate(calc(-1 * var(--map-rot))); }
    .avc-rot .room-btn > ha-icon,
    .avc-rot .room-overlay > ha-icon { transform: rotate(calc(-1 * var(--map-rot))); }
    /* Field-caught 2026-08-03, superseded 1.0.7: the assign chip used to be
     * counter-rotated via this shared .avc-rot rule like every other on-map
     * label (room-gauge, rl-prog, room icons above). That's fine for SQUARE
     * elements (a 90° self-rotation doesn't change a square's footprint),
     * but the assign chip is a non-square pill row — a 90°/270° self-
     * rotation swaps its own width/height before the ambient rotation
     * carries it further, which broke its edge-anchored position (see the
     * render fn's comment for the full story). Now handled by an inline
     * transform (translate + rotate together) computed per-render, so this
     * shared rule no longer applies to it. */

    /* Portrait grid: compact badges (horizontal scroll, no wrap) + compact dock */
    .avc-grid--portrait .badges-row--grid {
      flex-wrap: nowrap;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .avc-grid--portrait .badges-row--grid::-webkit-scrollbar { display: none; }
    .avc-grid--portrait .badge { padding: 4px 10px 4px 4px; gap: 6px; flex-shrink: 0; }
    .avc-grid--portrait .badge-img { width: 30px; height: 30px; }
    .avc-grid--portrait .badge-icon { --mdc-icon-size: 26px; }
    .avc-grid--portrait .badge-name { font-size: 11px; }
    .avc-grid--portrait .dock { padding: 4px; gap: 4px; }
    .avc-grid--portrait .dock-mode { padding: 6px 2px; }
    .avc-grid--portrait .dock-mode span { display: none; }
    .avc-grid--portrait .dock-name { display: none; }
    .avc-grid--portrait .dock-row { padding: 5px 5px; gap: 4px; flex-wrap: wrap; justify-content: center; }
    /* .dock-name is hidden in portrait (below), so .dock-info's
     * margin-left: auto has no left column to push away from — with
     * justify-content: center on the row, an auto margin would eat the
     * would-be-centered free space and shove the block hard right instead.
     * Neutralised here; portrait's own centered-wrap look is unaffected. */
    .avc-grid--portrait .dock-info { margin-left: 0; }
    .avc-grid--portrait .dock-ages { gap: 3px; }
    .avc-grid--portrait .dock-age { font-size: 9px; }
    .avc-grid--portrait .dock-age ha-icon { --mdc-icon-size: 10px; }
    .avc-grid--portrait .dock-cov { font-size: 8px; }

    .avc-schemawarn {
      position: absolute;
      top: 4px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 5;
      padding: 8px 12px;
      border-radius: 12px;
      border: 1px solid rgba(var(--avc-warn-rgb), 0.55);
      background: rgba(var(--avc-warn-rgb), 0.12);
      color: rgb(var(--avc-warn-rgb));
      font-size: 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      max-width: 90%;
    }

    /* ── Badges ──────────────────────────────────────────────────────── */
    .badges-row {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .badge {
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 6px 18px 6px 6px;
      border-radius: 99px;
      cursor: pointer;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      transition: background 0.3s, border 0.3s, box-shadow 0.3s;
      /* Same mobile hold-gesture fix as .vac-icon-btn — badges use the
       * identical tap-vs-hold pointer pattern (short tap = focus, hold =
       * show/hide toggle). */
      touch-action: manipulation;
      -webkit-touch-callout: none;
      user-select: none;
    }

    .badge-img {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      object-fit: cover;
      flex-shrink: 0;
      position: relative;
      z-index: 1;
      -webkit-touch-callout: none;
      user-select: none;
      pointer-events: none;
    }

    .badge-icon {
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }

    .badge-name {
      font-size: 15px;
      font-weight: 700;
      white-space: nowrap;
      transition: color 0.3s;
      position: relative;
      z-index: 1;
    }

    /* ── Hold ring (shared by badges and action buttons) ─────────────── */
    .hold-ring {
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: rgba(var(--avc-ink-rgb), 0.18);
      transform: scaleX(0);
      transform-origin: left;
      pointer-events: none;
      z-index: 0;
    }

    .action-btn--holding .hold-ring,
    .badge--holding .hold-ring,
    .vac-icon-btn--holding .hold-ring,
    .room-overlay--holding .hold-ring {
      animation: hold-fill var(--hold-ms) linear forwards;
    }

    @keyframes hold-fill {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }

    /* ── Map ─────────────────────────────────────────────────────────── */
    .map-wrap {
      position: relative;
      width: 100%;
      padding-top: 27.5%;
      overflow: hidden;
      border-radius: 12px;
    }

    .map-img {
      position: absolute;
      transform-origin: center center;
      object-fit: cover;
    }

    .map-wrap--image { padding-top: 0; }
    .image-base-img { position: relative; display: block; width: 100%; height: auto; transform-origin: center center; }
    .map-img--overlay { opacity: 0.55; pointer-events: none; }
    .map-vector { position: absolute; transform-origin: center center; pointer-events: none; overflow: visible; }
    .avc-err-halo { animation: avc-err-pulse 1.3s ease-in-out infinite; }
    @keyframes avc-err-pulse { 0%,100% { opacity: 0.18; } 50% { opacity: 0.6; } }
    .zone-rect { position: absolute; border: 2px solid rgb(var(--avc-ink-rgb)); background: rgba(var(--avc-ink-rgb), 0.15); border-radius: 4px; pointer-events: none; box-shadow: 0 0 0 1px rgba(var(--avc-shade-rgb), 0.45); }
    /* Move/resize handles (docs/19 follow-up) — decoration only, no pointer
       handlers: the overlaying .map-clickcatch does the actual hit-testing
       (_zoneHit) so a drag anywhere near a corner resizes, and inside the box
       moves the whole rectangle. */
    .zone-handle { position: absolute; width: 12px; height: 12px; margin: -6px; border-radius: 50%; background: rgb(var(--avc-ink-rgb)); border: 2px solid rgba(var(--avc-shade-rgb), 0.45); pointer-events: none; }
    .zone-handle--nw { left: 0; top: 0; }
    .zone-handle--ne { left: 100%; top: 0; }
    .zone-handle--sw { left: 0; top: 100%; }
    .zone-handle--se { left: 100%; top: 100%; }
    .layer-toggles { position: absolute; top: 8px; right: 8px; display: flex; gap: 6px; z-index: 3; }
    .layer-btn { display: flex; align-items: center; gap: 3px; padding: 3px 8px; border-radius: 999px; border: 1px solid rgba(var(--avc-ink-rgb), 0.2); background: rgba(var(--avc-shade-rgb), 0.45); color: rgba(var(--avc-ink-rgb), 0.55); font-size: 11px; font-weight: 600; cursor: pointer; --mdc-icon-size: 16px; user-select: none; -webkit-touch-callout: none; touch-action: manipulation; }
    .layer-btn.on { color: rgb(var(--avc-ink-rgb)); border-color: rgba(var(--avc-ink-rgb), 0.55); background: rgba(var(--avc-shade-rgb), 0.7); }
    .layer-menu { position: absolute; top: 38px; right: 0; min-width: 200px; max-width: 86vw; max-height: 60vh; overflow-y: auto; display: flex; flex-direction: column; gap: 2px; padding: 6px; border-radius: 12px; background: rgba(var(--avc-scrim-rgb), 0.96); border: 1px solid rgba(var(--avc-ink-rgb), 0.15); box-shadow: 0 8px 24px rgba(var(--avc-shade-rgb), 0.5); }
    .layer-menu-head { display: flex; align-items: center; gap: 6px; font-size: 11px; color: rgba(var(--avc-ink-rgb), 0.5); padding: 2px 6px 5px; --mdc-icon-size: 14px; }
    .layer-menu-row { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 8px; border: 1px solid transparent; background: transparent; color: rgba(var(--avc-ink-rgb), 0.88); cursor: pointer; font-size: 13px; --mdc-icon-size: 16px; }
    .layer-menu-row.on { background: rgba(var(--avc-ink-rgb), 0.12); border-color: rgba(var(--avc-ink-rgb), 0.4); }
    .lm-name { flex: 1; text-align: left; }
    .layer-menu-row b { font-weight: 700; }
    /* .rl-prog is the live coverage chip (_renderProgChip) and is still used —
       the rest of the old .room-list/.rl-* set went with _renderRoomList
       (dead since docs/19 A4, deleted 2026-08-08). */
    .rl-prog { font-size: 12px; font-weight: 700; display: flex; align-items: baseline; gap: 1px; }
    .rl-prog small { font-size: 8px; opacity: 0.55; }
    .map-wrap--fixed { padding-top: 0; }
    .image-base-img--fit { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; }

    /* ── Room buttons ────────────────────────────────────────────────── */
    .room-btn {
      position: absolute;
      width: 46px;
      height: 46px;
      border-radius: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transform: translate(-50%, -50%);
      transition: background 0.2s, box-shadow 0.2s;
      /* Same mobile hold-gesture fix as .vac-icon-btn/.badge (field-caught
       * 2026-07-24, docs/25 §7b): without this the browser's own long-press
       * handling (context menu / scroll-intent detection) can win the race
       * against our JS hold timer and fire pointercancel before it completes
       * — the room's own hold-to-inspect gesture then silently does nothing,
       * reported specifically on large (near full-map-width) rooms, where a
       * bigger touch target makes that native-gesture race more likely to
       * be won by the browser. */
      touch-action: manipulation;
      -webkit-touch-callout: none;
      user-select: none;
    }

    .room-btn ha-icon {
      --mdc-icon-size: 22px;
      pointer-events: none;
    }

    .room-overlay {
      position: absolute;
      transform: translate(-50%, -50%);
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      padding: 3px;
      transition: background 0.2s, border 0.3s, box-shadow 0.3s;
      /* Same mobile hold-gesture fix as .room-btn above. */
      touch-action: manipulation;
      -webkit-touch-callout: none;
      user-select: none;
    }
    .room-overlay > ha-icon { pointer-events: none; }
    /* Mutual exclusion: room selection disabled while Pin & Go / Zone is active
       (docs/19 A3) — dim + not-allowed cursor, no color-only distinction so it
       reads even on the age-gradient border colors. */
    .room-overlay--locked { opacity: 0.4; cursor: not-allowed; }
    /* docs/25 §7d: room age lives here now, not in the border/icon color —
       those are reserved for interaction state (normal/whole-home/selected)
       so a stable, always-recognizable icon doesn't get repainted by how
       long ago the room was cleaned. Two small dots (dry/wet, same order as
       everywhere else in the card) in the corner instead — a double ring
       around the whole room was tried and rejected (splits into one blurry
       edge at real room size, field-tested). */
    .room-age-dots { position: absolute; top: -3px; right: -3px; display: flex; gap: 1.5px; }
    .room-age-dot { width: 7px; height: 7px; border-radius: 50%; border: 1px solid rgba(var(--avc-shade-rgb), 0.5); }
    /* Who's assigned to a selected room (docs/19 A1) — small chips, not area
       tinting, so assignment doesn't fight with the selection highlight or the
       age-gradient colors. */
    /* Field feedback (2026-08-03): moved from bottom-left to bottom-right —
     * user's judgment call after seeing it live, no functional reason for
     * either corner. Also given a drop shadow (.room-overlay-assign
     * .dock-chip) since the chip's own background is a fairly transparent
     * color30-alpha (works fine in the dense dock list it's shared with,
     * but needed more contrast sitting directly on top of busy path
     * colors on the map). */
    /* Rotation-proof anchoring (1.0.7, see render fn comment for the full
     * derivation/history): .room-overlay-assign-anchor is a zero-size point
     * positioned (via the render fn's inline top/left) at the local room
     * corner that maps to visual bottom-right, for whichever of the four
     * right angles is currently active. .room-overlay-assign itself pins to
     * that point via its OWN bottom-right corner as transform-origin — the
     * pivot a rotation turns around never moves under that SAME rotation,
     * so this stays correct regardless of the chip's own self-rotation
     * swapping its width/height (the thing that broke the old edge-anchored
     * 2px insets specifically for 90°/270°). The actual rotate()+translate()
     * is set inline per-render (computed from totalRot), not here. */
    .room-overlay-assign-anchor {
      position: absolute;
      pointer-events: none;
      z-index: 4;
    }
    .room-overlay-assign {
      position: absolute;
      bottom: 0;
      right: 0;
      transform-origin: 100% 100%;
      display: flex;
      gap: 2px;
      pointer-events: none;
      z-index: 4;
    }
    .room-overlay-assign .dock-chip { box-shadow: 0 1px 4px rgba(var(--avc-shade-rgb), 0.7); }

    /* docs/25 §7b: hold-to-inspect popup — per-room detail moved out of the
       (now hidden-by-default) portrait dock room list. cursor:default plus
       its own click stopPropagation (in the render fn) so tapping the
       popup itself doesn't re-toggle the room underneath it. */
    /* .room-inspect is a bare positioning wrapper (anchor + centering
       transform only) — NO border/background/padding here. Field-caught
       bug (0.72.1 first pass): those were on this outer div while only
       -inner rotated in .avc-rot, so the visible box (border/background)
       stayed in its pre-rotation wide/short shape while the text inside
       visually rotated within it, badly mismatched. Fix: the whole visual
       box (border/background/padding included) lives on -inner instead, so
       it rotates as one rigid unit — box and text always agree, upright or
       rotated. Anchored dead-center on the room (see the render fn's doc
       comment, 0.72.3) rather than below/above it — the only anchor that
       stays correct at any room size under the map's rotation.
       left/top come from an inline style (the room's own map_x/map_y, same
       coordinates its <button> uses) — this div is now a SIBLING of that
       button, not a child (0.72.5 field fix, see the render fn's doc
       comment), so it needs its own absolute position rather than
       inheriting one relative to the button's box. */
    .room-inspect {
      position: absolute;
      transform: translate(-50%, -50%);
      z-index: 20;
      cursor: default;
      pointer-events: auto;
    }
    .room-inspect-inner {
      min-width: 84px;
      /* Field-caught (2026-07-24): 0.94 opacity let the selected room's
       * white gradient border/glow (box-shadow 0 0 18px, painted on the
       * same button this popup sits centered on top of) bleed faintly
       * through the background, reading as "the ring crosses the popup"
       * even though the popup is already the topmost paint layer
       * (z-index: 20). Bumped near-opaque + isolation:isolate so no
       * ancestor glow/blend can show through at all. */
      background: rgba(var(--avc-scrim-rgb), 0.99);
      border: 1px solid rgba(var(--avc-ink-rgb), 0.25);
      border-radius: 8px;
      padding: 6px 8px;
      font-size: 11px;
      white-space: nowrap;
      box-shadow: 0 4px 14px rgba(var(--avc-shade-rgb), 0.45);
      isolation: isolate;
    }
    .room-inspect-name { font-weight: 600; margin-bottom: 4px; color: rgb(var(--avc-ink-rgb)); }
    .room-inspect-ages { display: flex; gap: 8px; margin-bottom: 4px; }
    /* Unlike the small icon/gauges, a whole popup of TEXT read sideways is
       genuinely unreadable, not just a minor legibility ding — worth the
       counter-rotation the icon/gauges already get elsewhere in .avc-rot
       (rotated portrait map). Whole box (see -inner above), not just text,
       so border/background rotate together with the content they wrap.
       --map-rot (docs/32) — same one variable as the other counter-rotation
       rules, covers all four total angles, not just the old fixed 90 degrees. */
    .avc-rot .room-inspect-inner { transform: rotate(calc(-1 * var(--map-rot))); }

    /* ── Debug per-room progress gauges (dry + wet) ──────────────────── */
    .room-gauges {
      position: absolute;
      top: 2px;
      right: 2px;
      display: flex;
      gap: 2px;
      pointer-events: none;
      z-index: 4;
    }
    .room-gauge {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .room-gauge span {
      width: 19px;
      height: 19px;
      border-radius: 50%;
      background: rgba(var(--avc-shade-rgb), 0.82);
      color: rgb(var(--avc-ink-rgb));
      font-size: 9px;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* ── Status card (v1.1.0, 2026-08-03 — compact redesign, docs/33) ──── */
    .status-card {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding: 10px 12px;
      background: var(--avc-surface);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border-radius: 16px;
      overflow: hidden;
      transition: border 0.4s, box-shadow 0.4s;
    }

    .status-header { display: flex; align-items: center; gap: 10px; }

    /* Mirrors .vac-icon-btn's established circular-avatar look (docs/25 §7)
     * — same ring/fallback-icon language, reused here so the two places a
     * vacuum gets a small round portrait in this card stay visually
     * consistent. The info badge marks the "tap for HA's native more-info
     * dialog" escape hatch (user-requested "rescue control" — shrinking the
     * avatar shouldn't make this less discoverable, just smaller). */
    .status-avatar {
      position: relative;
      flex-shrink: 0;
      width: 44px; height: 44px;
      border-radius: 50%;
      border: 1.5px solid rgba(var(--avc-ink-rgb), 0.2);
      background: rgba(var(--avc-ink-rgb), 0.05);
      display: flex; align-items: center; justify-content: center;
      overflow: hidden;
      cursor: pointer;
    }
    .status-avatar img {
      width: 100%; height: 100%; object-fit: cover;
      transition: opacity 0.5s, filter 0.5s;
    }
    .avatar-info-badge {
      position: absolute; bottom: -2px; right: -2px;
      width: 14px; height: 14px; border-radius: 50%;
      background: rgba(var(--avc-scrim-2-rgb), 0.95); border: 1px solid rgba(var(--avc-shade-rgb), 0.6);
      display: flex; align-items: center; justify-content: center;
    }
    .avatar-info-badge ha-icon { --mdc-icon-size: 9px; color: rgba(var(--avc-ink-rgb), 0.6); }

    .status-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }

    .error-row {
      display: flex; align-items: center; gap: 6px;
      padding-bottom: 2px; animation: pulse-error 2s ease-in-out infinite;
    }
    @keyframes pulse-error { 0%,100% { opacity:1; } 50% { opacity:0.6; } }

    .status-line1 { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
    .model-label { font-size: 13px; font-weight: 500; color: rgba(var(--avc-ink-rgb), 0.85); }
    .status-label { font-size: 12px; font-weight: 600; text-align: right; }

    .status-line2 { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .current-room { display: flex; align-items: center; gap: 3px; font-size: 11px; color: rgba(var(--avc-ink-rgb), 0.45); }

    .status-meta { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .battery { display: flex; align-items: center; gap: 3px; font-size: 11px; font-weight: 600; }
    .battery ha-icon { --mdc-icon-size: 13px; }
    .last-clean { display: flex; align-items: center; gap: 3px; font-size: 11px; color: rgba(var(--avc-ink-rgb), 0.45); }
    .last-clean ha-icon { --mdc-icon-size: 11px; color: rgba(var(--avc-ink-rgb), 0.25); }

    /* ── Progress bar ────────────────────────────────────────────────── */
    .progress { display: flex; align-items: center; gap: 8px; }
    .progress-track {
      flex: 1; height: 3px;
      background: rgba(var(--avc-ink-rgb), 0.08); border-radius: 2px; overflow: hidden;
    }
    .progress-fill { height: 100%; border-radius: 2px; transition: width 0.5s ease; }
    .progress-label { font-size: 11px; font-weight: 600; flex-shrink: 0; }

    /* ── Debug per-room progress strip ───────────────────────────────── */
    .dbg-prog { display: flex; flex-wrap: wrap; gap: 6px 12px; padding-top: 2px; }
    .dbg-prog-item { display: flex; align-items: center; gap: 3px; font-size: 11px; color: rgba(var(--avc-ink-rgb), 0.55); --mdc-icon-size: 14px; }
    .dbg-prog-name { color: rgba(var(--avc-ink-rgb), 0.45); }
    .dbg-prog-item b { font-weight: 700; }
    .dbg-prog-item small { color: rgba(var(--avc-ink-rgb), 0.4); font-size: 10px; }
    .mini-gauge-wrap { display: inline-flex; align-items: center; gap: 2px; }
    .mini-gauge-ico { --mdc-icon-size: 12px; opacity: 0.8; }
    .mini-gauge { width: 22px; height: 22px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; }
    .mini-gauge span { width: 16px; height: 16px; border-radius: 50%; background: rgba(var(--avc-shade-rgb), 0.82); color: rgb(var(--avc-ink-rgb)); font-size: 8px; font-weight: 700; display: flex; align-items: center; justify-content: center; }

    /* ── Action buttons ──────────────────────────────────────────────── */
    .actions { display: flex; gap: 8px; }
    /* v1.1.0: preset chips sit INLINE beside START (was its own stacked row
     * above it) — overflow-x:auto lets a long preset list scroll instead
     * of wrapping to a second row, which is exactly the extra height this
     * redesign removes. flex-shrink:0 keeps it from being squeezed by
     * START's flex:1 on narrow cards; a hard max-width caps how much of
     * the row it can claim even when there's room, so START never shrinks
     * to an unreadable sliver with many presets. */
    .preset-chip-row {
      display: flex; gap: 6px; flex-shrink: 0; max-width: 45%;
      overflow-x: auto; scrollbar-width: none;
    }
    .preset-chip-row::-webkit-scrollbar { display: none; }

    .action-btn {
      position: relative;
      overflow: hidden;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 8px 12px;
      border-radius: 12px;
      cursor: pointer;
      transition: opacity 0.2s;
      font-family: inherit;
    }

    .action-btn:disabled { cursor: default; opacity: 0.7; }

    .action-btn ha-icon { --mdc-icon-size: 18px; flex-shrink: 0; position: relative; z-index: 1; }
    .action-btn span { font-size: 13px; font-weight: 700; color: rgb(var(--avc-ink-rgb)); position: relative; z-index: 1; }

    .action-btn--secondary {
      background: rgba(var(--avc-info-rgb), 0.08);
      border: 1px solid rgba(var(--avc-info-rgb), 0.2) !important;
    }

    .action-btn--warn {
      background: rgba(var(--avc-warn-rgb), 0.18);
      border: 1px solid rgba(var(--avc-warn-rgb), 0.5) !important;
    }

    /* ── Start button body ───────────────────────────────────────────── */
    .start-body {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 2px;
      position: relative;
      z-index: 1;
    }

    .start-body small { font-size: 10px; }

    .map-clickcatch { position: absolute; inset: 0; cursor: crosshair; z-index: 5; }
    .map-tools { display: flex; gap: 6px; margin: 6px 0 0; }
    .mtbtn { display: inline-flex; align-items: center; gap: 4px; padding: 5px 10px; border-radius: 8px; border: 1px solid rgba(var(--avc-ink-rgb), 0.18); background: rgba(var(--avc-ink-rgb), 0.06); color: inherit; cursor: pointer; font-size: 12px; font-weight: 600; }
    .mtbtn.on { background: rgba(var(--avc-tool-rgb), 0.25); border-color: rgb(var(--avc-tool-rgb)); }
    .mtbtn:disabled { opacity: 0.4; cursor: default; }
    .mtbtn ha-icon { --mdc-icon-size: 16px; }
    .mtbtn--stat { cursor: default; background: transparent; border-color: transparent; gap: 3px; padding: 5px 6px; }
    .mtbtn--stat b { font-weight: 700; }
    .mtbtn--stat small { opacity: 0.7; font-weight: 500; }
    /* Sequence hint (docs/19 follow-up, TODO #2) — amber to read as "heads up",
       distinct from the neutral stat pills either side of it. */
    .mtbtn--warn { color: rgb(var(--avc-hint-rgb)); }
    .mtbtn--warn ha-icon { color: rgb(var(--avc-hint-rgb)); }
    .mtbtn--err { color: rgb(var(--avc-err-rgb)); }
    .mtbtn--err ha-icon { color: rgb(var(--avc-err-rgb)); }
    /* docs/28 §2: own panel (was transparent, flush with the map above and the
     * dock below) — background + radius visually lifts it off both neighbors
     * instead of reading as a loose row of same-weight buttons. */
    /* docs/28 §2 follow-up (field-verified 2026-07-25, live A/B via Claude in
     * Chrome on the user's own dashboard against a "modest"/"strong"/
     * "hairline-only" candidate — see docs/28 for the comparison): the
     * original 0.03/0.08 values (shared with .vac-picker/.dock elsewhere)
     * were too subtle against a near-black card background to read as a
     * distinct panel at all — the specific goal this section was built for.
     * Bumped just for .meta-bar/.meta-bar-divider, not the other panels,
     * which weren't reported as a problem. */
    .meta-bar { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; padding: 6px 8px; background: var(--avc-panel-strong); border: 1px solid var(--avc-panel-strong-line); border-radius: 12px; }
    .meta-bar-cluster { display: flex; align-items: center; gap: 4px; }
    .meta-bar-spacer { flex: 1 1 auto; }
    .meta-bar-divider { width: 0.5px; align-self: stretch; background: rgba(var(--avc-ink-rgb), 0.22); margin: 0 4px; }
    /* Refresh: a quiet icon, not a bordered button on par with Pin & Go/Zone —
     * it shouldn't compete with the actual map-interaction tools for attention. */
    .mtbtn--ghost { border: none; background: transparent; color: rgba(var(--avc-ink-rgb), 0.45); padding: 5px; }
    .mtbtn--ghost:hover { color: rgba(var(--avc-ink-rgb), 0.75); }
    .mtbtn--spin ha-icon { animation: avc-refresh-spin 0.6s ease; }
    @keyframes avc-refresh-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .mode-action { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; }
    .mode-action .mtbtn { width: 100%; justify-content: center; box-sizing: border-box; animation: avc-mode-action-pulse 1.6s ease-in-out infinite; }
    @keyframes avc-mode-action-pulse { 0%,100% { box-shadow: 0 0 0 rgba(var(--avc-tool-rgb), 0); } 50% { box-shadow: 0 0 12px rgba(var(--avc-tool-rgb), 0.55); } }
    .calib-panel { margin-top: 4px; font-size: 12px; opacity: 0.9; padding: 6px 8px; background: rgba(var(--avc-tool-rgb), 0.12); border-radius: 8px; }
    .calib-panel > div { margin-bottom: 4px; }
    .calib-actions { display: flex; gap: 6px; flex-wrap: wrap; }

    /* ══ On-map channel reset ══════════════════════════════════════════════
     * Everything inside .map-wrap is painted on the vacuum's own map bitmap,
     * not on the card's surface, so it must keep white-on-black regardless of
     * the card's theme — a light theme reaching in here would erase every
     * on-map label. Derived tokens (--avc-ink, the panel/surface set) re-
     * resolve per element against these, so resetting the three channel bases
     * is enough; nothing has to be listed individually. */
    .map-wrap {
      --avc-ink-rgb: 255, 255, 255;
      --avc-shade-rgb: 0, 0, 0;
      --avc-scrim-rgb: 18, 18, 18;
    }

    /* ══ Theme: dark (the v1.2.0 default) ══════════════════════════════════
     * Off pure black and off pure white: a near-black surface swallows any
     * low-alpha accent laid over it, which is exactly why docs/25 §6's sage
     * START read as "no change" in the field. Surfaces are lifted, the ink is
     * very slightly cool, and the semantic palette steps down from the Ant
     * Design defaults it inherited — same hues, same meanings, less shout. */
    .avc-theme--dark,
    .avc-theme--auto {
      --avc-ink-rgb: 234, 238, 245;
      --avc-shade-rgb: 5, 7, 12;
      --avc-scrim-rgb: 24, 26, 33;
      --avc-scrim-2-rgb: 38, 41, 51;

      --avc-ok-rgb: 108, 197, 118;
      --avc-warn-rgb: 226, 170, 82;
      --avc-err-rgb: 230, 110, 116;
      --avc-hint-rgb: 208, 168, 96;
      --avc-tool-rgb: 116, 158, 232;
      --avc-info-rgb: 112, 176, 224;

      --avc-surface: rgba(30, 33, 42, 0.78);
      --avc-panel: rgba(var(--avc-ink-rgb), 0.05);
      --avc-panel-line: transparent;
      --avc-panel-strong: rgba(var(--avc-ink-rgb), 0.075);
      --avc-panel-strong-line: transparent;
      --avc-sunken: rgba(var(--avc-shade-rgb), 0.45);
      --avc-disabled: rgba(var(--avc-ink-rgb), 0.07);

      --avc-elev-1: 0 1px 2px rgba(0, 0, 0, 0.45), 0 8px 22px rgba(0, 0, 0, 0.3);
      --avc-elev-2: 0 2px 6px rgba(0, 0, 0, 0.5), 0 18px 44px rgba(0, 0, 0, 0.38);

      --avc-press: 0.972;
      --avc-press-ms: 0.12s;
      --avc-live: avc-live-breathe 3.4s ease-in-out infinite;
    }

    /* ══ Theme: light ══════════════════════════════════════════════════════
     * Before 1.2.0 the card painted white text and white-alpha panels
     * unconditionally, so on a light HA theme it was not merely ugly but
     * unreadable. The palette darkens rather than just inverting: the same
     * hue at the same lightness that reads as "calm" on near-black reads as
     * "washed out" on porcelain. */
    .avc-theme--light {
      --avc-ink-rgb: 26, 29, 37;
      --avc-shade-rgb: 30, 36, 48;
      --avc-scrim-rgb: 252, 252, 253;
      --avc-scrim-2-rgb: 244, 245, 248;

      --avc-ok-rgb: 52, 131, 70;
      --avc-warn-rgb: 154, 106, 21;
      --avc-err-rgb: 197, 58, 66;
      --avc-hint-rgb: 147, 110, 28;
      --avc-tool-rgb: 42, 104, 210;
      --avc-info-rgb: 34, 121, 184;

      --avc-surface: rgba(255, 255, 255, 0.93);
      --avc-panel: rgba(255, 255, 255, 0.68);
      --avc-panel-line: rgba(var(--avc-ink-rgb), 0.07);
      --avc-panel-strong: rgba(255, 255, 255, 0.94);
      --avc-panel-strong-line: rgba(var(--avc-ink-rgb), 0.09);
      --avc-sunken: rgba(var(--avc-ink-rgb), 0.045);
      --avc-disabled: rgba(var(--avc-ink-rgb), 0.06);

      --avc-elev-1: 0 1px 2px rgba(24, 30, 45, 0.06), 0 8px 20px rgba(24, 30, 45, 0.08);
      --avc-elev-2: 0 2px 6px rgba(24, 30, 45, 0.08), 0 18px 40px rgba(24, 30, 45, 0.12);

      --avc-press: 0.972;
      --avc-press-ms: 0.12s;
      --avc-live: avc-live-breathe 3.4s ease-in-out infinite;
    }

    /* auto = dark, flipped by the OS/browser preference. The light values
     * are restated rather than shared because CSS custom properties have no
     * conditional aliasing — a media query can only re-declare them. Kept
     * adjacent to the block above so the two never drift apart unnoticed. */
    @media (prefers-color-scheme: light) {
      .avc-theme--auto {
        --avc-ink-rgb: 26, 29, 37;
        --avc-shade-rgb: 30, 36, 48;
        --avc-scrim-rgb: 252, 252, 253;
        --avc-scrim-2-rgb: 244, 245, 248;

        --avc-ok-rgb: 52, 131, 70;
        --avc-warn-rgb: 154, 106, 21;
        --avc-err-rgb: 197, 58, 66;
        --avc-hint-rgb: 147, 110, 28;
        --avc-tool-rgb: 42, 104, 210;
        --avc-info-rgb: 34, 121, 184;

        --avc-surface: rgba(255, 255, 255, 0.93);
        --avc-panel: rgba(255, 255, 255, 0.68);
        --avc-panel-line: rgba(var(--avc-ink-rgb), 0.07);
        --avc-panel-strong: rgba(255, 255, 255, 0.94);
        --avc-panel-strong-line: rgba(var(--avc-ink-rgb), 0.09);
        --avc-sunken: rgba(var(--avc-ink-rgb), 0.045);
        --avc-disabled: rgba(var(--avc-ink-rgb), 0.06);

        --avc-elev-1: 0 1px 2px rgba(24, 30, 45, 0.06), 0 8px 20px rgba(24, 30, 45, 0.08);
        --avc-elev-2: 0 2px 6px rgba(24, 30, 45, 0.08), 0 18px 40px rgba(24, 30, 45, 0.12);
      }
    }

    /* ══ Structural pass — every theme except legacy ═════════════════════
     * The token flip above only changes colour. This is the part that changes
     * the card's genre: panels carry elevation instead of a hairline outline,
     * and corners step up one notch. legacy simply never gets the
     * .avc-theme class, so none of this applies to it. */
    .avc-theme .status-card { border-radius: 20px; box-shadow: var(--avc-elev-1); }
    .avc-theme .dock,
    .avc-theme .vac-picker { border-radius: 18px; box-shadow: var(--avc-elev-1); }
    .avc-theme .meta-bar { border-radius: 16px; box-shadow: var(--avc-elev-1); }
    .avc-theme .map-wrap { border-radius: 18px; box-shadow: var(--avc-elev-1); }
    .avc-theme .dock-sheet { border-radius: 14px; }
    .avc-theme .dock-row,
    .avc-theme .dock-mode,
    .avc-theme .dock-sheet-action { border-radius: 12px; }
    .avc-theme .action-btn { border-radius: 14px; }
    .avc-theme .mtbtn { border-radius: 10px; }
    .avc-theme .start-bar { border-radius: 22px; }
    .avc-theme .start-seg { border-radius: 18px; }
    .avc-theme .room-inspect-inner { border-radius: 12px; box-shadow: var(--avc-elev-2); }
    .avc-theme .layer-menu { border-radius: 16px; box-shadow: var(--avc-elev-2); }
    /* Rounder rooms read softer without touching the field-tuned selection
     * ring itself (0.52/0.53 spent real effort landing that gradient). */
    .avc-theme .room-overlay { border-radius: 10px; }
    .avc-theme .room-btn { border-radius: 14px; }
    /* The age dots were the most instrument-like detail on the map: two 7px
     * discs with a hard 1px black stroke. Same information, softer edge. */
    .avc-theme .room-age-dot {
      width: 8px; height: 8px; border: none;
      box-shadow: 0 0 0 1.5px rgba(0, 0, 0, 0.5), 0 1px 3px rgba(0, 0, 0, 0.45);
    }

    /* START is the one thing the whole screen exists for. docs/25 §6 gave it
     * its own sage green but at 24% over near-black, where the hue simply
     * disappeared (the user's verdict at the time: "looks unchanged"). On the
     * lifted surface it can finally carry a gradient, a stronger edge and a
     * soft cast without shouting. */
    .avc-theme .start-bar:not(:disabled) {
      background: linear-gradient(180deg, rgba(var(--avc-accent-rgb), 0.34), rgba(var(--avc-accent-rgb), 0.2));
      border-color: rgba(var(--avc-accent-rgb), 0.55);
      box-shadow: 0 6px 18px rgba(var(--avc-accent-rgb), 0.14);
      letter-spacing: 0.2px;
    }
    .avc-theme .start-bar--cancel:not(:disabled) {
      background: linear-gradient(180deg, rgba(var(--avc-warn-rgb), 0.28), rgba(var(--avc-warn-rgb), 0.16));
      border-color: rgba(var(--avc-warn-rgb), 0.55);
      box-shadow: 0 6px 18px rgba(var(--avc-warn-rgb), 0.14);
      animation: var(--avc-live);
    }
    /* Landscape's primary action lives in the dock footer, not in the START
     * bar (that one is portrait's). Same promotion, same reason. */
    .avc-theme .dock-run:not(:disabled) {
      background: linear-gradient(180deg, rgba(var(--avc-accent-rgb), 0.34), rgba(var(--avc-accent-rgb), 0.2));
      border-color: rgba(var(--avc-accent-rgb), 0.55);
      box-shadow: 0 4px 14px rgba(var(--avc-accent-rgb), 0.16);
    }
    .avc-theme.avc-calm .dock-run:not(:disabled) {
      box-shadow: 0 0 0 1px rgba(var(--avc-accent-rgb), 0.4),
                  0 8px 20px rgba(var(--avc-accent-rgb), 0.16);
    }

    .avc-theme .dock-row.on {
      background: rgba(var(--avc-accent-rgb), 0.14);
      border-color: rgba(var(--avc-accent-rgb), 0.5);
    }

    /* Type floor (docs/35 §4). 8–10px is instrument sizing; nothing sits
     * below 10px any more, and everything whose value ticks gets tabular
     * figures so a live ETA or battery reading stops shoving its neighbours
     * sideways on every poll. */
    .avc-theme .dock-age,
    .avc-theme .dock-chip,
    .avc-theme .start-seg,
    .avc-theme .dock-sheet-debug,
    .avc-theme .dock-sheet-care-badge,
    .avc-theme .start-body small,
    .avc-theme .dbg-prog-item small,
    .avc-theme .version-chip { font-size: 11px; }
    .avc-theme .dock-cov { font-size: 10px; }
    .avc-theme .rl-prog small { font-size: 9px; }
    .avc-theme .room-gauge span { font-size: 10px; }
    .avc-theme .mini-gauge span { font-size: 9px; }
    /* Portrait keeps its own tighter scale, just lifted off the floor too —
     * these need one more class than the .avc-grid--portrait rules above to
     * win, hence the doubled prefix rather than a plain override. */
    .avc-theme .avc-grid--portrait .dock-age { font-size: 10px; }
    .avc-theme .avc-grid--portrait .dock-cov { font-size: 9px; }
    .avc-theme .avc-grid--portrait .badge-name { font-size: 12px; }
    .avc-theme .dock-age,
    .avc-theme .dock-est,
    .avc-theme .dock-cov,
    .avc-theme .battery,
    .avc-theme .status-label,
    .avc-theme .progress-label,
    .avc-theme .last-clean,
    .avc-theme .rl-prog,
    .avc-theme .mtbtn--stat { font-variant-numeric: tabular-nums; }

    /* ══ Micro-interactions (docs/35 §5) ═══════════════════════════════════
     * Transform/opacity only, declarative only — no JS, nothing per frame.
     * The mobile companion app has real crash history around anything that
     * takes imperative ownership of layout (docs/21 §5b), so this stays
     * entirely in CSS.
     *
     * Deliberately NOT applied to .room-btn / .room-overlay: those carry a
     * positioning transform of their own (translate(-50%, -50%)), and a
     * scale() here would replace it and throw the room off its anchor. */
    .avc-theme .action-btn,
    .avc-theme .start-bar,
    .avc-theme .start-seg,
    .avc-theme .dock-mode,
    .avc-theme .dock-row,
    .avc-theme .dock-sheet-action,
    .avc-theme .dock-sheet-tab,
    .avc-theme .dock-sheet-care-reset,
    .avc-theme .mtbtn,
    .avc-theme .badge,
    .avc-theme .vac-icon-btn,
    .avc-theme .layer-btn {
      transition: transform var(--avc-press-ms) var(--avc-ease),
                  opacity 0.15s ease,
                  background 0.25s var(--avc-ease),
                  border-color 0.25s var(--avc-ease),
                  box-shadow 0.25s var(--avc-ease);
    }
    .avc-theme .action-btn:active:not(:disabled),
    .avc-theme .start-bar:active:not(:disabled),
    .avc-theme .start-seg:active,
    .avc-theme .dock-mode:active,
    .avc-theme .dock-row:active:not(:disabled),
    .avc-theme .dock-sheet-action:active,
    .avc-theme .dock-sheet-tab:active,
    .avc-theme .dock-sheet-care-reset:active:not(.pending),
    .avc-theme .mtbtn:active:not(:disabled),
    .avc-theme .badge:active,
    .avc-theme .vac-icon-btn:active,
    .avc-theme .layer-btn:active { transform: scale(var(--avc-press)); }

    /* Keyboard focus. The card had no focus styling at all before 1.2.0 — not
     * suppressed, just never considered, so keyboard users got the browser's
     * default ring over a design that had moved on. :focus-visible is the
     * right primitive: it matches keyboard focus and stays out of the way on
     * tap and click, where the press feedback above already answers.
     *
     * outline (not box-shadow) on purpose. Several of these elements carry a
     * box-shadow of their own, some of it set inline — the selected room's
     * glow, START's cast, the panels' elevation — and an inline value wins,
     * so a box-shadow ring would be silently missing exactly on the elements
     * that matter most. outline also never disturbs layout, which is why it
     * is safe here on .room-btn/.room-overlay, unlike the scale() press
     * feedback (those carry their own positioning transform).
     *
     * Scoped to .avc-theme like every other 1.2.0 rule, so legacy keeps the
     * browser default — unstyled, but accessible on its own. */
    .avc-theme .action-btn:focus-visible,
    .avc-theme .start-bar:focus-visible,
    .avc-theme .start-seg:focus-visible,
    .avc-theme .dock-mode:focus-visible,
    .avc-theme .dock-row:focus-visible,
    .avc-theme .dock-chip:focus-visible,
    .avc-theme .dock-sheet-action:focus-visible,
    .avc-theme .dock-sheet-tab:focus-visible,
    .avc-theme .dock-sheet-care-reset:focus-visible,
    .avc-theme .mtbtn:focus-visible,
    .avc-theme .badge:focus-visible,
    .avc-theme .vac-icon-btn:focus-visible,
    .avc-theme .layer-btn:focus-visible,
    .avc-theme .layer-menu-row:focus-visible,
    .avc-theme .room-btn:focus-visible,
    .avc-theme .room-overlay:focus-visible {
      outline: 2px solid rgb(var(--avc-accent-rgb));
      outline-offset: 2px;
    }
    /* On the map the accent can land on anything the floorplan happens to be,
     * so the ring switches to the on-map ink channel — which the .map-wrap
     * reset already guarantees is white, in every theme — and steps further
     * off the element so it reads against a busy path underneath. */
    .avc-theme .map-wrap .room-btn:focus-visible,
    .avc-theme .map-wrap .room-overlay:focus-visible,
    .avc-theme .map-wrap .layer-btn:focus-visible,
    .avc-theme .map-wrap .layer-menu-row:focus-visible {
      outline: 3px solid rgb(var(--avc-ink-rgb));
      outline-offset: 3px;
    }

    @keyframes avc-live-breathe {
      0%, 100% { box-shadow: 0 6px 18px rgba(var(--avc-warn-rgb), 0.12); }
      50%      { box-shadow: 0 6px 26px rgba(var(--avc-warn-rgb), 0.3); }
    }

    /* A slow highlight travelling along the progress bar — the difference
     * between "a bar that happens to be partly filled" and "something is
     * happening right now". White on purpose: it is a specular highlight on
     * a coloured bar, not ink, so it does not follow the theme. */
    .avc-theme .progress-track { height: 4px; border-radius: 3px; }
    .avc-theme .progress-fill { position: relative; overflow: hidden; }
    .avc-theme .progress-fill::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.45), transparent);
      transform: translateX(-100%);
      animation: avc-sheen 2.6s ease-in-out infinite;
    }
    @keyframes avc-sheen {
      0%        { transform: translateX(-100%); }
      60%, 100% { transform: translateX(100%); }
    }

    /* ══ Calm resting state (docs/35 §7) ═══════════════════════════════════
     * Applied when nothing is running, nothing is selected and no map tool is
     * armed — which is most of the time. Purely de-emphasis: every control
     * stays present, tappable and in place, the leftover trace and the
     * secondary metadata just stop competing with the one thing worth
     * touching. calm_state: false opts out. */
    .avc-calm .map-vector { opacity: 0.5; }
    .avc-calm .room-age-dots { opacity: 0.55; }
    .avc-calm .dock-cov { opacity: 0.35; }
    .avc-calm .dbg-prog { opacity: 0.55; }
    .avc-theme.avc-calm .meta-bar { background: var(--avc-panel); box-shadow: none; }
    .avc-theme.avc-calm .start-bar:not(:disabled) {
      box-shadow: 0 0 0 1px rgba(var(--avc-accent-rgb), 0.4),
                  0 10px 26px rgba(var(--avc-accent-rgb), 0.16);
    }
    .avc-theme .map-vector,
    .avc-theme .room-age-dots { transition: opacity 0.6s var(--avc-ease); }


    /* ══ Light-theme legibility (docs/35 §9b) ══════════════════════════════
     * The dim ink tiers were tuned as white-on-near-black, where 45% still
     * reads. Flipped to black-on-porcelain the same 45% lands at 2.8:1 —
     * below WCAG AA for the 11px text it is used on. Rather than change ~40
     * shared use sites (and with them the dark theme they were tuned for),
     * the light themes lift the tiers on the elements that actually carry
     * text. Measured, not eyeballed: 0.61 alpha is where black-on-panel
     * crosses 4.5:1, 0.68 leaves headroom for the lighter dashboards a user
     * might sit the card on.
     *
     * The threshold colours are a separate problem: they come from
     * room_thresholds, a documented user-editable default, and from inline
     * styles, so they cannot be re-mapped here without overriding what the
     * user configured. They are also correct where they are primarily used —
     * on the map, which stays dark in every theme. Darkening them at the
     * point of use keeps the configured hue and the map untouched, and only
     * fixes the one place they are unreadable. brightness(0.45) is the value
     * at which all four defaults clear 4.5:1 (amber is the binding one). */
    .avc-theme--light .dock-est,
    .avc-theme--light .last-clean,
    .avc-theme--light .current-room,
    .avc-theme--light .map-tools-label,
    .avc-theme--light .mtbtn--ghost,
    .avc-theme--light .dock-mode,
    .avc-theme--light .dock-sheet-debug,
    .avc-theme--light .dock-sheet-care-value,
    .avc-theme--light .dbg-prog-item,
    .avc-theme--light .dbg-prog-name,
    .avc-theme--light .layer-menu-head { color: rgba(var(--avc-ink-rgb), 0.68); }
    .avc-theme--light .last-clean ha-icon,
    .avc-theme--light .dock-age ha-icon,
    .avc-theme--light .dbg-prog-item small { color: rgba(var(--avc-ink-rgb), 0.55); }
    .avc-theme--light .dock-cov { opacity: 0.72; }
    .avc-theme--light.avc-calm .dock-cov { opacity: 0.6; }
    .avc-theme--light .dock-age b,
    .avc-theme--light .dock-cov,
    .avc-theme--light .dbg-prog-item b { filter: brightness(0.45) saturate(1.4); }

    @media (prefers-color-scheme: light) {
      .avc-theme--auto .dock-est,
      .avc-theme--auto .last-clean,
      .avc-theme--auto .current-room,
      .avc-theme--auto .map-tools-label,
      .avc-theme--auto .mtbtn--ghost,
      .avc-theme--auto .dock-mode,
      .avc-theme--auto .dock-sheet-debug,
      .avc-theme--auto .dock-sheet-care-value,
      .avc-theme--auto .dbg-prog-item,
      .avc-theme--auto .dbg-prog-name,
      .avc-theme--auto .layer-menu-head { color: rgba(var(--avc-ink-rgb), 0.68); }
      .avc-theme--auto .last-clean ha-icon,
      .avc-theme--auto .dock-age ha-icon,
      .avc-theme--auto .dbg-prog-item small { color: rgba(var(--avc-ink-rgb), 0.55); }
      .avc-theme--auto .dock-cov { opacity: 0.72; }
      .avc-theme--auto.avc-calm .dock-cov { opacity: 0.6; }
      .avc-theme--auto .dock-age b,
      .avc-theme--auto .dock-cov,
      .avc-theme--auto .dbg-prog-item b { filter: brightness(0.45) saturate(1.4); }
    }

    /* Motion opt-outs. The OS preference wins unconditionally; .avc-still
     * is the config-level equivalent (reduce_motion: true) for people who
     * want them off without changing an OS setting. */
    .avc-still,
    .avc-still .start-bar--cancel { --avc-press: 1; --avc-press-ms: 0s; --avc-live: none; }
    .avc-still .progress-fill::after { display: none; }
    @media (prefers-reduced-motion: reduce) {
      .avc-theme,
      .avc-theme .start-bar--cancel { --avc-press: 1; --avc-press-ms: 0s; --avc-live: none; }
      .avc-theme .progress-fill::after { display: none; }
      .avc-theme .avc-err-halo { animation: none; opacity: 0.45; }
      .avc-theme .error-row { animation: none; }
      .avc-theme .mode-action .mtbtn { animation: none; }
    }

    /* == Align mode overlay (docs/41, Faze C - C2a batch) ==================
     * Rendered inside the document.body portal (align-overlay.ts), NOT
     * inside this card's own shadow root -- the SAME adopted stylesheet
     * reaches both (docs/14 rule 1: one stylesheet), so these rules just
     * need to exist once, here. .align-overlay carries the SAME theme
     * class this card's own <ha-card> does (_rootClasses()), so every
     * --avc-* token above resolves identically inside the portal. */
    .align-overlay {
      position: fixed; inset: 0; display: flex; flex-direction: column;
      background: rgba(var(--avc-shade-rgb), 0.92);
      color: rgb(var(--avc-ink-rgb));
      font-family: inherit;
      touch-action: none;
    }
    .align-toolbar {
      display: flex; align-items: center; gap: 8px;
      padding: max(10px, env(safe-area-inset-top)) 12px 10px 12px;
      background: var(--avc-surface);
      box-shadow: var(--avc-elev-1);
      flex-wrap: wrap;
    }
    .align-toolbar-title {
      display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 13px;
    }
    .align-toolbar-spacer { flex: 1 1 auto; }
    .align-vac-picker { display: flex; gap: 6px; flex-wrap: wrap; }
    .align-vac-chip {
      font: inherit; font-size: 11px; font-weight: 600; cursor: pointer;
      padding: 5px 10px; border-radius: 999px; color: rgb(var(--avc-ink-rgb));
      background: var(--avc-panel); border: 1px solid var(--avc-panel-line);
    }
    .align-vac-chip.on { background: rgba(var(--avc-tool-rgb), 0.22); border-color: rgba(var(--avc-tool-rgb), 0.6); }
    .align-btn {
      display: inline-flex; align-items: center; justify-content: center;
      width: 34px; height: 34px; border-radius: 10px; cursor: pointer;
      color: rgb(var(--avc-ink-rgb)); background: var(--avc-panel);
      border: 1px solid var(--avc-panel-line);
    }
    .align-close-btn:hover { background: rgba(var(--avc-err-rgb), 0.18); border-color: rgba(var(--avc-err-rgb), 0.5); }
    .align-canvas {
      position: relative; flex: 1 1 auto; overflow: hidden;
      display: flex; align-items: center; justify-content: center;
      touch-action: none; user-select: none; -webkit-user-select: none;
      padding-bottom: env(safe-area-inset-bottom);
    }
    .align-scene {
      position: relative; flex: 0 0 auto; transform-origin: center center;
    }
    .align-floorplan-img {
      position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain;
      transform-origin: center center; pointer-events: none; -webkit-touch-callout: none;
    }
    .align-ghost { position: absolute; inset: 0; opacity: 0.28; pointer-events: none; }
    .align-seat-layer { position: absolute; inset: 0; pointer-events: none; }
    .align-seat-img {
      position: absolute; height: auto; pointer-events: auto; touch-action: none;
      -webkit-touch-callout: none; -webkit-user-select: none; user-select: none;
      cursor: grab;
    }
    .align-gizmo { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; overflow: visible; }
    .align-gizmo-box { fill: none; stroke: rgb(var(--avc-tool-rgb)); stroke-width: 0.4; vector-effect: non-scaling-stroke; }
    .align-gizmo-arm { stroke: rgb(var(--avc-tool-rgb)); stroke-width: 0.3; stroke-dasharray: 1.2 1; vector-effect: non-scaling-stroke; }
    .align-handle {
      position: absolute; width: 26px; height: 26px; margin: -13px 0 0 -13px;
      border-radius: 50%; background: rgb(var(--avc-tool-rgb)); border: 2px solid rgb(var(--avc-ink-rgb));
      box-shadow: var(--avc-elev-1); touch-action: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center; color: rgb(var(--avc-ink-rgb));
      --mdc-icon-size: 16px;
    }
    .align-handle--rotate { background: rgba(var(--avc-tool-rgb), 0.85); }
    .align-handle--side {
      width: 20px; height: 20px; margin: -10px 0 0 -10px; opacity: 0.85;
      --mdc-icon-size: 13px;
    }
    .align-handle--side ha-icon { pointer-events: none; }
    .align-axis-hint {
      position: absolute; margin: -8px 0 0 -8px; width: 16px; height: 16px;
      display: flex; align-items: center; justify-content: center;
      color: rgba(var(--avc-ink-rgb), 0.55); pointer-events: none;
      --mdc-icon-size: 13px;
    }
    .align-btn[disabled] { opacity: 0.35; cursor: default; pointer-events: none; }
    .align-btn--flash { background: rgba(var(--avc-ok-rgb), 0.22); border-color: rgba(var(--avc-ok-rgb), 0.6); }
    .align-save-btn {
      width: auto; padding: 0 12px; gap: 6px; font-weight: 700; font-size: 12px;
      background: rgba(var(--avc-tool-rgb), 0.22); border-color: rgba(var(--avc-tool-rgb), 0.6);
    }
    .align-tier-group {
      display: flex; border-radius: 10px; overflow: hidden;
      border: 1px solid var(--avc-panel-line);
    }
    .align-tier-btn {
      font: inherit; font-size: 11px; font-weight: 600; cursor: pointer;
      padding: 0 10px; height: 34px; color: rgba(var(--avc-ink-rgb), 0.6);
      background: var(--avc-panel); border: none; border-right: 1px solid var(--avc-panel-line);
    }
    .align-tier-btn:last-child { border-right: none; }
    .align-tier-btn.on {
      color: rgb(var(--avc-ink-rgb)); font-weight: 700;
      background: rgba(var(--avc-tool-rgb), 0.22);
    }
    /* == Align mode: body row (canvas + numeric side panel, C2b) ========= */
    .align-body { display: flex; flex: 1 1 auto; min-height: 0; }
    .align-side-panel {
      flex: 0 0 208px; display: flex; flex-direction: column; gap: 10px;
      padding: 14px 12px; overflow-y: auto;
      background: var(--avc-surface); box-shadow: var(--avc-elev-1);
    }
    .align-field-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .align-field-row label {
      font-size: 12px; font-weight: 600; color: rgba(var(--avc-ink-rgb), 0.75);
      display: flex; align-items: center; gap: 3px;
    }
    .align-field-row label span { font-size: 10.5px; font-weight: 500; color: rgba(var(--avc-ink-rgb), 0.5); }
    .align-field-arrow {
      --mdc-icon-size: 13px; color: rgb(var(--avc-tool-rgb));
      flex-shrink: 0;
    }
    .align-field-row input[type="number"] {
      width: 84px; font: inherit; font-size: 12px; text-align: right;
      color: rgb(var(--avc-ink-rgb)); background: var(--avc-panel);
      border: 1px solid var(--avc-panel-line); border-radius: 8px; padding: 5px 7px;
    }
    .align-field-row input[disabled] { opacity: 0.4; }
    .align-field-row--opacity { flex-direction: column; align-items: stretch; gap: 2px; }
    .align-field-row--opacity input[type="range"] {
      width: 100%; accent-color: rgb(var(--avc-tool-rgb)); cursor: pointer;
    }
    .align-field-row--check label { flex: 1 1 auto; display: flex; align-items: center; gap: 6px; }
    .align-field-row--check input[type="checkbox"] { width: 15px; height: 15px; }
    @media (max-width: 700px) {
      .align-body { flex-direction: column-reverse; }
      .align-side-panel {
        flex: 0 0 auto; width: 100%; max-height: 32vh;
        flex-direction: row; flex-wrap: wrap; align-items: center;
      }
      .align-field-row { flex: 1 1 45%; }
    }
    /* == Align mode: home-frame degradation (docs/41 §4.8) =============== */
    .align-seat-layer--readonly { cursor: default; }
    .align-seat-layer--readonly .align-seat-img { cursor: default; }
    .align-readonly-note {
      position: absolute; left: 50%; bottom: 6%; transform: translateX(-50%);
      display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600;
      padding: 7px 12px; border-radius: 999px; white-space: nowrap;
      color: rgb(var(--avc-ink-rgb)); background: var(--avc-surface); box-shadow: var(--avc-elev-1);
    }
    /* == Align mode: Cancel confirmation (docs/41 §4.4, Esc/X row) ======== */
    .align-confirm-backdrop {
      position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
      background: rgba(var(--avc-shade-rgb), 0.55); z-index: 1;
    }
    .align-confirm-panel {
      width: min(320px, 86vw); padding: 18px; border-radius: 14px;
      background: var(--avc-surface); box-shadow: var(--avc-elev-1);
      color: rgb(var(--avc-ink-rgb));
    }
    .align-confirm-title { font-size: 14px; font-weight: 700; margin-bottom: 6px; }
    .align-confirm-body { font-size: 12.5px; color: rgba(var(--avc-ink-rgb), 0.7); margin-bottom: 14px; }
    .align-confirm-actions { display: flex; justify-content: flex-end; gap: 8px; }
    .align-confirm-keep, .align-confirm-discard {
      width: auto; height: 32px; padding: 0 12px; font-size: 12px; font-weight: 700;
    }
    .align-confirm-discard { background: rgba(var(--avc-err-rgb), 0.18); border-color: rgba(var(--avc-err-rgb), 0.5); }
  `;
}

const customCards =
  ((window as Window & { customCards?: Array<Record<string, unknown>> }).customCards ??= []);
if (!customCards.some((c) => c["type"] === CARD_NAME)) {
  customCards.push({
    type: CARD_NAME,
    name: "AnyVac Card",
    description: "Feature-rich card for Roborock vacuums — map, room selection, multi-vacuum tabs, global actions.",
    preview: false,
    documentationURL: "https://github.com/Michailjovic/anyvac-card",
  });
}
